+{
   locale_version => 0.88,
   entry => <<'ENTRY', # for DUCET v6.1.0
0149      ; [.1734.0020.0009.0149] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
