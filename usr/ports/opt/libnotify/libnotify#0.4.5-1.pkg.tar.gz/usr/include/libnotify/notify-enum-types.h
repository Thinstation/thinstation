


#ifndef _NOTIFY_ENUM_TYPES_H_
#define _NOTIFY_ENUM_TYPES_H_

#include <glib-object.h>

G_BEGIN_DECLS
/* enumerations from "notification.h" */
GType notify_urgency_get_type(void);
#define NOTIFY_TYPE_URGENCY (notify_urgency_get_type())
G_END_DECLS

#endif /* _NOTIFY_ENUM_TYPES_H_ */



