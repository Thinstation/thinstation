package App::TheYoke;
our $VERSION = 1.23;
# ABSTRACT: an ultra-simple, polite feed aggregrator designed for use on the UNIX command line.

1;
