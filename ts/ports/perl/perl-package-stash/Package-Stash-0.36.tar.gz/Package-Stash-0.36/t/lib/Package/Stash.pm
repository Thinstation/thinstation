$Package::Stash::IMPLEMENTATION = 'PP';
do 'lib/Package/Stash.pm';
1;
