package No::Middle;

sub foo {}

package No::Middle::Package::A;

sub foo {}


package No::Middle::Package::B;

sub foo {}

1;
