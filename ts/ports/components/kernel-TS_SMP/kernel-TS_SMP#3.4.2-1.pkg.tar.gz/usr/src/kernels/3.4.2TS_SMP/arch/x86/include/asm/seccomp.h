#ifdef CONFIG_X86_32
# include "seccomp_32.h"
#else
# include "seccomp_64.h"
#endif
