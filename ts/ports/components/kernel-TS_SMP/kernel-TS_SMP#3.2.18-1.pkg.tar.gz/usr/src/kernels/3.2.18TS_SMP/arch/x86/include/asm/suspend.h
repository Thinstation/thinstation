#ifdef CONFIG_X86_32
# include "suspend_32.h"
#else
# include "suspend_64.h"
#endif
