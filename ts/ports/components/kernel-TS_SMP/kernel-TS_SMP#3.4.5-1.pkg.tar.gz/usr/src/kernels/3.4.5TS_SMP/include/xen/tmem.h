#ifndef _XEN_TMEM_H
#define _XEN_TMEM_H

#include <linux/types.h>

/* defined in drivers/xen/tmem.c */
extern bool tmem_enabled;

#endif /* _XEN_TMEM_H */
