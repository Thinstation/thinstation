
/* Generated data (by glib-mkenums) */

#ifndef __UDISKS_ENUM_TYPES_H__
#define __UDISKS_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "udisksenums.h" */
GType udisks_error_get_type (void) G_GNUC_CONST;
#define UDISKS_TYPE_ERROR (udisks_error_get_type ())
GType udisks_partition_type_info_flags_get_type (void) G_GNUC_CONST;
#define UDISKS_TYPE_PARTITION_TYPE_INFO_FLAGS (udisks_partition_type_info_flags_get_type ())
G_END_DECLS

#endif /* __UDISKS_ENUM_TYPES_H__ */

/* Generated data ends here */

