#ifndef _LINUX_VFS_H
#define _LINUX_VFS_H

#include <linux/statfs.h>

#endif
