#ifndef _LINUX_CRC_T10DIF_H
#define _LINUX_CRC_T10DIF_H

#include <linux/types.h>

__u16 crc_t10dif(unsigned char const *, size_t);

#endif
