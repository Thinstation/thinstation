/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/* The MIT Kerberos header file krb5.h used to live here.

   As of the 1.5 release, we're installing multiple Kerberos headers,
   so they're all moving to a krb5/ subdirectory.  This file is
   present just to keep old software still compiling.  Please update
   your code to use the new path for the header.  */
#include <krb5/krb5.h>
