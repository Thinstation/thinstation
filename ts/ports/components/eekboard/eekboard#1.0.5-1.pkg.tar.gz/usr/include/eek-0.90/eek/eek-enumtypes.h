
/* Generated data (by glib-mkenums) */


#if !defined(__EEK_H_INSIDE__) && !defined(EEK_COMPILATION)
#error "Only <eek/eek.h> can be included directly."
#endif

#ifndef __EEK_ENUMTYPES_H__
#define __EEK_ENUMTYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "./eek-symbol.h" */
GType eek_symbol_category_get_type (void) G_GNUC_CONST;
#define EEK_TYPE_SYMBOL_CATEGORY (eek_symbol_category_get_type ())

/* enumerations from "./eek-types.h" */
GType eek_orientation_get_type (void) G_GNUC_CONST;
#define EEK_TYPE_ORIENTATION (eek_orientation_get_type ())
GType eek_modifier_behavior_get_type (void) G_GNUC_CONST;
#define EEK_TYPE_MODIFIER_BEHAVIOR (eek_modifier_behavior_get_type ())
GType eek_modifier_type_get_type (void) G_GNUC_CONST;
#define EEK_TYPE_MODIFIER_TYPE (eek_modifier_type_get_type ())
GType eek_gradient_type_get_type (void) G_GNUC_CONST;
#define EEK_TYPE_GRADIENT_TYPE (eek_gradient_type_get_type ())
G_END_DECLS

#endif /* __EEK_ENUMTYPES_H__ */

/* Generated data ends here */

