/*
 * Copyright 1994, Integrated Computer Solutions, Inc.
 *
 * All Rights Reserved.
 *
 * Author: Rick Umali
 *
 * fontsel.h
 *
 */
/**************************************************************
 *		DEFINES
 **************************************************************/
#define EXPLAIN_CURFONT 1
#define EXPLAIN_SHOWFONT 2
