


#ifndef SPICE_WIDGET_ENUMS_H
#define SPICE_WIDGET_ENUMS_H

G_BEGIN_DECLS

#define SPICE_TYPE_DISPLAY_KEY_EVENT spice_display_key_event_get_type()
GType spice_display_key_event_get_type (void);
G_END_DECLS

#endif /* SPICE_WIDGET_ENUMS_H */



