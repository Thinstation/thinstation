
/* Generated data (by glib-mkenums) */

#ifndef __POLKIT_AGENT_ENUM_TYPES_H__
#define __POLKIT_AGENT_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "polkitagentlistener.h" */
GType polkit_agent_register_flags_get_type (void) G_GNUC_CONST;
#define POLKIT_TYPE_AGENT_REGISTER_FLAGS (polkit_agent_register_flags_get_type ())
G_END_DECLS

#endif /* __POLKIT_AGENT_ENUM_TYPES_H__ */

/* Generated data ends here */

