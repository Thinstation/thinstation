
/* Generated data (by glib-mkenums) */

#ifndef __POLKIT_ENUM_TYPES_H__
#define __POLKIT_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "polkitcheckauthorizationflags.h" */
GType polkit_check_authorization_flags_get_type (void) G_GNUC_CONST;
#define POLKIT_TYPE_CHECK_AUTHORIZATION_FLAGS (polkit_check_authorization_flags_get_type ())

/* enumerations from "polkiterror.h" */
GType polkit_error_get_type (void) G_GNUC_CONST;
#define POLKIT_TYPE_ERROR (polkit_error_get_type ())

/* enumerations from "polkitimplicitauthorization.h" */
GType polkit_implicit_authorization_get_type (void) G_GNUC_CONST;
#define POLKIT_TYPE_IMPLICIT_AUTHORIZATION (polkit_implicit_authorization_get_type ())

/* enumerations from "polkitauthorityfeatures.h" */
GType polkit_authority_features_get_type (void) G_GNUC_CONST;
#define POLKIT_TYPE_AUTHORITY_FEATURES (polkit_authority_features_get_type ())
G_END_DECLS

#endif /* __POLKIT_ENUM_TYPES_H__ */

/* Generated data ends here */

