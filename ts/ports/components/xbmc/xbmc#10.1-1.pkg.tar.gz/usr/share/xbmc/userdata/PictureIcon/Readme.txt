xbmc tuxbox client

pictureIcon

you can define your own picture icon for the channel
1. open and edit the picon.xml file
   name: is the channel name
   png: is the filename for the channel (defaul picon size: 128x128 pixel)
   <service name="das erste" png="ard.png" />
2. put the png file into the folder: \Picon\*.*


that's all! after connecting to your tuxbox device and listing the channels, 
the defined picon in picon.xml will be used.

you can also use the enigma "Picon plugin" (picon.xml and the icons!)
which can be download from several places. just unpack it and
copy the picon.xml and picon to this folder! 


15.01.2005
GeminiServer


