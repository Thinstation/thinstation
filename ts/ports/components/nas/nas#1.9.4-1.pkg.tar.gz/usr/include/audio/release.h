static const char *release = "Network Audio System Release 1.9.4";
