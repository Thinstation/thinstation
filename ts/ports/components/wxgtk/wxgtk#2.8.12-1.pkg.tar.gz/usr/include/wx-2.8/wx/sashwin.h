/////////////////////////////////////////////////////////////////////////////
// Name:        wx/sashwin.h
// Purpose:     Base header for wxSashWindow
// Author:      Julian Smart
// Modified by:
// Created:
// RCS-ID:      $Id: sashwin.h 33948 2005-05-04 18:57:50Z JS $
// Copyright:   (c) Julian Smart
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_SASHWIN_H_BASE_
#define _WX_SASHWIN_H_BASE_

#include "wx/generic/sashwin.h"

#endif
    // _WX_SASHWIN_H_BASE_
