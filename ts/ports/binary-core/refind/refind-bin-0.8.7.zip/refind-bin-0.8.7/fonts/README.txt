This directory contains PNGs built from a couple of open source fonts: the
sans serif Liberation Mono Regular and the serif Luxi Mono Regular, in 12-,
14, and 24-point versions. All of these font files have anti-aliasing (aka
font smoothing) applied. The directory also includes the original rEFInd
font, which is a 12-point un-smoothed Times-like font.



