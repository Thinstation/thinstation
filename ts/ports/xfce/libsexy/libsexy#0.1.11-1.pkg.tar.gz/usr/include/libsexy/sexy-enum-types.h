


#ifndef _SEXY_ENUM_TYPES_H_
#define _SEXY_ENUM_TYPES_H_

#include <glib-object.h>

G_BEGIN_DECLS
/* enumerations from "sexy-icon-entry.h" */
GType sexy_icon_entry_position_get_type(void);
#define SEXY_TYPE_ICON_ENTRY_POSITION (sexy_icon_entry_position_get_type())
/* enumerations from "sexy-spell-entry.h" */
GType sexy_spell_error_get_type(void);
#define SEXY_TYPE_SPELL_ERROR (sexy_spell_error_get_type())
G_END_DECLS

#endif /* _SEXY_ENUM_TYPES_H_ */



