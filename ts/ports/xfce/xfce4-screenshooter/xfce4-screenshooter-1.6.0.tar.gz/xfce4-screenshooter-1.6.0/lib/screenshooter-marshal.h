
#ifndef ___screenshooter_marshal_MARSHAL_H__
#define ___screenshooter_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:STRING (screenshooter-marshal.list:1) */
#define _screenshooter_marshal_VOID__STRING	g_cclosure_marshal_VOID__STRING

/* VOID:POINTER,STRING (screenshooter-marshal.list:2) */
extern void _screenshooter_marshal_VOID__POINTER_STRING (GClosure     *closure,
                                                         GValue       *return_value,
                                                         guint         n_param_values,
                                                         const GValue *param_values,
                                                         gpointer      invocation_hint,
                                                         gpointer      marshal_data);

G_END_DECLS

#endif /* ___screenshooter_marshal_MARSHAL_H__ */

