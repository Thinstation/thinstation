#ifndef __GARCON_MARSHAL_H__
#define __GARCON_MARSHAL_H__

#ifndef __garcon_marshal_MARSHAL_H__
#define __garcon_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:OBJECT,OBJECT (./garcon-marshal.list:1) */
extern void garcon_marshal_VOID__OBJECT_OBJECT (GClosure     *closure,
                                                GValue       *return_value,
                                                guint         n_param_values,
                                                const GValue *param_values,
                                                gpointer      invocation_hint,
                                                gpointer      marshal_data);

G_END_DECLS

#endif /* __garcon_marshal_MARSHAL_H__ */

#endif /* !__GARCON_MARSHAL_H__ */
