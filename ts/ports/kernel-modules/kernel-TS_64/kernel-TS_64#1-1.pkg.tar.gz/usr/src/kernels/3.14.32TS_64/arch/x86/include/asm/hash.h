#ifndef _ASM_X86_HASH_H
#define _ASM_X86_HASH_H

struct fast_hash_ops;
extern void setup_arch_fast_hash(struct fast_hash_ops *ops);

#endif /* _ASM_X86_HASH_H */
