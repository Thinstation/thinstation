#ifndef _ASM_X86_REBOOT_FIXUPS_H
#define _ASM_X86_REBOOT_FIXUPS_H

extern void mach_reboot_fixups(void);

#endif /* _ASM_X86_REBOOT_FIXUPS_H */
