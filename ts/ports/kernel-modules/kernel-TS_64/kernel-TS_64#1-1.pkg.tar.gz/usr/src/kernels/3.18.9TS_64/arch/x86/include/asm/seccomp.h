#ifdef CONFIG_X86_32
# include <asm/seccomp_32.h>
#else
# include <asm/seccomp_64.h>
#endif
