#ifndef __ASM_GENERIC_HASH_H
#define __ASM_GENERIC_HASH_H

struct fast_hash_ops;
static inline void setup_arch_fast_hash(struct fast_hash_ops *ops)
{
}

#endif /* __ASM_GENERIC_HASH_H */
