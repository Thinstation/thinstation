#ifndef __remmina_marshal_MARSHAL_H__
#define __remmina_marshal_MARSHAL_H__

#include        <glib-object.h>

G_BEGIN_DECLS

/* BOOLEAN:INT (remminamarshals.list:4) */
extern void remmina_marshal_BOOLEAN__INT(GClosure *closure, GValue *return_value, guint n_param_values,
					 const GValue *param_values, gpointer invocation_hint, gpointer marshal_data);

/* BOOLEAN:INT,STRING (remminamarshals.list:5) */
extern void remmina_marshal_BOOLEAN__INT_STRING(GClosure *closure, GValue *return_value, guint n_param_values,
						const GValue *param_values, gpointer invocation_hint, gpointer marshal_data);

G_END_DECLS

#endif /* __remmina_marshal_MARSHAL_H__ */

