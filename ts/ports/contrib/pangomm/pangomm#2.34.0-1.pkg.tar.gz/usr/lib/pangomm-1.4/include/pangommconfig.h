/* pango/pangommconfig.h.  Generated from pangommconfig.h.in by configure.  */
/* This file is part of pangomm. */
#ifndef PANGOMM_PANGOMMCONFIG_H_INCLUDED
#define PANGOMM_PANGOMMCONFIG_H_INCLUDED

#include <glibmmconfig.h>

/* Define to omit deprecated API from the library. */
/* #undef PANGOMM_DISABLE_DEPRECATED */

/* Major version number of pangomm. */
#define PANGOMM_MAJOR_VERSION 2

/* Micro version number of pangomm. */
#define PANGOMM_MICRO_VERSION 0

/* Minor version number of pangomm. */
#define PANGOMM_MINOR_VERSION 34

#endif /* !PANGOMM_PANGOMMCONFIG_H_INCLUDED */
