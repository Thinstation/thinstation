class Mustache
  Version = VERSION = '0.99.5'
end
