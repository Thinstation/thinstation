// These data types may be already defined if building on Windows (using MinGW)
#ifndef DWORD
  #define DWORD unsigned long
#endif
#ifndef WORD
  #define WORD unsigned int
#endif
#ifndef BYTE
  #define BYTE unsigned char
#endif
