#ifndef GNOME_H
#define GNOME_H

#include <gtk/gtk.h>
#include <libgnome/libgnome.h>
#include <libgnomecanvas/libgnomecanvas.h>
#include <libgnomeui/libgnomeui.h>

#endif
