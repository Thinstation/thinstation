


#ifndef __LIBGNOMETYPEBUILTINS_H__
#define __LIBGNOMETYPEBUILTINS_H__ 1

#include <libgnome/libgnome.h>

G_BEGIN_DECLS


/* --- gnome-triggers.h --- */
#define GNOME_TYPE_TRIGGER_TYPE gnome_trigger_type_get_type()
GType gnome_trigger_type_get_type (void);

/* --- gnome-program.h --- */
#define GNOME_TYPE_FILE_DOMAIN gnome_file_domain_get_type()
GType gnome_file_domain_get_type (void);

/* --- gnome-help.h --- */
#define GNOME_TYPE_HELP_ERROR gnome_help_error_get_type()
GType gnome_help_error_get_type (void);

/* --- gnome-url.h --- */
#define GNOME_TYPE_URL_ERROR gnome_url_error_get_type()
GType gnome_url_error_get_type (void);
G_END_DECLS

#endif /* __LIBGNOMETYPEBUILTINS_H__ */



