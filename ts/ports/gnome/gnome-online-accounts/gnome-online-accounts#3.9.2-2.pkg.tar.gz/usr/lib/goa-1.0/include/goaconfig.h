/* goaconfig.h
 *
 * This is a generated file.  Please modify 'configure.ac'
 */

#ifndef __GOA_CONFIG_H__
#define __GOA_CONFIG_H__

G_BEGIN_DECLS

#define GOA_MAJOR_VERSION 3
#define GOA_MINOR_VERSION 9
#define GOA_MICRO_VERSION 2

G_END_DECLS

#endif /* __GOA_CONFIG_H__ */
