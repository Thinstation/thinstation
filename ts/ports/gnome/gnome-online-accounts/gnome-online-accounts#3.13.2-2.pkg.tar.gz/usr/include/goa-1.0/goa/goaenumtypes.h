
/* Generated data (by glib-mkenums) */

#ifndef __GOA_ENUM_TYPES_H__
#define __GOA_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "goaenums.h" */
GType goa_error_get_type (void) G_GNUC_CONST;
#define GOA_TYPE_ERROR (goa_error_get_type ())
G_END_DECLS

#endif /* __GOA_ENUM_TYPES_H__ */

/* Generated data ends here */

