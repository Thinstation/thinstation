
/* Generated data (by glib-mkenums) */

#ifndef __GOA_BACKEND_ENUM_TYPES_H__
#define __GOA_BACKEND_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "goabackendenums.h" */
GType goa_provider_group_get_type (void) G_GNUC_CONST;
#define GOA_TYPE_PROVIDER_GROUP (goa_provider_group_get_type ())
GType goa_provider_features_get_type (void) G_GNUC_CONST;
#define GOA_TYPE_PROVIDER_FEATURES (goa_provider_features_get_type ())
G_END_DECLS

#endif /* __GOA_BACKEND_ENUM_TYPES_H__ */

/* Generated data ends here */

