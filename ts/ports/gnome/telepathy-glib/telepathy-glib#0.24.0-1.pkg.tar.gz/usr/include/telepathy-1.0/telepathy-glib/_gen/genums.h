
/* Generated data (by glib-mkenums) */


#ifndef __TP_GENUMS_H__
#define __TP_GENUMS_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "base-room-config.h" */
GType tp_base_room_config_property_get_type (void) G_GNUC_CONST;
#define TP_TYPE_BASE_ROOM_CONFIG_PROPERTY (tp_base_room_config_property_get_type ())

/* enumerations from "connection-manager.h" */
GType tp_cm_info_source_get_type (void) G_GNUC_CONST;
#define TP_TYPE_CM_INFO_SOURCE (tp_cm_info_source_get_type ())

/* enumerations from "contact.h" */
GType tp_contact_feature_get_type (void) G_GNUC_CONST;
#define TP_TYPE_CONTACT_FEATURE (tp_contact_feature_get_type ())

/* enumerations from "dbus.h" */
GType tp_dbus_name_type_get_type (void) G_GNUC_CONST;
#define TP_TYPE_DBUS_NAME_TYPE (tp_dbus_name_type_get_type ())

/* enumerations from "dbus-properties-mixin.h" */
GType tp_dbus_properties_mixin_flags_get_type (void) G_GNUC_CONST;
#define TP_TYPE_DBUS_PROPERTIES_MIXIN_FLAGS (tp_dbus_properties_mixin_flags_get_type ())

/* enumerations from "errors.h" */
GType tp_error_get_type (void) G_GNUC_CONST;
#define TP_TYPE_ERROR (tp_error_get_type ())

/* enumerations from "proxy.h" */
GType tp_dbus_error_get_type (void) G_GNUC_CONST;
#define TP_TYPE_DBUS_ERROR (tp_dbus_error_get_type ())
G_END_DECLS

#endif /* __TP_GENUMS_H__ */

/* Generated data ends here */

