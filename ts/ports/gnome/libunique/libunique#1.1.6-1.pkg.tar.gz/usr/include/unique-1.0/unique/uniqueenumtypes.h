
/* Generated data (by glib-mkenums) */

#ifndef __UNIQUE_ENUM_TYPES_H__
#define __UNIQUE_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "../unique/uniqueapp.h" */
GType unique_command_get_type (void) G_GNUC_CONST;
#define UNIQUE_TYPE_COMMAND (unique_command_get_type())

GType unique_response_get_type (void) G_GNUC_CONST;
#define UNIQUE_TYPE_RESPONSE (unique_response_get_type())

G_END_DECLS

#endif /* !__UNIQUE_ENUM_TYPES_H__ */

/* Generated data ends here */

