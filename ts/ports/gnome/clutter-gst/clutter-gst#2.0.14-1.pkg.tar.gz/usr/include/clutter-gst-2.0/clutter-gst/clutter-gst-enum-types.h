
/* Generated data (by glib-mkenums) */

#ifndef __CLUTTER_GST_ENUM_TYPES_H__
#define __CLUTTER_GST_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "./clutter-gst-types.h" */
GType clutter_gst_seek_flags_get_type (void) G_GNUC_CONST;
#define CLUTTER_GST_TYPE_SEEK_FLAGS (clutter_gst_seek_flags_get_type())

GType clutter_gst_buffering_mode_get_type (void) G_GNUC_CONST;
#define CLUTTER_GST_TYPE_BUFFERING_MODE (clutter_gst_buffering_mode_get_type())

G_END_DECLS

#endif /* !__CLUTTER_GST_ENUM_TYPES_H__ */

/* Generated data ends here */

