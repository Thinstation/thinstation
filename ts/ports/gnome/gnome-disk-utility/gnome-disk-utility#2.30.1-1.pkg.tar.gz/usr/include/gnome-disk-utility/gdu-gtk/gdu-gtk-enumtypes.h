
/* Generated data (by glib-mkenums) */

#ifndef __GDU_GTK_ENUM_TYPES_H__
#define __GDU_GTK_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "gdu-gtk-enums.h" */
GType gdu_pool_tree_model_column_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_POOL_TREE_MODEL_COLUMN (gdu_pool_tree_model_column_get_type ())
GType gdu_pool_tree_view_flags_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_POOL_TREE_VIEW_FLAGS (gdu_pool_tree_view_flags_get_type ())
GType gdu_pool_tree_model_flags_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_POOL_TREE_MODEL_FLAGS (gdu_pool_tree_model_flags_get_type ())
GType gdu_format_dialog_flags_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_FORMAT_DIALOG_FLAGS (gdu_format_dialog_flags_get_type ())
GType gdu_disk_selection_widget_flags_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_DISK_SELECTION_WIDGET_FLAGS (gdu_disk_selection_widget_flags_get_type ())
GType gdu_add_component_linux_md_flags_get_type (void) G_GNUC_CONST;
#define GDU_TYPE_ADD_COMPONENT_LINUX_MD_FLAGS (gdu_add_component_linux_md_flags_get_type ())
G_END_DECLS

#endif /* __GDU_GTK_ENUM_TYPES_H__ */

/* Generated data ends here */

