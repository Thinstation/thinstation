/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/**
 * Compatibility include file for Bonobo 1.0 compatibility
 *
 * Author:
 *     Michael Meeks <michael@ximian.com>
 *
 * Copyright 2001 Ximian, Inc.
 */

#ifndef _BONOBO_H_
#define _BONOBO_H_

#include <libbonoboui.h>

#endif /* _BONOBO_H_ */
