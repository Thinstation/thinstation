
/* Generated data (by glib-mkenums) */


#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "../gck/gck.h" */
#ifndef GCK_TYPE_ERROR
GType gck_error_get_type (void) G_GNUC_CONST;
#define GCK_TYPE_ERROR (gck_error_get_type ())
#endif

#ifndef GCK_TYPE_SESSION_OPTIONS
GType gck_session_options_get_type (void) G_GNUC_CONST;
#define GCK_TYPE_SESSION_OPTIONS (gck_session_options_get_type ())
#endif

#ifndef GCK_TYPE_BUILDER_FLAGS
GType gck_builder_flags_get_type (void) G_GNUC_CONST;
#define GCK_TYPE_BUILDER_FLAGS (gck_builder_flags_get_type ())
#endif

#ifndef GCK_TYPE_URI_ERROR
GType gck_uri_error_get_type (void) G_GNUC_CONST;
#define GCK_TYPE_URI_ERROR (gck_uri_error_get_type ())
#endif

#ifndef GCK_TYPE_URI_FLAGS
GType gck_uri_flags_get_type (void) G_GNUC_CONST;
#define GCK_TYPE_URI_FLAGS (gck_uri_flags_get_type ())
#endif

G_END_DECLS


/* Generated data ends here */

