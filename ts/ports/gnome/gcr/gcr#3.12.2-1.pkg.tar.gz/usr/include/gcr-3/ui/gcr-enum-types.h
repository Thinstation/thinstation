
/* Generated data (by glib-mkenums) */


#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "../ui/gcr-collection-model.h" */
#ifndef GCR_TYPE_COLLECTION_MODEL_MODE
GType gcr_collection_model_mode_get_type (void) G_GNUC_CONST;
#define GCR_TYPE_COLLECTION_MODEL_MODE (gcr_collection_model_mode_get_type ())
#endif

G_END_DECLS


/* Generated data ends here */

