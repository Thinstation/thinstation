
/* Generated data (by glib-mkenums) */

#ifndef __COGL_PATH_ENUM_TYPES_H__
#define __COGL_PATH_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "./cogl-path-types.h" */
GType cogl_path_fill_rule_get_type (void) G_GNUC_CONST;
#define COGL_TYPE_PATH_FILL_RULE (cogl_path_fill_rule_get_type())

G_END_DECLS

#endif /* __COGL_PATH_ENUM_TYPES_H__ */

/* Generated data ends here */

