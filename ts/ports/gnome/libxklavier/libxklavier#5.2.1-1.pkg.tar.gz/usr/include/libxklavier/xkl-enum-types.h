


#ifndef __XKL_ENUM_TYPES_H__
#define __XKL_ENUM_TYPES_H__
/* enumerations from "xkl_engine.h" */
GType xkl_engine_state_change_get_type (void);
#define XKL_TYPE_ENGINE_STATE_CHANGE (xkl_engine_state_change_get_type())
GType xkl_engine_features_get_type (void);
#define XKL_TYPE_ENGINE_FEATURES (xkl_engine_features_get_type())
GType xkl_engine_listen_modes_get_type (void);
#define XKL_TYPE_ENGINE_LISTEN_MODES (xkl_engine_listen_modes_get_type())
#endif /* __XKL_ENUM_TYPES_H__ */



