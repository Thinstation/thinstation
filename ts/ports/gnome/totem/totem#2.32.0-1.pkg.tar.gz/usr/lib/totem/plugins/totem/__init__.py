import gettext
gettext.textdomain("totem")

D_ = gettext.dgettext
_ = gettext.gettext

