#ifndef ORBIT_TYPES_H
#define ORBIT_TYPES_H 1

#include <orbit/util/orbit-util.h>
#ifdef ORBIT2_INTERNAL_API
#  include <orbit/GIOP/giop-basics.h>
#endif
#include <orbit/orb-core/orb-core-types.h>
#include <orbit/poa/poa-basics.h>

#endif
