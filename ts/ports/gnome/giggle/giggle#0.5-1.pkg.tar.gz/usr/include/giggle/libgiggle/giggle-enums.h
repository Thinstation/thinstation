
/* Generated data (by glib-mkenums) */

#ifndef GIGGLE_ENUMERATIONS_H
#define GIGGLE_ENUMERATIONS_H

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "giggle-error.h" */
GType giggle_error_get_type (void);
#define GIGGLE_TYPE_ERROR (giggle_error_get_type())
/* enumerations from "giggle-plugin.h" */
GType giggle_plugin_error_get_type (void);
#define GIGGLE_TYPE_PLUGIN_ERROR (giggle_plugin_error_get_type())
/* enumerations from "giggle-remote-branch.h" */
GType giggle_remote_direction_get_type (void);
#define GIGGLE_TYPE_REMOTE_DIRECTION (giggle_remote_direction_get_type())
/* enumerations from "giggle-remote.h" */
GType giggle_remote_mechanism_get_type (void);
#define GIGGLE_TYPE_REMOTE_MECHANISM (giggle_remote_mechanism_get_type())
/* enumerations from "giggle-searchable.h" */
GType giggle_search_direction_get_type (void);
#define GIGGLE_TYPE_SEARCH_DIRECTION (giggle_search_direction_get_type())
G_END_DECLS

#endif /* !GIGGLE_ENUMERATIONS_H */

/* Generated data ends here */

