
/* Generated data (by glib-mkenums) */

#ifndef GIGGLE_GIT_ENUMERATIONS_H
#define GIGGLE_GIT_ENUMERATIONS_H

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "giggle-git-config.h" */
GType giggle_git_config_field_get_type (void);
#define GIGGLE_TYPE_GIT_CONFIG_FIELD (giggle_git_config_field_get_type())
/* enumerations from "giggle-git-list-files.h" */
GType giggle_git_list_files_status_get_type (void);
#define GIGGLE_TYPE_GIT_LIST_FILES_STATUS (giggle_git_list_files_status_get_type())
G_END_DECLS

#endif /* !GIGGLE_GIT_ENUMERATIONS_H */

/* Generated data ends here */

