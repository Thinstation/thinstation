#ifndef __dconf_readtype_h__
#define __dconf_readtype_h__

typedef enum
{
  DCONF_READ_NORMAL,
  DCONF_READ_SET,
  DCONF_READ_RESET
} DConfReadType;

#endif /* __dconf_readtype_h__ */
