#define X264_BIT_DEPTH  8
#define X264_GPL        1
#define X264_INTERLACED 1
