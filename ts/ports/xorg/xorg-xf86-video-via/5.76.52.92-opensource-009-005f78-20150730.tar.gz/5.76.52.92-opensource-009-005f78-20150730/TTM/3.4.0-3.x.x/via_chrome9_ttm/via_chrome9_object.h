/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_OBJECT_H_
#define _VIA_CHROME9_OBJECT_H_

#include "ttm/ttm_bo_api.h"
extern int via_chrome9_allocate_basic_bo(struct drm_device *dev);

extern void via_ttm_placement_from_domain(struct via_chrome9_object *vbo,
		u32 domain);

extern int via_chrome9_buffer_object_create(struct ttm_bo_device *bdev,
		unsigned long size,
		enum ttm_bo_type type,
		uint32_t flags,
		uint32_t page_alignment,
		unsigned long buffer_start,
		bool interruptible,
		struct file *persistant_swap_storage,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,18,0)
        struct reservation_object *resv,
#endif
		struct via_chrome9_object **p_bo);
extern int via_chrome9_buffer_object_create2(unsigned long size,
		enum ttm_bo_type type,
		uint32_t flags,
		uint32_t page_alignment,
		unsigned long buffer_start,
		bool interruptible,
		struct file *persistant_swap_storage,
		struct via_chrome9_object **p_bo);
extern int via_chrome9_object_wait(struct via_chrome9_object *vobj,
		bool no_wait);
extern int via_chrome9_buffer_object_kmap(struct via_chrome9_object *vobj,
		void **ptr);
extern int via_chrome9_gem_object_init(struct drm_gem_object *obj);
extern void via_chrome9_gem_object_free(struct drm_gem_object *gobj);
extern void via_chrome9_buffer_object_unref(struct via_chrome9_object **vobj);

extern void via_chrome9_buffer_object_kunmap(struct via_chrome9_object *vobj);

extern void via_chrome9_buffer_object_ref(struct ttm_buffer_object *bo);

extern int via_chrome9_object_mmap(struct drm_file *file_priv,
		struct via_chrome9_object *vobj,
		uint64_t size, uint64_t *offset, void **virtual);
extern int via_chrome9_mmap(struct file *filp, struct vm_area_struct *vma);
int via_chrome9_evict_vram(struct drm_device *dev);
int via_chrome9_bo_pin(struct via_chrome9_object *bo,
		u32 domain, u64 *gpu_addr);
int via_chrome9_bo_unpin(struct via_chrome9_object *bo);
int via_chrome9_object_set_domain(struct via_chrome9_object *bo,
		u32 domain);
int via_chrome9_object_wait_cpu_access(
	struct via_chrome9_object *bo, struct drm_file *file_priv);
#endif
