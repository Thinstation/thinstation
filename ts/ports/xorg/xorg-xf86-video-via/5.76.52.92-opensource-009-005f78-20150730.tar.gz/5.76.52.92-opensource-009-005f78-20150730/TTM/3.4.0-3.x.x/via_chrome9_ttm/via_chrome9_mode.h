/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef VIA_CHROME9_MODE_H
#define VIA_CHROME9_MODE_H

#include "drmP.h"
#include <drm/drm_mode.h>
#include "drm_crtc.h"
#include "drm_crtc_helper.h"
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,19,0)
#include "drm_plane_helper.h"
#endif
#include "via_chrome9_fb.h"
#include "via_chrome9_display_common.h"

/* encoder type index */
#define VIA_CHROME9_ENCODER_DAC_INDEX        0x00000001
#define VIA_CHROME9_ENCODER_LVDS_INDEX        0x00000002
#define VIA_CHROME9_ENCODER_TMDS_INDEX        0x00000003
#define VIA_CHROME9_ENCODER_DP_1_INDEX        0x00000004
#define VIA_CHROME9_ENCODER_DP_2_INDEX        0x00000005
#define VIA_CHROME9_ENCODER_TV_INDEX        0x00000006
#define VIA_CHROME9_ENCODER_HDMI_INDEX        0x00000007
#define VIA_CHROME9_ENCODER_LVDS_2_INDEX    0x00000008
#define VIA_CHROME9_ENCODER_TMDS_2_INDEX    0x00000009
#define VIA_CHROME9_ENCODER_DAC_2_INDEX    0x0000000a
#define VIA_CHROME9_ENCODER_HDMI_2_INDEX    0x0000000b

/* connector type index*/
#define VIA_CHROME9_CONNECTOR_CRT_INDEX        0x00000001
#define VIA_CHROME9_CONNECTOR_LCD_INDEX        0x00000002
#define VIA_CHROME9_CONNECTOR_DVI_D_INDEX    0x00000003
#define VIA_CHROME9_CONNECTOR_DP_1_INDEX    0x00000004
#define VIA_CHROME9_CONNECTOR_DP_2_INDEX    0x00000005
#define VIA_CHROME9_CONNECTOR_TV_INDEX        0x00000006
#define VIA_CHROME9_CONNECTOR_HDMI_INDEX        0x00000007
#define VIA_CHROME9_CONNECTOR_LCD_2_INDEX    0x00000008
#define VIA_CHROME9_CONNECTOR_DVI_D_2_INDEX    0x00000009
#define VIA_CHROME9_CONNECTOR_CRT_2_INDEX        0x0000000a
#define VIA_CHROME9_CONNECTOR_HDMI_2_INDEX    0x0000000b

/* encoder type */
#define VIA_CHROME9_DEVICE_ENCODER_DAC   \
	(0x1L << VIA_CHROME9_ENCODER_DAC_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_LVDS   \
	(0x1L << VIA_CHROME9_ENCODER_LVDS_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_TMDS   \
	(0x1L << VIA_CHROME9_ENCODER_TMDS_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_DP_1   \
	(0x1L << VIA_CHROME9_ENCODER_DP_1_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_DP_2   \
	(0x1L << VIA_CHROME9_ENCODER_DP_2_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_TV   \
	(0x1L << VIA_CHROME9_ENCODER_TV_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_HDMI   \
	(0x1L << VIA_CHROME9_ENCODER_HDMI_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_LVDS_2   \
	(0x1L << VIA_CHROME9_ENCODER_LVDS_2_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_TMDS_2   \
	(0x1L << VIA_CHROME9_ENCODER_TMDS_2_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_DAC_2   \
	(0x1L << VIA_CHROME9_ENCODER_DAC_2_INDEX)
#define VIA_CHROME9_DEVICE_ENCODER_HDMI_2   \
	(0x1L << VIA_CHROME9_ENCODER_HDMI_2_INDEX)

/* connector type */
#define VIA_CHROME9_DEVICE_CONNECTOR_CRT    \
    (0x1L << VIA_CHROME9_CONNECTOR_CRT_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_LCD    \
	(0x1L << VIA_CHROME9_CONNECTOR_LCD_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_DVI_D	\
	(0x1L << VIA_CHROME9_CONNECTOR_DVI_D_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_DP_1	\
	(0x1L << VIA_CHROME9_CONNECTOR_DP_1_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_DP_2	\
	(0x1L << VIA_CHROME9_CONNECTOR_DP_2_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_TV	\
	(0x1L << VIA_CHROME9_CONNECTOR_TV_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_HDMI	\
	(0x1L << VIA_CHROME9_CONNECTOR_HDMI_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_LCD_2	\
	(0x1L << VIA_CHROME9_CONNECTOR_LCD_2_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_DVI_D_2	\
        (0x1L << VIA_CHROME9_CONNECTOR_DVI_D_2_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_CRT_2	\
        (0x1L << VIA_CHROME9_CONNECTOR_CRT_2_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2	\
        (0x1L << VIA_CHROME9_CONNECTOR_HDMI_2_INDEX)
#define VIA_CHROME9_DEVICE_CONNECTOR_UNKNOW 0xFFFFFFFF

#define VIA_CHROME9_CONNECTOR_LIMIT 4

#define IGA1	0
#define IGA2	1

/* Define VIA Graphic Chip IGA Scaling support caps */
/* Support IGA1 DownScaling */
#define     CAPS_IGA1_DOWNSCALING  BIT0
/* Support IGA1 UpScaling */
#define     CAPS_IGA1_EXPAND             BIT1
/* Support IGA2 DownScaling */
#define     CAPS_IGA2_DOWNSCALING  BIT2

/* Bits per pixel */
#define BPP8		8
#define BPP16	16
#define BPP32	32

/* location: {REG_CR13,0,7},{REG_CR35,5,7}*/
#define VIA_IGA1_OFFSET_REG_NUM				2
/*location: {REG_CR66,0,7},{REG_CR67,0,1}*/
#define VIA_IGA2_OFFSET_REG_NUM				2
/*location: {REG_CR66,0,7},{REG_CR67,0,1},{REG_CR71,7}*/
#define VIA_IGA2_OFFSET_13BIT_REG_NUM		3

/* IGA Offset Register */
struct via_iga1_offset_regs {
	u8	reg_num;
	struct via_chrome9_io_bit reg[VIA_IGA1_OFFSET_REG_NUM];
};

/* IGA2 Offset Register */
struct via_iga2_offset_regs {
	u8	reg_num;
	struct via_chrome9_io_bit reg[VIA_IGA2_OFFSET_REG_NUM];
};

/* IGA2 13-bit Offset register */
struct via_iga2_offset_13bit_regs {
	u8	reg_num;
	struct via_chrome9_io_bit reg[VIA_IGA2_OFFSET_13BIT_REG_NUM];
};

/* IGA Offset Register */
struct via_offset_regs {
	struct via_iga1_offset_regs iga1;
	struct via_iga2_offset_regs iga2;
};

/*location: {REG_SR1C,0,7},{REG_SR1D,0,1}*/
#define VIA_IGA1_FETCH_COUNT_REG_NUM                2
/*location: {REG_CR65,0,7},{REG_CR67,2,3}*/
#define VIA_IGA2_FETCH_COUNT_REG_NUM                2

/* IGA1 Fetch Count Register */
struct via_iga1_fetch_count_regs {
	u8    reg_num;
	struct via_chrome9_io_bit reg[VIA_IGA1_FETCH_COUNT_REG_NUM];
};

/* IGA2 Fetch Count Register */
struct via_iga2_fetch_count_regs {
	u8 reg_num;
	struct via_chrome9_io_bit reg[VIA_IGA2_FETCH_COUNT_REG_NUM];
};

/* IGA Fetch Count Register */
struct via_iga_fetch_count_regs {
	struct via_iga1_fetch_count_regs iga1;
	struct via_iga2_fetch_count_regs iga2;
};

struct via_chrome9_crtc;
struct via_chrome9_encoder;
struct via_chrome9_connector;
struct via_chrome9_framebuffer;

#define to_via_chrome9_connector(x) \
		container_of(x, struct via_chrome9_connector, base)
#define to_via_chrome9_encoder(x) \
		container_of(x, struct via_chrome9_encoder, base)
#define to_via_chrome9_crtc(x) \
		container_of(x, struct via_chrome9_crtc, base)
#define to_via_chrome9_framebuffer(x) \
	container_of(x, struct via_chrome9_framebuffer, base)

struct via_chrome9_mode_info {
	struct via_chrome9_crtc *crtcs[2];
	struct via_chrome9_fbdev *vfbdev;
	int chip_index;

	/* HDMI borders properties */
	struct drm_property *left_border_property;
	struct drm_property *right_border_property;
	struct drm_property *top_border_property;
	struct drm_property *bottom_border_property;
	/* TV properties */
	struct drm_property *tv_scan_property;
	struct drm_property *tv_signal_property;	
	struct drm_property *tv_standard_property;
	struct drm_property *tv_dotcrawl_property;
	struct drm_property *tv_brightness_property;
	struct drm_property *tv_contrast_property;
	struct drm_property *tv_saturation_property;
	struct drm_property *tv_hue_property;
	struct drm_property *tv_adaptive_deflicker_property;
	struct drm_property *tv_deflicker_filter_property;
	struct drm_property *tv_deflicker_filter_val_property;
	struct drm_property *tv_pos_h_property;	
	struct drm_property *tv_pos_v_property;
	struct drm_property *signal_format;
	struct drm_property *connector_type;
};

struct via_chrome9_crtc {
	struct drm_crtc base;
	/* identify the crtc  0=>crtc1  1=>crtc2 */
	int crtc_id;
	int crtc_scale_status;
	/* identify this crtc enabled or not */
	bool enabled;
        struct drm_connector  *currentActiveConnector;
	u16 lut_r[256], lut_g[256], lut_b[256];
	struct drm_gem_object *cursor_bo;
};

enum via_chrome9_encoder_type {
	VIA_CHROME9_ENCODER_UNKNOWN = 0,
	VIA_CHROME9_INTERNAL_ENCODER,
	VIA_CHROME9_EXTERNAL_ENCODER
};

enum via_chrome9_connector_type {
	VIA_CHROME9_CONNECTOR_UNKNOWN = 0,
	VIA_CHROME9_INTERNAL_CONNECTOR,
	VIA_CHROME9_EXTERNAL_CONNECTOR
};

struct via_chrome9_encoder {
	/* encoder base */
	struct drm_encoder base;
	/* the encoder id */
	uint32_t encoder_id;
	uint32_t di_port;
	/* internal or external card*/
	enum via_chrome9_encoder_type encoder_type;
	/* this encoder support types */
	uint32_t supported_connect_types;
	/* the current active type */
	uint32_t active_connect_type;
	void *encoder_private;
};

struct via_chrome9_connector {
	/* connector base */
	struct drm_connector base;
	/* connector id */
	unsigned int connector_id;
	/* save the latest mode index */
	unsigned int mode_index;
	/* internal or external connector*/
	enum via_chrome9_connector_type connector_type;
	struct drm_encoder *detected_encoder;
	void (*set_xorg_options)(void *options, int size,
		struct drm_connector *connector);
	void (*set_edid)(void *options, int size,
		struct drm_connector *connector);
	struct edid *edid;
	struct list_head list;
	void *options;
	void *connector_info;
	void *connector_private;
	unsigned int edid_min_horizontal_rate;
	unsigned int edid_max_horizontal_rate;
	unsigned int edid_min_vertical_rate;
	unsigned int edid_max_vertical_rate;
	unsigned int edid_max_pixel_clock;
	bool edid_limit_flag;
	unsigned int dpms_state;    
};

struct via_chrome9_framebuffer {
	struct drm_framebuffer base;
	struct drm_gem_object *obj;
};

struct internal_encoder_list {
	int encoder_type;
	int support_chip_id;
	char *name;
};

/* Definition Sync Polarity*/
#define NEGATIVE       1
#define POSITIVE        0

struct via_chrome9_support_mode {
	u8 name[10];
	int modeindex;
	int hactive;
	int vactive;
};

struct via_vga_options {
	bool	no_ddc_value;
	/*Clock Polarity*/
	u8	clk_polarity;
	/*Clock Adjust*/
	u8	clk_adjust;
	/*DVP0 or DVP1 Clock Driving Selection*/
	u8	clk_driving_sel;
	/*DVP0 or DVP1 Data Driving Selection*/
	u8	data_driving_sel;
	bool	is_clk_polarity_used;
	bool	is_clk_adjust_used;
	bool	is_clk_driving_sel_used;
	bool	is_data_driving_sel_used;
};

struct via_lcd_options {
	u32	physical_width;
	u32	physical_height;
	u32	panel_index;
	bool	msb;
	bool	center;
	bool	fix_on_iga1;
	bool	dual_channel;
	bool	no_dithering;
	/*Clock Polarity*/
	u8	clk_polarity;
	/*Clock Adjust*/
	u8	clk_adjust;
	/*DVP0 or DVP1 Clock Driving Selection*/
	u8	clk_driving_sel;
	/*DVP0 or DVP1 Data Driving Selection*/
	u8	data_driving_sel;
	bool	is_clk_polarity_used;
	bool	is_clk_adjust_used;
	bool	is_clk_driving_sel_used;
	bool	is_data_driving_sel_used;
	u8	vt1636_clk_sel_st1;
	u8	vt1636_clk_sel_st2;
	bool	is_vt_1636_clk_sel_st1_used;
	bool	is_vt_1636_clk_sel_st2_used;
};

struct via_dvi_options {
	bool	no_ddc_value;
	/*Clock Polarity*/
	u8	clk_polarity;
	/*Clock Adjust*/
	u8	clk_adjust;
	/*DVP0 or DVP1 Clock Driving Selection*/
	u8	clk_driving_sel;
	/*DVP0 or DVP1 Data Driving Selection*/
	u8	data_driving_sel;
	u8	ad9389_circuit_state_adjust;
	bool	is_clk_polarity_used;
	bool	is_clk_adjust_used;
	bool	is_clk_driving_sel_used;
	bool	is_data_driving_sel_used;
	bool	is_ad9389_circuit_state_adjust_used;
};

struct via_hdmi_options {
	bool	attach_all_modes;
	/*Clock Polarity*/
	u8	clk_polarity;
	/*Clock Adjust*/
	u8	clk_adjust;
	/*DVP0 or DVP1 Clock Driving Selection*/
	u8	clk_driving_sel;
	/*DVP0 or DVP1 Data Driving Selection*/
	u8	data_driving_sel;
	u8	ad9389_circuit_state_adjust;
	bool	is_clk_polarity_used;
	bool	is_clk_adjust_used;
	bool	is_clk_driving_sel_used;
	bool	is_data_driving_sel_used;
	bool	is_ad9389_circuit_state_adjust_used;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
	u32 left_border;
	u32 right_border;
	u32 top_border;
	u32 bottom_border;
#else
	u64 left_border;
	u64 right_border;
	u64 top_border;
	u64 bottom_border;

#endif	
	u8 is_hdmi_audio_disable;
};

struct via_dp_options {
	u8	no_ddc_value;
	u8	sw_link_training;
};

struct via_tv_options {
	u32 mode_index;
	u32 standard;
	u32 signal;
	u32 scan;
	/* Clock Polarity */
	u8 clk_polarity;
	/* Clock Adjust */
	u8 clk_adjust;
	/* DVP0 or DVP1 Clock Driving Selection */
	u8 clk_driving_sel;
	/* DVP0 or DVP1 Data Driving Selection */
	u8 data_driving_sel;
	u8 vt1625_clk_adjust;
	bool is_clk_polarity_used;
	bool is_clk_adjust_used;
	bool is_clk_driving_sel_used;
	bool is_data_driving_sel_used;
	bool is_vt1625_clk_adjust_used;
	bool de_dot_crawl;
};

/*******************************************************/
/*Display data structure*/
/*******************************************************/
struct display_timing {
	u16   hor_total;
	u16   hor_addr;
	u16   hor_blank_start;
	u16   hor_blank_end;
	u16   hor_sync_start;
	u16   hor_sync_end;

	u16   ver_total;
	u16   ver_addr;
	u16   ver_blank_start;
	u16   ver_blank_end;
	u16   ver_sync_start;
	u16   ver_sync_end;
};

#define LCD_MODE_TABLE		0x1

struct display_timing_table {
	u32  mode_index;
	u32  refresh_rate;
	u32  clk;
	int   hsync_polarity;
	int   vsync_polarity;
	struct display_timing timing;
};

/* Generate a index according to width and height */
#define     VIA_MAKE_ID(w, h)	(((h) << 16) | (w))

/* via index for tv and lcd use */
#define     VIA_480X640		VIA_MAKE_ID(480, 640)
#define     VIA_640X480		VIA_MAKE_ID(640, 480)
#define     VIA_800X600		VIA_MAKE_ID(800, 600)
#define     VIA_800X480_GEN	VIA_MAKE_ID(800, 480)
#define     VIA_800X480		VIA_MAKE_ID(800, 480)
#define     VIA_1024X600		VIA_MAKE_ID(1024, 600)
#define     VIA_1024X768		VIA_MAKE_ID(1024, 768)
#define     VIA_848X480		VIA_MAKE_ID(848, 480)
#define     VIA_720X480		VIA_MAKE_ID(720, 480)
#define     VIA_720X576		VIA_MAKE_ID(720, 576)
#define     VIA_1280X720		VIA_MAKE_ID(1280, 720)
#define     VIA_1280X768		VIA_MAKE_ID(1280, 768)
#define     VIA_1280X800		VIA_MAKE_ID(1280, 800)
#define     VIA_1280X1024		VIA_MAKE_ID(1280, 1024)
#define     VIA_1360X768		VIA_MAKE_ID(1360, 768)
#define     VIA_1366X768		VIA_MAKE_ID(1366, 768)
#define     VIA_1440X900		VIA_MAKE_ID(1440, 900)
#define     VIA_1400X1050		VIA_MAKE_ID(1400, 1050)
#define     VIA_1600X1200		VIA_MAKE_ID(1600, 1200)
#define     VIA_1920X1080		VIA_MAKE_ID(1920, 1080)
#define     VIA_INVALID                 0

/* Definition Refresh Rate */
#define REFRESH_43	43
#define REFRESH_47	47
#define REFRESH_50	50
#define REFRESH_60	60
#define REFRESH_70	70
#define REFRESH_75	75
#define REFRESH_85	85
#define REFRESH_90	90
#define REFRESH_100	100
#define REFRESH_120	120
#define REFRESH_160	160

#define CLK_22_000M     22000000
#define CLK_25_175M     25175000
#define CLK_29_581M     29581000
#define CLK_40_000M     40000000
#define CLK_48_875M     48875000
#define CLK_56_250M     56250000
#define CLK_72_000M     72000000
#define CLK_80_136M     80136000
#define CLK_85_500M     85500000
#define CLK_85_860M     85860000
#define CLK_88_750M     88750000
#define CLK_101_000M    101000000
#define CLK_108_000M    108000000
#define CLK_130_250M    130250000
#define CLK_150_340M    150340000

#define DCLK_22_000M     22000
#define DCLK_25_175M     25175
#define DCLK_25_200M     25200
#define DCLK_27_000M     27000
#define DCLK_29_581M     29581
#define DCLK_40_000M     40000
#define DCLK_48_875M     48875
#define DCLK_54_000M     54000
#define DCLK_56_250M     56250
#define DCLK_72_000M     72000
#define DCLK_74_250M     74250
#define DCLK_80_136M     80136
#define DCLK_85_500M     85500
#define DCLK_85_860M     85860
#define DCLK_88_750M     88750
#define DCLK_101_000M    101000
#define DCLK_108_000M    108000
#define DCLK_130_250M    130250
#define DCLK_148_500M    148500
#define DCLK_150_340M    150340

/* TV standard define */
#define TV_STANDARD_NTSC	BIT0
#define TV_STANDARD_PAL	BIT1
#define TV_STANDARD_480P	BIT2
#define TV_STANDARD_576P	BIT3
#define TV_STANDARD_720P	BIT4
#define TV_STANDARD_1080I	BIT5
#define TV_STANDARD_ALL	(BIT0|BIT1|BIT2|BIT3|BIT4|BIT5)
/* TV signal define */
#define TV_SIGNAL_COMPOSITE	BIT6
#define TV_SIGNAL_SVIDEO	BIT7
#define TV_SIGNAL_RGB	BIT8
#define TV_SIGNAL_YCBCR	BIT9
#define TV_SIGNAL_ALL	(BIT6|BIT7|BIT8|BIT9)
/* TV Item/flag lists (Bitwise) */
#define TV_TUNING_FFILTER	BIT10
/* Adaptive Flicker Filter */
#define TV_TUNING_ADAPTIVE_FFILTER	BIT11
/* Brightness */
#define TV_TUNING_BRIGHTNESS	BIT12
/* Contrast */
#define TV_TUNING_CONTRAST	BIT13
/* Saturation */
#define TV_TUNING_SATURATION	BIT14
/* Hue */
#define TV_TUNING_HUE	BIT15
/* support position tuning */
#define TV_POSITION_TUNING_SUPPORT	BIT16
/* support tv size tuning,only use for internal TV */
#define TV_SIZE_TUNING_SUPPORT	BIT17
#define TV_SETTING_DOT_CRAWL	BIT18
#define TV_SETTING_LOCK_ASPECT_RATIO	BIT19
#define TV_STANDARD	BIT20
#define TV_SIGNAL_OUT	BIT21
#define TV_TVENCODER_TYPE	BIT22
/* support tv size tuning, only use for external TV:vt1625 */ 
#define TV_SETTING_LEVEL	BIT23
#define TV_MMIO_BASE_ADDR	BIT24
#define TV_PHYSICAL_BASE_ADDR	BIT25
#define TV_SETTING_FFILTER	BIT26
#define TV_SETTING_ADAPTIVE_FFILTER	BIT27

/* TV scan mode define */
#define TV_SCAN_NORMAL	BIT0
#define TV_SCAN_FIT	BIT1
#define TV_SCAN_OVER	BIT2
#define TV_SCAN_TYPE_ALL (BIT0|BIT1|BIT2)

#define TV_DEFLICKER_FILTER_ON	0x01
#define TV_ADAPTIVE_DEFLICKER_ON	0x02
#define TV_FLICKER_OFF	0x03

#define TV_DOTCRAWL_OFF	0x0
#define TV_DOTCRAWL_ON		0x1

#define SIGNAL_FORMAT_UNKNOWN	BIT0
#define SIGNAL_FORMAT_VGA	BIT1
#define SIGNAL_FORMAT_TMDS	BIT2
#define SIGNAL_FORMAT_LVDS	BIT3
#define SIGNAL_FORMAT_DISPLAYPORT	BIT4
#define SIGNAL_FORMAT_COMPOSITE	BIT5
#define SIGNAL_FORMAT_COMPOSITE_PAL	BIT6
#define SIGNAL_FORMAT_COMPOSITE_NTSC	BIT7
#define SIGNAL_FORMAT_COMPOSITE_SECAM	BIT8
#define SIGNAL_FORMAT_SVIDEO	BIT9
#define SIGNAL_FORMAT_COMPONENT	BIT10

#define CONNECTOR_TYPE_UNKNOWN	BIT0
#define CONNECTOR_TYPE_VGA	BIT1
#define CONNECTOR_TYPE_DVI_I	BIT2
#define CONNECTOR_TYPE_DVI_D	BIT3
#define CONNECTOR_TYPE_DISPLAYPORT	BIT4
#define CONNECTOR_TYPE_HDMI	BIT5
#define CONNECTOR_TYPE_PANEL	BIT6
#define CONNECTOR_TYPE_DVI	BIT7
#define CONNECTOR_TYPE_DVI_A	BIT8
#define CONNECTOR_TYPE_TV	BIT9
#define CONNECTOR_TYPE_TV_COMPOSITE	BIT10
#define CONNECTOR_TYPE_TV_SVIDEO	BIT11
#define CONNECTOR_TYPE_TV_COMPONENT	BIT12
#define CONNECTOR_TYPE_TV_SCART	BIT13
#define CONNECTOR_TYPE_TV_C4	BIT14


static inline bool via_chrome9_is_internal_connector(
		struct via_chrome9_connector *via_conn)
{
	return via_conn->connector_type == VIA_CHROME9_INTERNAL_CONNECTOR;
}

/* global */
extern int via_chrome9_mode_set_init(struct drm_device *dev);
extern void via_chrome9_mode_set_fini(struct drm_device *dev);
extern void via_chrome9_suspend_mode_set(struct drm_device *dev);
extern int via_chrome9_resume_mode_set(struct drm_device *dev);
extern void via_chrome9_crtc_init(struct drm_device *dev, int index);
extern int via_chrome9_detect_enc_conn(struct drm_device *dev);
extern void via_chrome9_add_connector(struct drm_device *dev,
	int connector_id, enum via_chrome9_connector_type type);
extern int via_chrome9_internal_encoder_init(struct drm_device *dev);
extern void via_chrome9_set_cea_modes_id(
		struct drm_device *dev, struct list_head *mode_list);
extern void via_chrome9_get_monitor_physical_size(
		struct drm_connector *connector, u32 *width, u32 *height);
extern struct drm_encoder *via_chrome9_best_single_encoder(
		struct drm_connector *connector);
extern bool via_chrome9_drm_helper_crtc_in_use(struct drm_crtc *crtc);

#endif
