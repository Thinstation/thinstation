/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_FB_H_
#define _VIA_CHROME9_FB_H_

#include "drmP.h"
#include "via_chrome9_mode.h"
struct via_chrome9_fbdev;

extern void via_chrome9_fbdev_init(struct drm_device *dev);
extern void via_chrome9_fbdev_fini(struct drm_device *dev);
extern struct drm_framebuffer *
via_chrome9_user_framebuffer_create(struct drm_device *dev,
		struct drm_file *file_priv,
		struct drm_mode_fb_cmd2 *user_mode);
int via_chrome9_fb_cmd_parse(char *name, void *ret_data);
extern void via_chrome9_fb_output_poll_changed(struct drm_device *dev);
extern void via_chrome9_restore_vga(struct drm_device *dev);
#endif
