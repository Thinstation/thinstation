/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_object.h"
#include "via_chrome9_gem.h"

int via_chrome9_gem_object_create(struct drm_device *dev, int size,
			     int alignment, int initial_domain,
			     bool kernel,
			     bool interruptible,
			     struct drm_gem_object **obj)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
	struct drm_gem_object *gobj;
#endif
	struct via_chrome9_object *vobj;
	enum ttm_bo_type type = ttm_bo_type_device;
	int ret;

	size = roundup(size, PAGE_SIZE);
	if (kernel)
		type = ttm_bo_type_kernel;

#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
        gobj = drm_gem_object_alloc(dev, size);
        if (gobj == NULL)
                return -ENOMEM;
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,18,0))
	ret = via_chrome9_buffer_object_create(&dev_priv->bdev, size, type,
			initial_domain, 0, 0, interruptible, NULL, &vobj);
#else
    ret = via_chrome9_buffer_object_create(&dev_priv->bdev, size, type,
            initial_domain, 0, 0, interruptible, NULL, NULL, &vobj);
#endif
	if (ret) {
		DRM_ERROR("Failed to allocate GEM object\n");
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
		mutex_lock(&dev->struct_mutex);
                drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
#endif
		return ret;
	}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,13,0))
        gobj->driver_private = vobj;
        *obj = gobj;
#else
        ret = drm_gem_object_init(dev, &vobj->gobj, size);
        if (ret) {
		DRM_ERROR("Failed to initialize GEM object\n");
		mutex_lock(&dev->struct_mutex);
                drm_gem_object_unreference(&vobj->gobj);
		mutex_unlock(&dev->struct_mutex);
		return ret;
        }

	*obj = &vobj->gobj;
#endif

	return 0;
}

int via_chrome9_gem_user_object_create(struct drm_device *dev, int size,
		int alignment,
		unsigned long buffer_start,
		bool interruptible,
		struct drm_gem_object **obj)
{
#if 0
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	enum ttm_bo_type type = ttm_bo_type_user;
	int initial_domain = VIA_CHROME9_GEM_DOMAIN_GTT;
	int ret;

	size = roundup(size, PAGE_SIZE);
	gobj = drm_gem_object_alloc(dev, size);
	if (gobj == NULL)
		return -ENOMEM;

	ret = via_chrome9_buffer_object_create(&dev_priv->bdev, size, type,
		initial_domain, 0, buffer_start, interruptible, NULL, &vobj);
	if (ret) {
		DRM_ERROR("Failed to allocate GEM object\n");
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
		return ret;
	}
	gobj->driver_private = vobj;
	*obj = gobj;
	/* needs flush cache here? */
	drm_clflush_pages(vobj->bo.ttm->pages, vobj->bo.ttm->num_pages);
#endif
	return 0;
}
