/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_platform.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_cea_timing.h"



BYTE cbReadRegByte(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx)
{
    BYTE regGroup = (BYTE)(groupInx>>8);
    BYTE regIndex = (BYTE)(groupInx);
    BYTE retValue = 0, counter = 0;
    USHORT regValue = 0;
    BOOL IndexSafe = FALSE;

    if (ZSR == regGroup)
    {
        // read SR
        while(!IndexSafe && counter < 3)
        {
            WriteUchar(CB_SEQ_ADDR_REG, regIndex);
            regValue = ReadUshort(CB_SEQ_ADDR_REG);
            if((BYTE)regValue == regIndex)
            {
                retValue = (BYTE)(regValue >> 8);
                IndexSafe = TRUE;
            }
            counter++;
        }
    }
    else
    {
        // read CR
        while(!IndexSafe && counter < 3)
        {
            WriteUchar(CB_CRT_ADDR_REG, regIndex);
            regValue = ReadUshort(CB_CRT_ADDR_REG);
            if((BYTE)regValue == regIndex)
            {
                retValue = (BYTE)(regValue >> 8);
                IndexSafe = TRUE;
            }
            counter++;
        }
    }

    return retValue;
}

void cbWriteRegByte(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx, BYTE data)
{
    BYTE regGroup = (BYTE)(groupInx>>8);
    USHORT regData = data;
       
    regData = (regData << 8) | (BYTE)(groupInx);

    if (ZSR == regGroup)
    {
        // write SR
        WriteUshort(CB_SEQ_ADDR_REG, regData);
    }
    else
    {
        // write CR
        WriteUshort(CB_CRT_ADDR_REG, regData);
    }
}

void cbWriteRegBits(PCBIOS_EXTENSION pcbe, RegGroupIndex groupInx, BYTE mask, BYTE data)
{

    BYTE regData;

    regData = (cbReadRegByte(pcbe, groupInx) & ~mask) | (data & mask);
    cbWriteRegByte(pcbe, groupInx, regData);
}

//--------------------------------------------------------------------------
//  cbDelayMilliSecondsByHW
//      This function will Delay MilliSeconds using HW counter
//  IN  :
//      Milliseconds: milli-seconds for delay
//
//  OUT : None
//--------------------------------------------------------------------------
#define MS_COUNTER_STEP  112

VOID cbDelayMilliSecondsByHW(PCBIOS_EXTENSION pcbe, ULONG  Milliseconds)
{
    while(Milliseconds)
    {
        //Timer step setting, one step is about 10us (8.9us)
        cbWriteRegByte(pcbe, SR_5D, MS_COUNTER_STEP);
        //Delay for 1 Milli-second
        while(!(cbReadRegByte(pcbe, SR_5D) & BIT7))
        {
            ;
        }
        Milliseconds--;
    }
}

VOID cbHWResetEnable_UMA(PCBIOS_EXTENSION pcbe)
{
    // HW Reset Enable, CR17[7] = 0
    cbWriteRegBits(pcbe, CR_17, BIT7, 0x00);
}

VOID cbHWResetDisable_UMA(PCBIOS_EXTENSION pcbe)
{
    DWORD i = 0, maxloop = 50;
    while((cbReadRegByte(pcbe, SR_3C) & BIT3) == 0 && i++ < maxloop)
    {
        cbDelayMicroSeconds(20);
    }
    // HW Reset Disable, CR17[7] = 1
    cbWriteRegBits(pcbe, CR_17, BIT7, BIT7);
}

//------------------------------------------------------------------------
//  cbIGA2HWResetEnable_UMA
//      This function reset IGA2, clear IGA2 fetch counter 
//  IN : 
//      NONE
//  OUT :
//      NONE
//------------------------------------------------------------------------
VOID cbIGA2HWResetEnable_UMA(PCBIOS_EXTENSION pcbe)
{
    // IGA2 HW Reset Enable, CR6A[6] = 0
    cbWriteRegBits(pcbe, CR_6A, BIT6, 0x00);
}

//------------------------------------------------------------------------
//  cbIGA2HWResetDisable_UMA
//      This function disable reset IGA2, clear IGA2 fetch counter 
//  IN : 
//      NONE
//  OUT :
//      NONE
//------------------------------------------------------------------------
VOID cbIGA2HWResetDisable_UMA(PCBIOS_EXTENSION pcbe)
{
    DWORD i = 0, maxloop = 50;
    while((cbReadRegByte(pcbe, SR_3C) & BIT2) == 0 && i++ < maxloop)
    {
        cbDelayMicroSeconds(20);
    }
    // IGA2 HW Reset Disble, CR6A[6] = 1
    cbWriteRegBits(pcbe, CR_6A, BIT6, BIT6);
}


BYTE cbGetCheckSum(BYTE *pBuf, DWORD length)
{
    BYTE    checkSum = 0;
    DWORD   i;

    if (!pBuf)
    {
        ASSERT(FALSE);
        return 0xff;
    }
    
    for (i=0; i<length; i++)
    {
        checkSum += pBuf[i];
    }

    return (0xff - checkSum + 1);
}

enum
{
    ECK = 0,
    VCK,
    LCK,
    VDCK
};

void
cbPLL_Reset_UMA(
    PCBIOS_EXTENSION pcbe,
    ULONG CLKType
    )
{
    if (CLKType == ECK)
    {
        // Set SR40[0] = 1
        cbWriteRegBits(pcbe, SR_40, BIT0, BIT0);
        // Set SR40[0] = 0
        cbWriteRegBits(pcbe, SR_40, BIT0, 0x0);
    }
    else if (CLKType == VCK)
    {
        // Set SR40[1] = 1
        cbWriteRegBits(pcbe, SR_40, BIT1, BIT1);
        // Set SR40[1] = 0
        cbWriteRegBits(pcbe, SR_40, BIT1, 0x0);
    }
    else if (CLKType == LCK)
    {
        // Set SR40[2] = 1
        cbWriteRegBits(pcbe, SR_40, BIT2, BIT2);
        // Set SR40[2] = 0
        cbWriteRegBits(pcbe, SR_40, BIT2, 0x0);
    }
    else if (CLKType == VDCK)
    {
        // Set SRC3[1] = 1
        cbWriteRegBits(pcbe, SR_C3, BIT1, BIT1);
        // Set SRC3[1] = 0
        cbWriteRegBits(pcbe, SR_C3, BIT1, 0x0);
    }
    else
    {
        ASSERT(0);
    }
}

//--------------------------------------------------------------------------
//  cbSetECLK_UMA
//      This function is used to set Engine clock of the GFX
//  IN: 
//      ulPLLMRN : PLL registers value
//          [31:16]  DM{7:0]
//          [15:8 ]  DR[2:0]
//          [7 :0 ]  DN[6:0]
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------------
CBIOS_STATUS cbSetECLK_UMA(PCBIOS_EXTENSION pcbe, ULONG ulPLLMRN)
{
    BYTE PreM = 0, PreR = 0, PreN = 0;
    BYTE M, R, N;

    M = (BYTE)((ulPLLMRN & 0xFF0000) >> 16);
    R = (BYTE)(((ulPLLMRN & 0x00FF00) >> 8) & 0x7F);    // skip DTZ value
    N = (BYTE)((ulPLLMRN & 0x0000FF) & 0x7F);           // skip DTZ value

    //PLL register change will cause clock goes to 0 then resume, whick like a ECK reset
    //And HDAC register write will miss in that time
    PreM = cbReadRegByte(pcbe, SR_47);
    PreR = (cbReadRegByte(pcbe, SR_48) & 0x7F);   // skip DTZ value
    PreN = (cbReadRegByte(pcbe, SR_49) & 0x7F);   // skip DTZ value

    //if equals skip clock setting
    if (PreM == M && PreR == R && PreN == N)
    {
        return CBIOS_OK;
    }

    // Set ECLK
    cbWriteRegByte(pcbe, SR_47, (BYTE)((ulPLLMRN & 0xFF0000) >> 16));
    // set DTZ to 2b'11 also, for PLL output stable by HW suggestion
    cbWriteRegByte(pcbe, SR_48, (BYTE)((ulPLLMRN & 0xFF00) >> 8) | (PLL_DTZ_DEFAULT & BIT0)<<7);
    cbWriteRegByte(pcbe, SR_49, (BYTE)(ulPLLMRN & 0xFF) | (PLL_DTZ_DEFAULT & BIT1)<<6);

    // To make a PLL reset signal
    cbPLL_Reset_UMA(pcbe, ECK);

    // Reload PLL data
    WriteUchar(CB_MISC_OUTPUT_WRITE_REG, ReadUchar(CB_MISC_OUTPUT_READ_REG));

    return CBIOS_OK;
}

//--------------------------------------------------------------------------
//  cbSetVDCLK_UMA
//      This function is used to set Video IP clock of the GFX
//  IN: 
//      ulPLLMRN : PLL registers value
//          [31:16]  DM{7:0]
//          [15:8 ]  DR[2:0]
//          [7 :0 ]  DN[6:0]
//  OUT:
//      CBIOS_STATUS
//--------------------------------------------------------------------------
CBIOS_STATUS cbSetVDCLK_UMA(PCBIOS_EXTENSION pcbe, ULONG ulPLLMRN)
{
    if(!pcbe->ChipCaps.VDCLK_Support)
    {
        return CBIOS_ER_NOT_SUPPORT;
    }

    // Set VDCLK
    cbWriteRegByte(pcbe, SR_C0, (BYTE)((ulPLLMRN & 0xFF0000) >> 16));
    // set DTZ to 2b'11 also, for PLL output stable by HW suggestion
    cbWriteRegByte(pcbe, SR_C1, (BYTE)((ulPLLMRN & 0xFF00) >> 8) | (PLL_DTZ_DEFAULT & BIT0)<<7);
    cbWriteRegByte(pcbe, SR_C2, (BYTE)(ulPLLMRN & 0xFF) | (PLL_DTZ_DEFAULT & BIT1)<<6);

    // To make a PLL reset signal
    cbPLL_Reset_UMA(pcbe, VDCK);

    return CBIOS_OK;
}

//***********************************
// Clock Select
//***********************************
// Input: clock of MHz * 1,000,000
// For exemple, to set 133.33 MHz, ulClock would be 133,330,000 (07ED6B40h)
#define UMA_CLK_Reference    14318180
#define CSR_VCO_UP          600000000
#define CSR_VCO_DOWN        300000000


//--------------------------------------------------------------------------
//  cbGetMRN_UMA
//      This function gets the best frequency M, R, N value according to 
//  the input clock frequence
//  IN :
//      ulClock : Clock frequence (.Hz)
//  OUT :
//      PLL_MRN : PLL registers M, R, N value
//          [31:16]  DM[7:0]
//          [15:8 ]  DR[2:0]
//          [7 :0 ]  DN[6:0]
//--------------------------------------------------------------------------

DWORD cbGetMRN_UMA(BOOL bPLLUse409Formula, IN DWORD ulClock)
{
    DWORD PLL_Mplus2, PLL_R, PLL_Nplus2;
    DWORD bestClkDiff = ulClock;
    DWORD bestPLL_Mplus2 = 2;
    DWORD bestPLL_Nplus2 = 2;
    DWORD bestPLL_R = 0;
    DWORD clkDiff;
    DWORD PLLFout; 
    DWORD PLLFvco;
    DWORD PLL_MRN = 0;

	PLL_MRN_Value PLLTempArray[5];
	int Counter_PLLTempArray = 0;

    // initialize PLLTempArray
    memset(PLLTempArray, 0x0, sizeof(PLL_MRN_Value)*5);
    
    //Fout = Fin * (M+2) / [(N+2) * 2^R]
    //Fin = 14318180Hz
    for (PLL_Nplus2=2; PLL_Nplus2<6; PLL_Nplus2++)              //N[6:0]
    {
        for (PLL_R=0; PLL_R<6; PLL_R++)                         //R[2:0]
        {
            for (PLL_Mplus2=2; PLL_Mplus2<512; PLL_Mplus2++)    //M[9:0]
            {
                // first divide PLL_Nplus2 then multiply PLL_Mplus2
                // We have to reduce PLL_Mplus2 to 512 to get rid of 
                // the overflow 
                PLLFvco= (UMA_CLK_Reference / PLL_Nplus2) * PLL_Mplus2;
                if ((PLLFvco >= CSR_VCO_DOWN) && (PLLFvco <= CSR_VCO_UP))   
                {
                    PLLFout= PLLFvco >> PLL_R;
		
                    if (PLLFout < ulClock)
                    {
                        clkDiff = ulClock - PLLFout;
                    }
                    else
                    {
                        clkDiff = PLLFout - ulClock;
                    }

					//if ulClock(which is the PLL we want to set) > 150MHz,
					//the MRN value we write in register must < ulClock, and get MRN value whose M is the largeset
                    if (PLLFout<=ulClock && ulClock >= 150000000)
                    {				
						if((clkDiff<=PLLTempArray[0].DiffCLK) || PLLTempArray[0].PLLFout == 0)	
						{
							for(Counter_PLLTempArray = ((sizeof(PLLTempArray)/sizeof(PLL_MRN_Value))-1); Counter_PLLTempArray >=1; Counter_PLLTempArray--)		
							{
								PLLTempArray[Counter_PLLTempArray] = PLLTempArray[Counter_PLLTempArray-1];
							}
							PLLTempArray[0].PLL_M = PLL_Mplus2;
							PLLTempArray[0].PLL_R = PLL_R;
							PLLTempArray[0].PLL_N = PLL_Nplus2;
							PLLTempArray[0].DiffCLK = clkDiff;
							PLLTempArray[0].PLLFout = PLLFout;
						}								
                    }

					if (clkDiff < bestClkDiff)
                    {
						bestClkDiff     = clkDiff;
                        bestPLL_Mplus2  = PLL_Mplus2;
                        bestPLL_Nplus2  = PLL_Nplus2;
                        bestPLL_R       = PLL_R;
					}
					
                    
                } // if PLLFvco in VCO range
            } // for PLL M
        } // for PLL R
    } // for PLL N

	//if ulClock(which is the PLL we want to set) > 150MHz,
	//the MRN value we write in register must < ulClock, and get MRN value whose M is the largeset
	if(ulClock > 150000000)
	{
		Counter_PLLTempArray = 0;
		bestPLL_Mplus2 = PLLTempArray[Counter_PLLTempArray].PLL_M;
		bestPLL_R	   = PLLTempArray[Counter_PLLTempArray].PLL_R;
		bestPLL_Nplus2 = PLLTempArray[Counter_PLLTempArray].PLL_N;
	}

    if(bPLLUse409Formula)
    {
        //Clcok Synthesizer Value 0 :      DM[7:0]
        PLL_MRN =  ((bestPLL_Mplus2) & 0xFF) << 16;

        //Clcok Synthesizer Value 1[1:0] : DM[9:8]
        //Clcok Synthesizer Value 1[4:2] : DR[2:0]
        //Clcok Synthesizer Value 1[7]   : DTZ[0]
        PLL_MRN |=  (((PLL_DTZ_DEFAULT & 0x1) << 7) | ((bestPLL_R &0x7) << 2) | (((bestPLL_Mplus2) >> 8) & 0x3)) << 8;

        //Clcok Synthesizer Value 2[6:0] : DN[6:0]
        //Clcok Synthesizer Value 2[7]   : DTZ[1]
        PLL_MRN |=  (((PLL_DTZ_DEFAULT>>1) & 0x1) << 7) | ((bestPLL_Nplus2) & 0x7F);
    }
    else
    {
        //Clcok Synthesizer Value 0 :      DM[7:0]
        PLL_MRN =  ((bestPLL_Mplus2-2) & 0xFF) << 16;

        //Clcok Synthesizer Value 1[1:0] : DM[9:8]
        //Clcok Synthesizer Value 1[4:2] : DR[2:0]
        //Clcok Synthesizer Value 1[7]   : DTZ[0]
        PLL_MRN |=  (((PLL_DTZ_DEFAULT & 0x1) << 7) | ((bestPLL_R &0x7) << 2) | (((bestPLL_Mplus2-2) >> 8) & 0x3)) << 8;

        //Clcok Synthesizer Value 2[6:0] : DN[6:0]
        //Clcok Synthesizer Value 2[7]   : DTZ[1]
        PLL_MRN |=  (((PLL_DTZ_DEFAULT>>1) & 0x1) << 7) | ((bestPLL_Nplus2-2) & 0x7F);
    }

    return PLL_MRN;
}

//--------------------------------------------------------------------------
//  cbSetPixelCLK_UMA
//      This function sets PLL frequency reg M, R, N value , if pre-frequence 
//  equals the setting one, just keep the setting unchanged.
//  IN :
//      ulClock : Clock frequence (.Hz)
//  OUT :
//      pPLLMNR : PLL registers M, R, N value
//      CBIOS_STATUS : function status
//--------------------------------------------------------------------------
CBIOS_STATUS cbSetPixelCLK_UMA(PCBIOS_EXTENSION pcbe, IN ULONG ulPllMRN, IN ULONG IGANumber)
{
    CBIOS_STATUS status = CBIOS_OK;
    BYTE PreM = 0, PreR = 0, PreN = 0;
    BYTE M, R, N;

    M = (BYTE)((ulPllMRN & 0xFF0000) >> 16);
    R = (BYTE)((ulPllMRN & 0x00FF00) >> 8);
    N = (BYTE)(ulPllMRN & 0x0000FF);

    //since reset PLL will cause device flicker, So every time before reloading
    //CLK first check whether pre-clock is the same as setting one 
    switch(IGANumber)
    {
    case IGA1:
        // Set IGA1 pixel clock
        PreM = cbReadRegByte(pcbe, SR_44);
        PreR = cbReadRegByte(pcbe, SR_45);
        PreN = cbReadRegByte(pcbe, SR_46);
        break;
    case IGA2:
        // Set IGA2 pixel clock
        PreM = cbReadRegByte(pcbe, SR_4A);
        PreR = cbReadRegByte(pcbe, SR_4B);
        PreN = cbReadRegByte(pcbe, SR_4C);
        break;
    default:
        cbDbgPrint(1, "Error IGA type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    //if equals skip clock setting
    if (PreM == M && PreR == R && PreN == N)
    {
        return CBIOS_OK;
    }

    switch(IGANumber)
    {
    case IGA1:
        // Set IGA1 pixel clock
        cbProgramDClk1_UMA(pcbe, M, R, N);
        break;
    case IGA2:
        // Set IGA2 pixel clock
        cbProgramDClk2_UMA(pcbe, M, R, N);
        break;
    default:
        cbDbgPrint(1, "Error IGA type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}

 //--------------------------------------------------------------------------
 //  cbCalcClkFromMRN
 //      This function transfer MRN register bytes to clock(Hz)
 //
 //  IN :
 //      M, R, N register BYTE value
 //  OUT :
 //      Clock Frequency (Hz)
 //--------------------------------------------------------------------------
DWORD cbCalcClkFromMRN(PCBIOS_EXTENSION pcbe,
                       IN BYTE M,
                       IN BYTE R,
                       IN BYTE N)
 {
    //Clcok Synthesizer Value 0 :      DM[7:0]
    //Clcok Synthesizer Value 1[4:2] : DR[2:0]
    //Clcok Synthesizer Value 2[6:0] : DN[6:0]
    DWORD PLLDM = (ULONG)M;
    DWORD PLLDR = (ULONG)((R & 0x1C) >> 2);
    //Remove DTZ bit
    DWORD PLLDN = (ULONG)(N & 0x7F);
    if (pcbe->ChipCaps.PLL_USE_409_FORMULA)
    {
        if( PLLDN == 0)
        {
            cbDbgPrint(1, "Error MRN input!\n");
            return 0;
        }
        //True Output Fout = Fref * (DM) / [(DN)(2^DR)]
        return ( UMA_CLK_Reference*(PLLDM) / ((PLLDN) *((DWORD)1 << PLLDR)) );
    }
    else
    {
        //True Output Fout = Fref * (DM + 2) / [(DN+2)(2^DR)]
        return ( UMA_CLK_Reference*(PLLDM + 2) / ((PLLDN + 2) *((DWORD)1 << PLLDR)) );
    }
 }
 //--------------------------------------------------------------------------
 //  cbCalcClkFromDWORDMRN
 //      This function transfer MRN dword to clock(Hz)
 //
 //  IN :
 //      dwMRN MRN dword value
 //  OUT :
 //      Clock Frequency (Hz)
 //--------------------------------------------------------------------------
DWORD cbCalcClkFromDWORDMRN(PCBIOS_EXTENSION pcbe,
                                          IN DWORD dwMRN)
{
    BYTE M = (BYTE)(dwMRN >> 16);
    BYTE R = (BYTE)(dwMRN >>  8);
    BYTE N = (BYTE)(dwMRN);
    return cbCalcClkFromMRN(pcbe,M,R,N);
}
//--------------------------------------------------------------------------
//  cbGetMCLK_UMA
//      This function gets current Memory clock according to Scratch Pad 2 
//
//  OUT :
//      pClockFreq : current Memory clock (.Hz)
//      CBIOS_STATUS : function status
//--------------------------------------------------------------------------
CBIOS_STATUS cbGetMCLK_UMA(PCBIOS_EXTENSION pcbe, OUT ULONG *pClockFreq)
{
    ULONG ClockFreqTbl[] = {66000000,   // 66  MHz
                            100000000,  // 100 MHz
                            133000000,  // 133 MHz
                            200000000,  // 200 MHz
                            266000000,  // 266 MHz
                            333000000,  // 333 MHz
                            400000000,  // 400 MHz
                            533000000,  // 533 MHz
                            667000000,  // 667 MHz
                            800000000,  // 800 MHz
                            1066000000  // 1066 Mhz
                            };
    ULONG ClockFreqCount = sizeof(ClockFreqTbl) / sizeof(UINT32);
    
    if(pcbe->sPad_2.Mem_Data_Rate >= ClockFreqCount)
    {
        // wrong memory clock frequency use default clock 400 MHz
        cbDbgPrint(0, "Wrong DRAM clock rate! Use default clock 400 MHz\n");
        ASSERT(FALSE);
        pcbe->sPad_2.Mem_Data_Rate = 6;
    }

    *pClockFreq = ClockFreqTbl[pcbe->sPad_2.Mem_Data_Rate];
    return CBIOS_OK;
 }

 //--------------------------------------------------------------------------
 //  cbGetPixelCLK_UMA
 //      This function gets current Memory clock according to Scratch Pad 2 
 //
 //  OUT :
 //      pClockFreq : current Memory clock (.Hz)
 //      CBIOS_STATUS : function status
 //--------------------------------------------------------------------------
 CBIOS_STATUS cbGetPixelCLK_UMA(PCBIOS_EXTENSION pcbe, 
    IN ULONG IGANumber, 
    OUT PULONG pClockFreq)
 {
    BYTE M, R, N;
    CBIOS_STATUS status = CBIOS_OK;
    
    switch(IGANumber)
    {
    case IGA1:
        M = cbReadRegByte(pcbe, SR_44);
        R = cbReadRegByte(pcbe, SR_45);
        N = cbReadRegByte(pcbe, SR_46);
        break;
    case IGA2:
        M = cbReadRegByte(pcbe, SR_4A);
        R = cbReadRegByte(pcbe, SR_4B);
        N = cbReadRegByte(pcbe, SR_4C);
        break;
    default:
        cbDbgPrint(1, "Error IGA type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    if (status == CBIOS_OK)
    {
        *pClockFreq = cbCalcClkFromMRN(pcbe, M, R, N);
    }

    return status;
 }


 //--------------------------------------------------------------------------
 //  cbGetECLK_UMA
 //      This function gets current engine clock according to Scratch Pad 2 
 //
 //  OUT :
 //      pClockFreq : current Memory clock (.Hz)
 //      CBIOS_STATUS : function status
 //--------------------------------------------------------------------------
 CBIOS_STATUS cbGetECLK_UMA(PCBIOS_EXTENSION pcbe, OUT PULONG pClockFreq)
 {
    BYTE M, R, N;
    CBIOS_STATUS status = CBIOS_OK;

    if(pcbe->ChipRevision == FPGA_ChipRevision)
    {
        //FPGA ECK is 10MHz
        *pClockFreq = 0x989680;
        return status;
    }

    M = cbReadRegByte(pcbe, SR_47);
    R = cbReadRegByte(pcbe, SR_48);
    N = cbReadRegByte(pcbe, SR_49);

    *pClockFreq = cbCalcClkFromMRN(pcbe, M, R, N);

    return status;
 }


//----------------------------------------------------------------------------
//cbGetMonitorSizeFromDDC_EDIDv1
//  This function get the biggest mode from EDID (established / std /detailed)
// and if CEA extension block exists, extension block should also be checked.
// This function should be called after device EDID has been parsed (function : 
// cbEDIDParser_UMA has been called)
//    IN : 
//       Device : device type 
//    OUT :
//       pxRes  : xRes
//       pyRes  : yRes
//---------------------------------------------------------------------------
 BOOL cbGetMonitorSizeFromDDC_EDIDv1(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD Device, 
    OUT PDWORD pxRes, 
    OUT PDWORD pyRes)
 {
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(Device)] );
     ULONG xRes = 0, yRes = 0, i;
     
    if (!pxRes || !pyRes)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

     // find Max resolution in EDID as monitor size 
     //----------------- CEA extension block 1 check -------------------
     if (pEDID->EDIDInfo.CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
     {
        // CEA extension block 1.3 or above, first check SVD 
        if (pEDID->EDIDInfo.CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {   
               // more robust check all SVD 
               if (pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD != 0
                && CEA861_FormatTbl[pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes >= xRes
                && CEA861_FormatTbl[pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes >= yRes)
               {
                    xRes = CEA861_FormatTbl[pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes;
                    yRes = CEA861_FormatTbl[pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes;
               }
            }
        }
     
        // check in DTD in CEA extension block
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if ( (pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].Valid)
                && ( pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].XResolution >= xRes )
                && ( pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].YResolution >= yRes ) )
            {
                // resolution exist in EDID
                xRes = pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].XResolution;
                yRes = pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].YResolution;
            }
        }
     }
         
     
     //----------------- EDID block 0 data check ------------------ 
     // check in Detailed timing
     for (i = 0; i < 4; i++)
     {
         if ( (pEDID->EDIDInfo.DtlTimings[i].Valid)
             && ( pEDID->EDIDInfo.DtlTimings[i].XResolution >= xRes )
             && ( pEDID->EDIDInfo.DtlTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->EDIDInfo.DtlTimings[i].XResolution;
             yRes = pEDID->EDIDInfo.DtlTimings[i].YResolution;
         }
     }
     
     // check in Standard timing
     for (i = 0; i < 8; i++)
     {
         if ( (pEDID->EDIDInfo.StdTimings[i].Valid)
             && ( pEDID->EDIDInfo.StdTimings[i].XResolution >= xRes )
             && ( pEDID->EDIDInfo.StdTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->EDIDInfo.StdTimings[i].XResolution;
             yRes = pEDID->EDIDInfo.StdTimings[i].YResolution;
         }
     }
     
     // check in Establish timing
     for (i = 0; i < 16; i++)
     {
         if ( (pEDID->EDIDInfo.EstTimings[i].Valid)
             && ( pEDID->EDIDInfo.EstTimings[i].XResolution >= xRes )
             && ( pEDID->EDIDInfo.EstTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->EDIDInfo.EstTimings[i].XResolution;
             yRes = pEDID->EDIDInfo.EstTimings[i].YResolution;
         }
     }
     
        
     if (xRes > 0 && yRes > 0)
     {
        *pxRes = xRes;
        *pyRes = yRes;
     }
     else
     {
        return FALSE;
     }

     return TRUE;

}

/****************************************************************
; ProgramDCLK1
;
; Purpose: Programs a Clock frequency
;          DCLK11  -> SR44~SR46
;
; Input:
; BYTE byClk_MValue = M ( 8 bits)
; BYTE byClk_RValue = R ( 3 bits)
; BYTE byClk_NValue = N ( 6 bits)
;
; Output:
;
;
;****************************************************************/
void cbProgramDClk1_UMA(PCBIOS_EXTENSION pcbe,
                       BYTE byClk_MValue,
                       BYTE byClk_RValue,
                       BYTE byClk_NValue)
{
    UCHAR RealSetDClk = TRUE; 
    UCHAR PreM, PreR, PreN; 
	DWORD CurrentCLK;
	BYTE  PLL_DTZ;

    if(byClk_MValue == 0 && byClk_RValue == 0 && byClk_NValue == 0)
    {
        return;
    }
	//clear DTZ bits
	byClk_RValue &= 0x7F; 
	byClk_NValue &= 0x7F;

	//Get current CLK
	CurrentCLK = cbCalcClkFromMRN(pcbe,byClk_MValue,byClk_RValue,byClk_NValue);
	
	// set DTZ to 2b'11 also, for PLL output stable by HW suggestion
    if(CurrentCLK > 150000000)
    {
		//If PLL > 150Mhz, set DTZ bits as 10 
		PLL_DTZ = 0x01;
		byClk_RValue |= (PLL_DTZ & BIT0)<<7;
    	byClk_NValue |= (PLL_DTZ & BIT1)<<6;
    }
	else
	{
		byClk_RValue |= (PLL_DTZ_DEFAULT & BIT0)<<7;
    	byClk_NValue |= (PLL_DTZ_DEFAULT & BIT1)<<6;
	}
	
    PreM = cbReadRegByte(pcbe, SR_44);
    PreR = cbReadRegByte(pcbe, SR_45);
    PreN = cbReadRegByte(pcbe, SR_46);

	//clear DTZ bits
	PreR &= 0x7F; 
	PreN &= 0x7F;

    if(CurrentCLK > 150000000)
    {
		//If PLL > 150Mhz, set DTZ bits as 10 
		PLL_DTZ = 0x01;
		PreR |= (PLL_DTZ & BIT0)<<7;
    	PreN |= (PLL_DTZ & BIT1)<<6;
    }
	else
	{
		PreR |= (PLL_DTZ_DEFAULT & BIT0)<<7;
    	PreN |= (PLL_DTZ_DEFAULT & BIT1)<<6;
	}


    // if pre Dclock equals as Dclock need to be set just skip
    // Here we will check DTZ bits too, because vbios will change BIT7 in some case, such as: specific platform full screen
    if(pcbe->IGA1Info.dispDev & (S3_LCD | S3_LCD2 | S3_TV | S3_HDTV))
    {
        if ((PreM == byClk_MValue) && (PreR == byClk_RValue) && (PreN == byClk_NValue))
        {
            RealSetDClk = FALSE;
        }
    }
    if (RealSetDClk)
    {
		// Enter HW Reset state, CR17[7]=0
        cbHWResetEnable_UMA(pcbe);

        // Set VCLK
        cbWriteRegByte(pcbe, SR_44, byClk_MValue);
        cbWriteRegByte(pcbe, SR_45, byClk_RValue);
        cbWriteRegByte(pcbe, SR_46, byClk_NValue);

        // Reload PLL data
        WriteUchar(CB_MISC_OUTPUT_WRITE_REG, ReadUchar(CB_MISC_OUTPUT_READ_REG));

        // To make a PLL reset signal    
        cbPLL_Reset_UMA(pcbe, VCK);

        // Exit HW Reset state, CR17[7]=1
        cbHWResetDisable_UMA(pcbe);
    }
}

/****************************************************************
; ProgramDCLK2
;
; Purpose: Programs a Clock frequency
;          DCLK12  -> SR4A~SR4C
;
; Input:
; BYTE byClk_MValue = M ( 8 bits)
; BYTE byClk_RValue = R ( 3 bits)
; BYTE byClk_NValue = N ( 6 bits)
;
; Output:
;
;
;****************************************************************/
void cbProgramDClk2_UMA(PCBIOS_EXTENSION pcbe,
                       BYTE byClk_MValue,
                       BYTE byClk_RValue,
                       BYTE byClk_NValue)
{
    UCHAR RealSetDClk = TRUE;
    UCHAR PreM, PreR, PreN; 
	DWORD CurrentCLK;
	BYTE  PLL_DTZ;

    if(byClk_MValue == 0 && byClk_RValue == 0 && byClk_NValue == 0)
    {
        return;
    }
	
	//clear DTZ bits
	byClk_RValue &= 0x7F; 
	byClk_NValue &= 0x7F;

	//Get current CLK
	CurrentCLK = cbCalcClkFromMRN(pcbe,byClk_MValue,byClk_RValue,byClk_NValue);

	// set DTZ to 2b'11 also, for PLL output stable by HW suggestion
    if(CurrentCLK > 150000000)
    {
		//If PLL > 150Mhz, set DTZ bits as 10 
		PLL_DTZ = 0x01;
		byClk_RValue |= (PLL_DTZ & BIT0)<<7;
    	byClk_NValue |= (PLL_DTZ & BIT1)<<6;
    }
	else
	{
		byClk_RValue |= (PLL_DTZ_DEFAULT & BIT0)<<7;
    	byClk_NValue |= (PLL_DTZ_DEFAULT & BIT1)<<6;
	}

    PreM = cbReadRegByte(pcbe, SR_4A);
    PreR = cbReadRegByte(pcbe, SR_4B);
    PreN = cbReadRegByte(pcbe, SR_4C);
	
	//clear DTZ bits
	PreR &= 0x7F; 
	PreN &= 0x7F;

    if(CurrentCLK > 150000000)
    {
		//If PLL > 150Mhz, set DTZ bits as 10 
		PLL_DTZ = 0x01;
		PreR |= (PLL_DTZ & BIT0)<<7;
    	PreN |= (PLL_DTZ & BIT1)<<6;
    }
	else
	{
		PreR |= (PLL_DTZ_DEFAULT & BIT0)<<7;
    	PreN |= (PLL_DTZ_DEFAULT & BIT1)<<6;
	}

    // if pre Dclock equals as Dclock need to be set just skip
    // Here we will check DTZ bits too, because vbios will change BIT7 in some case, such as: specific platform full screen
    if(pcbe->IGA2Info.dispDev & (S3_LCD | S3_LCD2 | S3_TV | S3_HDTV))
    {
        if ((PreM == byClk_MValue) && (PreR == byClk_RValue) && (PreN == byClk_NValue))
        {
            RealSetDClk = FALSE;
        }
    }
    if (RealSetDClk)
    {
        // set IGA2 dot clock

        // Enter HW Reset state, CR6A[6]=0
        cbIGA2HWResetEnable_UMA(pcbe);

        // Set LCDCLK
        cbWriteRegByte(pcbe, SR_4A, byClk_MValue);
        cbWriteRegByte(pcbe, SR_4B, byClk_RValue);
        cbWriteRegByte(pcbe, SR_4C, byClk_NValue);

        // To make a PLL reset signal    
        cbPLL_Reset_UMA(pcbe, LCK);

        // Exit HW Reset state, CR6A[6]=1
        cbIGA2HWResetDisable_UMA(pcbe);
    }
}


/****************************************************************
; cbIsInVBlank
;
; This function is called to query whether the  IGA is in vertical blank 
;
; IN:
;     IGA number
; OUT:
;     None
; Ret:
;     TRUE or FALSE
;
;****************************************************************/
BOOL cbIsInVBlank(PCBIOS_EXTENSION pcbe, DWORD iga_num)
{
    if(iga_num == IGA1)
    {
        // 1: Display, 0:VerticalBlank     
        if(!(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0200)) & 0x02))
        {
            return TRUE;
        }
    }
    else if (iga_num == IGA2)
    {
        // 1: Display, 0:VerticalBlank        
        if(!(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0204)) & 0x04))
        {
            return TRUE;
        }
    }
    return FALSE;
}

/****************************************************************
; cbWaitVBlank
;
; This function is called to wait to vertical blank for the specified IGA 
;
; IN:
;     IGA number
; OUT:
;     None
; Ret:
;     None
;
;****************************************************************/
void cbWaitVBlank(PCBIOS_EXTENSION pcbe, DWORD iga_num)
{
    if(iga_num == IGA1)
    {
        // 1: Display, 0:VerticalBlank     
        while(!(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0200)) & 0x02));
        while(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0200)) & 0x02);
    }
    else if (iga_num == IGA2)
    {
        // 1: Display, 0:VerticalBlank        
        while(!(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0204)) & 0x04));
        while(ReadUchar((PVOID)((ULONG_PTR)pcbe->MmioBase + 0x0204)) & 0x04);
    }
}

//****************************************************************************
// cbSearchVBIOSInitTable_UMA
//    This function will get value of input register from initial table
//    IN : 
//       type  : Register type: CR/SR/GR
//       index : Register index
//    OUT :
//       pdata : data of this register
//    Return :
//       status: = TRUE, if register exist in initial table; 
//               = FALSE, if not 
//       
//****************************************************************************
BOOL cbSearchVBIOSInitTable_UMA(PCBIOS_EXTENSION pcbe,
                           IN BYTE type,
                           IN BYTE index,
                           OUT PBYTE pdata)
{
    BOOL status = FALSE;

    if (NULL != pcbe->pVCPInfo)
    {
        if (0 != pcbe->pVCPInfo->xRInitTbl)
        {
            WORD OffsetInitTbl = pcbe->pVCPInfo->xRInitTbl;
            PVBINITTBL pRegTable = (PVBINITTBL)(pcbe->RomData + OffsetInitTbl);
           
            while(pRegTable->group!=0xFF&&(pRegTable->group!=type||pRegTable->index!=index))
            {
                pRegTable++;
            }
            
            if(pRegTable->group!=0xFF)
            {
                *pdata=pRegTable->data;
                status=TRUE;
            }
        }
    }
    
    return status;
}

//****************************************************************************
// cbLoadTable_UMA: load register from input reg table
//****************************************************************************

void cbLoadTable_UMA(PCBIOS_EXTENSION pcbe,
                     CBREGISTER *pRegTable)
{
    CBREGISTER  *pReg;
    int     i;
    BYTE    bData;
    UCHAR   byTemp;

    cbDbgPrint(0, "cbLoadTable_UMA: Loadtable called\n");

    for( i=0; ; i++)
    {
        pReg = &pRegTable[i];

        if (pReg->type == 0xFF) break;

        bData = pReg->value;

        switch (pReg->type)
        {
        case ZCR:
            cbWriteRegByte(pcbe, pReg->index, ((cbReadRegByte(pcbe, pReg->index) & ~pReg->mask) | bData));
            break;

        case ZSR:
            cbWriteRegByte(pcbe, (0x0100 | pReg->index), 
                ((cbReadRegByte(pcbe, (0x0100 | pReg->index)) & ~pReg->mask) | bData));
            break;

        case ZAR:
            ReadUchar(CB_ATTR_INITIALIZE_REG);
            WriteUchar(CB_ATTR_ADDR_REG, pReg->index);
            byTemp = ReadUchar(CB_ATTR_DATA_READ_REG);
            ReadUchar(CB_ATTR_INITIALIZE_REG);
            WriteUchar(CB_ATTR_ADDR_REG, pReg->index);
            WriteUchar(CB_ATTR_DATA_WRITE_REG, (byTemp & ~pReg->mask) | bData);
            break;

        case ZGR:
            WriteUchar(CB_GRAPH_ADDR_REG, pReg->index);
            WriteUchar(CB_GRAPH_DATA_REG, (UCHAR)((ReadUchar(CB_GRAPH_DATA_REG) & ~pReg->mask) | bData));
            break;

        case ZMISC:
            byTemp = ReadUchar(CB_MISC_OUTPUT_READ_REG);
            WriteUchar(CB_MISC_OUTPUT_WRITE_REG, (UCHAR)((byTemp & ~pReg->mask) | bData));
            break;

        default:
            break;

        }
    }
}

//****************************************************************************
// cbGetBitNumbers
//    This function will get bit numbers of input value
//    IN : 
//       data  : input value to check valid bits(Number of bit '1'), Maximum 32 bit
//    OUT :
//       None
//    Return :
//       Number of bit '1' in the input data, Maximum 32
//       
//****************************************************************************
BYTE cbGetBitNumbers(PCBIOS_EXTENSION pcbe,
                     IN DWORD data)
{
    BYTE BitNumber = 0;
    while(data != 0)
    {
        BitNumber++;
        data = CLEAR_LOWEST_BIT1(data);
    }
    return BitNumber;
}

I2C_PORT_TYPE IsI2CGPIO(BYTE I2CPort)
{
    if ( I2CPort == 0x2C || I2CPort == 0x3D || I2CPort == 0x25)
    {
        return GPIO;    
    }
    else
    {
        return I2C;
    }
}

/****************************************************************
;       I2C_Out_INV
;
;       Controls the individual toggling of bits in SERIALPORT2 to produce
;       clock and data pulses, and in the end provides a delay.
;
; Serial Port 2 is defined as follows:
;
;      ...  5   4   3   2      SCW = CLK  Write
; --------|---|---|---|---|--  SDW = DATA Write
;      ...|SCW|SDW|SCR|SDR|..  SCR = CLK  Read
; ---------------------------  SDR = DATA Read
;
;       Input:
;               UCHAR ucData
;                   Bit 7   = W SCL Enable
;                   Bit 6   = R SDA Enable
;                   Bit 5   = SCL
;                   Bit 4   = SDA 
;       Output:
;
;****************************************************************/
void I2C_Out_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, UCHAR ucData)
{
    UCHAR ucPortData;
    unsigned int uCount;
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);

    //
    //  read the current value, clear the clock and data bits, and add
    //  the new clock and data values
    //

    ucPortData = (cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort) & 0x0F) | ucData;

    cbWriteRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort, ucPortData);

    if(pi2c->Flags & SIL9022_BURST_READ)
    {
        cbDelayMicroSeconds(12); // Provide delay.
    }
    else
    {
        cbDelayMicroSeconds(7); // Provide delay.
    }

    //
    //  if we set the clock high, wait for target to set clock high
    //
    if (ucData & 0x20)
    {
        uCount = 2000;
        do
        {
            --uCount;
            ucPortData = cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort);
            if (GPIO == i2cType)
            {
                ucPortData &= 0x20;
            }
            else                
            {
                ucPortData &= 0x8;
            }
        } while ( (!ucPortData) && (uCount > 0) );
    }
    else
    {
        uCount = 2000;
        do
        {
            --uCount;
            ucPortData = cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort);
            if (GPIO == i2cType)
            {
                ucPortData &= 0x20;
            }
            else                
            {
                ucPortData &= 0x8;
            }
        } while ( (ucPortData) && (uCount > 0) );
    }

}

/****************************************************************
;   I2C_SetDDC2_INV
;
;   The display shall switch to DDC2 as soon as it sees a high to low 
;   transition on the clock line.
;
;   Input:
;
;   Output:
;
;****************************************************************/
BOOL
I2C_SetDDC2_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    BOOL status = TRUE;
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);

    if(GPIO == i2cType)
    {
        //  SetDDC2
        //  CLK=low, DATA=high
        I2C_Out_INV(pcbe, pi2c, 0xD2);
        //  CLK=low, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0xC2);
        //  CLK=high, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0xE2);
        //  CLK=low, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0xC2);
        //  CLK=low, DATA=high
        I2C_Out_INV(pcbe, pi2c, 0xD2);
        //  check DATA status
        if(((cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort) & 0x04) >> 2) == 0)
        {
            status = FALSE;
            return status;
        }
    }
    else
    {
        //  SetDDC2
        //  CLK=low, DATA=high
        I2C_Out_INV(pcbe, pi2c, 0x11);
        //  CLK=low, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0x01);
        //  CLK=high, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0x21);
        //  CLK=low, DATA=low
        I2C_Out_INV(pcbe, pi2c, 0x01);
        //  CLK=low, DATA=high
        I2C_Out_INV(pcbe, pi2c, 0x11);
        //  check DATA status
        if(((cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort) & 0x04) >> 2) == 0)
        {
            status = FALSE;
            return status;
        }
    }
    
    return status;
}

/****************************************************************
;   I2C_StartService_INV
;
;   Provide start sequence for talking to I2C bus.
;
;   Input:
;
;   Output:
;
;****************************************************************/
void
I2C_StartService_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);
    //   CLK  _--_
    //  Data  --__
    if (GPIO == i2cType)
    {
        //
        //  CLK=low, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0xD2);
        //
        //  CLK=high, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0xF2);
        //
        //  CLK=high, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0xE2);
        //
        //  CLK=low, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0xC2);
    }
    else
    {
        //
        //  CLK=low, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x11);
        //
        //  CLK=high, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x31);
        //
        //  CLK=high, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0x21);
        //
        //  CLK=low, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0x01);
    }
}

/****************************************************************
;   I2C_BitWrite_INV
;
;   Writes one SDA bit to the I2C bus.
;
;   Input:
;       Bit 1 of ucData = Bit to be written.
;
;   Output:
;
;***************************************************************/
void
I2C_BitWrite_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c,
    UCHAR ucData
    )
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);
    ucData &= 0x01;

    //   CLK  _-_
    //  Data  XXX
    if (GPIO == i2cType)
    {
        if ( ucData )
        {
            //
            // CLK=low,  DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0xD2);
            //
            // CLK=high, DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0xF2);
            //
            // CLK=low,  DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0xD2);
        }
        else
        {
            //
            // CLK=low,  DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0xC2);
            //
            // CLK=high, DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0xE2);
            //
            // CLK=low,  DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0xC2);
        }
    }
    else
    {
        if ( ucData )
        {
            //
            // CLK=low,  DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0x11);
            //
            // CLK=high, DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0x31);
            //
            // CLK=low,  DATA=high
            //
            I2C_Out_INV(pcbe, pi2c, 0x11);
        }
        else
        {
            //
            // CLK=low,  DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0x01);
            //
            // CLK=high, DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0x21);
            //
            // CLK=low,  DATA=low
            //
            I2C_Out_INV(pcbe, pi2c, 0x01);
        }
    }

}

/****************************************************************
;   I2C_BitRead_INV
;
;   Reads in 1 bit from SDA via the GIP.
;
;   Input:
;
;   Output:
;       Bit 0 of return value contains bit read
;
;***************************************************************/
UCHAR 
I2C_BitRead_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);
    UCHAR ucRetval;

    //   CLK  _-R_
    //  Data  --R-
    if (GPIO == i2cType)
    {
        //
        //  CLK=low,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x82);
        //
        //  CLK=high,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0xA2);
        //
        //  now read in the data bit
        //
        ucRetval = (cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort) & 0x04) >> 2;
        //
        //  CLK=low,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x82);
    }
    else
    {
        //
        //  CLK=low,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x11);
        //
        //  CLK=high,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x31);
        //
        //  now read in the data bit
        //
        ucRetval = (cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort) & 0x04) >> 2;
        //
        //  CLK=low,  DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x11);
    }

    return (ucRetval);
}

/****************************************************************
;   I2C_ByteWrite_INV
;
;   Output a byte of information to the Display.
;
;   Input:
;       ucData = Byte to be written.
;
;   Output:
;       TRUE - write successfully
;       FALSE - write failure
;
;***************************************************************/
BOOL 
I2C_ByteWrite_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c,
    UCHAR ucData
    )
{
    UCHAR uOutData;
    int i;

    uOutData = ucData;

    //
    //  send MSB first
    //

    for (i=7; i >= 0; i--)
    {
        //
        //  move data bit to bit 1
        //

        uOutData = (ucData >> i)&0x01;
        I2C_BitWrite_INV(pcbe, pi2c, uOutData);
    }

    //
    //  float the data line high for ACK
    //
    return (TRUE);
}

/****************************************************************
;   I2C_ByteRead_INV
;
;   Read a byte of information from the Display
;
;   Input:
;
;   Output:
;       return value is the byte read
;
;***************************************************************/
UCHAR 
I2C_ByteRead_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    UCHAR ucRetval;
    int i;

    ucRetval = 0;
    for (i=0; i < 8; i++)
    {
        ucRetval <<= 1;
        ucRetval |= I2C_BitRead_INV(pcbe, pi2c);
    }

    return (ucRetval);

}

/****************************************************************
;   I2C_AckRead_INV
;
;   Send Acknowledgement when reading info.
;
;   Input:
;
;   Output:
;       True/False
;
;***************************************************************/
BOOL
I2C_AckRead_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    UCHAR Ack;

    if ( (pi2c->I2cPort != 0x26) && (pi2c->I2cPort != 0x31) &&
         (pi2c->I2cPort != 0x2C) && (pi2c->I2cPort != 0x3D) &&
         (pi2c->I2cPort != 0x25) )
    {
        return FALSE;
    }

    Ack = I2C_BitRead_INV(pcbe, pi2c);

    if (Ack ==0)
        return TRUE;
    else 
        return FALSE;
}

/****************************************************************
;   I2C_AckWrite_INV
;
;   Send Acknowledgement when reading info.
;
;   Input:
;
;   Output:
;
;***************************************************************/
void
I2C_AckWrite_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    I2C_BitWrite_INV(pcbe, pi2c, 0x00);
}

/****************************************************************
;   I2C_NackWrite_INV
;
;   Send Not ACKnowledgement when reading information.
;   A NACK is DATA high during one clock pulse.
;
;   Input:
;
;   Output:
;
;***************************************************************/
void 
I2C_NackWrite_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    I2C_BitWrite_INV(pcbe, pi2c, 0x01);
}

BOOL
I2C_Write_Word_INV(PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    BOOL   status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->IndexLOData); //Send Write Low Data
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->IndexHIData); //Send Write High Data
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_StopService_INV(pcbe, pi2c);

    return status;
}

BOOL 
I2C_Read_Word_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    UCHAR status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr+1); //Send Device Address + read

    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    pi2c->IndexLOData = I2C_ByteRead_INV(pcbe, pi2c);
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    pi2c->IndexHIData = I2C_ByteRead_INV(pcbe, pi2c);
    I2C_NackWrite_INV(pcbe, pi2c);

    I2C_StopService_INV(pcbe, pi2c);

    return status;

}

/****************************************************************
;   I2C_HWMasteringCR_WriteByte_INV
;
;   Use Hardware control to Write a byte of information from the Display
;
;   Input:
;
;   Output:
;***************************************************************/
BOOL I2C_HWMasteringCR_WriteByte_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
    BYTE   I2C_Port_Bits = 0x00;
    BOOL   status = TRUE;
    int    Retry_Times;

    //-----------------------------------------------
    //1. Write data index which we want to read
    //-----------------------------------------------
    
    //Initialization
    switch(pi2c->I2cPort)
    {
        case 0x31:          
            I2C_Port_Bits = 0x00;
            cbWriteRegByte(pcbe, SR_31, 0x00);
            break;
        case 0x26:          
            I2C_Port_Bits = BIT3;
            cbWriteRegByte(pcbe, SR_26, 0x00);
            break;
        case 0x2C:          
            I2C_Port_Bits = BIT2;
            cbWriteRegByte(pcbe, SR_2C, 0x00);
            break;
        /*
        case 0x25:
            I2C_Port_Bits = BIT2 + BIT3;
            break;
        */
        default:            
            status = FALSE;
            break;
    }
    cbWriteRegByte(pcbe, SR_64, BIT2 + BIT3 + BIT4);  //recover IIC status 
    cbWriteRegByte(pcbe, SR_63, BIT7);                // to reset I2C.
    cbWriteRegByte(pcbe, SR_63, 0x00);                // set SR63 bit 7 = 0
    cbReadRegByte(pcbe, SR_63);                       //read sr63 to reset sr62 data index. however, we do not need the data 
    
    //I2C Mode Control (SR60)
    cbWriteRegByte(pcbe, SR_60, BIT5 + BIT0);
    
    //I2C Host addr and r/w bit (SR61)
    cbWriteRegByte(pcbe, SR_61, pi2c->SlaveAddr & 0xFE);
    
    //I2C Host Data (SR62)
    cbWriteRegByte(pcbe, SR_62, pi2c->RegIndex);
    cbWriteRegByte(pcbe, SR_62, pi2c->IndexData);
    
    //I2C Host Control (SR63)
    cbWriteRegByte(pcbe, SR_63, BIT4 + I2C_Port_Bits + BIT0);
    
    //Check I2C status (SR64)
    for(Retry_Times = 0 ; Retry_Times < 10000; Retry_Times++)
    {
        //retry 10000 times, if SR64 bit3(data transfer done) or bit2(error) has been set as 1, break.
        if((cbReadRegByte(pcbe, SR_64) & (BIT3 + BIT2)) != 0)
            break; 
    }
    //check if abnormal status
    if((cbReadRegByte(pcbe, SR_64) & BIT2) != 0)
        status = FALSE;

    return status;

    
}

/****************************************************************
;   I2C_HWMasteringCR_ReadByte_INV
;
;   Use Hardware control to Read a byte of information from the Display
;
;   Input:
;
;   Output:
;       return value is the byte read
;
;***************************************************************/
BOOL I2C_HWMasteringCR_ReadByte_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c
    )
{
	BYTE   I2C_Port_Bits = 0x00;
    BOOL   status = TRUE;
    int    Retry_Times;

    //-----------------------------------------------
    //1. Write data index which we want to read
    //-----------------------------------------------
    
    //Initialization
    switch(pi2c->I2cPort)
    {
        case 0x31:          
            I2C_Port_Bits = 0x00;
            cbWriteRegByte(pcbe, SR_31, 0x00);
            break;
        case 0x26:          
            I2C_Port_Bits = BIT3;
            cbWriteRegByte(pcbe, SR_26, 0x00);
            break;
        case 0x2C:          
            I2C_Port_Bits = BIT2;
            cbWriteRegByte(pcbe, SR_2C, 0x00);
            break;
        /*
        case 0x25:
            I2C_Port_Bits = BIT2 + BIT3;
            break;
        */
        default:            
            I2C_Port_Bits = 0x00;
            cbWriteRegByte(pcbe, SR_31, 0x00);
            break;
    }
    cbWriteRegByte(pcbe, SR_64, BIT2 + BIT3 + BIT4);  //recover IIC status 
    cbWriteRegByte(pcbe, SR_63, BIT7);                // to reset I2C.
    cbWriteRegByte(pcbe, SR_63, 0x00);                // set SR63 bit 7 = 0
    cbReadRegByte(pcbe, SR_63);                       //read sr63 to reset sr62 data index. however, we do not need the data 

    //I2C Mode Control (SR60)
    cbWriteRegByte(pcbe, SR_60, BIT4 + BIT2 + BIT0);
    
    //I2C Host addr and r/w bit (SR61)
    cbWriteRegByte(pcbe, SR_61, pi2c->SlaveAddr & 0xFE);
    
    //I2C Host Data (SR62)
    cbWriteRegByte(pcbe, SR_62, pi2c->RegIndex);
    
    //I2C Host Control (SR63)
    cbWriteRegByte(pcbe, SR_63, BIT4 + I2C_Port_Bits + BIT0);

    //Check I2C status (SR64)
    for(Retry_Times = 0 ; Retry_Times < 10000; Retry_Times++)
    {
        //retry 10000 times, if SR64 bit3(data transfer done) or bit2(error) has been set as 1, break.
        if((cbReadRegByte(pcbe, SR_64) & (BIT3 + BIT2)) != 0)
            break; 
    }
    //check if abnormal status
    if((cbReadRegByte(pcbe, SR_64) & BIT2) != 0)
        status = FALSE;

    //-----------------------------------------------
    //2. read data
    //-----------------------------------------------
    //Initialization
    cbWriteRegByte(pcbe, SR_64, BIT2 + BIT3 + BIT4);  //recover IIC status 
    
    //I2C Mode Control (SR60)
    cbWriteRegByte(pcbe, SR_60, BIT4 + BIT0);
    
    //I2C Host addr and r/w bit (SR61)
    cbWriteRegByte(pcbe, SR_61, (pi2c->SlaveAddr & 0xFE) + BIT0);
    
    
    //I2C Host Control (SR63)
    cbWriteRegByte(pcbe, SR_63, BIT4 + I2C_Port_Bits + BIT0);

    //Check I2C status (SR64)
    for(Retry_Times = 0 ; Retry_Times < 10000; Retry_Times++)
    {
        //retry 10000 times, if SR64 bit3(data transfer done) or bit2(error) has been set as 1, break.
        if((cbReadRegByte(pcbe, SR_64) & (BIT3 + BIT2)) != 0)
            break; 
    }
    //check if abnormal status
    if((cbReadRegByte(pcbe, SR_64) & BIT2) != 0)
        status = FALSE;


    pi2c->IndexData= cbReadRegByte(pcbe, SR_62);
    
    return status;
    
}

BOOL
I2C_SWCR_WriteByte_INV(PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    BOOL   status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->IndexData); //Send Write Data
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_StopService_INV(pcbe, pi2c);

    return status;
}

BOOL 
I2C_SWCR_ReadByte_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    UCHAR status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr+1); //Send Device Address + read

    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    pi2c->IndexData= I2C_ByteRead_INV(pcbe, pi2c);
    I2C_NackWrite_INV(pcbe, pi2c);

    I2C_StopService_INV(pcbe, pi2c);

    return status;

}

BOOL
I2C_Write_Byte_INV(PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    //if I2C port is 31,26 or 2C, use hardware mastering control.
    if((pi2c->I2cPort==0x31 || pi2c->I2cPort==0x26 || pi2c->I2cPort==0x2C) && (pcbe->ChipCaps.I2C_HWMasteringCR_Mode == TRUE))
        return I2C_HWMasteringCR_WriteByte_INV(pcbe, pi2c);
    else
        return I2C_SWCR_WriteByte_INV(pcbe, pi2c);
}

BOOL 
I2C_Read_Byte_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    //if I2C port is 31,26 or 2C, use hardware mastering control.
    if((pi2c->I2cPort==0x31 || pi2c->I2cPort==0x26 || pi2c->I2cPort==0x2C) && (pcbe->ChipCaps.I2C_HWMasteringCR_Mode == TRUE))
        return I2C_HWMasteringCR_ReadByte_INV(pcbe, pi2c);
    else
        return I2C_SWCR_ReadByte_INV(pcbe, pi2c);
}

BOOL I2C_Write_Bit_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, BYTE Mask)
{
    BYTE dataold,datanew;
    BYTE status = TRUE;
    datanew = (pi2c->IndexData)&Mask;
    status = (BYTE)I2C_Read_Byte_INV(pcbe,pi2c);
    if(status==TRUE)
    {
        dataold = pi2c->IndexData;
        dataold &= ~Mask;
        datanew |= dataold;
        pi2c->IndexData = datanew;
        status = (BYTE)I2C_Write_Byte_INV(pcbe,pi2c);
    }
    return status;
}

BOOL 
I2C_Write_DDCBus_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c
    )
{
    UCHAR status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    return status;
}

/****************************************************************
;   I2C_HWMasteringCR_Data_Request_INV
;
;   Setup Display to query EDID or VDIF information depending
;   upon the offset given. 
;
;   Input:
;       ucWriteAddr Write Address of info
;       Length      Length to read,
;       Flags       VERIFY_CHECKSUM
;       pBuffer     pointer to buffer to receive data
;
;   Output:
;       TRUE    successful read
;       FALSE   read failure or bad checksum
;
;****************************************************************/
UCHAR 
I2C_HWMasteringCR_Data_Request_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    )
{
    UCHAR ucData, Count;
    UCHAR ucCheckSum = 0, status = TRUE;
    ULONG blocknum;
    
    if(Flags & DATA_FETCH_DELAY)
    {
        cbDelayMicroSeconds(20);
    }

    //  ---------------------- read I2C data -----------------------------
    switch(pi2c->SlaveAddr)
    {
    case 0xA0:
        // EDID 1.x : 128 byte 1 block, every block do check sum
        for (blocknum = 0; blocknum < (Length >> 7); blocknum++)
        {
            ucCheckSum = 0;
            // first 127 byte
            for (Count = 0; Count < 127; Count++)
            {
                pi2c->RegIndex = Count;
                if(!I2C_Read_Byte_INV(pcbe, pi2c))
                    status = FALSE;
                ucData = pi2c->IndexData;
                *pBuffer++ = ucData;
                ucCheckSum += ucData;
            }

            // For AD9389 TX, we must read full 128 byte in one sequential reading,
            // If not, it will fail when restart(stop and start) iic to read next 128 byte.
            pi2c->RegIndex = 127;
            if(!I2C_Read_Byte_INV(pcbe, pi2c))
                status = FALSE;
            ucData = pi2c->IndexData;
            //if vbios support correct fail EDID checksum
            if(Flags & CORRECT_FAIL_EDID)
            {
                ucData = 0xff - ucCheckSum + 1;
            }
            
            *pBuffer++ = ucData;
            ucCheckSum += ucData;
            
            // last byte of the block do check sum 
            // if not right , NACK, stop transmission
            if (Flags & VERIFY_CHECKSUM)
            {
                // wrong checksum
                if (ucCheckSum != 0)
                {
                    return FALSE;     
                }
            }
        }

        // if user pass buffer size is not a 128*n length
        // last bytes less than 1 block so do not check sum
        if ((Length & 0x7F) != 0)
        {
            for (Count = 0; Count < (Length & 0x7F) ; Count++)
            {
                pi2c->RegIndex = Count;
                if(!I2C_Read_Byte_INV(pcbe, pi2c))
                    status = FALSE;
                ucData = pi2c->IndexData;
                *pBuffer++ = ucData;
            }
        }

        break;

    case 0xA2:
    case 0xA6:
         // EDID 2.0 : 256 byte 1 block, here we read only one block 
         for (Count = 0; Count < Length ; Count++)
         {
             pi2c->RegIndex = Count;
             if(!I2C_Read_Byte_INV(pcbe, pi2c))
                    status = FALSE;
             ucData = pi2c->IndexData;
             *pBuffer++ = ucData;
             ucCheckSum += ucData;
         }

         if (Flags & VERIFY_CHECKSUM)
         {
             if (ucCheckSum != 0)
             {
                 return FALSE;     // bad checksum
             }
         }
         break;

    default:
         // this function not only for EDID get but DDC/CI data and DDC status
         // check
         for (Count = 0; Count < Length; Count++)
         {
             pi2c->RegIndex = Count;
             if(!I2C_Read_Byte_INV(pcbe, pi2c))
                    status = FALSE;
             ucData = pi2c->IndexData;
             *pBuffer++ = ucData;
             ucCheckSum += ucData;
         }
         
         if (Flags & VERIFY_CHECKSUM)
         {
             if (ucCheckSum != 0)
             {
                 return FALSE;     // bad checksum
             }
         }
         break;                
    }
    
    return status;
}

/****************************************************************
;   I2C_DATA_Request_INV
;
;   Setup Display to query EDID or VDIF information depending
;   upon the offset given. 
;
;   Input:
;       ucWriteAddr Write Address of info
;       Length      Length to read,
;       Flags       VERIFY_CHECKSUM
;       pBuffer     pointer to buffer to receive data
;
;   Output:
;       TRUE    successful read
;       FALSE   read failure or bad checksum
;
;****************************************************************/
UCHAR 
I2C_SWCR_Data_Request_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    )
{
    UCHAR ucData;
    UCHAR ucCheckSum = 0;
    ULONG blocknum, Count;

    // 1.----------------------- start I2C read ---------------------------
    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        return FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
    {
        I2C_StopService_INV(pcbe, pi2c);
        return FALSE;
    }   

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
    {
        I2C_StopService_INV(pcbe, pi2c);
        return FALSE;
    }
    
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr+1); //Send Device Address + read

    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
    {
        I2C_StopService_INV(pcbe, pi2c);
        return FALSE;
    }
    
    if(Flags & DATA_FETCH_DELAY)
    {
        cbDelayMicroSeconds(20);
    }

    // 2. ---------------------- read I2C data -----------------------------
    switch(pi2c->SlaveAddr)
    {
    case 0xA0:
        // EDID 1.x : 128 byte 1 block, every block do check sum
        for (blocknum = 0; blocknum < (Length >> 7); blocknum++)
        {
            ucCheckSum = 0;
            // first 127 byte
            for (Count = 0; Count < 127; Count++)
            {
                ucData= I2C_ByteRead_INV(pcbe, pi2c);
                I2C_AckWrite_INV(pcbe, pi2c);
                *pBuffer++ = ucData;
                ucCheckSum += ucData;
            }

            // For AD9389 TX, we must read full 128 byte in one sequential reading,
            // If not, it will fail when restart(stop and start) iic to read next 128 byte.
            ucData = I2C_ByteRead_INV(pcbe, pi2c);
            // if vbios support correct fail EDID checksum
            if(Flags & CORRECT_FAIL_EDID)
            {
                ucData = 0xff - ucCheckSum + 1;
            }

            *pBuffer++ = ucData;
            ucCheckSum += ucData;
            
            // last byte of the block do check sum 
            // if not right , NACK, stop transmission
            if (Flags & VERIFY_CHECKSUM)
            {
                // wrong checksum
                if (ucCheckSum != 0)
                {
                    // Nack stop I2C transaction & return
                    I2C_NackWrite_INV(pcbe, pi2c);
                    I2C_StopService_INV(pcbe, pi2c);
                    return FALSE;     
                }
            }
        }

        // if user pass buffer size is not a 128*n length
        // last bytes less than 1 block so do not check sum
        if ((Length & 0x7F) != 0)
        {
            for (Count = 0; Count < (Length & 0x7F) - 1; Count++)
            {
                ucData= I2C_ByteRead_INV(pcbe, pi2c);
                I2C_AckWrite_INV(pcbe, pi2c);
                *pBuffer++ = ucData;
            }
            ucData= I2C_ByteRead_INV(pcbe, pi2c);
            *pBuffer = ucData;
        }
        
        // if I2C read success stop the I2C transaction 
        I2C_NackWrite_INV(pcbe, pi2c);
        I2C_StopService_INV(pcbe, pi2c);
        break;

    case 0xA2:
    case 0xA6:
         // EDID 2.0 : 256 byte 1 block, here we read only one block 
         for (Count = 0; Count < Length - 1; Count++)
         {
             ucData= I2C_ByteRead_INV(pcbe, pi2c);
             I2C_AckWrite_INV(pcbe, pi2c);
             *pBuffer++ = ucData;
             ucCheckSum += ucData;
         }
         // last byte NACK, stop transmission
         ucData= I2C_ByteRead_INV(pcbe, pi2c);
         I2C_NackWrite_INV(pcbe, pi2c);
         I2C_StopService_INV(pcbe, pi2c);
         *pBuffer = ucData;
         ucCheckSum += ucData;

         if (Flags & VERIFY_CHECKSUM)
         {
             if (ucCheckSum != 0)
             {
                 return FALSE;     // bad checksum
             }
         }
         break;

    default:
         // this function not only for EDID get but DDC/CI data and DDC status
         // check
         for (Count = 0; Count < Length-1; Count++)
         {
             ucData= I2C_ByteRead_INV(pcbe, pi2c);
             I2C_AckWrite_INV(pcbe, pi2c);
             *pBuffer++ = ucData;
             ucCheckSum += ucData;
         }
         // last byte NACK, stop transmission
         ucData= I2C_ByteRead_INV(pcbe, pi2c);
         I2C_NackWrite_INV(pcbe, pi2c);
         *pBuffer = ucData;
         ucCheckSum += ucData;
         I2C_StopService_INV(pcbe, pi2c);
         
         if (Flags & VERIFY_CHECKSUM)
         {
             if (ucCheckSum != 0)
             {
                 return FALSE;     // bad checksum
             }
         }
         break;                
    }
    
    return TRUE;

}

/****************************************************************
;   I2C_DATA_Request_INV
;
;   Setup Display to query EDID or VDIF information depending
;   upon the offset given. 
;
;   Input:
;       ucWriteAddr Write Address of info
;       Length      Length to read,
;       Flags       VERIFY_CHECKSUM
;       pBuffer     pointer to buffer to receive data
;
;   Output:
;       TRUE    successful read
;       FALSE   read failure or bad checksum
;
;****************************************************************/
UCHAR 
I2C_Data_Request_INV (PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    )
{
    //if I2C port is 31,26 or 2C, use hardware mastering control.
    if((pi2c->I2cPort==0x31 || pi2c->I2cPort==0x26 || pi2c->I2cPort==0x2C) && (pcbe->ChipCaps.I2C_HWMasteringCR_Mode == TRUE))
        return I2C_HWMasteringCR_Data_Request_INV(pcbe, pi2c, Length, Flags, pBuffer);
    else
        return I2C_SWCR_Data_Request_INV(pcbe, pi2c, Length, Flags, pBuffer);
}

/****************************************************************
;   I2C_StopService_INV
;
;   Provide stop sequence to the I2C bus.
;
;   Input:
;
;   Output:
;
;***************************************************************/
void I2C_StopService_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);

    if((pi2c->Flags & SIL9022_BURST_READ))
        return;
    //   CLK  _--_
    //  Data  __--
    if (GPIO == i2cType)
    {
        //
        //  CLK=low, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0xC0);
        //
        //  CLK=high, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0xE0);
        //
        //  CLK=high, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0xF0);
    }
    else
    {
        //
        //  CLK=low, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0x01);
        //
        //  CLK=high, DATA=low
        //
        I2C_Out_INV(pcbe, pi2c, 0x21);
        //
        //  CLK=high, DATA=high
        //
        I2C_Out_INV(pcbe, pi2c, 0x31);
        //
        //  CLK=low, DATA=high
        //
        //I2C_Out_INV(pcbe, pi2c, 0x11);
    }

}

/****************************************************************
;   I2C_DATA_Update_INV
;
;   Setup Display to update information depending
;   upon the offset given.
;
;   Input:
;       ucWriteAddr Write Address of info
;       Length      Length to read,
;       Flags       
;       pBuffer     pointer to buffer to receive data
;
;   Output:
;       TRUE    successful read
;       FALSE   read failure or bad checksum
;
;****************************************************************/
UCHAR 
I2C_Data_Update_INV (
    PCBIOS_EXTENSION pcbe,
    PI2C_CONTROL_UMA pi2c,
    ULONG   Length,
    ULONG   Flags,
    UCHAR   *pBuffer
    )
{
    ULONG Count;
    UCHAR status=TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status =  FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
        
    //I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    //if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
    //    status = FALSE;

    if(status)
    {
        for (Count = 0; Count < Length; Count++)
        {
            I2C_ByteWrite_INV(pcbe, pi2c, pBuffer[Count]);
            if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
                status = FALSE;
        }

        I2C_StopService_INV(pcbe, pi2c);
    }

    return status;
}

/****************************************************************
;   I2C_Write_Byte_InVBI_INV
;
;   wait  vertical blank and write a Byte in case of TV jiggle .
;
;****************************************************************/

BOOL I2C_Write_Byte_InVB_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    BOOL status = TRUE;

    if(I2C_SetDDC2_INV(pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    // Wait vblank.
    if(S3_TV == pcbe->IGA1Info.dispDev)
    {
        cbWaitVBlank(pcbe, IGA1);
    }
    else if (S3_TV == pcbe->IGA2Info.dispDev)
    {
        cbWaitVBlank(pcbe, IGA2);
    }

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->IndexData); //Send Write Data
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_StopService_INV(pcbe, pi2c);

    return status;
}

/****************************************************************
;   I2C_Write_Buf_INV
;
;   write buf of data to device
;
;****************************************************************/
BOOL I2C_Write_Buf_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, BYTE *pBuf, DWORD len)
{
    BOOL status = TRUE;
    DWORD i;

    if(I2C_SetDDC2_INV( pcbe, pi2c) == FALSE)
        status = FALSE;
    I2C_StartService_INV(pcbe, pi2c);

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->SlaveAddr); //Send Device Address + write
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    I2C_ByteWrite_INV(pcbe, pi2c, pi2c->RegIndex); //Send Write Address
    if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
        status = FALSE;

    for (i = 0; i < (len-1); i++)
    {                   
        I2C_ByteWrite_INV(pcbe, pi2c, pBuf[i]); //Send Write Data
        if(I2C_AckRead_INV(pcbe, pi2c) == FALSE)
            status = FALSE;
    }

    I2C_ByteWrite_INV(pcbe, pi2c, pBuf[len-1]); //Send last Write Data
    I2C_NackWrite_INV(pcbe, pi2c);

    I2C_StopService_INV(pcbe, pi2c);

    return status;
}

/****************************************************************
;below two functions are used to convert I2C portnum to I2C busnum or convert 
;I2C busnum to portnum, the mapping rule is referred to VBIOS external interface
;spec for Deltachrome IGP, int 10 4f14 00
****************************************************************/
BOOL cbConvert_I2CPortNum_to_I2CBusNum(OUT PBYTE BusNum,IN BYTE portnum)
{
        switch(portnum)
    {
        case 0x26:
            *BusNum = I2CBUS0;
            break;
        case 0x2C:
            *BusNum = I2CBUS1;
            break;
        case 0x31:
            *BusNum = I2CBUS2;
            break;
        case 0x3D:
            *BusNum = I2CBUS3;
            break;
        case 0x25:
            *BusNum = I2CBUS4;
            break;
        default:
            *BusNum = I2CBUSNULL;
            return FALSE;
    }
    return TRUE;
}


BOOL cbConvert_I2CBusNum_to_I2CPortNum(IN BYTE BusNum,OUT BYTE *portnum)
{
    if(BusNum > MAXI2CBUSNUM)
    {
        return FALSE;
    }    
    switch(BusNum)
    {
        case I2CBUSNULL:
            return FALSE;
        case I2CBUS0:
            *portnum = 0x26;
            break;
        case I2CBUS1:
            *portnum = 0x2C;
            break;
        case I2CBUS2:
            *portnum = 0x31;
            break;
        case I2CBUS3:
            *portnum = 0x3D;
            break;
        case I2CBUS4:
            *portnum = 0x25;
            break;
        default:
            *portnum = 0x26;
            break;
    }
    return TRUE;
}

/****************************************************************
;  cbDDCCI_I2C_Stop_INV
;
; This function is required by DDC/CI operation,corresponding to 
; DDC/CI command RESET
;    IN:
;         pcbe
;         pi2c
;    
;    OUT:
;          status     
****************************************************************/

ULONG 
cbDDCCI_I2C_Stop_INV(PCBIOS_EXTENSION pcbe, 
    PI2C_CONTROL_UMA pi2c
    )
{
    I2C_NackWrite_INV(pcbe,pi2c);
    
    I2C_StopService_INV(pcbe, pi2c);

    return CBI2C_STATUS_NOERROR;
}

/****************************************************************
;  cbDDCCI_I2C_Null_INV
;
; This function is required by DDC/CI operation,corresponding to 
; DDC/CI command NULL
;    IN:
;         pcbe
;         Flags
;         pi2c
;    
;    OUT:
;          status     
****************************************************************/

ULONG 
cbDDCCI_I2C_Null_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    )
{
    if(Flags & CBI2C_FLAGS_DATACHAINING)
    {
        I2C_StopService_INV(pcbe,pi2c);

        I2C_StartService_INV(pcbe,pi2c);
    }

    if(Flags & CBI2C_FLAGS_START)
    {
        I2C_StartService_INV(pcbe,pi2c);
    }

    if(Flags & CBI2C_FLAGS_STOP)
    {
        I2C_StopService_INV(pcbe,pi2c);
    }

    return CBI2C_STATUS_NOERROR;
}

/****************************************************************
;  cbDDCCI_I2C_Read_INV
;
; This function is required by DDC/CI read operation,corresponding to 
; DDC/CI command READ
;    IN:
;         pcbe
;         Flags
;         pi2c
;    
;    OUT:
;          status     
****************************************************************/

ULONG 
cbDDCCI_I2C_Read_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    )
{
    if(Flags & CBI2C_FLAGS_DATACHAINING)
    {
        I2C_StopService_INV(pcbe,pi2c);

        I2C_StartService_INV(pcbe,pi2c);
    }

    if(Flags & CBI2C_FLAGS_START)
    {
        I2C_StartService_INV(pcbe,pi2c);
    }

    pi2c->IndexData = I2C_ByteRead_INV(pcbe,pi2c);

    if(Flags & CBI2C_FLAGS_ACK)
    {
        I2C_AckWrite_INV(pcbe,pi2c);
    }

    if(Flags & CBI2C_FLAGS_STOP)
    {
        I2C_StopService_INV(pcbe,pi2c);
    }

    return CBI2C_STATUS_NOERROR;
}

/****************************************************************
;  cbDDCCI_I2C_Write_INV
;
; This function is required by DDC/CI write operation,corresponding to 
; DDC/CI command WRITE
;    IN:
;         pcbe
;         Flags
;         pi2c
;    
;    OUT:
;          status     
****************************************************************/

ULONG 
cbDDCCI_I2C_Write_INV(PCBIOS_EXTENSION pcbe, 
    ULONG Flags, 
    PI2C_CONTROL_UMA pi2c
    )
{
    if(Flags & CBI2C_FLAGS_DATACHAINING)
    {
        I2C_StopService_INV(pcbe,pi2c);

        I2C_StartService_INV(pcbe,pi2c);
    }

    if(Flags & CBI2C_FLAGS_START)
    {
        I2C_StartService_INV(pcbe,pi2c);
    }

    I2C_ByteWrite_INV(pcbe,pi2c,pi2c->IndexData);
    
    if(I2C_AckRead_INV(pcbe,pi2c) == FALSE)  
    {
        return CBI2C_STATUS_ERROR;
    }
    
    if(Flags & CBI2C_FLAGS_STOP)
    {
        I2C_StopService_INV(pcbe,pi2c);
    }

    return CBI2C_STATUS_NOERROR;
}

/****************************************************************
;  cbDDCCI_I2C_Enable_INV
;    To enable I2C bus by write 0x31 to I2C port,
;  or write 0xC0 to GPIO
;      IN:
;            pi2c,pcbe
;    
;       OUT:
;            status     
****************************************************************/
ULONG cbDDCCI_I2C_Enable_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);
    UCHAR temp;
    ULONG status = CBI2C_STATUS_NOERROR;

    temp = cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort);

    if (GPIO == i2cType)
    {
        temp |= 0xC0;           //GPIO bit[7:6]=1   
    }
    else
    {
        temp |= 0x31;           //I2C bit[5:4&0]=1
    }
    
    cbWriteRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort,temp);

    return status;
}

/****************************************************************
;  cbDDCCI_I2C_Disable_INV
;
; To disable I2C bus by write I2C port,or write GPIO
;    IN:
;         pi2c,pcbe
;    
;    OUT:
;          status     
****************************************************************/
ULONG cbDDCCI_I2C_Disable_INV(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    I2C_PORT_TYPE i2cType = IsI2CGPIO(pi2c->I2cPort);
    UCHAR temp;
    ULONG status = CBI2C_STATUS_NOERROR;

    temp = cbReadRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort);

    if (GPIO == i2cType)
    {
        temp &= 0x3F;           //GPIO bit[7:6]=0  
    }
    else
    {
        temp &= 0xCE;           // I2C bit[5:4&0]=0
    }
    
    cbWriteRegByte(pcbe, (ZSR<<8) + pi2c->I2cPort,temp);

    return status;
}

//---------------------------------------------------------------------------
//
//  PROCEDURE:      ConvertRRValuetoRRIndex_CSR
//  BIOS need refresh rate index, referred the BIOS Specification and 
//  translated the correct refresh rate index.
//
//  
//---------------------------------------------------------------------------
ULONG
ConvertRRValuetoRRIndex_CSR(ULONG Frequency)
{
    ULONG Index=0; 
    
    switch (Frequency)
    {
        case  60:
            Index = 0x00;
            break;
        case  56:
            Index = 0x01;
            break;
        case  65:
            Index = 0x02;
            break;
        case  70:
            Index = 0x03;
            break;
        case  72:
            Index = 0x04;
            break;
        case  75:
            Index = 0x05;
            break;
        case  80:
            Index = 0x06;
            break;
        case  85:
            Index = 0x07;
            break;
        case  90:
            Index = 0x08;
            break;
        case  100:
            Index = 0x09;
            break;
        case  120:
            Index = 0x0a;
            break;
        case  86:
            Index = 0x0b;
            break;
        case  94:
            Index = 0x0c;
            break;
        case  50:
            Index = 0x0d;
            break;
        case  30:
            Index = 0x0e;
            break;
        case  25:
            Index = 0x0f;
            break;
        default:
            // unknown refresh rate
            //cbDbgPrint(0,"S3: Unknown Refresh Rate 0x%lx\n", Frequency);
            break;
             
    }
     return (Index);
}

//-----------------------------------------------------------------------
// cbRoundDown
//    This function returns value round down to the nearest integer. Now the
// funtion is used in CVT timing caculation function/
//  IN:
//      
//  OUT:
//      round dow value returned
//-----------------------------------------------------------------------
ULONG cbRoundDown(
    IN ULONG dividend, 
    IN ULONG divisor)
{
    ULONG ulRet = 0;
    ULONG ulRemainder = 0;

    ulRemainder = dividend%divisor;
    ulRet = dividend/divisor;
    
    if(ulRemainder != 0)
    {
       if(2*ulRemainder >= divisor) 
       {
            ulRet = ulRet + 1;
       }
    }
    return ulRet;
}

//-----------------------------------------------------------------------
// cbGetLowestBitPos
//    This function get lowest bit position number of x
//    ex: x=16=10000b, lowest bit is bit 4, so return 4;
//        x= 1=    1b, lowest bit is bit 0, so return 0;
//        x=20=10100b, lowest bit is bit 2, so return 2;
//-----------------------------------------------------------------------
DWORD cbGetLowestBitPos(IN DWORD x)
{
    int i;
    ASSERT(x != 0);

    for (i=0; i<(sizeof(DWORD)<<3); i++)
    {
        if (x & _BIT(i))
        {
            return i;
        }
    }
    return 0;
}

//------------------------------------------------------------------------
// cbGetVsyncWidth
//    This function returns V sync duration time according to input X, Y resolution
//  size. This function references CVT excel file, but we can not find such 
//  limitation in CVT standard.
//  IN :
//      XRes : X resolution size
//      YRes : Y resolution size
//  OUT :
//      returned V sync width
//------------------------------------------------------------------------
ULONG cbGetVsyncWidth(
    IN ULONG XRes,
    IN ULONG YRes)
{
    ULONG ulRet = 10;
    ULONG ulTemp = 0;

    if (0 == YRes)
    {
        return 0;
    }

    ulTemp = XRes*100/YRes;
    if((ulTemp<134)&&(ulTemp>132))
    {
        ulRet = 4;
    }
    else if((ulTemp<178)&&(ulTemp>176))
    {
        ulRet = 5;
    }
    else if((ulTemp<161)&&(ulTemp>159))
    {
        ulRet = 6;    
    }
    else if((ulTemp<126)&&(ulTemp>125))
    {
        ulRet = 7;
    }
    else if((ulTemp<167)&&(ulTemp>165))
    {
        ulRet = 7;
    }
    else
    {
        ulRet = 10;
    }
    return ulRet;
}

#if DBG
//--------------------------------------------------------------------------
//  cbDbgPrintNull
//      This function do nothing but just return, for prevent driver
//  pass null function pointer to CBIOS to use
//--------------------------------------------------------------------------
void cbDbgPrintNull(IN ULONG DebugPrintLevel, IN LPSTR DebugMessage, ...)
{
    return;
}
#endif

void cbDelayNull(IN int time)
{
    return;
}

void cbSleepNull(IN int time)
{
    return;
}

#if LINUX_PLATFORM
DWORD ReadMMIOUlong(PUCHAR RegOffset)
{
    return *(PULONG)(RegOffset);
}

void WriteMMIOUlong(PUCHAR RegOffset, DWORD data)
{
    *(PULONG)(RegOffset) = data;
}
#endif

void cbWriteMMIOUlongBits(PCBIOS_EXTENSION pcbe, DWORD MMIOIndex, DWORD mask, DWORD data)
{
    DWORD regData;
    regData = (ReadMMIOUlong(CB_MMIO_OFFSET(MMIOIndex)) & ~mask) | (data & mask);
    WriteMMIOUlong(CB_MMIO_OFFSET(MMIOIndex), regData);
}

