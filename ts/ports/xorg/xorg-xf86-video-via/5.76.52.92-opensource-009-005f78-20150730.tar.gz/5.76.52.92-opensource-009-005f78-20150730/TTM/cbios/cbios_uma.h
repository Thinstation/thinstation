/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _CBIOS_UMA_NEW_H_
#define _CBIOS_UMA_NEW_H_
#if defined (__linux__)
#include "cbios_type.h"
#define CBIOSAPI
#define LINUX_PLATFORM TRUE
#else

#ifdef DOSDLL
#include "..\CbiosDosDll\cbiosdlltypes.h"
#define CBIOSAPI    __declspec(dllexport)
#else
#include "cbios_type.h"
#define CBIOSAPI        __cdecl
#endif
#define LINUX_PLATFORM FALSE
#endif

// for EFI_CBIOS build
#ifdef _EFI_GOP_H_
#define EFI_CBIOS TRUE
#else
#define EFI_CBIOS FALSE
#endif

//****************************************************************
//  CBios interface define:
//      VBE defines
//      Interface function prototype and parameter defines
//      CBIOS_EXTENSION defines
//
//******************************************************************************

#if EFI_CBIOS
//disable warning C4201 to skip UEFI compiler error
//warning C4201: nonstandard extension used : nameless struct/union
#pragma warning(disable : 4201)
#endif

//******************************************************************************
//
// General register definition
//
#define PCI_ID_VT3264       0x3224
#define PCI_ID_VT3293       0x3225  // H5
#define PCI_ID_VT3336       0x3230  // H5S1
#define PCI_ID_VT3364       0x3371  // H5S1 intel version
#define PCI_ID_VT3353       0x1122  // H6S2
#define PCI_ID_VT3382       0x2122  // K8 H5S2VP
#define PCI_ID_VT3394_3405  0x4122  // P4 H5S2VP
#define PCI_ID_VT3409       0x5124  // Cn H62V1P
#define PCI_ID_VT3409P      0x5122  // H6S1P
#define PCI_ID_VT3410       0x7122  // H5S2VP1
#define PCI_ID_VT3324       0x3157

//******************************************************************************

//******VBE defines
#define VBE_STATUS_NOT_SUPPORTED         0x0000
#define VBE_STATUS_SUCCESSFUL            0x004F
#define VBE_STATUS_FAILED                0x014F

#define IGA1        0
#define IGA2        1
#define IGA1_IGA2   2
#define NO_IGA      0xFF

#define ROM_SCAN_SIZE 0x10000

#define CENTER_SUPPORTED        0x01
#define UPSCALER_SUPPORTED      0x02    //IF NOT SUPPORT UPSCALE, THIS BIT IS 0

#define UPSCALER_NOT_PREFERRED      0x01   //CENTER
#define UPSCALER_PREFERRED          0x02   //UPSCALE
#define UPSCALER_KEEP_ASPECT_RATIO  0x04

typedef struct _CBREGISTER
{
    BYTE    type;
    BYTE    mask;
    BYTE    index;
    BYTE    value;
} CBREGISTER, *PCBREGISTER;

//******CBIOS_EXTENSION defines

typedef struct _RefreshRateInfo
{
    DWORD rRateX100;
    DWORD interlaced;
}RefreshRateInfo, *PRefreshRateInfo;

// ScaleType
typedef enum {
    ST_NONE = 0x00,
    ST_UPSCALE,
    ST_DOWNSCALE,
} ScaleType;

typedef struct _ScaleFactor
{
    WORD    HScaleFactor;           // Horizontal Scaling Factor
    WORD    VScaleFactor;           // Vertical Scaling Factor
} ScaleFactor, *PScaleFactor;

typedef struct _IGA_Scale_Info
{
    BOOL bNeedUpScale;
    BOOL bNeedDownScale;
    ScaleFactor mScaleFactor;
}IGAScaleInfo, *pIGAScaleInfo;

// IGA related info, for CBIOS new interface
typedef enum _POWER_NOW_STATE
{
    POWER_NOW_OFF,    // power now off
    POWER_NOW_ON      // power now on
} POWER_NOW_STATE;

typedef enum _POWER_NOW_CONDITION
{
    VB_ONLY,    // Vertical Blanking only
    VB_FIFO      // Vertical Blanking + FIFO
} POWER_NOW_CONDITION;

typedef enum _EDID_MONITOR_TYPE
{
    EDID_ANALOG         = 0,
    EDID_DIGITAL        = 1,
    EDID_DONT_CARE      = 2
}EDID_MONITOR_TYPE, *PEDID_MONITOR_TYPE;

typedef struct _IGA_Info
{
    DWORD   dispDev;
    
    // these are used to record src mode info
    DWORD   HRes;
    DWORD   VRes;
    DWORD   ColorDepth;

    // these are used to record target timing info
    DWORD   HTotal;                    
    DWORD   VTotal;
    DWORD   HDisEnd;
    DWORD   VDisEnd;
    RefreshRateInfo RRateInfo;
    DWORD   vPLL;

    // real target resolution
    DWORD   TargetHRes;
    DWORD   TargetVRes;

    BOOL    ScreenOnOffState;

    DWORD   IGAUpScalerCaps;
    DWORD   curUpScalerState;         // current up saler setting on IGA
    ScaleFactor curScaleFactor;       // current iga scale factor
    
    BOOL    bCurrentModeNeedUpScaler; // whether current need to use upscaler, it's false if current mode is fit mode.
    BOOL    bCurrentModeNeedDownScaler; // whether current need to use downscaler, it's false if current mode is fit mode.
    
    POWER_NOW_STATE    PowerNowState;
    POWER_NOW_CONDITION PowerNowCondition;
} IGA_Info, *PIGA_Info;

// this structure is used for CBIOS to handle utilty 
// adjust TV requirment
typedef struct _TVParameter
{
    LONG    CurContrast;
    LONG    DefaultContrast;
    LONG    CurSaturation;
    LONG    DefaultSaturation;
    LONG    CurHueAngle;
    LONG    DefaultHueAngle;
    LONG    CurBrightness;
    LONG    DefaultBrightness;
    LONG    CurHPosition;
    LONG    DefaultHPosition;
    LONG    CurVPosition;    
    LONG    DefaultVPosition;
    LONG    CurHContraction;
    LONG    DefaultHContraction;
    LONG    CurVContraction;
    LONG    DefaultVContraction;
    LONG    CurDeflickerFliterStatus;
    LONG    DefaultDeflickerFliterStatus;
} TVParameter;

typedef struct _CBIOS_QUERYCAPS
{
    /* NOTICE: this struct must sync with driver!!!!*/
    union
    {
    	struct {
            DWORD    DP2_RequireDetaiTiming          : 1;
            DWORD    BiosControlCMOSCallBack         : 1;
            DWORD    PanelUseInternelPWM             : 1;
            DWORD    HdmiOnlySupport720P             : 1;
            DWORD    RecognizeAsEDPConnect           : 1;
            // add your new caps before here...
            // if you add a new cap bit, please modify the Reserved bits length
            DWORD    Reserved                        : 27;
        }CapsBits;

        DWORD CapsValue;
    };
} CBIOS_QUERYCAPS, * PCBIOS_QUERYCAPS;


//*****************************************************************************
//
// EDID related structure
//
//*****************************************************************************
typedef struct _CBIOS_S3MODE_INFO {
    WORD XResolution;
    WORD YResolution;
    WORD rrateX100;
    BOOL Valid;
}CBIOS_S3MODE_INFO;


// EDID detailed timing info structure after EDID parse 
typedef struct _EDID_DETAILEDTIMING_INFO {
    WORD XResolution;
    WORD YResolution;
    WORD HActive;
    WORD VActive;
    WORD HBlank;
    WORD HSyncOffset;
    WORD HSyncPulseWidth;
    WORD VBlank;
    WORD VSyncOffset;
    WORD VSyncPulseWidth;
    WORD HImageSize;
    WORD VImageSize;
    DWORD PLL_MRN;          // clock in PLL MRN format
    WORD rRateX100;
    BOOL Valid;
    BYTE HBorder;
    BYTE VBorder;           
    BYTE Interlaced;
    BYTE VPolarity;         // 0 = positive, 1 = negative
    BYTE HPolarity;         // 0 = positive, 1 = negative
    BYTE AspectRatio;
}EDID_DETAILEDTIMING_INFO, *PEDID_DETAILEDTIMING_INFO;

typedef struct _CBIOS_SHORTVIDEO_DESCRIPTOR{
    BYTE SVD;
    BYTE IsNativeMode;
}CBIOS_SHORTVIDEO_DESCRIPTOR, *PCBIOS_SHORTVIDEO_DESCRIPTOR;

typedef struct _CBIOS_CEA861_MISC_ATTRIB
{
    BOOL   IsHDMIDevice;
    BOOL   IsSupportBasicAudio;
    BOOL   IsCEA861Monitor;
    BOOL   IsSupportUnderScan;
    BOOL   IsSupportYCbCr444;
    BOOL   IsSupportYCbCr422;  
    ULONG  TotalNumberOfNativeFormat;
    BYTE   Tag;
    BYTE   RevisionNumber;
    BYTE   OffsetOfDetailedTimingBlock;
}CBIOS_CEA861_MISC_ATTRIB, *PCBIOS_CEA861_MISC_ATTRIB;

#define EDID1X_BLOCK0_MAX_DTD_NUM  4

// only 5 bits for Video Block Payload.
#define CEAEXT_MAX_SVD_NUM       59    
// up to 6 Detailed timing descriptor can be supported in block1.
#define CEAEXT_MAX_DTD_NUM       6

//by now we only support EDID size upto 256 bytes
#define MAX_EDID_SIZE       256

typedef struct _CEA_EXTANSION_EDIDINFO{
    // for CEA861 spec. we can support atmost 6 detailed timing 
    // or 32 short video descriptors 
    UCHAR       CEAExtBlockTag;
    CBIOS_SHORTVIDEO_DESCRIPTOR ShortVideoDescriptor[CEAEXT_MAX_SVD_NUM];
    EDID_DETAILEDTIMING_INFO DtlTimings[CEAEXT_MAX_DTD_NUM];
    CBIOS_CEA861_MISC_ATTRIB CEA861MiscAttrib;
}CEA_EXTANSION_EDIDINFO, *PCEA_EXTANSION_EDIDINFO;

typedef struct _CBIOS_EDID_BUFFER {
    //'bHPD_EDIDBufferValid' means: TRUE---We did not get the EDID or DDC not detected, FALSE---EDID has been got successfully 
    ULONG EdidBufferLen;                      //Edid buffer size
    BYTE  EdidBuffer[MAX_EDID_SIZE];
} CBIOS_EDID_BUFFER, *PCBIOS_EDID_BUFFER;

typedef struct _CBIOS_EDID_STRUCTURE_DATA {
    UCHAR       EDIDVersion;

    //----------block 0 detailed timing---------
    CBIOS_S3MODE_INFO EstTimings[16];
    CBIOS_S3MODE_INFO StdTimings[8];
    EDID_DETAILEDTIMING_INFO DtlTimings[EDID1X_BLOCK0_MAX_DTD_NUM];

    //---------CEA Extansion block timing ---------
    // now only support 1 Extansion block    
    CEA_EXTANSION_EDIDINFO CEABlock_1;

    CBIOS_EDID_BUFFER      EDIDBuf;
} CBIOS_EDID_STRUCTURE_DATA, *PCBIOS_EDID_STRUCTURE_DATA;

// EDID index by I2C/GPIO port
enum
{
    EDID_25 = 0,
    EDID_26,
    EDID_2C,
    EDID_31,
    EDID_3D,
    EDID_PORT_END
};

//*****************************************************************************
//  Customize timing data structure
//
typedef struct _CustomizeTimingHead
{
    WORD    version;        // current CustomizeTiming file version
    BYTE    checkSum;       // to make whole customize timing table in file + checksum 
                            // to zero
    BYTE    reserved;       // reserve BYTE must be zero
    DWORD   fileLength;     // whole file from begining
    DWORD   timingNum;      // CustomizeTiming number in file
} CustomizeTimingHead, *PCustomizeTimingHead;

typedef struct _CustomizeTimingEntity
{
    DWORD   dispDev;        // Display device   
    DWORD   H_Res;          // Horizontal resulotion
    DWORD   V_Res;          // Vertical resulotion
    DWORD   colorDepth;     // 8 / 16 / 32 (bpp)
    DWORD   rRateX100;      // Refresh Rate in Hz * 100 (decimal)
    DWORD   vPLL;           // HW PLL value with format 0MRN
    WORD    HTotal;         // HorTotalTime
    WORD    HDisEnd;        // HorAddrTime
    WORD    HBlankStart;    // HorBlankStart
    WORD    HBlankEnd;      // HorBlankTime
    WORD    HSyncStart;     // HorSyncStart
    WORD    HSyncEnd;       // HorSyncEnd
    WORD    VTotal;         // VerTotalTime
    WORD    VDisEnd;        // VerAddrTime
    WORD    VBlankStart;    // VerBlankStart
    WORD    VBlankEnd;      // VerBlankEnd
    WORD    VSyncStart;     // VerSyncStart
    WORD    VSyncEnd;       // VerSyncEnd
    BYTE    HPolarity;      // HorPolarity - 0:positive, 1:negative
    BYTE    VPolarity;      // VorPolarity - 0:positive, 1:negative
    BYTE    Interlaced;     // Interlace mode
    BYTE    reserved;       // reserve BYTE must be zero
}CustomizeTimingEntity, *PCustomizeTimingEntity;

//****************************************************************************
// GFX Timing Info structure which CBIOS used and returned to driver 
// when queried for Target Timing
typedef struct GFXTimingTable
{
    DWORD   colorDepth;             // 8 / 16 / 32 (bpp)
    DWORD   rRateX100;              // Refresh Rate in Hz * 100 (decimal)
    DWORD   vPLL;                   // HW PLL value with format 0MRN

    WORD    HTotal;                 // HorTotalTime
    WORD    HDisEnd;                // HorAddrTime
    WORD    HBlankStart;            // HorBlankStart
    WORD    HBlankEnd;              // HorBlankTime
    WORD    HSyncStart;             // HorSyncStart
    WORD    HSyncEnd;               // HorSyncEnd
    WORD    VTotal;                 // VerTotalTime
    WORD    VDisEnd;                // VerAddrTime
    WORD    VBlankStart;            // VerBlankStart
    WORD    VBlankEnd;              // VerBlankEnd
    WORD    VSyncStart;             // VerSyncStart
    WORD    VSyncEnd;               // VerSyncEnd
    WORD    VSyncOffset;            // VSyncOffset (in pixel clock cycle) interlace timing only
    
    BYTE    HPolarity;              // HorPolarity - 0:positive, 1:negative
    BYTE    VPolarity;              // VorPolarity - 0:positive, 1:negative

    BYTE    AspectRatio;            // timing aspect ratio
    
    BYTE    Interlaced;             // Interlace / Progressive mode
} GFXTimingTable, *PGFXTimingTable;

//*****************************************************************************
// Structure for CBIOS set timing interface
typedef struct _CBios_Source_Mode_Params
{
    WORD    XRes;
    WORD    YRes;
    DWORD   colorDepth;
} CBiosSourceModeParams, *PCBiosSourceModeParams;

typedef struct _CBios_View_Size_Params
{
    WORD    XRes;
    WORD    YRes;
    WORD    XShift;             // View X shift on Dest
    WORD    YShift;             // View Y shift on Dest
} CBiosViewSizeParams, *PCBiosViewSizeParams;

typedef struct _CBios_Dest_Timing_Params
{
    WORD    XRes;
    WORD    YRes;
    RefreshRateInfo rRateInfo;
} CBiosDestTimingParams, *PCBiosDestTimingParams;

enum TIMING_PARAMETER_ATTRIBUTE
{
    TIMING_PARA_FULL_UPDATE     = 0x1,
    TIMING_PARA_UPSCALE_ONLY    = 0x2,
    TIMING_PARA_DOWNSCALE_ONLY  = 0x4,
};

typedef struct _CBios_Set_Timing_Params
{
    DWORD   size;                       // structure size
    DWORD   IGAIndex;                   // Specify which IGA need to be set mode
    CBiosSourceModeParams   srcMode;    // Specify Source Mode to set
    CBiosViewSizeParams     viewSize;   // Speicfy View Size, from this we can know info such as scale factor.
    CBiosDestTimingParams   destTiming; // Specify Destination Timing to set
    DWORD  flag;                        // for set timing attribute, TIMING_PARAMETER_ATTRIBUTE 
} CBiosSetTimingParams, *PCBiosSetTimingParams;

typedef struct _CBios_HDMI_FuncOnOff
{
    DWORD   dispDev;            // Display device    
    BOOL    FuncOnOff;          // on/off specific HDMI function
} CBios_HDMI_FuncOnOff, *PCBios_HDMI_FuncOnOff;

// structure for PWM control
typedef struct _CBios_PWM_Control_Params
{
    ULONG   IoControlCode;              // Specify which function we want to do
    BYTE    bLevel;                    // Specify the PWM Level
    BYTE    bCLKSrc;                   // Specify the PWM CLK SRC
} CBiosPWMControlParams, *PCBiosPWMControlParams;

typedef struct _PLL_MRN_Value
{
    DWORD 	PLL_M;
	DWORD 	PLL_R;
	DWORD 	PLL_N;
	DWORD	DiffCLK;
	DWORD   PLLFout;
} PLL_MRN_Value, *PPLL_MRN_Value;

typedef struct _CBios_USB_HANDLE
{
    PVOID phUSB_BULKREAD;
    PVOID phUSB_REGWRITE;
    PVOID phUSB_MEMWRITE;
} CBios_USB_HANDLE, *PCBios_USB_HANDLE;


//*****************************************************************************
// Structure for S1 power saving feature:
//     Below table will be used to save register original value, when entering S1.
//     And will be restored to HW register when resume from S1.
// Register:SR1E/SR2A/CR36/CRD2 should be managed in device power management,
// otherwise, we need add them at here too.
//*****************************************************************************
typedef struct _PowerSavingReg
{
    BYTE    PS_REG_SR19;       // Interface clock control
    BYTE    PS_REG_SR1B;       // IGA2/IGA1 engine clock Gate control, IGA1 LUT power down
    BYTE    PS_REG_SR2D;       // IGA2/IGA1 DCLK and engine clock PLL Power control
    BYTE    PS_REG_SR2E;       // Capture/Video Processor/DMA/Video playback clock control
    BYTE    PS_REG_SR3F;       // Command Regulator/3D/2D/DVD clock control
    BYTE    PS_REG_CR92;       // IGA2 LUT power down
    BYTE    PS_REG_SR68;
    BYTE    PS_REG_SR6A;       // SF base in SL
    BYTE    PS_REG_SR6B;
    BYTE    PS_REG_SR6C;       // SL base in SM
    BYTE    PS_REG_SR6D;
    BYTE    PS_REG_SR6E;
    BYTE    PS_REG_SR6F;
    BYTE    PS_REG_SRB9;
    BYTE    REG_CH7301_1C;
}PowerSavingReg, *PPowerSavingReg;

//******Call Back function *********
//******* these functions must be implemented outside *******
//******** time delay functions ********************************
typedef VOID    (*CALLBACK_cbDelayMicroSeconds)(ULONG Microseconds);
typedef VOID    (*CALLBACK_cbSleepMicroSeconds)(ULONG Microseconds);
//******** Debug Print functions *******************************
#if DBG
typedef VOID (*CALLBACK_cbDbgPrint)(IN ULONG DebugPrintLevel, IN LPSTR DebugMessage, ...);
#endif
//******** general VGA reg access functions ********************



#if EFI_CBIOS
typedef UCHAR  (*CALLBACK_cbReadUchar)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegisterPort);
typedef VOID    (*CALLBACK_cbWriteUchar)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegisterPort, UCHAR Value);

typedef USHORT  (*CALLBACK_cbReadUshort)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegisterPort);
typedef VOID    (*CALLBACK_cbWriteUshort)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegisterPort, USHORT Value);
#else
typedef UCHAR   (*CALLBACK_cbReadUchar)(PUCHAR RegisterPort);
typedef VOID    (*CALLBACK_cbWriteUchar)(PUCHAR RegisterPort, UCHAR Value);

typedef USHORT  (*CALLBACK_cbReadUshort)(PUSHORT RegisterPort);
typedef VOID    (*CALLBACK_cbWriteUshort)(PUSHORT RegisterPort, USHORT Value);
#endif



#if !LINUX_PLATFORM
#if EFI_CBIOS
	typedef ULONG   (*CALLBACK_cbReadMMIOUlong)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegOffset);
	typedef VOID    (*CALLBACK_cbWriteMMIOUlong)(PVOID VIA_GFX_PRIVATE_DATA, ULONG RegOffset, ULONG Value);
#else
	typedef ULONG   (*CALLBACK_cbReadMMIOUlong)(PUCHAR RegOffset);
	typedef VOID    (*CALLBACK_cbWriteMMIOUlong)(PUCHAR RegOffset, ULONG Value);
#endif
#endif

typedef enum _HDMI_TX_TYPE
{
    HDMI_TX_NONE  = 0,       //   No HDMI transmitter
    HDMI_AD9389B  = 0x01,
    HDMI_SIL9022  = 0x02,
    HDMI_ITE6610  = 0x03,
} HDMI_TX_TYPE;

typedef enum _HDMI_Signal
{
    HDMI_RGB      = 0x01,       //   No HDMI transmitter
    HDMI_YCbCr422 = 0x02,
    HDMI_YCbCr444 = 0x04,
} HDMI_Signal;

typedef enum _CBIOS_STATUS_tag {
    CBIOS_OK,                                 // 0    OK - no error
    CBIOS_ER_INVALID_PARAMETER,               //      As is
    CBIOS_ER_NOT_YET_IMPLEMENTED,             //      Feature / function not yet implemented
    CBIOS_ER_INTERNAL,                        //      internal error (should never happen)
    CBIOS_ER_OS_ERROR,                        //      Error propagated up from the underlying OS
    CBIOS_ER_LACKOFINFO,                      //      Need More info data
    CBIOS_ER_DDCRead,                         //      DDC read ERRROR    
    CBIOS_ER_LACKOFVCPDATA,
    CBIOS_ER_LACKOFCBIOSDATA,
    CBIOS_ER_NOT_SUPPORT,
    CBIOS_ER_LAST                             //      Number of error codes
} CBIOS_STATUS;

//*****************************************************************************
//
//  Module Name: cbios_uma.h
//
//  Content: CBIOS new meaningful interface.
//
//  Author: Alcard Wan
//
//*****************************************************************************

enum
{
    S3_CRT      = 0x0001,
    S3_LCD      = 0x0002,
    S3_TV       = 0x0004,
    S3_HDTV     = 0x0008,
    S3_DVI2     = 0x0010,
    S3_DVI      = 0x0020,
    S3_CRT2     = 0x0040,
    S3_LCD2     = 0x0100,
    S3_HDMI     = 0x0200,
    S3_DVI3     = 0x0400,
    S3_DVI4     = 0x0800,
    S3_HDMI1    = 0x1000,
    S3_HDMI2    = 0x2000,
    S3_HDMI4    = 0x4000,
    S3_DP       = 0x8000,
    S3_DP2      = 0x10000,
    S3_TV2      = 0x40000,
    ALL_SUPPORT_DEV = S3_CRT + S3_LCD + S3_TV + S3_HDTV + S3_DVI2 + S3_DVI + 
                      S3_CRT2 + S3_LCD2 + S3_TV2 + S3_HDMI + S3_HDMI2 + S3_DP + S3_DP2
};

enum DeviceTimingType
{
    VESAVPIT_TIMING_TYPE                = 0x0001,
    LCD_TIMING_TYPE                     = 0x0002,
    TV_TIMING_TYPE                      = 0x0004,
    HDTV_TIMING_TYPE                    = 0x0008,
    EDID_ENABLEDEVSCALING_TIMING_TYPE   = 0x0010,
    VESAFILTERBYEDID_TIMING_TYPE        = 0x0020,
    EDID_DISABLEDEVSCALING_TIMING_TYPE  = 0x0040,
    CEA_TIMING_TYPE                     = 0x0080,
    VESAVPIT_EDID_TIMING_TYPE           = 0x0100,
};

typedef enum
{
    POST = 1,   
    S3   = 3,
    S4   = 4,
    DOSFuLLScreen = 5,
    OSstart = 6
}InitEvent;


//------------------Display Resolution-----------------------------------------

CBIOS_STATUS CBIOSAPI CBiosGetCurrentMode (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT DWORD *pH_Res,
    OUT DWORD *pV_Res,
    OUT DWORD *pColorDepth,
    OUT RefreshRateInfo *pRRatesInfo
);

CBIOS_STATUS CBIOSAPI CBiosSetMode(
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
);

CBIOS_STATUS CBIOSAPI CBiosSetModeTwo (
    PVOID pvcbe, 
    IN DWORD H_ResIGA1,
    IN DWORD V_ResIGA1,
    IN DWORD colorDepthIGA1,
    IN RefreshRateInfo RRatesInfoIGA1,
    IN DWORD H_ResIGA2,
    IN DWORD V_ResIGA2,
    IN DWORD colorDepthIGA2,
    IN RefreshRateInfo RRatesInfoIGA2
);


CBIOS_STATUS CBIOSAPI CBiosGetDeviceResolutionsBufferSize (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pBufSize
);

CBIOS_STATUS CBIOSAPI CBiosGetDeviceResolutions (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN OUT DWORD *pResBuf,
    IN OUT DWORD *pBufSize
);

CBIOS_STATUS CBIOSAPI CBIOSGetDeviceModeTargetTiming ( 
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTargetTiming
);

CBIOS_STATUS CBIOSAPI CBiosSetTiming(
    PVOID pvcbe, 
    IN PCBiosSetTimingParams pTimingParams
);

CBIOS_STATUS CBIOSAPI CBiosSetHDMIAVMute(
    PVOID pvcbe, 
    IN PCBios_HDMI_FuncOnOff pAVMute
);

CBIOS_STATUS CBIOSAPI CBiosSetHDMIAudio(
    PVOID pvcbe, 
    IN PCBios_HDMI_FuncOnOff pAudioOnOff
);

CBIOS_STATUS CBIOSAPI CBiosSetHDACConnectStatus(
    PVOID   pvcbe,
    BOOL    *bEnable
);

#if !LINUX_PLATFORM
CBIOS_STATUS CBIOSAPI CBiosGetChipSSID(
    PVOID   pvcbe,
    DWORD 	*pChipSSID
);


#endif
CBIOS_STATUS CBIOSAPI CBiosSetUSBHandle(
    PVOID pvcbe,
    PCBios_USB_HANDLE phUSB
);

CBIOS_STATUS CBIOSAPI CBiosGetBiosCaps(
     PVOID  pvcbe,
     DWORD	Dev,
     PVOID 	QueryCpas
);

CBIOS_STATUS CBIOSAPI CBiosGetTransmitterType(
    IN PVOID   pvcbe,
    IN DWORD   Dev,
    OUT PVOID pTxType);

//------------------Color Depth and Refresh Rates Query------------------------
//----------------new refresh rate interface-------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetRefreshRatesBufferSizeForDeviceResolution (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT DWORD *pBufSize
);

CBIOS_STATUS CBIOSAPI CBiosGetRefreshRatesForDeviceResolution (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesX100Buf,
    IN OUT DWORD *pBufSize
);

enum
{
    COLOR_DEPTH_4BPP       = 0x01, // 4 bpp supported
    COLOR_DEPTH_8BPP       = 0x02, // 8 bpp supported
    COLOR_DEPTH_16BPP      = 0x08, // 16 bpp supported
    COLOR_DEPTH_32BPP_8888 = 0x20, // 32 bpp in (8, 8, 8) supported
    COLOR_DEPTH_32BPP_AAA2 = 0x40, // 32 bpp in (10, 10, 10, 2) supported
};

CBIOS_STATUS CBIOSAPI CBiosGetColorDepthForDeviceResolution (
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT DWORD *pColorDepth
);

CBIOS_STATUS CBIOSAPI CBiosLoadCustomizeTiming(
    PVOID pvcbe, 
    IN BYTE *pCustomizeTimingData
);

//------------------Device Control---------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetActiveDisplayDeviceConfigurationByIga (
    PVOID pvcbe, 
    IN UINT32 IgaNum,
    OUT UINT32 *pDispDev
);

CBIOS_STATUS CBIOSAPI CBiosGetActiveDisplayDeviceConfiguration (
    PVOID pvcbe, 
    OUT DWORD *pDispDevIGA1,
    OUT DWORD *pDispDevIGA2
);

CBIOS_STATUS CBIOSAPI CBiosSetActiveDisplayDeviceConfiguration (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2
);

CBIOS_STATUS CBIOSAPI CBiosSetActiveDisplayDeviceConfiguration_linux (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2,
    IN DWORD AffectIGAs);

CBIOS_STATUS CBIOSAPI CBiosGetDisplayDeviceInformation (
    PVOID pvcbe, 
    IN  UINT32 dispDevice,               // only one device bit can be set
    OUT PDWORD pHRes,
    OUT PDWORD pVRes,
    OUT UINT8  *pDDCPort                 // 0x00 indicates no DDC port used
);

CBIOS_STATUS CBIOSAPI CBiosGetUnsupportedDeviceCombinations (
    PVOID pvcbe, 
    INOUT DWORD *pDevBuf,
    INOUT DWORD *pBufSize
);
CBIOS_STATUS CBIOSAPI CBiosGetUnsupportedDeviceCombinationsBufferSize (
    PVOID pvcbe, 
    INOUT DWORD *pBufSize
);

CBIOS_STATUS CBIOSAPI CBiosGetHotKeySwitchDeviceCombinations (
    PVOID pvcbe, 
    INOUT DWORD *pDevBuf,
    INOUT DWORD *pBufSize
);
CBIOS_STATUS CBIOSAPI CBiosGetHotKeySwitchDeviceCombinationsBufferSize (
    PVOID pvcbe, 
    INOUT DWORD *pBufSize
);


//------------------Device Power Management------------------------------------
typedef enum
{
    S3PM_STANDBY    = 0x01,
    S3PM_SUSPEND    = 0x02,
    S3PM_OFF        = 0x04,
    S3PM_ON         = 0x08,
}PowerState;

CBIOS_STATUS CBIOSAPI CBiosGetDisplayDevicePowerManagementCapability (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pPowerCaps
);

CBIOS_STATUS CBIOSAPI CBiosGetDisplayDevicePowerState (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pPowerState
);

CBIOS_STATUS CBIOSAPI CBiosSetDisplayDevicePowerState (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD powerState
);

CBIOS_STATUS CBIOSAPI CBiosGetIgaScreenOnOffState (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT DWORD *pScreenState
);

CBIOS_STATUS CBIOSAPI CBiosSetIgaScreenOnOffState (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN DWORD screenState
);

CBIOS_STATUS CBIOSAPI CBiosDisableChip (
    PVOID pvcbe 
);

//------------------Graphics Controller----------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetIGAUpscalerCapability (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT UINT32 *pUpscalerCaps
);

CBIOS_STATUS CBIOSAPI CBiosGetIGAUpscalerSetting (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT UINT32 *pUpscalerSetting
);

CBIOS_STATUS CBIOSAPI CBiosSetIGAUpscalerSetting (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN UINT32 upScalerSetting
);

CBIOS_STATUS CBIOSAPI CBIOSCurrentModeNeedScaler (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT IGAScaleInfo *pIGAScaleInfo);

CBIOS_STATUS CBIOSAPI CBiosSetIGAPitch(
    PVOID pvcbe, 
    IN DWORD IGANum, 
    IN DWORD IGAPitch);

enum
{
    S3_MCLK     = 0x00,
    S3_DCLK1    = 0x01,
    S3_DCLK2    = 0x02,
    S3_ECLK     = 0x04,
    S3_ICLK     = 0x05,
};

CBIOS_STATUS CBIOSAPI CBiosSetClock (
    PVOID pvcbe, 
    IN ULONG clockFreq, 
    IN ULONG clockType
);

CBIOS_STATUS CBIOSAPI CBiosGetClock (
    PVOID pvcbe, 
    OUT PULONG pClockFreq,
    IN ULONG clockType
);

CBIOS_STATUS CBIOSAPI CBiosSlowDownClock(
    PVOID pvcbe,
    IN DWORD dispDev,
    IN BOOL operate
);

//------------------I2C--------------------------------------------------------

typedef struct _I2CData {
    BYTE  BusNum;         // I2C bus number
    BYTE  subAddr;
    BYTE  offset;
    ULONG bufLen;       // I2C buffer size
    BYTE* pBuf;
    ULONG DeviceID;
} I2CData, *PI2CData;

typedef struct _CBIOS_PARAM_GET_EDID {
    ULONG DisplayDeviceDWord;
    BYTE* EdidBuffer;
    ULONG EdidBufferLen;                      //Edid buffer size
    EDID_MONITOR_TYPE type;                   // to distinguish digital or analog
} CBIOS_PARAM_GET_EDID, *PCBIOS_PARAM_GET_EDID;

typedef struct _CBIOS_PARAM_INFOFRAME {
    ULONG DisplayDeviceDWord;
    ULONG H_Res;
    ULONG V_Res;
    RefreshRateInfo RRateInfo;
    ULONG CEAModeNumber;
    ULONG ColorFormat;
    ULONG CTS;
    ULONG CTSInterval;
} CBIOS_PARAM_INFOFRAME, *PCBIOS_PARAM_INFOFRAME;

enum EDIDVERSION{
    EDID_NONE = 0,
    EDID1_X,
    EDID2_0,
};

CBIOS_STATUS CBIOSAPI CBiosGetEdid (
    PVOID pvcbe, 
    OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid
);

CBIOS_STATUS CBIOSAPI CBiosParserEdid (
    PVOID pvcbe, 
    IN void*  EDIDBuf,
    IN UINT32 EDIDBufLen,
    OUT CBIOS_EDID_STRUCTURE_DATA* pEDIDTimingInfo
);

CBIOS_STATUS CBIOSAPI CBiosSetEdid (
    PVOID pvcbe, 
    IN PCBIOS_PARAM_GET_EDID pCBParamGetEdid
);

CBIOS_STATUS CBIOSAPI CBiosGetFakeEdid (
    PVOID pvcbe, 
    IN OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid
);

CBIOS_STATUS CBIOSAPI
CBiosUpdateOutputDeviceToVBIOS(
    void* pvcbe, 
    IN DWORD outputdevice
);

CBIOS_STATUS CBIOSAPI CBiosSetCPUDirectAccessFB (
    PVOID pvcbe, 
    IN OUT BOOL flag
);

CBIOS_STATUS CBIOSAPI CBiosSetInfoFrameData(
    PVOID pvcbe,
    IN PCBIOS_PARAM_INFOFRAME pInfoFrameData
);

CBIOS_STATUS CBIOSAPI CBiosSetHDAudioParameter(
    PVOID pvcbe,
    IN PCBIOS_PARAM_INFOFRAME pInfoFrameData
);

/*For DDC-CI */
typedef struct _I2COperation
{
    BYTE I2CBusNum;
    BYTE Data;              /* Data to write, or returned byte */
    ULONG Command;          /* I2C_COMMAND_* */
    ULONG Flags;            /* I2C_FLAGS_* */
    ULONG Status;           /* I2C_STATUS_* */
} I2COperation, *PI2COperation;

/* I2C Commands */
enum {
    CBI2C_COMMAND_NULL = 0x0000,
    CBI2C_COMMAND_READ,
    CBI2C_COMMAND_WRITE,
    CBI2C_COMMAND_STATUS,
    CBI2C_COMMAND_RESET,
    CBI2C_COMMAND_OPEN,
    CBI2C_COMMAND_CLOSE
};

/* The following flags are provided on a READ or WRITE command          */
enum {
    CBI2C_FLAGS_START = 0x0001,         /* START + addx              */
    CBI2C_FLAGS_STOP = 0x0002,          /* STOP                      */
    CBI2C_FLAGS_DATACHAINING = 0x0004,  /* STOP, START + addx        */
    CBI2C_FLAGS_ACK = 0x0010            /* ACKNOWLEDGE (normally set)*/
};

#define MAX_CLOCK_RATE 1000*1000            // in Hz

/* The following status flags are returned on completion of the operation */
enum {
    CBI2C_STATUS_NOERROR = 0x0000,
    CBI2C_STATUS_BUSY,
    CBI2C_STATUS_ERROR
};

CBIOS_STATUS CBIOSAPI CBiosI2COperation(
    PVOID pvcbe, 
    IN OUT PI2COperation pCBiosI2COperation
);
    
CBIOS_STATUS CBIOSAPI CBiosI2CDDCCIDataRead(
    PVOID pvcbe, 
    IN OUT PI2CData pI2CData
);

CBIOS_STATUS CBIOSAPI CBiosI2CDDCCIDataWrite(
    PVOID pvcbe, 
    IN PI2CData pI2CData
);                 

//------------------Misc-------------------------------------------------------

CBIOS_STATUS CBIOSAPI CBiosNonDestructiveDeviceDetect (
    PVOID pvcbe, 
    IN UINT32 detectDev,
    OUT BOOL *pbAttached
);

CBIOS_STATUS CBIOSAPI CBiosDestructiveDeviceDetect (
    PVOID pvcbe, 
    IN UINT32 detectDev,
    OUT BOOL *pbAttached
);


CBIOS_STATUS CBIOSAPI CBiosInitialization (
    IN PVOID pvcbe, 
    IN UINT32 InitializationEvent
);

CBIOS_STATUS CBIOSAPI CBiosSyncCBiosExtensionFromHWReg(IN PVOID pvcbe);

CBIOS_STATUS CBIOSAPI CBiosSyncCBiosExtensionToHWReg(IN PVOID pvcbe);

CBIOS_STATUS CBIOSAPI CBiosHContractionCTL(
    PVOID pvcbe, 
    IN ULONG CtlFunc,
    INOUT PULONG pHContractionlevel);    

CBIOS_STATUS CBIOSAPI CBiosGetSupDeviceTimingType(
    PVOID pvcbe, 
    IN DWORD Device,
    OUT PDWORD pSupTimingType);

CBIOS_STATUS CBIOSAPI CBiosGetCurDeviceTimingType(
    PVOID pvcbe, 
    IN DWORD Device,
    OUT PDWORD pCurTimingType);

CBIOS_STATUS CBIOSAPI CBiosSetDeviceTimingType(
    PVOID pvcbe, 
    IN DWORD Device,
    IN DWORD TimingType);

CBIOS_STATUS CBIOSAPI CBiosGetAlwaysOnDevice (
    PVOID pvcbe, 
    OUT DWORD *pAlwaysOnDev);

CBIOS_STATUS
CBiosInt10_UMA(PVOID pvcbe, 
               PVIDEO_X86_BIOS_ARGUMENTS biosArguments);

CBIOS_STATUS CBIOSAPI CBiosSetS1Powerstate (
    PVOID pvcbe, 
    IN DWORD powerState);

CBIOS_STATUS CBIOSAPI CBiosSetS3Powerstate (
    PVOID pvcbe, 
    IN DWORD powerState);

CBIOS_STATUS CBIOSAPI CBiosSetS4Powerstate (
    PVOID pvcbe);

typedef enum _CbiosHWPatchTag {
    HW_PATCH_NONE = 0,
    HW_PATCH_IGA1_PLL_CONTROL, // HW specific number
    HW_PATCH_SNAPSHOT_CONTROL,
    HW_PATCH_DISPLAY_REQUEST_DISABLE,
    HW_PATCH_KILLNUM,
    HW_PATCH_FORCE_HDMI_TO_DVI_MODE,
    HW_PATH_DISABLE_HDCP_CAPABILITY,
    HW_PATCH_ADJUST_7301_XCLK,
    HW_PATCH_DP_SW_LINK_TRAING,
    HW_PATCH_GET_PANEL_SIZE,
    HW_PATCH_SET_LINK_SPEED
}CbiosHWPatchTag;

// HW specific input buffer value
// for HW_PATCH_IGA1_PLL_CONTROL tag use only
enum {
    HW_PATCH_IGA1_PLL_CONTROL_OFF,
    HW_PATCH_IGA1_PLL_CONTROL_ON,
};
// HW specific input buffer value for snapshot
enum {
    HW_PATCH_SNAPSHOT_CONTROL_DISABLE = 0,
    HW_PATCH_SNAPSHOT_CONTROL_ENABLE,
};
// for HW_PATCH_KILLNUM tag use only
enum {
    HW_PATCH_KILLNUM_XP,
    HW_PATCH_KILLNUM_VISTA,
};
// for HW_PATCH_FORCE_HDMI_TO_DVI_MODE use only
 enum {
    HW_PATCH_FORCE_HDMI_TO_DVI_MODE_OFF,
    HW_PATCH_FORCE_HDMI_TO_DVI_MODE_ON,
};


CBIOS_STATUS CBIOSAPI CBiosPatchHW (
    PVOID pvcbe, 
    IN CbiosHWPatchTag HWPatchTag,
    IN  BYTE*   inBuf,
    IN  UINT32  inBufLen,
    OUT BYTE*   outBuf,
    OUT UINT32  outBufLen );

CBIOS_STATUS CBIOSAPI CBiosSetHardwareDownScaleBYIGA(
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN DWORD SrcWidth,
    IN DWORD SrcHeight,
    IN DWORD colorDepth,
    IN DWORD DstWidth,
    IN DWORD DstHeight,
    IN DWORD AutoFlip,
    IN DWORD PitchDelt,
    ULONG DstAddress0,ULONG  DstAddress1, ULONG DstAddress2
);

// Interrupt information coming from VCP
#define USING_LVDS_HPD_INTERRUPT       BIT0
#define USING_TMDS_HPD_INTERRUPT       BIT1
#define USING_DP_HPD_INTERRUPT         BIT2
#define USING_DP2_HPD_INTERRUPT        BIT3
#define USING_HDAUDIO_INTERRUPT        BIT4

#define FPGA_ChipRevision 0xFF

CBIOS_STATUS CBIOSAPI CBiosGetDeviceHotPlugInterruptSetting(
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT PDWORD pINTtype);

#define PWM_MAX_DUTY    254
#define PWM_MIN_DUTY    0
#define PWM_Enable      BIT0
#define PWM_Disable     0
#define PWM_Fire        BIT0
#define PWM_CLK_DIV_8   0
#define PWM_CLK_DIV_16  BIT1
#define PWM_CLK_DIV_32  BIT2
#define PWM_CLK_DIV_64  BIT2 | BIT1

#define PWM_IOCTL_CBiosSetPWMLevel              0x00000001
#define PWM_IOCTL_CBiosQueryMaxPWMLevel         0x00000002
#define PWM_IOCTL_CBiosGetCurrentPWMLevel       0x00000003
#define PWM_IOCTL_CBiosSetPWMCLKSrc             0x00000004
#define PWM_IOCTL_CBiosQueryMaxPWMCLKSrc        0x00000005
#define PWM_IOCTL_CBiosGetCurrentPWMCLKSrc      0x00000006

CBIOS_STATUS CBIOSAPI CBiosSetPWMLevel(
            IN PVOID pvcbe, 
            IN BYTE    Level);
CBIOS_STATUS CBIOSAPI CBiosQueryMaxPWMLevel(
            IN PVOID pvcbe,
            OUT BYTE  *pLevel);
CBIOS_STATUS CBIOSAPI CBiosGetCurrentPWMLevel(
            IN PVOID pvcbe,
            OUT BYTE  *pLevel);

CBIOS_STATUS CBIOSAPI CBiosPWMControl(
            IN PVOID pvcbe,
            OUT PCBiosPWMControlParams pPWMControlParams);

//********************************************************************************
typedef struct _CBIOS_CALLBACK_FUNCTIONS
{
    void *pFnDelayMicroSeconds;
    void *pFnSleepMicroSeconds;
    void *pFnDbgPrint;
    void *pFnReadUchar;
    void *pFnWriteUchar;
    void *pFnReadUshort;
    void *pFnWriteUshort;
#if !LINUX_PLATFORM
    void *pFnReadMMIOUlong;
    void *pFnWriteMMIOUlong;
#endif
}CBIOS_CALLBACK_FUNCTIONS, *PCBIOS_CALLBACK_FUNCTIONS;

CBIOS_STATUS CBIOSAPI CBiosSetCallBackFunctions(
    PVOID pvcbe, 
    IN PCBIOS_CALLBACK_FUNCTIONS pFnCallBack
);

typedef struct _CBIOS_EXT_INFO
{
    ULONG CbiosVer;
    ULONG pcbeSize;
}CBIOS_EXT_INFO, *PCBIOS_EXT_INFO;

CBIOS_STATUS CBIOSAPI CBiosGetCBiosExtInfo(
    OUT PCBIOS_EXT_INFO pCBiosExtInfo
);

#define CBIOS_BASIC_INFO_VERSION  0x01000001

// SpecifyParamFlag
typedef enum{
    CBE_INIT_PARAM_FULL                 = 0x00000000,
    CBE_INIT_PARAM_BASIC_INFO_VER       = 0x00000001,
    CBE_INIT_PARAM_BASIC_INFO_LENGTH    = 0x00000002,
    CBE_INIT_PARAM_MMIO_BASE            = 0x00000004,
    CBE_INIT_PARAM_VGA_MMIO_BASE        = 0x00000008,
    CBE_INIT_PARAM_PCI_DEVICE_ID        = 0x00000010,
    CBE_INIT_PARAM_CHIP_REVISION        = 0x00000020,
    CBE_INIT_PARAM_ROM_IMAGE            = 0x00000040,
    CBE_INIT_PARAM_ROM_IMAGE_LENGTH     = 0x00000080,
    CBE_INIT_PARAM_ROM_SYSTEM_INFO      = 0x00000100,
}CBIOS_EXTENSION_SPECIFY_INIT_PARAM_FLAG;

typedef struct _CBIOS_EXTENSION_INIT_PARAM
{
    ULONG   CBiosBasicInfoVer;
    ULONG   CBiosBasicInfoLength;
    PUCHAR  MmioBase;
    PUCHAR  VGAMmioBase;
    ULONG   PCIDeviceID;
    DWORD   ChipRevision;
    PVOID   RomImage;
    ULONG   RomImageLength;
    PVOID   pSysInfo;
    ULONG   SpecifyInitParamFlag;
}CBIOS_EXTENSION_INIT_PARAM, *PCBIOS_EXTENSION_INIT_PARAM;

CBIOS_STATUS CBIOSAPI CBiosInitCbiosExtParam(
    PVOID pvcbe,
    IN PCBIOS_EXTENSION_INIT_PARAM pCbiosExtInitParam
);

typedef struct _CBIOS_INTERRUPT
{
    ULONG Size;
    ULONG InterruptControlReg1; // For MMIO.200
    ULONG InterruptControlReg2; // For MMIO.204
    ULONG InterruptControlReg3; // For MMIO.1280
}CBIOS_INTERRUPT, *PCBIOS_INTERRUPT;

CBIOS_STATUS CBIOSAPI CBiosInterruptRoutine (
    PVOID pvcbe, 
    IN PCBIOS_INTERRUPT pHWInterrupt
);

CBIOS_STATUS CBIOSAPI CBiosIsCBiosAvailable(
    IN BYTE *pVBiosRom,
    IN ULONG RomLen,
    OUT BOOL *pbAvailable
);

typedef struct _CBIOS_VERSION
{
    WORD     BranchDriverNumber;       // Branch code number, 0 means trunk code.
    WORD     MajorVersionNumber;       // Big structure refine if change. 
    WORD     MediumVersionNumber;      // Little improvement, Add new feature
    WORD     MinorVersionNumber;       // Minor fix improvement, mainly focus on issue.
}CBIOS_VERSION,*PCBIOS_VERSION;

CBIOS_STATUS CBIOSAPI CBiosGetVersion(
    PVOID pvcbe, 
    OUT PCBIOS_VERSION pCbiosVersion
);

INT cbStrncmp(IN CONST CHAR *String1, IN CONST CHAR *String2, IN ULONG Length);

//------------------For Second Generation Interface, report function pointer-------------------

// This function pointer definition is for driver reference how to define the interface,
// when get the proc address from interface CBiosGetProcAddress.
typedef CBIOS_STATUS (*CBIOSPROC)(PVOID pvcbe,...);

CBIOS_STATUS CBIOSAPI CBiosGetProcAddress(
    PVOID pvcbe,
    IN char *strFunName, 
    IN OUT CBIOSPROC* pFuncPointer
);

//-------------------------Secondary generation cbios interface definition-------------------------
// Add a dummy interface for example as below:
#if DBG
typedef struct _CBIOS_DUMMY
{
    int size;
    int var1;
    int var2;
}CBIOS_DUMMY, *PCBIOS_DUMMY;

CBIOS_STATUS CBIOSAPI CBiosDummyFunction(
    void* pvcbe, 
    IN PCBIOS_DUMMY pdummy
);
// Need to add one more function pointer for interface and fill this in FunctionPointerTbl
typedef CBIOS_STATUS
(*PFN_CBiosDummyFunction)(void* pcbe, IN OUT PCBIOS_DUMMY pdummy);
#endif //DBG
//-------------------------Real new CBIOS interface area--------------------------------------


CBIOS_STATUS CBIOSAPI CBiosInitUEFIInfo(PVOID pvcbe, void *pvgpd);


CBIOS_STATUS CBIOSAPI CBiosGetConfFileInfo(PVOID pvcbe, char *ConfFile, char *name, UINT32 *value);
CBIOS_STATUS CBIOSAPI CBiosGetEdidConfInfo(PVOID pvcbe, char *ConfFile, char *name, UINT8 *ConfEdid);

#endif // _CBIOS_UMA_NEW_H_


