/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Programming info contained in this module about chips can be found at:
 *   Chrontel 7301 : http://www.chrontel.com/pdf/7301ds.pdf
 *   silicon 164 : http://www.siliconimage.com/docs/SiI-DS-0021-E-164.pdf
 *   TI tfp410 : http://www.ti.com/lit/ds/symlink/tfp410.pdf
 *   ADI ad9389b : http://www.analog.com/static/imported-files/data_sheets/AD9389B.pdf
 *                 http://ez.analog.com/servlet/JiveServlet/download/1741-8-10790/AD9889B%20Programming%20Guide%20RevB.pdf
 *   EDID info : http://en.wikipedia.org/wiki/Extended_display_identification_data
 */

#include "cbios_platform.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_cea_timing.h"
#if LINUX_PLATFORM
#include <asm/div64.h>
#endif

//=============================================================================
// below is new sub functions
//=============================================================================


//---------------------------------------------------------------
// HDMISupportResolution 
//     For  HDMI mode support, Since HDMI mode support from EDID has error 
//     Get mode table, olny support this modes
//---------------------------------------------------------------
DWORD const HDMISupportResolution[] =
{
      640,  480,     //  640  x  480
      720,  480,     //  720  x  480
     1280,  720,     //  1280 x  720
     1920, 1080,     //  1920 x 1080
};
DWORD const HDMI_RESOLUTION_NUM = sizeof(HDMISupportResolution) / sizeof(DWORD) / 2;

//---------------------------------------------------------------
//HDMIResolutionRefreshRate
//    For HDMI needs to report all  progressive timing.
//  
//--------------------------------------------------------------
HDMIResolutionRR const HDMIResolutionRefreshRate[] = 
{
     {640,  480,  60, PROGRESSIVE },    // 640 x 480 60P
     {720,  480,  60, PROGRESSIVE },    // 720 x 480 60P
     {1280, 720,  60, PROGRESSIVE },    //1280 x 720 60P
     {1280, 720,  50, PROGRESSIVE },    //1280 x 720 50P
     {1920,1080,  60, PROGRESSIVE },    //1920 x1080 60P
};

DWORD const HDMI_REFRESHRATE_NUM = sizeof(HDMIResolutionRefreshRate) / sizeof(HDMIResolutionRR);

//---------------------------------------------------------------
//AD9389BReginit
//    For AD9389B needs to programming some register as below.
//  
//--------------------------------------------------------------
AD9389BRegSetting const AD9389BReginit[] = 
{
     {0x41, 0x10,  0},  // all circuit power on
     {0x43, 0xA0,  0},  // Programming Tx to Get monitor EDID
     {0x15, 0x0A,  0},  // we set DDR RGB 444 input.
     {0x16, 0x02,  0},  // we set DDR RGB 444 output.
                        // DPA reg1[1]   ; Going falling edge for DPA setting
     {0xBA, 0x70,  0},  // DPA setting
     {0x9C, 0x38,  0},  // recommand setting
     {0x9D, 0x61,  0},  // recommand setting
     {0x98, 0x02,  0},  // Chip recommand setting
     {0x47, 0x80,  0},  // set active format aspect ratio same as picture aspect ratio
     {0xA2, 0x87,  0},  // Chip recommand setting
     {0xA3, 0x87,  0},  // Chip recommand setting
     {0x02, 0x18,  0},  // N value with SPDIF 48kHz value, For DVI audio has no effect
     {0x0A, 0x11,  0},  // SPDIF Audio,and runs at 256 bit Mclk_Pol, for DVI audio has no effect     
     {0xAF, 0x14,  0}   // Current Frame encrypted.Bit[1], HDMI mode turn on(Audio output),will programed by code 
     

};
DWORD const AD9389BReg_NUM = sizeof(AD9389BReginit) / sizeof(AD9389BRegSetting);

HDAuioWallClockRegSetting const WallClockReg[] =
{
    { 25200000,  0xCF3CF3CF, 0xF3 },
    { 27000000,  0x8E38E38E, 0xE3 },
    { 74270000,  0xBF5A814A, 0x52 },
    { 148500000, 0x5FAD40A5, 0x29 },
    { 162000000, 0xED097B42, 0x25 },
    { 270000000, 0xC16C16C1, 0x16 }
};

DWORD const WallClockReg_NUM = sizeof(WallClockReg)/sizeof(HDAuioWallClockRegSetting);

#if (EFI_CBIOS)
HDAuioSampleRateRegSetting const SampleRateReg[] =
{

    { 44100, 25235792, 0x754f5600, 0x208081f3, 0x72867c87, 0x20000000 }, // 6x4

    { 44100, 40090904, 0x4070bb2c, 0x20808199, 0x4816f0a0, 0x20000000 }, // 8x6

    { 44100, 49397721, 0x60530c00, 0x2080817c, 0x3a81ec1a, 0x20000000 }, // 8x6

    { 44100, 65147719, 0x4f0a4bcc, 0x2080815e, 0x2c5ce2d8, 0x20000000 }, // 10x7

    { 44100, 78749990, 0x04cd1c00, 0x2080814e, 0x24b33dfd, 0x20000000 }, // 10x7

    { 44100,108102259, 0xd5bb7200, 0x20808138, 0x1abc3754, 0x20000000 }, // 12x10

    { 48000, 25235792, 0x754f5600, 0x208081f3, 0x7ca7471b, 0x20000000 },

    { 48000, 40090904, 0x4070bb2c, 0x20808199, 0x4e77026c, 0x20000000 },

    { 48000, 49397721, 0x60530c00, 0x2080817c, 0x3fae801c, 0x20000000 },

    { 48000, 65147719, 0x4f0a4bcc, 0x2080815e, 0x30493c91, 0x20000000 },

    { 48000, 78749990, 0x04cd1c00, 0x2080814e, 0x27f21d29, 0x20000000 },

    { 48000,108102259, 0xd5bb7200, 0x20808138, 0x1d197ca8, 0x20000000 }

};

DWORD const SampleRateReg_NUM = sizeof(SampleRateReg)/sizeof(HDAuioSampleRateRegSetting);
#endif

HDAuioPacketClockRegSetting const PacketClockReg[] =
{
    { 32000,  25200000,  0x533866B9, 0x00 },
    { 32000,  27000000,  0x4DAC1B9C, 0x00 },
    { 32000,  54000000,  0x26D60DCE, 0x00 },
    { 32000,  74270000,  0x1C3E95AD, 0x00 },
    { 32000,  148500000, 0x0E1F4AD6, 0x00 },
    { 32000,  162000000, 0x0CF2049A, 0x00 },
    { 32000,  270000000, 0x07C46929, 0x00 },
    { 44100,  25200000,  0x72B020C4, 0x00 },
    { 44100,  27000000,  0x6B0AC940, 0x00 },
    { 44100,  54000000,  0x358564A0, 0x00 },
    { 44100,  74270000,  0x26ECA645, 0x00 },
    { 44100,  148500000, 0x13765322, 0x00 },
    { 44100,  162000000, 0x11D7218A, 0x00 },
    { 44100,  270000000, 0x0AB44753, 0x00 },
    { 88200,  25200000,  0xE5604189, 0x00 },
    { 88200,  27000000,  0xD6159280, 0x00 },
    { 88200,  54000000,  0x6B0AC940, 0x00 },
    { 88200,  74270000,  0x4DD94C8B, 0x00 },
    { 88200,  148500000, 0x26ECA645, 0x00 },
    { 88200,  162000000, 0x23AE4315, 0x00 },
    { 88200,  270000000, 0x15688EA6, 0x00 },
    { 176400, 25200000,  0xCAC08312, 0x01 },
    { 176400, 27000000,  0xAC2B2500, 0x01 },
    { 176400, 54000000,  0xD6159280, 0x00 },
    { 176400, 74270000,  0x9BB29917, 0x00 },
    { 176400, 148500000, 0x4DD94C8B, 0x00 },
    { 176400, 162000000, 0x475C862A, 0x00 },
    { 176400, 270000000, 0x2AD11D4C, 0x00 },
    { 48000,  25200000,  0x7CD49A16, 0x00 },
    { 48000,  27000000,  0x7482296A, 0x00 },
    { 48000,  54000000,  0x3A4114B5, 0x00 },
    { 48000,  74270000,  0x2A5DE083, 0x00 },
    { 48000,  148500000, 0x152EF041, 0x00 },
    { 48000,  162000000, 0x136B06E7, 0x00 },
    { 48000,  270000000, 0x0BA69DBD, 0x00 },
    { 96000,  25200000,  0xF9A9342C, 0x00 },
    { 96000,  27000000,  0xE90452D4, 0x00 },
    { 96000,  54000000,  0x7482296A, 0x00 },
    { 96000,  74270000,  0x54BBC107, 0x00 },
    { 96000, 148500000,  0x2A5DE083, 0x00 },
    { 96000, 162000000,  0x26D60DCE, 0x00 },
    { 96000, 270000000,  0x174D3B7B, 0x00 },
    { 192000, 25200000,  0xF3526859, 0x01 },
    { 192000, 27000000,  0xD208A5A9, 0x01 },
    { 192000, 54000000,  0xE90452D4, 0x00 },
    { 192000, 74270000,  0xA96BD34D, 0x00 },
    { 192000, 148500000, 0x54BBC107, 0x00 },
    { 192000, 162000000, 0x4DAC1B9C, 0x00 },
    { 192000, 270000000, 0x2E9A76F7, 0x00 }
};

DWORD const PacketClockReg_NUM = sizeof(PacketClockReg)/sizeof(HDAuioPacketClockRegSetting);

HDAuioCTSandNRegSetting const CTSandNReg[] =
{
#if (EFI_CBIOS)

    { 44100, 25235792, 0x106b4bcc, 0xb4b01800, 0x00000006 },
    { 44100, 40090904, 0x10aa74cc, 0xa7401800, 0x0000000a },
    { 44100, 49397721, 0x10d206cc, 0x20601800, 0x0000000d },
    { 44100, 65147719, 0x1114fdcc, 0x4fd01800, 0x00000011 },
    { 44100, 78749990, 0x114ed2cc, 0xed201800, 0x00000014 },
    { 44100,108102259, 0x11cb9ecc, 0xb9e01800, 0x0000001c },
    { 48000, 25235792, 0x106293cc, 0x29301800, 0x00000006 },
    { 48000, 40090904, 0x109c9acc, 0xc9a01800, 0x00000009 },
    { 48000, 49397721, 0x10c0f5cc, 0x0f501800, 0x0000000c },
    { 48000, 65147719, 0x10fe7bcc, 0xe7b01800, 0x0000000f },
    { 48000, 78749990, 0x11339dcc, 0x39d01800, 0x00000013 },
    { 48000,108102259, 0x11a646cc, 0x64601800, 0x0000001a }

#else

    { 32000,  25200000,  25200,  4096  },
    { 32000,  27000000,  27000,  4096  },
    { 32000,  54000000,  54000,  4096  },
    { 32000,  74270000,  74250,  4096  },
    { 32000,  148500000, 148500, 4096  },
    { 44100,  25200000,  28000,  6272  },
    { 44100,  27000000,  30000,  6272  },
    { 44100,  54000000,  60000,  6272  },
    { 44100,  74270000,  82500,  6272  },
    { 44100,  148500000, 165000, 6272  },
    { 88200,  25200000,  28000,  12544 },
    { 88200,  27000000,  30000,  12544 },
    { 88200,  54000000,  60000,  12544 },
    { 88200,  74270000,  82500,  12544 },
    { 88200,  148500000, 165000, 12544 },
    { 176400, 25200000,  28000,  25088 },
    { 176400, 27000000,  30000,  25088 },
    { 176400, 54000000,  60000,  25088 },
    { 176400, 74270000,  82500,  25088 },
    { 176400, 148500000, 16500,  25088 },
    { 48000,  25200000,  25200,  6144  },
    { 48000,  27000000,  27000,  6144  },
    { 48000,  54000000,  54000,  6144  },
    { 48000,  74270000,  74250,  6144  },
    { 48000,  148500000, 148500, 6144  },
    { 96000,  25200000,  25200,  12288 },
    { 96000,  27000000,  27000,  12288 },
    { 96000,  54000000,  54000,  12288 },
    { 96000,  74270000,  74250,  12288 },
    { 96000,  148500000, 148500, 12288 },
    { 192000, 25200000,  25200,  24576 },
    { 192000, 27000000,  27000,  24576 },
    { 192000, 54000000,  54000,  24576 },
    { 192000, 74270000,  74250,  24576 },
    { 192000, 148500000, 148500, 24576 },

#endif
};
DWORD const CTSandNReg_NUM = sizeof(CTSandNReg)/sizeof(HDAuioCTSandNRegSetting);

HDAuioMaudNaudRegSetting const MaudNaudReg[]=
{
    { 48000, 162000000, 512,  3375  },
    { 44100, 162000000, 784,  5625  },
    { 32000, 162000000, 1024, 10125 },
    { 48000, 270000000, 512,  5625  },
    { 44100, 270000000, 784,  9375  },
    { 32000, 270000000, 1024, 16875 }
};

DWORD const MaudNaudReg_NUM = sizeof(MaudNaudReg)/sizeof(HDAuioMaudNaudRegSetting);

VOID cbLoadAD9389BInitTbl(PCBIOS_EXTENSION pcbe, BYTE I2CPort, BYTE I2CAddr)
{
    I2C_CONTROL_UMA i2c;
    ULONG i;
    PVCPInfo pVcp = pcbe->pVCPInfo;
    PVBIOSAD9389INITTBL pAd9389InitTbl=NULL;
    i2c.I2cPort=I2CPort;
    i2c.SlaveAddr=I2CAddr;
    i2c.Flags = 0;
    
    if(pVcp)
    {
        if(pVcp->version >= VCP1_6 
            && pVcp->AD9389_HDMI_INIT_TBL!=0)
        { 
            pAd9389InitTbl=(PVBIOSAD9389INITTBL)(pcbe->RomData+pVcp->AD9389_HDMI_INIT_TBL);
        }
    }

    if(pAd9389InitTbl != NULL)  
    {
        if(pAd9389InitTbl->DevAddr!=0xFF)
        {
            do
            {
                i2c.RegIndex = pAd9389InitTbl->Index;
                i2c.IndexData = pAd9389InitTbl->Data;
                I2C_Write_Byte_INV(pcbe, &i2c);
                pAd9389InitTbl++;
            }while(pAd9389InitTbl->DevAddr!=0xFF);
        }
    }
    else
    {
        for(i=0; i<AD9389BReg_NUM; i++)
        {
            i2c.RegIndex = AD9389BReginit[i].ucIndex;
            i2c.IndexData = AD9389BReginit[i].ucData;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
    }   
}

//--------------------------------------------------------------------------
//  cbSetDVIPowerState
//  change DVI PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetDVIPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    I2C_CONTROL_UMA i2c;
    BYTE TxType;
    i2c.Flags = 0;
    
    // get DVI associated TxType
    if (cbGetDITXtype(pcbe, &TxType, S3_DVI) == FALSE)
    {
        cbDbgPrint(1, "Can not find TMDS transmitter!\n");
        return;
    }

    // Enable Pad first for I2C writing
    cbConfigureDigitalPort(pcbe, S3_DVI, ON);

    switch(TxType)
    {
        case AD9389B:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI))
            {
                return;
            } 
            
            if(powerstate == S3PM_ON)  
            {
                cbLoadAD9389BInitTbl(pcbe, i2c.I2cPort,i2c.SlaveAddr);
                //turn on DVI mode
                i2c.RegIndex=0xAF;
                i2c.IndexData = 0;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT1);
            }
            else
            {
                i2c.RegIndex  = 0x41;
                i2c.IndexData = 0x50;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
            
        case IN_TMDS:
            //if DVI in internal ,then no check Transmitter
            //only set CRD2[3]
            if(powerstate == S3PM_ON)  
            {
                //CRD2[3]=1 power down TMDS
                cbWriteRegBits(pcbe, CR_D2, BIT3, 0);     
            }
            else
            {
                //CRD2[3]=0 power down TMDS
                cbWriteRegBits(pcbe, CR_D2, BIT3, BIT3);
                cbConfigureDigitalPort(pcbe, S3_DVI, OFF);
            }
            break;

        case VT3192:
        case SII164:
            // Write Transmitter to control DVI
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI))
            {
                return;
            }

            //VT1632a power control TXReg 08[0]
            i2c.RegIndex = 0x08;
           
            if(!I2C_Read_Byte_INV(pcbe, &i2c))  // get i2c register index data
                return;
            
            if(powerstate == S3PM_ON)  
            {
                //  Enable DVI
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                
                 
            }
            else    
            {
                //  Disable DVI
                i2c.IndexData &= ~BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                cbConfigureDigitalPort(pcbe, S3_DVI, OFF);
               
            }
            break;
        case CH7301:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI))
            {
                return;
            }
            
            if(powerstate == S3PM_ON)  
            {
                //disable DAC
                //BIT0 : DAC bypass mode
                //BIT2 : DAC gain, low -RGB, high -YCrCb
                //BIT3 : enable the HSYNC and VSYNC outputs
                i2c.RegIndex  = 0x21;
                i2c.IndexData = 0x0;
                I2C_Write_Byte_INV(pcbe, &i2c);
            
                //disable YCrCb to RGB conversion
                i2c.RegIndex  = 0x56;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);

                //49[7:6] DVI is in normal function
                //BIT 0: Power Management on
                i2c.RegIndex  = 0x49;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData |= 0xC0;
                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            else
            {
                //BIT[7:6]: DVI is in normal function
                i2c.RegIndex  = 0x49;
                I2C_Read_Byte_INV(pcbe, &i2c);

                i2c.IndexData &= 0x3F;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
        case TFP410:
            // Write Transmitter to control DVI
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI))
            {
                return;
            }

            //VT1632a power control TXReg 08[0]
            i2c.RegIndex = 0x08;

            if(!I2C_Read_Byte_INV(pcbe, &i2c)) // get i2c register index data
                return;

            if(powerstate == S3PM_ON)  
            {
                // Enable DVI
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            else
            {
                // Disable DVI
                i2c.IndexData &= ~BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                cbConfigureDigitalPort(pcbe, S3_DVI, OFF);
            }
            break;
            
       case INTERNAL_DP:
            cbSetDPPowerState(pcbe, powerstate);
            break;
            
       default: 
            ASSERT(0);
            return ;   
    }
    //update device power statue 
    pcbe->devicepowerstate[DVIbit] = powerstate;
}


//--------------------------------------------------------------------------
//  cbSetDVI2PowerState
//  change DVI2 PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetDVI2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    I2C_CONTROL_UMA i2c;
    BYTE TxType;
    i2c.Flags = 0;
    
    // get DVI2 associated TxType
    if (cbGetDITXtype(pcbe, &TxType, S3_DVI2) == FALSE)
    {
        cbDbgPrint(1, "Can not find TMDS transmitter!\n");
        return;
    }

    // Enable Pad first for I2C writing
    cbConfigureDigitalPort(pcbe, S3_DVI2, ON);

    switch(TxType)
    {
        case AD9389B:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI2))
            {
                return;
            } 
            
            if(powerstate == S3PM_ON)  
            {
                cbLoadAD9389BInitTbl(pcbe, i2c.I2cPort,i2c.SlaveAddr);
                //turn on DVI mode
                i2c.RegIndex=0xAF;
                i2c.IndexData = 0;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT1);
            }
            else
            {
                i2c.RegIndex  = 0x41;
                i2c.IndexData = 0x50;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
            
        case IN_TMDS:
            //if DVI in internal ,then no check Transmitter
            //only set CRD2[3]
            if(powerstate == S3PM_ON)  
            {
                //CRD2[3]=1 power down TMDS
                cbWriteRegBits(pcbe, CR_D2, BIT3, 0);     
            }
            else
            {
                //CRD2[3]=0 power down TMDS
                cbWriteRegBits(pcbe, CR_D2, BIT3, BIT3);
                cbConfigureDigitalPort(pcbe, S3_DVI2, OFF);
            }
            break;
        case VT3192:
        case SII164:
            // Write Transmitter to control DVI
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI2))
            {
                return;
            }

            //VT1632a power control TXReg 08[0]
            i2c.RegIndex = 0x08;
           
            if(!I2C_Read_Byte_INV(pcbe, &i2c))  // get i2c register index data
                return;
            
            if(powerstate == S3PM_ON)  
            {
                //  Enable DVI
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                
                 
            }
            else    
            {
                //  Disable DVI
                i2c.IndexData &= ~BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                cbConfigureDigitalPort(pcbe, S3_DVI2, OFF);
               
            }
            break;
        case CH7301:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI2))
            {
                return;
            }

            if(powerstate == S3PM_ON)  
            {
                //disable DAC
                //BIT0 : DAC bypass mode
                //BIT2 : DAC gain, low -RGB, high -YCrCb
                //BIT3 : enable the HSYNC and VSYNC outputs
                i2c.RegIndex  = 0x21;
                i2c.IndexData = 0x0;
                I2C_Write_Byte_INV(pcbe, &i2c);
            
                //disable YCrCb to RGB conversion
                i2c.RegIndex  = 0x56;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);
        
                //49[7:6] DVI is in normal function
                //BIT 0: Power Management on
                i2c.RegIndex  = 0x49;
                I2C_Read_Byte_INV(pcbe, &i2c);
                i2c.IndexData |= 0xC0;
                i2c.IndexData &= 0xFE;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            else
            {
                //BIT[7:6]: DVI is in normal function
                i2c.RegIndex  = 0x49;
                I2C_Read_Byte_INV(pcbe, &i2c);
        
                i2c.IndexData &= 0x3F;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
        case TFP410:
            // Write Transmitter to control DVI
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI2))
            {
                return;
            }

            //VT1632a power control TXReg 08[0]
            i2c.RegIndex = 0x08;
           
            if(!I2C_Read_Byte_INV(pcbe, &i2c))    // get i2c register index data
                return;
            
            if(powerstate == S3PM_ON)  
            {
                //    Enable DVI
                i2c.IndexData |= BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            else    
            {
                //    Disable DVI
                i2c.IndexData &= ~BIT0;
                I2C_Write_Byte_INV(pcbe, &i2c);
                cbConfigureDigitalPort(pcbe, S3_DVI2, OFF);
            }
            break;

        case INTERNAL_DP:
            cbSetDPPowerState(pcbe, powerstate);
            break;
            
        default: 
            return ;
    }
    //update device power statue 
    pcbe->devicepowerstate[DVI2bit] = powerstate;
}

//=============================================================================
// below is new sub functions
// should be modified later (temp copy and modify from cbSetDVIPowerState)
//=============================================================================

//--------------------------------------------------------------------------
//  cbSetHDMIPowerState
//  change HDMI PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetHDMIPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    I2C_CONTROL_UMA i2c;
    CBios_HDMI_FuncOnOff AudioOnOff;
    BYTE TxType=0;
    i2c.Flags = 0;
    
    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TxType, S3_HDMI) == FALSE)
    {
        return;
    }
        
    // Enable Pad first for I2C writing
    if(powerstate == S3PM_ON)
        cbConfigureDigitalPort(pcbe, S3_HDMI, ON);
    else
        cbConfigureDigitalPort(pcbe, S3_HDMI, OFF);

    switch(TxType)
    {
        case AD9389B:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_HDMI))
            {
                return;
            } 
            
            if(powerstate == S3PM_ON)  
            {
                pcbe->TurnOnAD9389ing = TRUE;
                cbLoadAD9389BInitTbl(pcbe, i2c.I2cPort,i2c.SlaveAddr);
                pcbe->TurnOnAD9389ing = FALSE;
                //turn on HDMI mode
                i2c.RegIndex=0xAF;
                i2c.IndexData = BIT1;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT1);
                //Signal Part
                cbAD9389HDMIChangeSignal(pcbe, pcbe->HDMIAD9389Signal); 
            }
            else
            {
                i2c.RegIndex  = 0x41;
                i2c.IndexData = 0x50;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
            
        case INTERNAL_DP:
                cbSetDPPowerState(pcbe, powerstate);
            break;

        default:
            //reserved for other transmitter
            return;

    }

    AudioOnOff.dispDev = S3_HDMI;
    if(powerstate == S3PM_ON)
    {
        AudioOnOff.FuncOnOff = TRUE;
        CBiosSetHDMIAudio(pcbe, &AudioOnOff);
    }
    else
    {
        AudioOnOff.FuncOnOff = FALSE;
        CBiosSetHDMIAudio(pcbe, &AudioOnOff);
    }
    //update device power statue 
    pcbe->devicepowerstate[HDMIbit] = powerstate;
}

//--------------------------------------------------------------------------
//  cbSetHDMI2PowerState
//  change HDMI PowerState & initial digital port associated
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetHDMI2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    I2C_CONTROL_UMA i2c;
    CBios_HDMI_FuncOnOff AudioOnOff;
    BYTE TxType=0;
    i2c.Flags = 0;
    
    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TxType, S3_HDMI2) == FALSE)
    {
        return;
    }
        
    // Enable Pad first for I2C writing
    if(powerstate == S3PM_ON)
        cbConfigureDigitalPort(pcbe, S3_HDMI2, ON);
    else
        cbConfigureDigitalPort(pcbe, S3_HDMI2, OFF);

    switch(TxType)
    {
        case AD9389B:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, S3_HDMI2))
            {
                return;
            } 
            
            if(powerstate == S3PM_ON)  
            {
                cbLoadAD9389BInitTbl(pcbe, i2c.I2cPort,i2c.SlaveAddr);
                //turn on HDMI mode
                i2c.RegIndex=0xAF;
                i2c.IndexData = BIT1;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT1);
                //Signal Part
                cbAD9389HDMIChangeSignal(pcbe, pcbe->HDMIAD9389Signal); 
            }
            else
            {
                i2c.RegIndex  = 0x41;
                i2c.IndexData = 0x50;
                I2C_Write_Byte_INV(pcbe, &i2c);
            }
            break;
            
        case INTERNAL_DP:
                cbSetDPPowerState(pcbe, powerstate);
            break;

        default:
            //reserved for other transmitter
            return;

    }

    AudioOnOff.dispDev = S3_HDMI2;
    if(powerstate == S3PM_ON)
    {
        AudioOnOff.FuncOnOff = TRUE;
        CBiosSetHDMIAudio(pcbe, &AudioOnOff);
    }
    else
    {
        AudioOnOff.FuncOnOff = FALSE;
        CBiosSetHDMIAudio(pcbe, &AudioOnOff);
    }
    //update device power statue 
    pcbe->devicepowerstate[HDMI2bit] = powerstate;
}

void cbAD9389AudioEnable(PVOID pvcbe, BOOL bAudioEnabled)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    i2c.Flags = 0;

    // get i2c info first
    if (!cbGetDII2Csetting(pcbe, &i2c, S3_HDMI))
    {
        return;
    }

    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TXType, S3_HDMI) == FALSE)
    {
        return;
    }

    if(TXType == AD9389B)
    {
        i2c.RegIndex  = 0x44;     // SPDIF enable at bit 7
        if(bAudioEnabled)
            i2c.IndexData = 0xF8; // Audio on
        else
            i2c.IndexData = 0x78; // Audio off
        I2C_Write_Byte_INV(pcbe, &i2c); 
    }
    else
    {
        cbDbgPrint(0, "HDMI Audio not found. \n");
    }
}

void cbAD9389HDMIChangeSignal(PVOID pvcbe, ULONG ulHDMISignal)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    i2c.Flags = 0;

    pcbe->HDMIAD9389Signal = ulHDMISignal;
    // get i2c info first
    if (!cbGetDII2Csetting(pcbe, &i2c, S3_HDMI))
    {
        return;
    }

    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TXType, S3_HDMI) == FALSE)
    {
        return;
    }
    switch(ulHDMISignal)   
    {
        case HDMI_RGB: //RGB444
            i2c.RegIndex  = 0x15;     
            i2c.IndexData = 0x0A;  //In RGB 
            I2C_Write_Byte_INV(pcbe, &i2c); 
            cbDelayMicroSeconds(10 * 1000); //DelayMS(10) for testing;
            i2c.RegIndex  = 0x16;     
            i2c.IndexData = 0x02;  //Out RGB , //DPA Setting register 2
            I2C_Write_Byte_INV(pcbe, &i2c); 
            break;
        case HDMI_YCbCr422:
            i2c.RegIndex  = 0x15;     
            i2c.IndexData = 0x0C;  //In YCbCr 422 bit[3]
            I2C_Write_Byte_INV(pcbe, &i2c); 
            cbDelayMicroSeconds(10 * 1000); //DelayMS(10) for testing;
            i2c.RegIndex  = 0x16;     
            i2c.IndexData = 0xC3;  //Out YCbCr 422 , //DPA Setting register 2
            I2C_Write_Byte_INV(pcbe, &i2c); 
            break;
        case HDMI_YCbCr444:
            i2c.RegIndex  = 0x15;     
            i2c.IndexData = 0x0A;  //In YCbCr 444 ,the same as RGB
            I2C_Write_Byte_INV(pcbe, &i2c); 
            cbDelayMicroSeconds(10 * 1000); //DelayMS(10) for testing;
            i2c.RegIndex  = 0x16;     
            i2c.IndexData = 0x43;  //Out YCbCr 444 , //DPA Setting register 2
            I2C_Write_Byte_INV(pcbe, &i2c); 
            break;
        default: //treat as RGB
            i2c.RegIndex  = 0x15;     
            i2c.IndexData = 0x0A;
            I2C_Write_Byte_INV(pcbe, &i2c); 
            cbDelayMicroSeconds(10 * 1000); //DelayMS(10) for testing;
            i2c.RegIndex  = 0x16;     
            i2c.IndexData = 0x02;
            I2C_Write_Byte_INV(pcbe, &i2c); 
            break;
    }
}

//--------------------------------------------------------------------------
//  cbHDMITxDeviceDetect
//    This function will check if device is connected on HDMI TX.
//     IN
//        detectDev : devices can only be: DVI/DVI2/HDMI
//     OUT
//        *pbAttached: Attached status
//     Return:
//        Function status: TURE/FALSE
//--------------------------------------------------------------------------
BOOL cbHDMITxDeviceDetect(PCBIOS_EXTENSION pcbe, IN UINT32 detectDev, OUT BOOL *pbAttached)
{
    PDigitalPortInfo PDIPort = NULL;
    BOOL IsHDMI;
    BYTE TxType;
    I2C_CONTROL_UMA i2c;
    CBIOS_PARAM_GET_EDID CBParamGetEdid;
    BYTE EDID_buff[EDID1_X_BLOCKSIZE*2];

    *pbAttached = FALSE; //Assume not connected first

    if ((detectDev & (S3_DVI+S3_HDMI+S3_HDMI2+S3_DVI2)) == 0)
    {
        cbDbgPrint(0, "Device not matches TX!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // get i2c info first
    if (!cbGetDIPortInfo(pcbe, &PDIPort, detectDev))
    {
        return FALSE;
    }

    //If there is a device connecting to AD9389, then we should see if need to get real EDID or return buffer.    
    //If device EDID buffer is cleared or HPD happened, then we need to get real EDID again.      
    CBParamGetEdid.DisplayDeviceDWord = detectDev;
    CBParamGetEdid.EdidBuffer = EDID_buff;
    CBParamGetEdid.EdidBufferLen = EDID1_X_BLOCKSIZE*2;
    CBParamGetEdid.type = EDID_DIGITAL;
    if(!cbGetEDID_UMA(pcbe, &CBParamGetEdid))
    {
        //EDID NOT valid
        *pbAttached = FALSE;
        return TRUE;
    }
    
    //If we got real EDID or EDID buffer is valid, then distiguish HDMI/DVI
    IsHDMI = cbIsHDMIOUIExistInEDID(CBParamGetEdid.EdidBuffer, CBParamGetEdid.EdidBufferLen);
    if(detectDev & (S3_HDMI+S3_HDMI2))
    {
        *pbAttached = IsHDMI;
    }
    else
    {
        //HDMI connected, so DVI/DVI2 set to NOT connected
        *pbAttached = !IsHDMI;
    }

    if(IsHDMI)
    {
        if (cbGetDITXtype(pcbe, &TxType, detectDev) == FALSE)
        {
            return TRUE;
        }

        switch(TxType)
        {
            case AD9389B:
            // get i2c info first
            if (!cbGetDII2Csetting(pcbe, &i2c, detectDev))
            {
                return TRUE;
            } 
            
            i2c.RegIndex=0xAF;
            i2c.IndexData = BIT1;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT1);

            break;
        default:
            break;
        }
    }
    return TRUE;
}

//--------------------------------------------------------------------------
//  cbGetAD9389ConnectStatus
//    This function will check if any device is connected to AD9389 TX.
//     IN
//        None
//     OUT
//        Noe
//     Return:
//        Connect status: TURE: A device is connected to AD9389
//                        FALSE: No device is connected
//--------------------------------------------------------------------------
BOOL cbIsDeviceConnectOnAD9389(PCBIOS_EXTENSION pcbe, PDigitalPortInfo PDIPort)
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    i2c.I2cPort = PDIPort->PortInfo.I2CPort;
    i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
    i2c.RegIndex = 0x42;
    //To see if any device connected to AD9389, if no, clear EDID buffer and return false
    I2C_Read_Byte_INV(pcbe, &i2c);
    //Output reg.0x42 for debug convinience(to check connection status)
    //Reg.0x42[5]=1:HDMI clock termination detected.
    
    if(!(i2c.IndexData & BIT5))
    {
        cbDbgPrint(1, "Device not connected on TX. !\n");
        return FALSE;
    }
    return TRUE;
    
}

BOOL cbGetFourBlockEDID(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PDigitalPortInfo PDIPort, ULONG flags, PCBIOS_PARAM_GET_EDID pCBParamGetEdid)
{
    ULONG ADI_EDID_cnt = 0;
    BYTE Seg1_EDID[256];
    BOOL status = TRUE;
    
    switch(PDIPort->PortInfo.TXType)
    {
    case AD9389B:
        pi2c->SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
        pi2c->RegIndex = 0xC4;
        pi2c->IndexData = 0x01;
        I2C_Write_Byte_INV(pcbe, pi2c);

        ADI_EDID_cnt =0;
        pi2c->RegIndex = 0xC5;
        while(ADI_EDID_cnt < AD9389B_CHK_MAXTRIES)
        {
            I2C_Read_Byte_INV(pcbe, pi2c);
            if(pi2c->IndexData & BIT4)
                break;
            ADI_EDID_cnt++;
        }

        pi2c->SlaveAddr = 0xA0;
        pi2c->RegIndex = 0x0;
        if (FALSE == I2C_Data_Request_INV(pcbe,
                                      pi2c,
                                      EDID1_X_BLOCKSIZE * 2,
                                      flags,
                                      Seg1_EDID))
        {   
            cbDbgPrint(0, "Segment 1 EDID read failed !\n");
            status = FALSE;
        }
        break;
        
    case INTERNAL_DP:
        pi2c->SlaveAddr = 0x60;
        pi2c->RegIndex = 0x1;
        status = cbHDMII2CWriteDDC(pcbe, pi2c);

        pi2c->SlaveAddr = 0xA0;
        pi2c->RegIndex = 0x0;
        status = cbHDMII2CReadBytes(pcbe, pi2c, Seg1_EDID, EDID1_X_BLOCKSIZE * 2);

        break;

    default:
        status = FALSE;
        break;
    }
        
    if (status && Seg1_EDID[0]==0x02 && Seg1_EDID[1]==0x03)
    {
        memcpy((PBYTE)pCBParamGetEdid->EdidBuffer + EDID1_X_BLOCKSIZE, Seg1_EDID, EDID1_X_BLOCKSIZE);
    }

    return status;
}

BOOL cbHDMII2CReadByte(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    DWORD temp = 0;
    BOOL  status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);     

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address
    temp = pi2c->SlaveAddr;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Offset
    temp = pi2c->RegIndex;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address + 1
    temp = pi2c->SlaveAddr + 1;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Read Data
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    cbHDMII2CStatus(pcbe, 0x0008, TRUE);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0080, FALSE);

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B8)) & ~0x80));

    // STOP
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0021);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0029);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0828, TRUE);

    if(status == TRUE)
        pi2c->IndexData = (BYTE)((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0x0000FF00) >> 8);

    return status;
    
}

BOOL cbHDMII2CReadBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE EDIDBuffer, DWORD length)
{
    DWORD j = 0, temp = 0;
    BYTE  ckm = 0;
    BOOL  status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address
    temp = pi2c->SlaveAddr;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Offset
    temp = 0;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address + 1
    temp = pi2c->SlaveAddr + 1;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    for(j = 0; j < length; j++)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
        cbHDMII2CStatus(pcbe, 0x0008, TRUE);
        cbHDMII2CStatus(pcbe, 0x0080, FALSE);

        // correct EDID check sum
        if(j%128 == 127)
        {
            *EDIDBuffer++ = (0x100 - ckm);
            ckm = 0;
        }
        else
        {
            ckm += (BYTE)((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0x0000FF00) >> 8);
            *EDIDBuffer++ = (BYTE)((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0x0000FF00) >> 8);
        }

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B8)) & ~0x80));
    }

    // STOP
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0021);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0029);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0828, TRUE);

    return status;
}

BOOL cbHDMII2CReadDDCBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE EDIDBuffer, DWORD length)
{
    DWORD j = 0, temp = 0;
    BYTE  ckm = 0;
    BOOL  status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address + 1
    temp = pi2c->SlaveAddr + 1;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    for(j = 0; j < length; j++)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
        cbHDMII2CStatus(pcbe, 0x0008, TRUE);
        cbHDMII2CStatus(pcbe, 0x0080, FALSE);

        // correct EDID check sum
        if(j%128 == 127)
        {
            *EDIDBuffer++ = (0x100 - ckm);
            ckm = 0;
        }
        else
        {
            ckm += (BYTE)((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0x0000FF00) >> 8);
            *EDIDBuffer++ = (BYTE)((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0x0000FF00) >> 8);
        }

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B8)) & ~0x80));
    }

    // STOP
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0021);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0029);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0828, TRUE);

    return status;
}

BOOL cbHDMII2CWriteByte(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    DWORD temp = 0;
    BOOL status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address
    temp = pi2c->SlaveAddr;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Offset
    temp = pi2c->RegIndex;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Write Data
    temp = pi2c->IndexData;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // STOP
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0021);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0029);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0828, TRUE);
    
    return status;
}

BOOL cbHDMII2CWriteDDCBytes(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c, PBYTE DataBuffer, DWORD Length)
{
    DWORD temp = 0, i = 0;
    BOOL status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address
    temp = pi2c->SlaveAddr;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Write Data
    for(i = 0; i < Length; i++)
    {
        temp = DataBuffer[i];
        temp <<= 16;
        temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
        if(status)
            status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);
    }
    
    // STOP
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0021);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0029);
    //if(status)
    //    status = cbHDMII2CStatus(pcbe, 0x0828, TRUE);
    
    return status;
}

BOOL cbHDMII2CWriteDDC(PCBIOS_EXTENSION pcbe, PI2C_CONTROL_UMA pi2c)
{
    DWORD temp = 0;
    BOOL status = TRUE;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & ~BIT7));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC000), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC000)) | 0x00000001));
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0C4), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC0C4)) & 0xFC7FFFFF) | 0x00800000);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x00000001);

    // START
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0011);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0019);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0018, TRUE);

    // Slave Address
    temp = pi2c->SlaveAddr;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);

    // Offset
    temp = pi2c->RegIndex;
    temp <<= 16;
    temp |= ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B4)) & 0xFF00FFFF;
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B4), temp);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC0B8), 0x0009);
    if(status)
        status = cbHDMII2CStatus(pcbe, 0x0008, TRUE);
    
    return status;
}

BOOL cbHDMII2CStatus(PCBIOS_EXTENSION pcbe, DWORD checkbits, BOOL condition)
{
    BOOL status = TRUE;
    DWORD i = 0, maxloop = 50;

    if(condition)
    {
        while((ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B8)) & checkbits) && i < maxloop)
        {
            cbDelayMicroSeconds(20);
            if(++i == maxloop) status = FALSE;
        }
    }
    else
    {
        while(!(ReadMMIOUlong(CB_MMIO_OFFSET(0xC0B8)) & checkbits) && i < maxloop)
        {
            cbDelayMicroSeconds(20);
            if(++i == maxloop) status = FALSE;
        }
    }
    return status;
}

//--------------------------------------------------------------------------
//  cbHDMISetAudioInfoFrame
//    This function will set Audio InfoFrame data for 410 Internal HDMI
//     IN
//        None
//     OUT
//        Noe
//--------------------------------------------------------------------------
void cbHDMISetAudioInfoFrame(PCBIOS_EXTENSION pcbe, ULONG device)
{
    HDMI_INFOFRAME  HDMIInfoFramePacket;
    DWORD   i = 0;
    BYTE    checksum = 0;
    DWORD   mmC204, mmC208, mmC20C, mmC210, mmC214, mmC218, mmC21C, mmC220, mmC224;

    DP_INFOFRAME DPInfoFramePacket;
    DWORD   mmC620, mmC624, mmC628, mmC62C, mmC630, mmC634, mmC638, mmC63C, mmC640;
    
    // initialize HDMIInfoFramePacket
    memset((&HDMIInfoFramePacket), 0x0, sizeof(HDMI_INFOFRAME));
    // initialize DPInfoFramePacket
    memset((&DPInfoFramePacket), 0x0, sizeof(DP_INFOFRAME));

    if(device == S3_HDMI)
    {
        HDMIInfoFramePacket.PacketHeader[0] = 0x84;
        HDMIInfoFramePacket.PacketHeader[1] = 0x01;
        HDMIInfoFramePacket.PacketHeader[2] = 0x0A;
        HDMIInfoFramePacket.ECCCode = cbHDMIInsertBCHCode(HDMIInfoFramePacket.PacketHeader, 3);

        // set Packet Bytes
        for(i = 0; i < 28; i++)
            HDMIInfoFramePacket.PacketByte[i] = 0;
        HDMIInfoFramePacket.PacketByte[1] |= 0x0;
        HDMIInfoFramePacket.PacketByte[1] |= 0x00;
        HDMIInfoFramePacket.PacketByte[2] |= 0x00;
        HDMIInfoFramePacket.PacketByte[2] |= 0x00;

        // count checksum
        for(i = 0; i < 28; i++)
            checksum += HDMIInfoFramePacket.PacketByte[i];
        checksum += ( 0x84 + 0x01 + 0x0A );
        
        checksum = 0x100 - checksum;
        HDMIInfoFramePacket.PacketByte[0] = checksum;

        // set BCHCode
        for(i = 0; i < 4; i++)
        {
            HDMIInfoFramePacket.BCHCode[i] = cbHDMIInsertBCHCode( &(HDMIInfoFramePacket.PacketByte[i*7]), 7);
        }

        mmC204 = (HDMIInfoFramePacket.ECCCode << 24 ) | (HDMIInfoFramePacket.PacketHeader[2] << 16) | 
                 (HDMIInfoFramePacket.PacketHeader[1] << 8) | HDMIInfoFramePacket.PacketHeader[0];
        mmC208 = (HDMIInfoFramePacket.PacketByte[3] << 24) | (HDMIInfoFramePacket.PacketByte[2] << 16) |
                 (HDMIInfoFramePacket.PacketByte[1] << 8) | HDMIInfoFramePacket.PacketByte[0];
        mmC20C = (HDMIInfoFramePacket.BCHCode[0] << 24) | (HDMIInfoFramePacket.PacketByte[6] << 16) |
                 (HDMIInfoFramePacket.PacketByte[5] << 8) | HDMIInfoFramePacket.PacketByte[4];
        mmC210 = (HDMIInfoFramePacket.PacketByte[10] << 24) | (HDMIInfoFramePacket.PacketByte[9] << 16) |
                 (HDMIInfoFramePacket.PacketByte[8] << 8) | HDMIInfoFramePacket.PacketByte[7];
        mmC214 = (HDMIInfoFramePacket.BCHCode[1] << 24) | (HDMIInfoFramePacket.PacketByte[13] << 16) |
                 (HDMIInfoFramePacket.PacketByte[12] << 8) | HDMIInfoFramePacket.PacketByte[11];
        mmC218 = (HDMIInfoFramePacket.PacketByte[17] << 24) | (HDMIInfoFramePacket.PacketByte[16] << 16) |
                 (HDMIInfoFramePacket.PacketByte[15] << 8) | HDMIInfoFramePacket.PacketByte[14];
        mmC21C = (HDMIInfoFramePacket.BCHCode[2] << 24) | (HDMIInfoFramePacket.PacketByte[20] << 16) |
                 (HDMIInfoFramePacket.PacketByte[19] << 8) | HDMIInfoFramePacket.PacketByte[18];
        mmC220 = (HDMIInfoFramePacket.PacketByte[24] << 24) | (HDMIInfoFramePacket.PacketByte[23] << 16) |
                 (HDMIInfoFramePacket.PacketByte[22] << 8) | HDMIInfoFramePacket.PacketByte[21];
        mmC224 = (HDMIInfoFramePacket.BCHCode[3] << 24) | (HDMIInfoFramePacket.PacketByte[27] << 16) |
                 (HDMIInfoFramePacket.PacketByte[26] << 8) | HDMIInfoFramePacket.PacketByte[25];

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC204), mmC204);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC208), mmC208);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC20C), mmC20C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC210), mmC210);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC214), mmC214);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC218), mmC218);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC21C), mmC21C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC220), mmC220);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC224), mmC224);

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC200), 0x81);  
    }

    if(device == S3_DP)
    {
        // header
        DPInfoFramePacket.PacketHeader[0] = 0;       //Secondary-data packet ID;
        DPInfoFramePacket.PacketHeader[1] = 0x84;
        DPInfoFramePacket.PacketHeader[2] = 0x1B;
        DPInfoFramePacket.PacketHeader[3] = 0x44;

        // data
        // set Packet Bytes
        for(i = 0; i < 24; i++)
            DPInfoFramePacket.PacketByte[i] = 0;
        DPInfoFramePacket.PacketByte[0] |= 0x0;
        DPInfoFramePacket.PacketByte[0] |= 0x00;
        DPInfoFramePacket.PacketByte[1] |= 0x00;
        DPInfoFramePacket.PacketByte[1] |= 0x00;

        mmC620 = (DPInfoFramePacket.PacketHeader[3] << 24 ) | (DPInfoFramePacket.PacketHeader[2] << 16) | 
                 (DPInfoFramePacket.PacketHeader[1] << 8) | DPInfoFramePacket.PacketHeader[0];
        mmC624 = (DPInfoFramePacket.PacketByte[3] << 24) | (DPInfoFramePacket.PacketByte[2] << 16) |
                 (DPInfoFramePacket.PacketByte[1] << 8) | DPInfoFramePacket.PacketByte[0];
        mmC628 = (DPInfoFramePacket.PacketByte[7] << 24) | (DPInfoFramePacket.PacketByte[6] << 16) |
                 (DPInfoFramePacket.PacketByte[5] << 8) | DPInfoFramePacket.PacketByte[4];
        mmC62C = (DPInfoFramePacket.PacketByte[11] << 24) | (DPInfoFramePacket.PacketByte[10] << 16) |
                 (DPInfoFramePacket.PacketByte[9] << 8) | DPInfoFramePacket.PacketByte[8];
        mmC630 = (DPInfoFramePacket.PacketByte[15] << 24) | (DPInfoFramePacket.PacketByte[14] << 16) |
                 (DPInfoFramePacket.PacketByte[13] << 8) | DPInfoFramePacket.PacketByte[12];
        mmC634 = (DPInfoFramePacket.PacketByte[19] << 24) | (DPInfoFramePacket.PacketByte[18] << 16) |
                 (DPInfoFramePacket.PacketByte[17] << 8) | DPInfoFramePacket.PacketByte[16];
        mmC638 = (DPInfoFramePacket.PacketByte[23] << 24) | (DPInfoFramePacket.PacketByte[22] << 16) |
                 (DPInfoFramePacket.PacketByte[21] << 8) | DPInfoFramePacket.PacketByte[20];
        mmC63C = (DPInfoFramePacket.PacketByte[27] << 24) | (DPInfoFramePacket.PacketByte[26] << 16) |
                 (DPInfoFramePacket.PacketByte[25] << 8) | DPInfoFramePacket.PacketByte[24];

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC620), mmC620);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC624), mmC624);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC628), mmC628);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC62C), mmC62C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC630), mmC630);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC634), mmC634);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC638), mmC638);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC63C), mmC63C);

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC660), 0x01);  

        mmC640 = (ReadMMIOUlong(CB_MMIO_OFFSET(0xC640)) & 0xFF80000F);
        mmC640 |= 0x00008010;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC640), mmC640);
    }
    
    
}

//--------------------------------------------------------------------------
//  cbHDMISetAVIInfoFrame
//    This function will set InfoFrame data for 410 Internal HDMI
//     IN
//        None
//     OUT
//        Noe
//--------------------------------------------------------------------------
void cbHDMISetAVIInfoFrame(PCBIOS_EXTENSION pcbe, ULONG device, ULONG FormatNum)
{
    HDMI_INFOFRAME  HDMIInfoFramePacket;
    DWORD   i = 0;
    BYTE    checksum = 0;
    DWORD   mmC204, mmC208, mmC20C, mmC210, mmC214, mmC218, mmC21C, mmC220, mmC224;

    DP_INFOFRAME DPInfoFramePacket;
    DWORD   mmC620, mmC624, mmC628, mmC62C, mmC630, mmC634, mmC638, mmC63C, mmC640;

    if(device == S3_HDMI)
    {
        HDMIInfoFramePacket.PacketHeader[0] = 0x82;
        HDMIInfoFramePacket.PacketHeader[1] = 0x02;
        HDMIInfoFramePacket.PacketHeader[2] = 0x0D;
        HDMIInfoFramePacket.ECCCode = cbHDMIInsertBCHCode(HDMIInfoFramePacket.PacketHeader, 3);

        // set Packet Bytes
        for(i = 0; i < 28; i++)
            HDMIInfoFramePacket.PacketByte[i] = 0;
        HDMIInfoFramePacket.PacketByte[1] |= 0x2;
        HDMIInfoFramePacket.PacketByte[1] |= 0x10;
        HDMIInfoFramePacket.PacketByte[2] |= 0x08;

        switch(CEA861_FormatTimingTbl[FormatNum-1].AspectRatio)
        {
            case CBIOS_RATIO_4_3:
                HDMIInfoFramePacket.PacketByte[2] |= 0x10;
                break;
            case CBIOS_RATIO_16_9:
                HDMIInfoFramePacket.PacketByte[2] |= 0x20;
                break;
            default:
                break;
        }

        // ITC bit
        HDMIInfoFramePacket.PacketByte[3] |= 0x80;

        // VIC code
        HDMIInfoFramePacket.PacketByte[4] |= CEA861_FormatTimingTbl[FormatNum-1].Video_ID_Code;

        // count checksum
        for(i = 0; i < 28; i++)
            checksum += HDMIInfoFramePacket.PacketByte[i];
        checksum += ( 0x82 + 0x02 + 0x0D );
        
        checksum = 0x100 - checksum;
        HDMIInfoFramePacket.PacketByte[0] = checksum;

        // set BCHCode
        for(i = 0; i < 4; i++)
        {
            HDMIInfoFramePacket.BCHCode[i] = cbHDMIInsertBCHCode( &(HDMIInfoFramePacket.PacketByte[i*7]), 7);
        }

        mmC204 = (HDMIInfoFramePacket.ECCCode << 24 ) | (HDMIInfoFramePacket.PacketHeader[2] << 16) | 
                 (HDMIInfoFramePacket.PacketHeader[1] << 8) | HDMIInfoFramePacket.PacketHeader[0];
        mmC208 = (HDMIInfoFramePacket.PacketByte[3] << 24) | (HDMIInfoFramePacket.PacketByte[2] << 16) |
                 (HDMIInfoFramePacket.PacketByte[1] << 8) | HDMIInfoFramePacket.PacketByte[0];
        mmC20C = (HDMIInfoFramePacket.BCHCode[0] << 24) | (HDMIInfoFramePacket.PacketByte[6] << 16) |
                 (HDMIInfoFramePacket.PacketByte[5] << 8) | HDMIInfoFramePacket.PacketByte[4];
        mmC210 = (HDMIInfoFramePacket.PacketByte[10] << 24) | (HDMIInfoFramePacket.PacketByte[9] << 16) |
                 (HDMIInfoFramePacket.PacketByte[8] << 8) | HDMIInfoFramePacket.PacketByte[7];
        mmC214 = (HDMIInfoFramePacket.BCHCode[1] << 24) | (HDMIInfoFramePacket.PacketByte[13] << 16) |
                 (HDMIInfoFramePacket.PacketByte[12] << 8) | HDMIInfoFramePacket.PacketByte[11];
        mmC218 = (HDMIInfoFramePacket.PacketByte[17] << 24) | (HDMIInfoFramePacket.PacketByte[16] << 16) |
                 (HDMIInfoFramePacket.PacketByte[15] << 8) | HDMIInfoFramePacket.PacketByte[14];
        mmC21C = (HDMIInfoFramePacket.BCHCode[2] << 24) | (HDMIInfoFramePacket.PacketByte[20] << 16) |
                 (HDMIInfoFramePacket.PacketByte[19] << 8) | HDMIInfoFramePacket.PacketByte[18];
        mmC220 = (HDMIInfoFramePacket.PacketByte[24] << 24) | (HDMIInfoFramePacket.PacketByte[23] << 16) |
                 (HDMIInfoFramePacket.PacketByte[22] << 8) | HDMIInfoFramePacket.PacketByte[21];
        mmC224 = (HDMIInfoFramePacket.BCHCode[3] << 24) | (HDMIInfoFramePacket.PacketByte[27] << 16) |
                 (HDMIInfoFramePacket.PacketByte[26] << 8) | HDMIInfoFramePacket.PacketByte[25];

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC204), mmC204);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC208), mmC208);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC20C), mmC20C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC210), mmC210);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC214), mmC214);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC218), mmC218);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC21C), mmC21C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC220), mmC220);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC224), mmC224);

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC200), 0x80);  
    }

    if(device == S3_DP)
    {
        // header
        DPInfoFramePacket.PacketHeader[0] = 0;       //Secondary-data packet ID;
        DPInfoFramePacket.PacketHeader[1] = 0x82;
        DPInfoFramePacket.PacketHeader[2] = 0x1B;
        DPInfoFramePacket.PacketHeader[3] = 0x44;

        // data
        // set Packet Bytes
        for(i = 0; i < 24; i++)
            DPInfoFramePacket.PacketByte[i] = 0;
        DPInfoFramePacket.PacketByte[0] |= 0x2;
        DPInfoFramePacket.PacketByte[1] |= 0x08;

        switch(CEA861_FormatTimingTbl[FormatNum-1].AspectRatio)
        {
            case CBIOS_RATIO_4_3:
                DPInfoFramePacket.PacketByte[1] |= 0x10;
                break;
            case CBIOS_RATIO_16_9:
                DPInfoFramePacket.PacketByte[1] |= 0x20;
                break;
            default:
                break;
        }

        // ITC bit
        DPInfoFramePacket.PacketByte[2] |= 0x80;

        // VIC code
        DPInfoFramePacket.PacketByte[3] |= CEA861_FormatTimingTbl[FormatNum-1].Video_ID_Code;

        mmC620 = (DPInfoFramePacket.PacketHeader[3] << 24 ) | (DPInfoFramePacket.PacketHeader[2] << 16) | 
                 (DPInfoFramePacket.PacketHeader[1] << 8) | DPInfoFramePacket.PacketHeader[0];
        mmC624 = (DPInfoFramePacket.PacketByte[3] << 24) | (DPInfoFramePacket.PacketByte[2] << 16) |
                 (DPInfoFramePacket.PacketByte[1] << 8) | DPInfoFramePacket.PacketByte[0];
        mmC628 = (DPInfoFramePacket.PacketByte[7] << 24) | (DPInfoFramePacket.PacketByte[6] << 16) |
                 (DPInfoFramePacket.PacketByte[5] << 8) | DPInfoFramePacket.PacketByte[4];
        mmC62C = (DPInfoFramePacket.PacketByte[11] << 24) | (DPInfoFramePacket.PacketByte[10] << 16) |
                 (DPInfoFramePacket.PacketByte[9] << 8) | DPInfoFramePacket.PacketByte[8];
        mmC630 = (DPInfoFramePacket.PacketByte[15] << 24) | (DPInfoFramePacket.PacketByte[14] << 16) |
                 (DPInfoFramePacket.PacketByte[13] << 8) | DPInfoFramePacket.PacketByte[12];
        mmC634 = (DPInfoFramePacket.PacketByte[19] << 24) | (DPInfoFramePacket.PacketByte[18] << 16) |
                 (DPInfoFramePacket.PacketByte[17] << 8) | DPInfoFramePacket.PacketByte[16];
        mmC638 = (DPInfoFramePacket.PacketByte[23] << 24) | (DPInfoFramePacket.PacketByte[22] << 16) |
                 (DPInfoFramePacket.PacketByte[21] << 8) | DPInfoFramePacket.PacketByte[20];
        mmC63C = (DPInfoFramePacket.PacketByte[27] << 24) | (DPInfoFramePacket.PacketByte[26] << 16) |
                 (DPInfoFramePacket.PacketByte[25] << 8) | DPInfoFramePacket.PacketByte[24];

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC620), mmC620);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC624), mmC624);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC628), mmC628);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC62C), mmC62C);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC630), mmC630);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC634), mmC634);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC638), mmC638);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC63C), mmC63C);

        WriteMMIOUlong(CB_MMIO_OFFSET(0xC660), 0x101);  

        mmC640 = (ReadMMIOUlong(CB_MMIO_OFFSET(0xC640)) & 0xFF80000F);
        mmC640 |= 0x00008010;
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC640), mmC640);
    }
    
}

// calcute the BCH code and output 1 byte BCH code
BYTE cbHDMIInsertBCHCode(BYTE* input, DWORD length)
{
    DWORD   i, n;
    DWORD   reg[9]={0, 0, 0, 0, 0, 0, 0, 0, 0};
    DWORD   matrix[56];
    BYTE    output = 0;

    // initialize matrix
    for(i = 0; i < length; i++)
    {
        matrix[0 + i*8] = (input[i] >> 0) & BIT0;
        matrix[1 + i*8] = (input[i] >> 1) & BIT0;
        matrix[2 + i*8] = (input[i] >> 2) & BIT0;
        matrix[3 + i*8] = (input[i] >> 3) & BIT0;
        matrix[4 + i*8] = (input[i] >> 4) & BIT0;
        matrix[5 + i*8] = (input[i] >> 5) & BIT0;
        matrix[6 + i*8] = (input[i] >> 6) & BIT0;
        matrix[7 + i*8] = (input[i] >> 7) & BIT0;
    }

    for(i = 0; i < length * 8; i++)
    {
        reg[0] = reg[8] ^ matrix[i];
        reg[8] = reg[7] ^ reg[0];
        reg[7] = reg[6] ^ reg[0];

        reg[6]=reg[5];
        reg[5]=reg[4];
        reg[4]=reg[3];
        reg[3]=reg[2];
        reg[2]=reg[1];
        reg[1]=reg[0];
    }

    n = 0;
    for(i = 1; i <= 4; i++)
    {
        if(reg[i] == 1)
            n = 2*n + 1;
        else 
            n = 2*n;
    }

    output |= n << 4;

    n = 0;
    for(i = 5; i <= 8; i++)
    {
        if(reg[i] == 1)
            n = 2*n + 1;
        else 
            n = 2*n;
    }

    output |= n;

    return output;
}

BOOL cbSetHDAudioSampleRate(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock)
{
#if (EFI_CBIOS)
    DWORD   i = 0;
#endif
    DWORD   mmC400=0, mmC404=0, mmC410=0, mmC414=0, rem = 0;
    DWORDLONG WallClock = 0, PacketClock = 0;

    if(dwPixelClock == 0)
    {
        cbDbgPrint(0,"cbSetHDAudioSampleRate : divide by zero error!\n");
        return FALSE;
    }

#if LINUX_PLATFORM
    mmC404 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC404)) & 0xFFFF7F00;
#else
    mmC404 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC404)) & 0xFFFFFF00;
#endif
    mmC414 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC414)) & 0xFFFFFF00;

    cbDbgPrint(0,"cbSetHDAudioSampleRate: pixel clock %ld!\n", dwPixelClock);
    cbDbgPrint(0,"cbSetHDAudioSampleRate: dwSampleRate %ld!\n", dwSampleRate);

#if (EFI_CBIOS)
    // we can't use 64bit/float operation in linux kernel
    for(i = 0; i < SampleRateReg_NUM; i++)
    {
        if(SampleRateReg[i].SampleRate == dwSampleRate && SampleRateReg[i].PixelClock == dwPixelClock)
        {
            // Wall clock
            mmC400 = SampleRateReg[i].MM_C400;
            mmC404 = SampleRateReg[i].MM_C404;
            // Audio sample rate
            mmC410 = SampleRateReg[i].MM_C410;
            mmC414 = SampleRateReg[i].MM_C414;
            break;
        }      
    }

    if(i == SampleRateReg_NUM)
    {
        // Wall clock
        WallClock = ((0xFFFFFFFF / dwPixelClock) * 24000000);
        mmC400 = (DWORD)(WallClock & 0xFFFFFF) << 8;
        mmC404 |= (DWORD)WallClock >> 24;
        // Audio sample rate
        PacketClock = (0xFFFFFFFF / dwPixelClock) * dwSampleRate;
        mmC410 = (DWORD)(PacketClock & 0xFFFFFF) << 8;
        mmC414 |= (DWORD)PacketClock >> 24;
    }

#else
    WallClock = TWO2FORTHY;
#if LINUX_PLATFORM
    rem = do_div(WallClock, dwPixelClock);
 #else 
    WallClock = TWO2FORTHY / dwPixelClock;
 #endif
    WallClock *= 24000000;
    mmC400 = (DWORD)(WallClock & 0xFFFFFFFF);
    mmC404 |= (DWORD)(WallClock >> 32);

    PacketClock = dwSampleRate * TWO2FORTHY;
#if LINUX_PLATFORM
    rem = do_div(PacketClock, dwPixelClock);
#else
    PacketClock /= dwPixelClock;
#endif
    mmC410 = (DWORD)(PacketClock & 0xFFFFFFFF);
    mmC414 |= (DWORD)(PacketClock >> 32); 
#endif
    mmC404 |= BIT23;

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC404), mmC404);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC400), mmC400);

    cbDbgPrint(0,"cbSetHDAudioSampleRate: wall clock %x!\n", WallClock);
    cbDbgPrint(0,"cbSetHDAudioSampleRate: wall clock Low %x!\n", mmC400);
    cbDbgPrint(0,"cbSetHDAudioSampleRate: wall clock High %x!\n", mmC404);    

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC414), mmC414);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC410), mmC410);

    cbDbgPrint(0,"cbSetHDAudioSampleRate: PacketClock %x!\n", PacketClock);
    cbDbgPrint(0,"cbSetHDAudioSampleRate: PacketClock Low %x!\n", mmC410);
    cbDbgPrint(0,"cbSetHDAudioSampleRate: PacketClock High %x!\n", mmC414);
   
    return TRUE;
}

ULONG cbSetHDAudioCTSandN(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock)
{
#if (EFI_CBIOS)
    DWORD   i = 0;
#endif
    ULONG   mmC294 = 0, mmC298 = 0, mmC29C = 0, CTSInterval = 0;
    DWORDLONG  CTS = 0, N = 0;
    DWORDLONG  CTSx1000 = 0 , rem = 0;

    if(dwPixelClock == 0 || dwSampleRate== 0)
    {
        cbDbgPrint(0,"cbSetHDAudioCTSandN : divide by zero error!\n");
        return FALSE;
    }
/* 
 * CTS and N value setting refer to 2.6.38 kernel
 * drivers/gpu/drm/radeon/r600_hdmi.c
 * r600_hdmi_calc_CTS funtion.
 * we fix N to 6144, and calculate CTS here.
 */
#if (EFI_CBIOS)
    for(i = 0; i < CTSandNReg_NUM; i++)
    {
        if(CTSandNReg[i].SampleRate == dwSampleRate && CTSandNReg[i].PixelClock == dwPixelClock)
        {
            mmC294 = CTSandNReg[i].MM_C294;
            mmC298 = CTSandNReg[i].MM_C298;
            mmC29C = CTSandNReg[i].MM_C29C;
            break;
        }
    }
#else
    N = 6144;
    CTS = (dwPixelClock * N);
#if LINUX_PLATFORM
    rem = do_div(CTS, (128 * dwSampleRate));
#else
    CTS /= (128 * dwSampleRate);
#endif

    CTSx1000 = (dwPixelClock * N) * 1000;
#if LINUX_PLATFORM
    rem = do_div(CTSx1000, (128 * dwSampleRate));
#else
    CTSx1000 /= (128*dwSampleRate);
#endif

    cbDbgPrint(0, "cbSetHDAudioCTSandN: CTS = %x, myCTS= %x\n", CTS, dwPixelClock / (128*dwSampleRate) * N);
    
    CTSInterval = (ULONG)(CTSx1000 - (CTS * 1000));

    mmC294 = (ReadMMIOUlong(CB_MMIO_OFFSET(0xc294)) & 0x0000000F) | 0x100000C0;
    mmC294 |= ((DWORD)(CTS-1) << 8);
        
    mmC298 = (DWORD)(N) | (((DWORD)(CTS) & 0xFFF ) << 20);

    mmC29C = ReadMMIOUlong(CB_MMIO_OFFSET(0xC29C)) & 0xFFFFFF00;
    mmC29C |= (((DWORD)(CTS) >> 12) & 0xFF);
#endif

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC294), mmC294);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC298), mmC298);
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC29C), mmC29C);

    cbDbgPrint(0,"cbSetHDAudioCTSandN: mmC294 %x!\n", mmC294);
    cbDbgPrint(0,"cbSetHDAudioCTSandN: mmC298 %x!\n", mmC298);
    cbDbgPrint(0,"cbSetHDAudioCTSandN: mmC29C %x!\n", mmC29C);

    return CTSInterval;
}

BOOL cbSetHDAudioMaudNaud(PCBIOS_EXTENSION pcbe, DWORD dwSampleRate, DWORD dwPixelClock, DWORD DPIndex)
{
    DWORD MaudReg = 0, NaudReg = 0;
    DWORDLONG Naud = 0x8000, Maud = 0, rem = 0;

    if(dwPixelClock == 0 || dwSampleRate== 0)
    {
        cbDbgPrint(0,"cbSetHDAudioMaudNaud : divide by zero error!\n");
        return FALSE;
    }

    if(DPIndex == DP1)
    {
        NaudReg = ReadMMIOUlong(CB_MMIO_OFFSET(0xC738)) & 0xFF000000;
        MaudReg = ReadMMIOUlong(CB_MMIO_OFFSET(0xC73C)) & 0xFF000000;
    }
    if(DPIndex == DP2)
    {
        NaudReg = ReadMMIOUlong(CB_MMIO_OFFSET(0xC7B8)) & 0xFF000000;
        MaudReg = ReadMMIOUlong(CB_MMIO_OFFSET(0xC7BC)) & 0xFF000000;
    }

    Maud = Naud * 512 * dwSampleRate;
#if LINUX_PLATFORM
    rem = do_div(Maud, dwPixelClock);
#else
    Maud /= dwPixelClock;
#endif

    NaudReg |= Naud;
    MaudReg |= Maud;

    if(DPIndex == DP1)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC738), NaudReg);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC73C), MaudReg);
    }
    if(DPIndex == DP2)
    {
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC7B8), NaudReg);
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC7BC), MaudReg);
    }

    return TRUE;
}

DWORD cbGetHDMIVICByTargetTiming(PCBIOS_EXTENSION pcbe, DWORD H_Res, DWORD V_Res, RefreshRateInfo RRateInfo)
{
    DWORD i = 0, VIC = 0;
    
    for(i = 0; i < CEA861_FORMAT_NUM; i++)
    {
        if( H_Res == CEA861_FormatTbl[i].XRes && 
            V_Res == CEA861_FormatTbl[i].YRes &&
            RRateInfo.rRateX100 == CEA861_FormatTbl[i].rRateX100 && 
            RRateInfo.interlaced == CEA861_FormatTbl[i].Interlaced )
        {
            VIC = CEA861_FormatTbl[i].Video_ID_Code;
            break;
        }
    }

    if(VIC == 0)
    {
        // find a nearest CEA mode to the target mode
        // 720x480; 1280x720; 1920x1080 all are 60P
        if( H_Res < 1280 && V_Res < 720 )
        {
            VIC = 4;    // 720P
        }
        else
        {
            VIC = 16;    // 1080P
        }
    }

    return VIC;
}

//--------------------------------------------------------------------------
//  cbCheckAD9389ConnectStatus
//    Not used function. Keep it for Driver/Cbios consistency
//--------------------------------------------------------------------------
BOOL cbCheckAD9389ConnectStatus( PVOID pvcbe, DWORD dev)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    i2c.Flags = 0;
    
    // get i2c info first
    if(!cbGetDII2Csetting(pcbe, &i2c, dev))
    {
        return FALSE;
    }

    // get Device associate TX type
    if(cbGetDITXtype(pcbe, &TXType, dev) == TRUE)
    {
        i2c.RegIndex  = 0x42;           // Connect status at bit 6
        I2C_Read_Byte_INV(pcbe, &i2c);  // get i2c register index data
        //Reg.0x42[6]=1: State of the hot plug detection is active, [5]=1:HDMI clock termination detected.
        //We use them both to detection 9389's device connetion status([6] may not work on some HDMI in S3)
        if(i2c.IndexData & 0x60)
            return TRUE;                // Device Connect 
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbInitAD9389
//    Not used function. Keep it for Driver/Cbios consistency
//--------------------------------------------------------------------------
void cbInitAD9389(PVOID pvcbe, DWORD dev)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    i2c.Flags = 0;
    
    // get i2c info first
    if (!cbGetDII2Csetting(pcbe, &i2c, dev))
    {
        return;
    }  

    // get Device associate TX type
    if(cbGetDITXtype(pcbe, &TXType, dev) == TRUE)
    {
        i2c.RegIndex  = 0xBA;
        i2c.IndexData = 0x90;           // RxBA[7:5] clk delay
        I2C_Write_Byte_INV(pcbe, &i2c); // RxBA[4] = 1, for proper operation
    }

    //SetUpDeGen();
    //TransmiterToPD();
}

BOOL cbGetRefreshRatesForDVIorHDMI (
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{
    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "cbGetRefreshRatesForDVIorHDMI: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if(dispDev == S3_DVI)
    {
        if (pcbe->devicetimingtype[DVIbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DVI,
                                                                          H_Res,
                                                                          V_Res,
                                                                          pRRatesInfoBuf,
                                                                          *pBufSize,
                                                                          NULL))
            {
                return FALSE;
            }
        }
        else if (pcbe->devicetimingtype[DVIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DVI,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                
        }        
        else if (pcbe->devicetimingtype[DVIbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DVI,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }                

    }
    else if(dispDev == S3_DVI2)
    {
        if (pcbe->devicetimingtype[DVI2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI2 VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DVI2,
                                                                          H_Res,
                                                                          V_Res,
                                                                          pRRatesInfoBuf,
                                                                          *pBufSize,
                                                                          NULL))
            {
                return FALSE;
            }
         }
         else if (pcbe->devicetimingtype[DVI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
         {
             // DVI2 Refresh rate reported
             // EDID or customize timing valid
             // 1. If Detailed timing: report its refresh rate only;
             // 2. If Est / STD timing smaller than EDID detailed timing: 
             //    find in VESAVPIT , if find then report founded refresh rate. 
             //    else using center on EDID detailed timing
             // 3. if Est / STD timing bigger than EDID detailed timing:
             //    find in VESAVPIT 
             //    if Est / STD resolution == EDID detailed resolution
             //    also add Est / STD timing & report them
             // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DVI2,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }                
        }
        else if (pcbe->devicetimingtype[DVI2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DVI2,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe, 
                                                            H_Res,
                                                            V_Res,
                                                            pRRatesInfoBuf,
                                                            *pBufSize,
                                                            NULL))
                {
                    return FALSE;
                }
            }
        }
        else
        {
            return FALSE;
        }                
    }
    else if(dispDev == S3_HDMI)
    {
        if (pcbe->devicetimingtype[HDMIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {        
            // HDMI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_HDMI,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID all invalid 
                // report all CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       pRRatesInfoBuf,
                                                       *pBufSize,
                                                       NULL))
                {
                    return FALSE;
                }
            }         
        }
        else if (pcbe->devicetimingtype[HDMIbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_HDMI,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       pRRatesInfoBuf,
                                                       *pBufSize,
                                                       NULL))
                {
                    return FALSE;
                }
            }
        }    
        else
        {
            return FALSE;
        }          

    }
    else if(dispDev == S3_HDMI2)
    {
        if (pcbe->devicetimingtype[HDMI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {        
            // HDMI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target timing
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_HDMI2,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // no Customize timing && EDID all invalid 
                // report all CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       pRRatesInfoBuf,
                                                       *pBufSize,
                                                       NULL))
                {
                    return FALSE;
                }
            }         
        }
        else if (pcbe->devicetimingtype[HDMI2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_HDMI2,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                // no Customize timing && EDID timing all invalid 
                // report all CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       pRRatesInfoBuf,
                                                       *pBufSize,
                                                       NULL))
                {
                    return FALSE;
                }
            }
        }    
        else
        {
            return FALSE;
        }          

    }
    else
    {
        cbDbgPrint(0, "cbGetRefreshRatesForDVIorHDMI: Error, incorrectly parameter! \n");
        return FALSE;

    }

    return TRUE;
}

