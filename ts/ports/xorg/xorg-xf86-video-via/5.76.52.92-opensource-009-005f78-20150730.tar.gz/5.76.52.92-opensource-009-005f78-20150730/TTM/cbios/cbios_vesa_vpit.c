/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * All DMT, establised timing, CEA861 timing refer to
 * xorg-server-1.12.2/hw/xfree86/modes/xf86EdidModes.c
 */
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"

static VESA_VPIT Mode640x480_RefreshRate_Buf[] = 
            {{DCLK_25_2M,   60, ATT_NHS+ATT_NVS,               800,  656,  752,  525,  490,  492},   // by VESA 1.0 R10
             {DCLK_31_5M,   72, ATT_NHS+ATT_NVS,               832,  664,  704,  520,  489,  492},   // by VESA 1.0 R10
             {DCLK_31_5M,   75, ATT_NHS+ATT_NVS,               840,  656,  720,  500,  481,  484},   // by VESA 1.0 R10 
             {DCLK_36M,     85, ATT_NHS+ATT_NVS,               832,  656,  720,  509,  481,  484}};  // by VESA 1.0 R10
#define Mode640x480_RefreshRateNUM  (sizeof(Mode640x480_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode800x600_RefreshRate_Buf[] = 
            {{DCLK_36M,     56, ATT_PHS+ATT_PVS,               1024,  824, 896,  625,  601,  603},   // by VESA 1.0 R10
             {DCLK_40M,     60, ATT_PHS+ATT_PVS,               1056,  840, 968,  628,  601,  605},   // by VESA 1.0 R10
             {DCLK_50M,     72, ATT_PHS+ATT_PVS,               1040,  856, 976,  666,  637,  643},   // by VESA 1.0 R10
             {DCLK_49_5M,   75, ATT_PHS+ATT_PVS,               1056,  816, 896,  625,  601,  604},   // by VESA 1.0 R10
             {DCLK_56_25M,  85, ATT_PHS+ATT_PVS,               1048,  832, 896,  631,  601,  604}};  // by VESA 1.0 R10
#define Mode800x600_RefreshRateNUM  (sizeof(Mode800x600_RefreshRate_Buf) / sizeof(VESA_VPIT))
 
static VESA_VPIT Mode1024x768_RefreshRate_Buf[] = 
            {{DCLK_65M,     60, ATT_NHS+ATT_NVS,               1344, 1048, 1184,  806,  771,  777},   // by VESA 1.0 R10
             {DCLK_75M,     70, ATT_NHS+ATT_NVS,               1328, 1048, 1184,  806,  771,  777},   // by VESA 1.0 R10
             {DCLK_78_75M,  75, ATT_PHS+ATT_PVS,               1312, 1040, 1136,  800,  769,  772},   // by VESA 1.0 R10
             {DCLK_94_5M,   85, ATT_PHS+ATT_PVS,               1376, 1072, 1168,  808,  769,  772}};  // by VESA 1.0 R10
#define Mode1024x768_RefreshRateNUM  (sizeof(Mode1024x768_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x720_RefreshRate_Buf[] = 
            {{DCLK_62M,     50, ATT_PHS+ATT_PVS,               1664, 1336, 1472,  746,  721,  724},   // from VBIOS timing table
             {DCLK_72_78M,  59, ATT_PHS+ATT_PVS,               1664, 1336, 1472,  746,  721,  724},   // from VBIOS timing table
             {DCLK_74_27M,  60, ATT_PHS+ATT_PVS,               1664, 1336, 1472,  746,  721,  724}};  // by GTF V1R1
#define Mode1280x720_RefreshRateNUM  (sizeof(Mode1280x720_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x768_RefreshRate_Buf[] = 
            {{DCLK_79_47M,  60, ATT_NHS+ATT_PVS,               1664, 1344, 1472,  798,  771,  778},   // by VESA 1.0 R10
             {DCLK_102_91M, 75, ATT_NHS+ATT_PVS,               1696, 1360, 1488,  805,  771,  778},   // by VESA 1.0 R10
             {DCLK_117_5M,  85, ATT_NHS+ATT_PVS,               1712, 1360, 1496,  809,  771,  778}};  // by VESA 1.0 R10
#define Mode1280x768_RefreshRateNUM  (sizeof(Mode1280x768_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x800_RefreshRate_Buf[] = 
            {{DCLK_83_5M,   60, ATT_NHS+ATT_PVS,               1680, 1344, 1480,  828,  801,  804},   // by VESA 1.0 R10
             {DCLK_107M,    75, ATT_NHS+ATT_PVS,               1712, 1360, 1496,  835,  801,  804},   // by VESA 1.0 R10
             {DCLK_122_9M,  85, ATT_NHS+ATT_PVS,               1728, 1368, 1504,  840,  801,  804}};  // by VESA 1.0 R10
#define Mode1280x800_RefreshRateNUM  (sizeof(Mode1280x800_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1280x960_RefreshRate_Buf[] = 
            {{DCLK_108M,    60, ATT_PHS+ATT_PVS,               1800, 1376, 1488, 1000,  961,  964},   // by VESA 1.0 R10  
             {DCLK_148_5M,  85, ATT_PHS+ATT_PVS,               1728, 1344, 1504, 1011,  961,  964}};  // by VESA 1.0 R10
#define Mode1280x960_RefreshRateNUM  (sizeof(Mode1280x960_RefreshRate_Buf) / sizeof(VESA_VPIT))
  
static VESA_VPIT Mode1280x1024_RefreshRate_Buf[] = 
            {{DCLK_108M,    60, ATT_PHS+ATT_PVS,               1688, 1328, 1440, 1066, 1025, 1028},   // by VESA 1.0 R10
             {DCLK_135M,    75, ATT_PHS+ATT_PVS,               1688, 1296, 1440, 1066, 1025, 1028},   // by VESA 1.0 R10
             {DCLK_157_5M,  85, ATT_PHS+ATT_PVS,               1728, 1344, 1504, 1072, 1025, 1028}};  // by VESA 1.0 R10
#define Mode1280x1024_RefreshRateNUM  (sizeof(Mode1280x1024_RefreshRate_Buf) / sizeof(VESA_VPIT)) 

static VESA_VPIT Mode1360x768_RefreshRate_Buf[] = 
            {{DCLK_85_91M,  60, ATT_PHS+ATT_PVS,               1792, 1424, 1536,  795,  771,  777},    // by VESA 1.0 R10
             {DCLK_108_8M,  75, ATT_PHS+ATT_PVS,               1808, 1440, 1584,  802,  769,  772}};   // by VESA 1.0 R10
#define Mode1360x768_RefreshRateNUM  (sizeof(Mode1360x768_RefreshRate_Buf) / sizeof(VESA_VPIT))
   
static VESA_VPIT Mode1440x900_RefreshRate_Buf[] = 
            {{DCLK_106_47M, 60, ATT_NHS+ATT_PVS,               1904, 1520, 1672,  934,  903,  909},    // by VESA 1.0 R10
             {DCLK_136_74M, 75, ATT_NHS+ATT_PVS,               1936, 1536, 1688,  942,  903,  909},    // by VESA 1.0 R10
             {DCLK_156_8M,  85, ATT_NHS+ATT_PVS,               1952, 1544, 1696,  948,  903,  909}};   // by VESA 1.0 R10
#define Mode1440x900_RefreshRateNUM  (sizeof(Mode1440x900_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1400x1050_RefreshRate_Buf[] = 
            {{DCLK_121_70M, 60, ATT_NHS+ATT_PVS,               1864, 1488, 1632, 1089, 1053, 1057},    // by VESA 1.0 R10
             {DCLK_156M,    75, ATT_NHS+ATT_PVS,               1896, 1504, 1648, 1099, 1053, 1057},    // by VESA 1.0 R10
             {DCLK_178_8M,  85, ATT_NHS+ATT_PVS,               1912, 1504, 1656, 1105, 1053, 1057}};   // by VESA 1.0 R10
#define Mode1400x1050_RefreshRateNUM  (sizeof(Mode1400x1050_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1600x1200_RefreshRate_Buf[] = 
            {{DCLK_162M,    60, ATT_PHS+ATT_PVS,               2160, 1664, 1856, 1250, 1201, 1204},    // by VESA 1.0 R10  
             {DCLK_175M,    65, ATT_PHS+ATT_PVS,               2160, 1664, 1856, 1250, 1201, 1204},    // by VESA 1.0 R10  
             {DCLK_189M,    70, ATT_PHS+ATT_PVS,               2160, 1664, 1856, 1250, 1201, 1204},    // by VESA 1.0 R10  
             {DCLK_202_5M,  75, ATT_PHS+ATT_PVS,               2160, 1664, 1856, 1250, 1201, 1204},    // by VESA 1.0 R10  
             {DCLK_229_5M,  85, ATT_PHS+ATT_PVS,               2160, 1664, 1856, 1250, 1201, 1204}};   // by VESA 1.0 R10  
#define Mode1600x1200_RefreshRateNUM  (sizeof(Mode1600x1200_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1680x1050_RefreshRate_Buf[] = 
            {{DCLK_146_76M, 60, ATT_NHS+ATT_PVS,               2240, 1784, 1960, 1089, 1053, 1059},     // by VESA 1.0 R10  
             {DCLK_187_568M,75, ATT_NHS+ATT_PVS,               2272, 1800, 1976, 1099, 1053, 1059},     // by VESA 1.0 R10  
             {DCLK_214_772M,85, ATT_NHS+ATT_PVS,               2288, 1808, 1984, 1105, 1053, 1059}};    // by VESA 1.0 R10  
#define Mode1680x1050_RefreshRateNUM  (sizeof(Mode1680x1050_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1920x1080_RefreshRate_Buf[] = 
           {{DCLK_173M,    60, ATT_NHS+ATT_PVS,               2576, 2040, 2248, 1120, 1082, 1087}};     // by VESA 1.0 R10      
#define Mode1920x1080_RefreshRateNUM  (sizeof(Mode1920x1080_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT Mode1920x1200_RefreshRate_Buf[] = 
            {{DCLK_193M,    60, ATT_NHS+ATT_PVS,               2592, 2056, 2256, 1245, 1203, 1209},     // by VESA 1.0 R10  
             {DCLK_245_198M,75, ATT_NHS+ATT_PVS,               2608, 2056, 2264, 1255, 1203, 1209},     // by VESA 1.0 R10  
             {DCLK_281_590M,85, ATT_NHS+ATT_PVS,               2624, 2064, 2272, 1262, 1203, 1209}};    // by VESA 1.0 R10  
#define Mode1920x1200_RefreshRateNUM  (sizeof(Mode1920x1200_RefreshRate_Buf) / sizeof(VESA_VPIT))


//-----------------------------------------------------------------------
// CEA mode support---This table is obsoleted after adding all ceat timing suppport
//      1. MODE640x480
//      2. MODE720x480
//      3. MODE1280x720
//      4. MODE1920x1080
//-----------------------------------------------------------------------

static VESA_VPIT CEAMode640x480_RefreshRate_Buf[] = 
            {
            {DCLK_25_2M,   60, ATT_NHS+ATT_NVS, 800,  656,  752,  525,  490,  492}
             };  // by CEA-861 spec
#define CEAMode640x480_RefreshRateNUM  (sizeof(CEAMode640x480_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT CEAMode720x480_RefreshRate_Buf[] = 
            {
            {DCLK_27_07M,  60, ATT_NHS+ATT_NVS, 858,  736,  798,  525,  489,  495}
            };  // by CEA-861 spec
#define CEAMode720x480_RefreshRateNUM  (sizeof(CEAMode720x480_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT CEAMode1280x720_RefreshRate_Buf[] = 
            {
            {DCLK_74_27M,  50, ATT_PHS+ATT_PVS, 1980, 1720, 1760, 750,  725,  730},
            {DCLK_74_27M,  60, ATT_PHS+ATT_PVS, 1650, 1390, 1430, 750,  725,  730}
            };  // CEA-861 spec
#define CEAMode1280x720_RefreshRateNUM  (sizeof(CEAMode1280x720_RefreshRate_Buf) / sizeof(VESA_VPIT))

static VESA_VPIT CEAMode1920x1080_RefreshRate_Buf[] = 
            {
            {DCLK_148_5M,  60, ATT_PHS+ATT_PVS, 2200, 2008, 2052, 1125,  1084,  1089}
            };  // CEA-861 spec
#define CEAMode1920x1080_RefreshRateNUM  (sizeof(CEAMode1920x1080_RefreshRate_Buf) / sizeof(VESA_VPIT))



//-----------------------------------------------------------------------
// Generic mode support AND ENABLE---This function is obsoleted after adding all ceat timing suppport
//      1. MODE640x480_SUPPORT         =       TRUE
//      2. MODE720x480_SUPPORT         =       TRUE
//      3. MODE1280x720_SUPPORT        =       TRUE
//----------------------------------------------------------------------
CEA_INFO_CBIOS CEA_MODE_TABLE_CBIOS[CBIOS_CEA_MODESUPPORT_NUM] =  
               {{{ 640,  480, 0x101, 0x111, 0x112, CEAMode640x480_RefreshRateNUM},   CEAMode640x480_RefreshRate_Buf},
                {{ 720,  480, 0x171, 0x173, 0x175, CEAMode720x480_RefreshRateNUM},   CEAMode720x480_RefreshRate_Buf},
                {{1280,  720, 0x125, 0x126, 0x127, CEAMode1280x720_RefreshRateNUM},  CEAMode1280x720_RefreshRate_Buf},
                {{1920, 1080, 0x166, 0x167, 0x168, CEAMode1920x1080_RefreshRateNUM},  CEAMode1920x1080_RefreshRate_Buf}
                };


//-----------------------------------------------------------------------
// Generic mode support AND ENABLE
//      1. MODE640x480_SUPPORT         =       TRUE
//      2. MODE800x600_SUPPORT         =       TRUE
//      3. MODE1024x768_SUPPORT        =       TRUE
//      4. MODE1280x720_SUPPORT        =       TRUE
//      5. MODE1280x768_SUPPORT        =       TRUE
//      6. MODE1280x800_SUPPORT        =       TRUE
//      7. MODE1280x960_SUPPORT        =       TRUE
//      8. MODE1280x1024_SUPPORT       =       TRUE
//      9. MODE1360X768_SUPPORT        =       TRUE
//     10. MODE1440X900_SUPPORT        =       TRUE
//     11. MODE1400X1050_SUPPORT       =       TRUE
//     12. MODE1600x1200_SUPPORT       =       TRUE
//     13. MODE1680x1050_SUPPORT       =       TRUE
//     14. MODE1920x1080_SUPPORT       =       TRUE
//     15. MODE1920X1200_SUPPORT       =       TRUE
//----------------------------------------------------------------------
VESA_INFO_CBIOS MODE_TABLE_CBIOS[CBIOS_GENRIC_MODESUPPORT_NUM] =  
               {{{ 640,  480, 0x101, 0x111, 0x112, Mode640x480_RefreshRateNUM},   Mode640x480_RefreshRate_Buf},
                {{ 800,  600, 0x103, 0x114, 0x115, Mode800x600_RefreshRateNUM},   Mode800x600_RefreshRate_Buf},
                {{1024,  768, 0x105, 0x117, 0x118, Mode1024x768_RefreshRateNUM},  Mode1024x768_RefreshRate_Buf},
                {{1280,  720, 0x125, 0x126, 0x127, Mode1280x720_RefreshRateNUM},  Mode1280x720_RefreshRate_Buf},
                {{1280,  768, 0x179, 0x17A, 0x17B, Mode1280x768_RefreshRateNUM},  Mode1280x768_RefreshRate_Buf},
                {{1280,  800, 0x1B6, 0x1B7, 0x1B8, Mode1280x800_RefreshRateNUM},  Mode1280x800_RefreshRate_Buf},
                {{1280,  960, 0x13F, 0x14F, 0x16A, Mode1280x960_RefreshRateNUM},  Mode1280x960_RefreshRate_Buf},
                {{1280, 1024, 0x107, 0x11A, 0x11B, Mode1280x1024_RefreshRateNUM}, Mode1280x1024_RefreshRate_Buf},
                {{1360,  768, 0x16C, 0x16D, 0x16E, Mode1360x768_RefreshRateNUM},  Mode1360x768_RefreshRate_Buf},
                {{1440,  900, 0x211, 0x212, 0x213, Mode1440x900_RefreshRateNUM},  Mode1440x900_RefreshRate_Buf},
                {{1400, 1050, 0x13B, 0x13C, 0x13E, Mode1400x1050_RefreshRateNUM}, Mode1400x1050_RefreshRate_Buf},
                {{1600, 1200, 0x120, 0x122, 0x124, Mode1600x1200_RefreshRateNUM}, Mode1600x1200_RefreshRate_Buf},
                {{1680, 1050, 0x12B, 0x12C, 0x12D, Mode1680x1050_RefreshRateNUM}, Mode1680x1050_RefreshRate_Buf},
                {{1920, 1080, 0x166, 0x167, 0x168, Mode1920x1080_RefreshRateNUM}, Mode1920x1080_RefreshRate_Buf},
                {{1920, 1200, 0x196, 0x197, 0x198, Mode1920x1200_RefreshRateNUM}, Mode1920x1200_RefreshRate_Buf}};

