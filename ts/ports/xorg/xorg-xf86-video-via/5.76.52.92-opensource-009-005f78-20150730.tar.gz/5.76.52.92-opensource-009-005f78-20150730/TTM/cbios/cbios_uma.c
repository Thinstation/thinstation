/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <linux/kernel.h> 
#include <linux/module.h> 
#include <linux/fs.h> 
#include <asm/uaccess.h> 
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/version.h>

#include "cbios_platform.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"
#include "cbios_cea_timing.h"
#include "cbios_ver.h"

UINT32 dp1LinkspeedConf;
UINT32 dp2LinkspeedConf;

// CBIOS interface function pointer map table
static CBIOS_PROC_ADDR FunctionPointerTbl[]=
{ 
    // Add new cbios interface here, like:
    //{"FunctionName",  sizeof("FunctionName"),  (CBIOSPROC)FunctionName}
#if DBG    
    {"CBiosDummyFunction", sizeof("CBiosDummyFunction"), (CBIOSPROC)CBiosDummyFunction},
#endif    
    {"CBiosUpdateOutputDeviceToVBIOS",  sizeof("CBiosUpdateOutputDeviceToVBIOS"),   (CBIOSPROC)CBiosUpdateOutputDeviceToVBIOS},
    {"CBiosSetInfoFrameData",           sizeof("CBiosSetInfoFrameData"),            (CBIOSPROC)CBiosSetInfoFrameData},
    {"CBiosSetTiming",                  sizeof("CBiosSetTiming"),                   (CBIOSPROC)CBiosSetTiming},
    {"CBiosGetFakeEdid",                sizeof("CBiosGetFakeEdid"),                 (CBIOSPROC)CBiosGetFakeEdid},
    {"CBiosSetCPUDirectAccessFB",       sizeof("CBiosSetCPUDirectAccessFB"),        (CBIOSPROC)CBiosSetCPUDirectAccessFB},
    {"CBiosSetHDAudioParameter",        sizeof("CBiosSetHDAudioParameter"),         (CBIOSPROC)CBiosSetHDAudioParameter},
    {"CBiosSetHDMIAVMute",              sizeof("CBiosSetHDMIAVMute"),               (CBIOSPROC)CBiosSetHDMIAVMute},
    {"CBiosSlowDownClock",              sizeof("CBiosSlowDownClock"),               (CBIOSPROC)CBiosSlowDownClock},
    {"CBiosPWMControl",                 sizeof("CBiosPWMControl"),                  (CBIOSPROC)CBiosPWMControl},
    {"CBiosSetHDMIAudio",               sizeof("CBiosSetHDMIAudio"),                (CBIOSPROC)CBiosSetHDMIAudio},
    {"CBiosSetHDACConnectStatus",       sizeof("CBiosSetHDACConnectStatus"),        (CBIOSPROC)CBiosSetHDACConnectStatus},   
#if !LINUX_PLATFORM
	{"CBiosGetChipSSID",        		sizeof("CBiosGetChipSSID"),		            (CBIOSPROC)CBiosGetChipSSID},	  
#endif
    {"CBiosSetUSBHandle",               sizeof("CBiosSetUSBHandle"),                (CBIOSPROC)CBiosSetUSBHandle}, 
	{"CBiosSetIGAPitch",                sizeof("CBiosSetIGAPitch"),                 (CBIOSPROC)CBiosSetIGAPitch},
	{"CBiosGetBiosCaps",				sizeof("CBiosGetBiosCaps"), 			    (CBIOSPROC)CBiosGetBiosCaps},
	{NULL,       0,              NULL}
};

//------------------Display Resolution-----------------------------------------

//*****************************************************************************
//
//  CBiosSetMode
//
//  This function sets the desired enhanced mode to one of the IGAs.
//  The timing of the other IGA will not be affected.
//  This function doesn��t clear video memory.
//
//  Parameters:
//      IGA_Num:        0 = IGA1, 1 = IGA2
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      colorDepth:     8 / 16 / 32 (bpp)
//      RRateInfo:     actual refresh rate * 100 (decimal)
//                      whether interlaced
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetMode(
    PVOID pvcbe,
    IN DWORD IGA_Num,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    BYTE cr30, cr9F;
        
    // save Power Now Indicator
    cr30 = cbReadRegByte(pcbe, CR_30);    // IGA1 CR30[2]
    cr9F = cbReadRegByte(pcbe, CR_9F);    // IGA2 CR9F[7]
    // Disable Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, 0);      // CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, 0);      // CR9F[7]

    // common registers
    cbLoadTable_UMA(pcbe, UMA_ModeCommon);

    if (IGA1 == IGA_Num)
    {
        status = cbSetIGA1DevMode(pcbe, H_Res, V_Res, colorDepth, RRateInfo);
    }
    else if (IGA2 == IGA_Num)
    {
        status = cbSetIGA2DevMode(pcbe, H_Res, V_Res, colorDepth, RRateInfo);
    }  
    // restore Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, cr30);    // IGA1 CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, cr9F);    // IGA2 CR9F[7]

    return status;
}

//*****************************************************************************
//
//  CBiosSetModeTwo
//
//  This function sets the desired enhanced modes to both IGAs.
//  This function doesn��t clear video memory.
//
//  Parameters:
//      H_ResIGA1:          IGA1 Horizontal Resolution (pixel)
//      V_ResIGA1:          IGA1 Vertical Resolution (pixel)
//      colorDepthIGA1:     IGA1 8 / 16 / 32 (bpp)
//      RRatesInfoIGA1:     IGA1 actual refresh rate * 100 (decimal)
//                          IGA1 whether interlaced
//      H_ResIGA2:          IGA2 Horizontal Resolution (pixel)
//      V_ResIGA2:          IGA2 Vertical Resolution (pixel)
//      colorDepthIGA2:     IGA2 8 / 16 / 32 (bpp)
//      RRatesInfoIGA2:     IGA2 actual refresh rate * 100 (decimal)
//                          IGA2 whether interlaced
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetModeTwo (
    PVOID pvcbe, 
    IN DWORD H_ResIGA1,
    IN DWORD V_ResIGA1,
    IN DWORD colorDepthIGA1,
    IN RefreshRateInfo RRatesInfoIGA1,
    IN DWORD H_ResIGA2,
    IN DWORD V_ResIGA2,
    IN DWORD colorDepthIGA2,
    IN RefreshRateInfo RRatesInfoIGA2
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    BYTE cr30, cr9F;
    
    // save Power Now Indicator
    cr30 = cbReadRegByte(pcbe, CR_30);    // IGA1 CR30[2]
    cr9F = cbReadRegByte(pcbe, CR_9F);    // IGA2 CR9F[7]
    // Disable Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, 0);      // CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, 0);      // CR9F[7]

    // common registers
    cbLoadTable_UMA(pcbe, UMA_ModeCommon);

    // work on IGA1
    status = cbSetIGA1DevMode(pcbe, H_ResIGA1, V_ResIGA1, colorDepthIGA1, RRatesInfoIGA1);
    if (CBIOS_OK == status)
    {
        // work on IGA2
        status = cbSetIGA2DevMode(pcbe, H_ResIGA2, V_ResIGA2, colorDepthIGA2, RRatesInfoIGA2);
    } 
    // restore Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, cr30);   // IGA1 CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, cr9F);   // IGA2 CR9F[7]

    return status;
}

//*****************************************************************************
//
//  CBiosGetCurrentMode
//
//  This function gets the current IGA setting.
//
//  Parameters:
//      IGA_Num:        0 = IGA1, 1 = IGA2
//      pH_Res:         return Horizontal Resolution (pixel)
//      pV_Res:         return Vertical Resolution (pixel)
//      pColorDepth:    return 8 / 16 / 32 (bpp)
//      pRRatesInfo:    return actual refresh rate * 100 (decimal)
//                      return whether interlaced
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetCurrentMode (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT DWORD *pH_Res,
    OUT DWORD *pV_Res,
    OUT DWORD *pColorDepth,
    OUT RefreshRateInfo *pRRatesInfo
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    PIGA_Info pIGAInfo;

    if (!pH_Res || !pV_Res || !pColorDepth || !pRRatesInfo)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if (IGA1 == IGA_Num)
    {
        pIGAInfo = &(pcbe->IGA1Info);
    }
    else if (IGA2 == IGA_Num)
    {
        pIGAInfo = &(pcbe->IGA2Info);
    }
    else
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }

    *pH_Res = pIGAInfo->HRes;
    *pV_Res = pIGAInfo->VRes;
    *pRRatesInfo = pIGAInfo->RRateInfo;
    *pColorDepth = pIGAInfo->ColorDepth;
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetDeviceResolutionsBufferSize
//
//  This function returns the size of resolution information memory buffer.
//
//  Parameters:
//      dispDev:        one device bit or valid simultaneous bits can be set
//                      for simultaeous bit function just return primary timing type
//      pBufSize:       returns the size of memory buffer required in bytes
//                      to hold the resolution information
//                      for the device specified.
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDeviceResolutionsBufferSize (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pBufSize
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD resolutionNum = 0;
    DWORD devicetimingtype;

    if (!pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // find the primary device to get timing 
    // for only one device bit just itself 
    // for simultaneous case get primary device
    devicetimingtype = cbGetPrimaryDevice(dispDev);
    if (0 == devicetimingtype) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    switch (devicetimingtype)
    {
    case S3_CRT:
        if (pcbe->devicetimingtype[CRTbit] == VESAVPIT_TIMING_TYPE)
        {
            // CRT resolution type
            // 1. Resolution based on VBIOS VESAVPIT
            // 2. Resolution based on EDID detailed timing
            // if VESAVPIT has conflict with EDID we use EDID detailed timing
            // if VCP is null we will use CBIOS VESAVPIT timing while do not use EDID
            // detailed timing 
            if (cbGetCRTTypeResolutionsBuffer(pcbe, S3_CRT, NULL, 0, pBufSize) == FALSE)
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[CRTbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            // LCD monitor support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing 
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_CRT, NULL, 0, pBufSize)) 
            {       
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_CRT2:
        if (pcbe->pVCPInfo != NULL && pcbe->devicetimingtype[CRT2bit] == VESAVPIT_TIMING_TYPE)
        {
            PVESA_INFO pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);
            while (pVESA_Info->HSize != INVALID_H_SIZE)
            {
                //Is mode need skip ?
                if( !cbIsCRT2SkipMode(pcbe, pVESA_Info) )
                {
                    resolutionNum++;
                }
                pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
            }
            if (resolutionNum == 0)
            {
                return CBIOS_ER_LACKOFINFO;
            }
            else
            {
                *pBufSize = resolutionNum * sizeof(DWORD) * 2;
            }
        }
        else if (pcbe->devicetimingtype[CRT2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            // LCD monitor support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing 
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_CRT2, NULL, 0, pBufSize)) 
            {       
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
                
        break;

    case S3_LCD:
        // LCD timing type return all resolutions in VESAVPIT which
        // is less than physical panel size
        if (pcbe->devicetimingtype[LCDbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {   
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing 
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_LCD, NULL, 0, pBufSize)) 
            {
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing less than LCD panel size 
                LCD_Info LCDInfo;
                cbGetLCDPanelInfo_UMA(pcbe, S3_LCD, &LCDInfo);
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    LCDInfo.H_Size,
                                                    LCDInfo.V_Size,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
        
    case S3_LCD2:
        // LCD2 timing type return all resolutions in VESAVPIT which
        // is less than physical panel size
        if (pcbe->devicetimingtype[LCD2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {   
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing 
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_LCD2, NULL, 0, pBufSize)) 
            {   
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing less than LCD panel size 
                LCD_Info LCD2Info;
                cbGetLCDPanelInfo_UMA(pcbe, S3_LCD2, &LCD2Info);
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    LCD2Info.H_Size,
                                                    LCD2Info.V_Size,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_DVI:
        if (pcbe->devicetimingtype[DVIbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DVI,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing            
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DVI, NULL, 0, pBufSize)) 
            {
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
        
    case S3_DVI2:
        if (pcbe->devicetimingtype[DVI2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI2 VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DVI2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI2 support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DVI2, NULL, 0, pBufSize)) 
            {
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_TV:
        if ( (NTSC == pcbe->sPad_8.TV_Type) ||
             (NTSCJP == pcbe->sPad_8.TV_Type) || 
             (PALM == pcbe->sPad_8.TV_Type) )     // PALM is base on NTSC to adjust
        {
            // NTSC TV
            *pBufSize = TV_NTSC_RESOLUTION_NUM * sizeof(DWORD) * 2;
        }
        else
        {
            // PAL TV
            *pBufSize = TV_PAL_RESOLUTION_NUM * sizeof(DWORD) * 2;
        }
        break;

    case S3_HDTV:
        if (HDTV720P == pcbe->sPad_11.HDTV_Type)
        {
            *pBufSize = HDTV720P_RESOLUTION_NUM * sizeof(DWORD) * 2;
        }
        else if (HDTV1080I == pcbe->sPad_11.HDTV_Type)
        {
            // Now specific for DTM test we need to report 
            // more resolutions for HDTV 1080I type so DTM can pass.
            *pBufSize = HDTV_RESOLUTION_NUM * sizeof(DWORD) * 2;
        }
        else
        {
            return CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
        break;
        
    case S3_HDMI: 
        if (pcbe->devicetimingtype[HDMIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI resolution table
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing            
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_HDMI, NULL, 0, pBufSize)) 
            {
                // HDMI EDID & customize timing invalid
                // report all valid CEA resolution 
                *pBufSize = CEA861_FORMAT_RES_NUM;
            }   
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          
        break;

    case S3_HDMI2: 
        if (pcbe->devicetimingtype[HDMI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI resolution table
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing            
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_HDMI2, NULL, 0, pBufSize)) 
            {
                // HDMI EDID & customize timing invalid
                // report all valid CEA resolution 
                *pBufSize = CEA861_FORMAT_RES_NUM;
            }   
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          
        break;

    case S3_DP:
        if (pcbe->devicetimingtype[DPbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DP,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DPbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing            
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DP, NULL, 0, pBufSize)) 
            {
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_DP2:
        if (pcbe->devicetimingtype[DP2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DP2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DP2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI support resolution tbl
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing            
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DP2, NULL, 0, pBufSize)) 
            {
                // EDID & customize timing invalid
                // report all valid VESAVPIT timing 
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    NULL,
                                                    0,
                                                    pBufSize))
                {                                                
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    default:
        return CBIOS_ER_NOT_YET_IMPLEMENTED;
    }

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetDeviceResolutions
//
//  The function returns all the resolution.
//
//  Parameters:
//      dispDev:        one device bit or valid simultaneous bits can be set
//                      for simultaeous bit function just return primary timing type
//      pResBuf:        returns all the resolutions
//                      in the buffer provided for the device specified.
//      pBufSize:       The buffer size passed through by Driver.
//                      Upon returned, fill bytes actually used in the pResBuf
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDeviceResolutions (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN OUT DWORD *pResBuf,
    IN OUT DWORD *pBufSize
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD xyNum = 0;
    DWORD const *pResolutionArray = NULL;
    DWORD resolutionNum = 0;
    DWORD devicetimingtype;

    if (!pResBuf || !pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // find the primary device to get timing 
    // for only one device bit just itself 
    // for simultaneous case get primary device
    devicetimingtype = cbGetPrimaryDevice(dispDev);
    if (0 == devicetimingtype) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }


    if( *pBufSize < (2 * sizeof(DWORD)) )
    {
        //no enough space for even one group of resolution
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    switch (devicetimingtype)
    {
    case S3_CRT:
        if (pcbe->devicetimingtype[CRTbit] == VESAVPIT_TIMING_TYPE)
        {
            // CRT resolution list
            // 1. Resolutions based on VBIOS VESAVPIT
            // 2. Resolutions based on EDID detailed timing
            // if VESAVPIT has conflict with EDID we use EDID detailed timing
            // if VCP is null we will use CBIOS VESAVPIT timing while do not use EDID
            // detailed timing 
            if (cbGetCRTTypeResolutionsBuffer(pcbe, S3_CRT, pResBuf, *pBufSize, NULL) == FALSE)
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[CRTbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            // LCD monitor type resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_CRT, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }    
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_CRT2:
        if (pcbe->pVCPInfo != NULL && pcbe->devicetimingtype[CRT2bit] == VESAVPIT_TIMING_TYPE)
        {
            PVESA_INFO pVESA_Info = (PVESA_INFO)(pcbe->RomData +  pcbe->pVCPInfo->VESAVPITPtr);
            while (pVESA_Info->HSize != INVALID_H_SIZE)
            {
                //Is mode need skip ?
                if( !cbIsCRT2SkipMode(pcbe,pVESA_Info) )
                {
                    pResBuf[xyNum] = pVESA_Info->HSize; // XResolution
                    pResBuf[xyNum+1] = pVESA_Info->VSize; // YResolution
                    xyNum += 2;
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) > (*pBufSize) )
                    {
                        // if no enough space in the buffer, jump out
                        break;
                    }

                }
                pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
            }
            if (xyNum == 0)
            {
                return CBIOS_ER_LACKOFINFO;
            }
            else
            {
                // fill actual bytes used
                *pBufSize = xyNum * sizeof(DWORD);
            }
        }
        else if (pcbe->devicetimingtype[CRT2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            // LCD monitor type resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_CRT2, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }    
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }

        break;

    case S3_LCD:
        // LCD timing type return all resolutions in VESAVPIT which
        // is less than physical panel size
        if (pcbe->devicetimingtype[LCDbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_LCD, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                LCD_Info LCDInfo;
                cbGetLCDPanelInfo_UMA(pcbe, S3_LCD, &LCDInfo);
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    LCDInfo.H_Size,
                                                    LCDInfo.V_Size,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_LCD2:
        // LCD2 timing type return all resolutions in VESAVPIT which
        // is less than physical panel size
        if (pcbe->devicetimingtype[LCD2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_LCD2, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                LCD_Info LCD2Info;
                cbGetLCDPanelInfo_UMA(pcbe, S3_LCD2, &LCD2Info);
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    LCD2Info.H_Size,
                                                    LCD2Info.V_Size,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        } 
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_DVI:
        if (pcbe->devicetimingtype[DVIbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DVI,
                                                                  pResBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DVI, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
        
     case S3_DVI2:
        if (pcbe->devicetimingtype[DVI2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI2 VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DVI2,
                                                                  pResBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI2 monitor resolution list 
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DVI2, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_TV:
        if ( (NTSC == pcbe->sPad_8.TV_Type) || 
             (NTSCJP == pcbe->sPad_8.TV_Type) || 
             (PALM == pcbe->sPad_8.TV_Type) )     // PALM is base on NTSC to adjust
        {
            // NTSC TV
            pResolutionArray = TVResolutionNTSC;
            resolutionNum = TV_NTSC_RESOLUTION_NUM;
        }
        else
        {
            // PAL TV
            pResolutionArray = TVResolutionPAL;
            resolutionNum = TV_PAL_RESOLUTION_NUM;
        }
        
        for (xyNum=0; xyNum<resolutionNum*2; xyNum+=2)
        {
            if ( ((xyNum+2) * sizeof(DWORD)) > (*pBufSize) )
            {
                // if no enough space in the buffer, jump out
                break;
            }
            pResBuf[xyNum]   = pResolutionArray[xyNum];   // XResolution
            pResBuf[xyNum+1] = pResolutionArray[xyNum+1]; // YResolution
        }

        // fill actual bytes used
        *pBufSize = xyNum * sizeof(DWORD);
        break;

    case S3_HDTV:
        if (HDTV720P == pcbe->sPad_11.HDTV_Type)
        {
            pResolutionArray = HDTVResolution720P;
            resolutionNum = HDTV720P_RESOLUTION_NUM;
        }
        else if (HDTV1080I == pcbe->sPad_11.HDTV_Type)
        {
            // Now specific for DTM test we need to report 
            // more resolutions for HDTV 1080I type so DTM can pass.
            pResolutionArray = HDTVSupportResolution;
            resolutionNum = HDTV_RESOLUTION_NUM;
        }
        else
        {
            return CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
        
        for (xyNum=0; xyNum<resolutionNum*2; xyNum+=2)
        { 
            if ( ((xyNum+2) * sizeof(DWORD)) > (*pBufSize) )
            {
                // if no enough space in the buffer, jump out
                break;
            }
            pResBuf[xyNum]   = pResolutionArray[xyNum];   // XResolution
            pResBuf[xyNum+1] = pResolutionArray[xyNum+1]; // YResolution
           
        }
        
        // fill actual bytes used
        *pBufSize = xyNum * sizeof(DWORD);
        break;

    case S3_HDMI: 
        if (pcbe->devicetimingtype[HDMIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI monitor resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_HDMI, pResBuf, *pBufSize, NULL))
            {
                // HDMI EDID & customize timing invalid
                // report all valid CEA resolution 
                cbGetCEAResolutionsBuffer(pcbe, pResBuf, pBufSize);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          
        break;

    case S3_HDMI2: 
        if (pcbe->devicetimingtype[HDMI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI monitor resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_HDMI2, pResBuf, *pBufSize, NULL))
            {
                // HDMI EDID & customize timing invalid
                // report all valid CEA resolution 
                cbGetCEAResolutionsBuffer(pcbe, pResBuf, pBufSize);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          
        break;

    case S3_DP:
        if (pcbe->devicetimingtype[DPbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DP,
                                                                  pResBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DPbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DP, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_DP2:
        if (pcbe->devicetimingtype[DP2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(pcbe, 
                                                                  S3_DP2,
                                                                  pResBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DP2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor resolution list
            // if EDID valid
            //   for resolution in VESAVPIT H / V =< Max EDID resolution all report it
            // EDID invalid 
            //   customize timing used as EDID detailed timing
            // since EDID_ENABLEDEVSCALING_TIMING_TYPE and EDID_DISABLEDEVSCALING_TIMING_TYPE report all resolution in VESAVPIT
            // which is less than EDID timing, so they can share same function
            if (!cbGetEDIDResolutionsBuffer(pcbe, S3_DP2, pResBuf, *pBufSize, NULL))
            {
                // EDID fail or no customize timing report all VESAVPIT table
                if (!cbGetVESAVPITResolutionsBuffer(pcbe, 
                                                    0xFFFF,
                                                    0xFFFF,
                                                    pResBuf,
                                                    *pBufSize,
                                                    NULL))
                {
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    default:
        return CBIOS_ER_NOT_YET_IMPLEMENTED;
    }

    return CBIOS_OK;
}


//*****************************************************************************
//
//  CBIOSGetDeviceModeTargetTiming
//
//      The function returns the whole the target timing table according to the given 
//  device mode( H / V resolution and refresh rate)
//
//  Parameters:
//  IN :
//    dispDev:        one device bit or valid simultaneous bits can be set
//                      for simultaeous bit function just return primary timing type
//      H_Res:          given mode H resolution size
//      V_Res:          given mode V resolution size
//     RRateInfo :      required refresh rate info                 
//  OUT :
//     pTargetTiming :  returned target timing table 
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBIOSGetDeviceModeTargetTiming ( 
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTargetTiming)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    if (!pTargetTiming)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if (TRUE == cbGetTargetGFXTimingTbl(pcbe,
                                        dispDev,
                                        H_Res,
                                        V_Res,
                                        RRateInfo,
                                        pTargetTiming))
    {
        return CBIOS_OK;
    }
    else
    {
        return CBIOS_ER_LACKOFINFO;
    }
}

//*****************************************************************************
//
//  CBiosSetTiming
//
//      The function set timing according src mode, view size & dest timing
//
//  Parameters:
//  IN :
//    pTimingParams: timing parameters want to be set
//  OUT :
//    CBIOS_STATUS
//    if can't set timing according dest timing, return CBIOS_ER_INVALID_PARAMETER
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetTiming(
    PVOID pvcbe, 
    IN PCBiosSetTimingParams pTimingParams)
{
    CBIOS_STATUS status = CBIOS_OK;
    PCBIOS_EXTENSION pcbe = pvcbe;
    BYTE cr30, cr9F;

    // save Power Now Indicator
    cr30 = cbReadRegByte(pcbe, CR_30);    // IGA1 CR30[2]
    cr9F = cbReadRegByte(pcbe, CR_9F);    // IGA2 CR9F[7]    

    if ( NULL == pTimingParams || (sizeof(CBiosSetTimingParams) != pTimingParams->size) )
    {
        cbDbgPrint(0, "Caution: CBiosSetTimingParams size not match!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // Disable Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, 0);      // CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, 0);      // CR9F[7]

    // common registers
    cbLoadTable_UMA(pcbe, UMA_ModeCommon);
	
	pcbe->TimingAttr = pTimingParams->flag;
	
	if (IGA1 == pTimingParams->IGAIndex)
    {
        if (!cbSetIGA1ModeTiming(pcbe,
                                 &(pTimingParams->srcMode),
                                 &(pTimingParams->viewSize),
                                 &(pTimingParams->destTiming)) )
        {
            status = CBIOS_ER_INVALID_PARAMETER;
        }
    }
    else if (IGA2 == pTimingParams->IGAIndex)
    {
        if (!cbSetIGA2ModeTiming(pcbe,
                                 &(pTimingParams->srcMode),
                                 &(pTimingParams->viewSize),
                                 &(pTimingParams->destTiming)) )
        {
            status = CBIOS_ER_INVALID_PARAMETER;
        }
    }  
    else
    {
        cbDbgPrint(0, "Caution: CBiosSetTimingParams wrong IGA index!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    // restore Power Now Indicator
    cbWriteRegBits(pcbe, CR_30, BIT2, cr30);    // IGA1 CR30[2]
    cbWriteRegBits(pcbe, CR_9F, BIT7, cr9F);    // IGA2 CR9F[7]

    return status;
}

//------------------Refresh Rates Query----------------------------------------

//*****************************************************************************
//
//  CBiosGetRefreshRatesBufferSizeForDeviceResolution
//
//  This function returns the size of refresh rate information memory buffer.
//
//  Parameters:
//      dispDev:        one device bit or valid simultaneous bits can be set
//                      for simultaeous bit function just return primary timing type
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pBufSize:       returns the size of memory buffer required in bytes
//                      to hold the refresh rate information 
//                      (refreshrate & interlaced) 
//                      for the specified device and resolution
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetRefreshRatesBufferSizeForDeviceResolution (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT DWORD *pBufSize
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD rrateNum = 0; 
    ULONG i;
    DWORD devicetimingtype;

    if (!pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // find the primary device to get timing 
    // for only one device bit just itself 
    // for simultaneous case get primary device
    devicetimingtype = cbGetPrimaryDevice(dispDev);
    if (0 == devicetimingtype) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    switch (devicetimingtype)
    {
    case S3_CRT:
        if (pcbe->devicetimingtype[CRTbit] == VESAVPIT_TIMING_TYPE)
        {
            // CRT refresh rate
            // 1. timing(Resolution & refresh rate) based on VBIOS VESAVPIT
            // 2. timing(Resolution & refresh rate) based on EDID detailed timing
            // if VESAVPIT has conflict with EDID we use EDID detailed timing
            if (!cbGetCRTTypeRefreshRatesForResolution(pcbe, 
                                                       S3_CRT, 
                                                       H_Res, 
                                                       V_Res,
                                                       NULL,
                                                       0,
                                                       pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }                                                             
        }
        else if (pcbe->devicetimingtype[CRTbit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            // LCD monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT
            // if Est / STD resolution == EDID detailed refresh rate
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_CRT, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {           
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[CRTbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_CRT,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;

    case S3_DVI:
        if (pcbe->devicetimingtype[DVIbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DVI,
                                                                          H_Res,
                                                                          V_Res,
                                                                          NULL,
                                                                          0,
                                                                          pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DVI, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[DVIbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DVI,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }        
        break;

    case S3_DVI2:
        if (pcbe->devicetimingtype[DVI2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI2 VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DVI2,
                                                                          H_Res,
                                                                          V_Res,
                                                                          NULL,
                                                                          0,
                                                                          pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DVI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI2 monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DVI2, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[DVI2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DVI2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }        
        break;
        
    case S3_HDMI: 
        if (pcbe->devicetimingtype[HDMIbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_HDMI, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID all invalid 
                // report all valid CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       NULL,
                                                       0,
                                                       pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[HDMIbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_HDMI,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID all invalid 
                // report all valid CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       NULL,
                                                       0,
                                                       pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          

        break;

    case S3_HDMI2: 
        if (pcbe->devicetimingtype[HDMI2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // HDMI Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_HDMI2, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID all invalid 
                // report all valid CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       NULL,
                                                       0,
                                                       pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[HDMI2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_HDMI2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID all invalid 
                // report all valid CEA refresh rates
                if (!cbGetCEARefreshRatesForResolution(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       NULL,
                                                       0,
                                                       pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }          

        break;

    case S3_DP:
        if (pcbe->devicetimingtype[DPbit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DP,
                                                                          H_Res,
                                                                          V_Res,
                                                                          NULL,
                                                                          0,
                                                                          pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DPbit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DP, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[DPbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DP,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }        
        break;

    case S3_DP2:
        if (pcbe->devicetimingtype[DP2bit] == VESAFILTERBYEDID_TIMING_TYPE)
        {
            // DVI VESAVPIT filter by EDID panelsize timing table
            // customize timing less than EDID detailed timing
            // all VESAVPIT timing which is less then EDID panel size
            if (!cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(pcbe, 
                                                                          S3_DP2,
                                                                          H_Res,
                                                                          V_Res,
                                                                          NULL,
                                                                          0,
                                                                          pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
        }
        else if (pcbe->devicetimingtype[DP2bit] & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            // DVI monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT 
            //    if Est / STD resolution == EDID detailed resolution
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_DP2, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[DP2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // DVI no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_DP2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }        
        break;
        
    case S3_CRT2:
        if (pcbe->devicetimingtype[CRT2bit] == VESAVPIT_TIMING_TYPE)
        {
            PVESA_INFO pVESA_Info = NULL;
            PVESA_VPIT pVesa_VPIT = NULL;
            rrateNum = 0;
            if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
            {
                pVesa_VPIT =  (PVESA_VPIT)(pVESA_Info + 1);
                for(i = 0; i < pVESA_Info->RRateCount; i++)
                {
                    //Is refresh rate need skip ?
                    if( !cbIsCRT2SkipRRate(pcbe, pVESA_Info, pVesa_VPIT->RRate) )
                    {
                        //buffer size add one DWORD
                        rrateNum++;
                    }
                    pVesa_VPIT++;
                }
                *pBufSize = rrateNum * sizeof(RefreshRateInfo);
            }
            else
            {
                return CBIOS_ER_INTERNAL;
            }
        }    
        else if (pcbe->devicetimingtype[CRT2bit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            // LCD monitor Refresh rate reported
            // EDID or customize timing valid
            // 1. If Detailed timing: report its refresh rate only;
            // 2. If Est / STD timing smaller than EDID detailed timing: 
            //    find in VESAVPIT , if find then report founded refresh rate. 
            //    else using center on EDID detailed timing
            // 3. if Est / STD timing bigger than EDID detailed timing:
            //    find in VESAVPIT
            // if Est / STD resolution == EDID detailed refresh rate
            //    also add Est / STD timing & report them
            // 4. other resolution center on nearest target mode
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_CRT2, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {           
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }        
        }
        else if (pcbe->devicetimingtype[CRT2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_CRT2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // no Customize timing && EDID timing all invalid 
                // report all valid VESAVPIT refresh rate
                if (!cbGetVESAVPITRefreshRatesForResolution(pcbe,
                                                            H_Res,    
                                                            V_Res,
                                                            NULL,
                                                            0,
                                                            pBufSize))
                {                                                             
                    return CBIOS_ER_LACKOFINFO;
                }
            }
        }        
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
        
    case S3_LCD:
        if (pcbe->devicetimingtype[LCDbit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_LCD, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // if EDID all invalid or broken and no customize timing
                // for all the mode of LCD / LCD2 report 60Hz refresh rate only
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else if (pcbe->devicetimingtype[LCDbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE)
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_LCD,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // if EDID all invalid or broken and no customize timing
                // for all the mode of LCD / LCD2 report 60Hz refresh rate only
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
         
    case S3_LCD2:
        if (pcbe->devicetimingtype[LCD2bit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_LCD2, 
                                                    H_Res, 
                                                    V_Res,
                                                    NULL,
                                                    0,
                                                    pBufSize))
            {
                // if EDID all invalid or broken and no customize timing
                // for all the mode of LCD / LCD2 report 60Hz refresh rate only
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            } 
        }  
        else if (pcbe->devicetimingtype[LCD2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE)
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_LCD2,
                                                                  NULL,
                                                                  0,
                                                                  pBufSize))
            {
                // if EDID all invalid or broken and no customize timing
                // for all the mode of LCD / LCD2 report 60Hz refresh rate only
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
        break;
        
    case S3_TV:
        // TV only support one refresh rate
        rrateNum = 1;   
        *pBufSize = rrateNum * sizeof(RefreshRateInfo);
        break;
        
    case S3_HDTV:
        for (i = 0; i < HDTV_REFRESHRATE_NUM; i++)
        {
           if (HDTVResolutionRefreshRate[i].xRes == H_Res
            && HDTVResolutionRefreshRate[i].yRes == V_Res)
           {
               rrateNum++;
           }
        }
        *pBufSize = rrateNum * sizeof(RefreshRateInfo);
        break;

    default:
        return CBIOS_ER_NOT_YET_IMPLEMENTED;
    }

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetRefreshRatesForDeviceResolution
//
//    The function is an extension for FUNC CBiosGetRefreshRatesForDeviceResolution
//  returns all the refresh rates parameters. 
//       1. refresh rate number
//       2. whether interlaced
//
//  Parameters:
//      dispDev:        one device bit or valid simultaneous bits can be set
//                      for simultaeous bit function just return primary timing type
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf: returns all the refresh rates info (actual RRate * 100 + 
//                      Interlaced)
//                      in the buffer provided for the specified device, resolution
//      pBufSize:       The buffer size passed through by Driver.
//                      Upon returned, fill bytes actually used in the pRRatesInfoBuf
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetRefreshRatesForDeviceResolution (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD devicetimingtype;
    DWORD TransmitterType = 0;
    DWORD RRateIdx0 = 0;
    DWORD RRateIdx1 = 0;
    DWORD Dclk = 0;
    DWORD HFreq = 0;    
    BOOL  bNeedFilter = FALSE;
    DWORD RefreshRateCount = 0;
    DWORD H_Total = 0;
    DWORD V_Total = 0;
    GFXTimingTable TargetTiming;


    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // find the primary device to get timing 
    // for only one device bit just itself 
    // for simultaneous case get primary device
    devicetimingtype = cbGetPrimaryDevice(dispDev);
    if (0 == devicetimingtype) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if( *pBufSize < sizeof(RefreshRateInfo) )
    {
        //no enough space for saving even one refresh rate
        return CBIOS_ER_INVALID_PARAMETER; 
    }

    switch(devicetimingtype)
    {
        case S3_CRT:
        case S3_CRT2:
            if(!cbGetRefreshRatesForCRT(pcbe, dispDev, H_Res, V_Res, pRRatesInfoBuf, pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
            break;
        case S3_DVI:
        case S3_DVI2:
        case S3_HDMI:
        case S3_HDMI2:
            if(!cbGetRefreshRatesForDVIorHDMI(pcbe, dispDev, H_Res, V_Res, pRRatesInfoBuf, pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
            break;
        case S3_DP:
        case S3_DP2:
            if(!cbGetRefreshRatesForDP(pcbe, dispDev, H_Res, V_Res, pRRatesInfoBuf, pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
            break;
        case S3_LCD:
        case S3_LCD2:
            if(!cbGetRefreshRatesForLCD(pcbe, dispDev, H_Res, V_Res, pRRatesInfoBuf, pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
            break;
        case S3_TV:
        case S3_HDTV:
            if(!cbGetRefreshRatesForTVorHDTV(pcbe, dispDev, H_Res, V_Res, pRRatesInfoBuf, pBufSize))
            {
                return CBIOS_ER_LACKOFINFO;
            }
            break;
        default:
            return CBIOS_ER_NOT_YET_IMPLEMENTED;
    }

    RefreshRateCount = *pBufSize/sizeof(RefreshRateInfo);    

    if(RefreshRateCount == 0)
    {
        return CBIOS_ER_INVALID_PARAMETER; 
    }
    
    // filter refresh rate of resolution
    for(RRateIdx0 = RefreshRateCount; RRateIdx0 > 0; RRateIdx0--)
    {
        if (cbGetTargetGFXTimingTbl(pcbe,
                                    dispDev,
                                    H_Res,
                                    V_Res,
                                    *(pRRatesInfoBuf + RRateIdx0 - 1),
                                    &TargetTiming))
        {
            H_Total = TargetTiming.HTotal;
            V_Total = TargetTiming.VTotal;
        }
        else
        {
            H_Total = H_Res;
            V_Total = V_Res;
        }
        
        HFreq = V_Total * ((pRRatesInfoBuf + RRateIdx0 - 1)->rRateX100) / 100;
        Dclk = H_Total * HFreq;

        if(dispDev == S3_CRT ||
           dispDev == S3_CRT2 ||
           dispDev == S3_DP ||
           dispDev == S3_DP2)
        {
            if(Dclk > 2832 * 1603 * 75)//2048*1536*75
            {
                bNeedFilter = TRUE;
            }   
            else if(dispDev == S3_CRT2)
            {
                if (cbGetDIEncodertype(pcbe, &TransmitterType, S3_CRT2) == FALSE)
                {
                    cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
                    return CBIOS_ER_LACKOFINFO;
                }                

                if(TransmitterType == CH7301)
                {
                    if(Dclk > 165000000)
                    {
                        bNeedFilter = TRUE;
                    }
                }
            }
        }
        else
        {
            if(Dclk > 2592 * 1245 * 60)//1920*1200*60
            {
                bNeedFilter = TRUE;
            }
        }
        
        if(bNeedFilter)
        {            
            if(RRateIdx0 == RefreshRateCount)
            {
                (pRRatesInfoBuf +  RRateIdx0 - 1)->rRateX100 = 0;
                (pRRatesInfoBuf +  RRateIdx0 - 1)->interlaced = 0;
            }
            else
            {
                for(RRateIdx1 = RRateIdx0; RRateIdx1 < RefreshRateCount; RRateIdx1++)
                {
                    *(pRRatesInfoBuf +  RRateIdx1 - 1) = *(pRRatesInfoBuf +  RRateIdx1);
                    (pRRatesInfoBuf +  RRateIdx1)->rRateX100 = 0;
                    (pRRatesInfoBuf +  RRateIdx1)->interlaced = 0;
                }
            }
                      
            bNeedFilter = FALSE;
            (*pBufSize) -= sizeof(RefreshRateInfo);
        }
    }

    return CBIOS_OK;
}


//*****************************************************************************
//
//  CBiosGetColorDepthForDeviceResolution
//
//  This function returns the color depths supported by a device resolution.
//
//  Parameters:
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pColorDepth:    returns the color depths caps
//                      for the specified device, resolution
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetColorDepthForDeviceResolution (
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT DWORD *pColorDepth
)
{    
    if (!pColorDepth)
    {
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if (MORE_THAN_1BIT(dispDev)) // if more than one device bit set, return fail
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // default support 8/16/32 bpp
    *pColorDepth = COLOR_DEPTH_8BPP | COLOR_DEPTH_16BPP | COLOR_DEPTH_32BPP_8888;
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosLoadCustomizeTiming
//
//      This function inits customize timing buffer address in pcbe. Customize timing 
//  is stored in FILE. Driver will allocate memeory & read data info into the memory 
//  driver then pass the buffer address to CBIOS. CBIOS will parse it by itself.
//
//  Parameters:
//      pCustomizeTimingData : timing data buffer
//      data storage structure
//      
//  CustomizeTimingHead  head;       CustomizeTiming file head
//      CustomizeTiming  timing0;    CustomizeTiming 0
//      CustomizeTiming  timing1;    CustomizeTiming 1
//      ...
//      CustomizeTiming  timingN;    CustomizeTiming N
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosLoadCustomizeTiming(
    PVOID pvcbe, 
    IN BYTE *pCustomizeTimingData
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    PCustomizeTimingHead pHead = NULL;
    
    if (!pCustomizeTimingData)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // init customize timing pointer
    pHead = (PCustomizeTimingHead)pCustomizeTimingData;

    // doing checksum for whole customize timing header + timing tbl
    if (cbGetCheckSum(pCustomizeTimingData, pHead->fileLength) == 0)
    {
        pcbe->pCustomizeTimingHead = (PCustomizeTimingHead)pCustomizeTimingData;
        pcbe->pCustomizeTimingEntityBuf = (PCustomizeTimingEntity)(pCustomizeTimingData 
                                          + sizeof(CustomizeTimingHead));
        return CBIOS_OK;
    }
    else
    {    
        pcbe->pCustomizeTimingHead = NULL;
        pcbe->pCustomizeTimingEntityBuf = NULL; 
        cbDbgPrint(1, "Checksum error for customize mode buffer!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
}


//------------------Device Control---------------------------------------------
//------------------------------------------------------------------------
//CBiosGetActiveDisplayDeviceConfigurationByIga
//      This function get device to related IGA separately
//    IN : 
//          IgaNum : IGA1 / IGA2
//          dispDev : device bit
//------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetActiveDisplayDeviceConfigurationByIga (
    PVOID pvcbe, 
    IN UINT32 IgaNum,
    OUT UINT32 *pDispDev
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    if (!pDispDev)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    switch(IgaNum)
    {
    case IGA1:
        *pDispDev =  pcbe->IGA1Info.dispDev;
        break;
    case IGA2:
        *pDispDev =  pcbe->IGA2Info.dispDev ;
        break;
    default:
        cbDbgPrint(1, "Error IGA input\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }
    
    return status;
}

//*****************************************************************************
//
//  CBiosGetActiveDisplayDeviceConfiguration
//
//      This function returns the current active display configuration.
//  The display device configuration returned will always be the one from 
//  the last set display device function.
//
//  Parameters:
//      pDispDevIGA1:       return device on IGA1 (DWORD)
//      pDispDevIGA1:       return device on IGA2 (DWORD)
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetActiveDisplayDeviceConfiguration (
    PVOID pvcbe, 
    OUT DWORD *pDispDevIGA1,
    OUT DWORD *pDispDevIGA2
)
{   
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pDispDevIGA1 || !pDispDevIGA2)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    //Remove attached on CRT from IGA info, there is no need to tell driver CRT attaches on one IGA
    *pDispDevIGA1 = pcbe->IGA1Info.dispDev;
    *pDispDevIGA2 = pcbe->IGA2Info.dispDev;

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosSetActiveDisplayDeviceConfiguration
//
//      This function associate the device with IGA. For new set mode logic, 
//  when device is configured to one IGA , then IGA data path & DI port data 
//  source associated with device should also be configured since we changed
//  DI port source and IGA data path we need to do screen on / off or device 
//  on / off to get rid of garbage
//
//  Parameters:
//      dispDevIGA1:        device to be set on IGA1 (DWORD)
//      dispDevIGA2:        device to be set on IGA2 (DWORD)
//      for simultaneous case one device can have two device bit for simultaneous
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetActiveDisplayDeviceConfiguration (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2
)
{
    //PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    
    status = CBiosSetActiveDisplayDeviceConfiguration_share(pvcbe, dispDevIGA1, dispDevIGA2, IGA1_IGA2);
    return status;
}


//*****************************************************************************
//
//  CBiosSetActiveDisplayDeviceConfiguration_linux
//
//      This function associate the device with IGA. For new set mode logic, 
//  when device is configured to one IGA , then IGA data path & DI port data 
//  source associated with device should also be configured since we changed
//  DI port source and IGA data path we need to do screen on / off or device 
//  on / off to get rid of garbage
//
//  Parameters:
//      dispDevIGA1:        device to be set on IGA1 (DWORD)
//      dispDevIGA2:        device to be set on IGA2 (DWORD)
//      for simultaneous case one device can have two device bit for simultaneous
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************

CBIOS_STATUS CBIOSAPI CBiosSetActiveDisplayDeviceConfiguration_linux (
    PVOID pvcbe, 
    IN DWORD dispDevIGA1,
    IN DWORD dispDevIGA2,
    IN DWORD AffectIGAs)
{
    //PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    
    status = CBiosSetActiveDisplayDeviceConfiguration_share(pvcbe, dispDevIGA1, dispDevIGA2, AffectIGAs);
    return status;
}


//*****************************************************************************
//
//  CBiosGetDisplayDeviceInformation
//
//      This function returns device associated info ( H/ V native mode resoltion
//  and DDC bus number for DDC/CI function). for TV PAL /NTSC we return 10x7 as its
//  native mode.
//
//  Parameters:
//      dispDevice:        device to query info
//                         (only one device bit can be set)
//  Return Value:
//           pHRes:        device native mode H resolution
//           pVRes:        device native mode V resolution
//      serialPortNum:     device associated DDC bus num
//                         0x00 indicates no serial port used
//      For details, refer to function Convert_I2CPortNum_to_I2CBusNum
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDisplayDeviceInformation (
    PVOID pvcbe, 
    IN  UINT32 dispDevice,           
    OUT PDWORD pHRes,
    OUT PDWORD pVRes,
    OUT UINT8  *pDDCPort     
)                                   
{   
    
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    CBIOS_STATUS status = CBIOS_OK;

    i2c.Flags = 0;
    // input parameters can not be 0 or NULL
    if (!dispDevice || !pHRes || !pVRes || !pDDCPort)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (MORE_THAN_1BIT(dispDevice))
    {
        cbDbgPrint(1, "More than one device to get ");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // get the Device serial Port Number I2C info
    if ( cbGetDeviceDDCPort(pcbe, &i2c, dispDevice) )
    {
        cbConvert_I2CPortNum_to_I2CBusNum(pDDCPort, i2c.I2cPort);
    }
    else
    {
        *pDDCPort = 0;
    }

    // get device native mode info
    switch(dispDevice)
    {
    case S3_DVI:
    case S3_DVI2:
    case S3_CRT:
    case S3_HDMI:
    case S3_HDMI2:
    case S3_DP:
    case S3_DP2:
        // DVI & CRT read EDID to get native mode 
        if (cbGetMonitorSizeFromDDC_EDIDv1(pcbe, dispDevice, pHRes, pVRes) == FALSE)
        {
            status = CBIOS_ER_DDCRead;
        }
        break;

    case S3_LCD:
    case S3_LCD2:
        // LCD / LCD2 read EDID to get native mode 
        if (cbGetMonitorSizeFromDDC_EDIDv1(pcbe, dispDevice, pHRes, pVRes) == FALSE)
        {
            // LCD / LCD2 device no EDID case  
            // 1. EDID broken
            // 2. no DDC port
            // we use ROM image panel size according to panel ID
            LCD_Info LCDInfo;
            cbGetLCDPanelInfo_UMA(pcbe, dispDevice, &LCDInfo);
            *pHRes = LCDInfo.H_Size;
            *pVRes = LCDInfo.V_Size;
        }
        break;

    case S3_TV:
        // set TV native mode according to its type
        // PALM is based on NTSC table
        // PALN & PALNc are based on PAL
        switch (pcbe->sPad_8.TV_Type)
        {
        case NTSC:
        case NTSCJP:
        case PALM:
            *pHRes = 720;
            *pVRes = 480;
            break;
        case PAL:
        case PALN:
        case PALNc:
        case PALI:
        case PALD:
            *pHRes = 720;
            *pVRes = 576;
            break;
        default:
            cbDbgPrint(1, "error TV type");
            status = CBIOS_ER_INVALID_PARAMETER;
        }    
        break;
        
    case S3_CRT2:
    {
        ULONG encodertype = 0;
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        }
        if (encodertype == CH7301)
        {
            if (cbGetMonitorSizeFromDDC_EDIDv1(pcbe, dispDevice, pHRes, pVRes) == FALSE)
            {
                status = CBIOS_ER_DDCRead;
            }
        }
        else
        {
            // default 1625 CRT2 native mode 1024*768
            *pHRes = 1024;
            *pVRes = 768;
        }
    }
        break;
    case S3_HDTV:
        // set HDTV native mode according to its type
        switch (pcbe->sPad_11.HDTV_Type)
        {
        case HDTV720P:
            *pHRes = 1280;
            *pVRes = 720;
            break;
        case HDTV1080I:
        case HDTV1080P:
            *pHRes = 1920;
            *pVRes = 1080;
            break;
        default:
            cbDbgPrint(1, "error HDTV type");
            status = CBIOS_ER_INVALID_PARAMETER;
        }
        break;

    default:
        cbDbgPrint(1, "error device type");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    
    return status;
}

//------------------Device Power Management------------------------------------

//*****************************************************************************
//
//  CBiosGetDisplayDevicePowerManagementCapability
//
//  This function can be called to query the power management capability.
//  Only one device at a time.
//
//  Parameters:
//      dispDev:            device to be query PM caps (DWORD)
//      pPowerState:        return device PM caps
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDisplayDevicePowerManagementCapability (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pPowerCaps
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pPowerCaps)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (MORE_THAN_1BIT(dispDev))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }

    //we support all, and need not test device
    *pPowerCaps = S3PM_OFF | S3PM_ON | S3PM_SUSPEND | S3PM_STANDBY ;

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetDisplayDevicePowerState
//
//  Parameters:
//      dispDev:            device to be get power state (DWORD)
//      pPowerState:        return current device power state
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDisplayDevicePowerState (
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT DWORD *pPowerState
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (!pPowerState)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (MORE_THAN_1BIT(dispDev))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // The difference between dispDev on IGA & DPMS_ON device 
    // is that device needs  to be first connected to one IGA.
    // Then it can be turned on /off, so dispDev on IGA
    // contained all DPMS_ON devices & some DPMS_OFF devices
    // Devices do not connect to IGA should keep DPMS_OFF
    if (!(dispDev & pcbe->IGA1Info.dispDev) &&
        !(dispDev & pcbe->IGA2Info.dispDev))
    {
        // if device not current active device, power state = off and funtion return
        *pPowerState = S3PM_OFF;
        return status;
    }

    // Get device power state according to the device bit
    switch(dispDev)
    {
    case S3_CRT:
        *pPowerState = pcbe->devicepowerstate[CRTbit]; 
        break;
    case S3_CRT2:
        *pPowerState = pcbe->devicepowerstate[CRT2bit]; 
        break;
    case S3_LCD:
        *pPowerState = pcbe->devicepowerstate[LCDbit]; 
        break;
    case S3_LCD2:
        *pPowerState = pcbe->devicepowerstate[LCD2bit];
        break;
    case S3_DVI:
        *pPowerState = pcbe->devicepowerstate[DVIbit]; 
        break;
    case S3_DVI2:
        *pPowerState = pcbe->devicepowerstate[DVI2bit]; 
        break;
    case S3_TV:
        *pPowerState = pcbe->devicepowerstate[TVbit]; 
        break;
    case S3_HDTV:
        *pPowerState = pcbe->devicepowerstate[HDTVbit]; 
        break;
    case S3_HDMI:
        *pPowerState = pcbe->devicepowerstate[HDMIbit]; 
        break;
    case S3_HDMI2:
        *pPowerState = pcbe->devicepowerstate[HDMI2bit]; 
        break;
    case S3_DP:
        *pPowerState = pcbe->devicepowerstate[DPbit]; 
        break;
    case S3_DP2:
        *pPowerState = pcbe->devicepowerstate[DP2bit]; 
        break;
    default:
        cbDbgPrint(1, "error device type");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}

//*****************************************************************************
//
//  CBiosSetDisplayDevicePowerState
//
//  Only one device��s power state can be changed by this function at a time.
//  device power state control has two parts to be considered
//   1. chip related power save control 
//      for example VCK / LCK powerstate control 
//                  Power now (only for VT3336)                   
//   2. device power state control
//
//  Parameters:
//      dispDev:            device to be set power state (DWORD)
//      powerState:         power state want set to device
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetDisplayDevicePowerState (
    PVOID pvcbe, 
    IN DWORD dispDev,
    IN DWORD powerState
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    if (MORE_THAN_1BIT(dispDev) ||
        MORE_THAN_1BIT(powerState))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // ----------------- set device power state ----------------------
    switch(powerState)
    {
    case S3PM_ON:
        //-------------------------------------------------
        //-- device power state change
        //-------------------------------------------------
        // when enable device 
        // we need to config the right data path 
        // from framebuffer to device
        // 1. digital port source/ pad / DPA
        // 2. device power on (Tx /TV enc /DAC)
        status = cbenableDevice_UMA(pcbe, dispDev);
        break;

    case S3PM_SUSPEND:
    case S3PM_STANDBY:
    case S3PM_OFF:
        status = cbdisableDevice_UMA(pcbe, dispDev);
        break;

    default:
        cbDbgPrint(1, "error device power state!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
        break;
    }

    
    // ------------- Update active display device bits ---------------------
    // it may switch to VBIOS so need to update scratchpad
    if (status == CBIOS_OK)
    {
        cbUpdateHWDispDeviceBits(pcbe);   
    }
    
    return status;
}

//*****************************************************************************
//
//  CBiosGetDeviceScreenOnOffState
//
//  The device screen on-off state is independent of the power management state
//
//  Parameters:
//      IGA_Num:            0 = IGA1, 1 = IGA2
//      pScreenState:       return current screen state: 1 - on, 0 - off
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetIgaScreenOnOffState (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT DWORD *pScreenState
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (!pScreenState)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    switch(IGA_Num)
    {
    case IGA1:
        *pScreenState = pcbe->IGA1Info.ScreenOnOffState;
        break;
    case IGA2:
        *pScreenState = pcbe->IGA2Info.ScreenOnOffState;
        break;
    default:
        cbDbgPrint(1, "IGA paramter error\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}

//*****************************************************************************
//
//  CBiosSetDeviceScreenOnOffState
//
//     Change a device screen on-off state. 
//  
//  Caution! Per hardware explanation
//      Screen on / off function now have handware limitations. Rather than being 
//  turned off immediately, screen is off after current frame finished. so if driver
//  update framebuffer as soon as screen is off, this will cause garbage.
//
//  Parameters:
//      IGA_Num:            0 = IGA1, 1 = IGA2
//      screenState:        screen state want set to IGA: 1 �C on, 0 - off
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetIgaScreenOnOffState (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN DWORD screenState
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    switch (IGA_Num)
    {
    case IGA1:
        status = SetIGA1screenOnOff(pcbe, screenState);
        break;
    case IGA2:
        status = SetIGA2screenOnOff(pcbe, screenState);
        break;
    default:
        cbDbgPrint(1, "IGA paramter error\n");
        status = CBIOS_ER_INVALID_PARAMETER;
        break;
    }

    return status;
}

//*****************************************************************************
//
//  CBiosDisableChip
//
//  Disable chip when into S3/4. For HW DPMS issue.
//
//  Parameters:
//      None
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosDisableChip (
    PVOID pvcbe
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    // Disable PCI power management control
    cbWriteRegBits(pcbe, CR_36, 0x01, 0x00);

    return CBIOS_OK;
}

//------------------Graphics Controller----------------------------------------
// CBiosGetIGAUpscalerCapability
//      This function returns current scaler capbility,  According to our hardware
// limitation, IGA1 has no upscaler, VT3336 desktop chipset aslo has no upscaler.
//    IN :
//      IGA_Num : IGA1 | IGA2
//   OUT : 
//      pUpscalerCaps :
//          Bit [31:3]    Reserved
//          Bit [2]   Keep Aapect Ratio
//          Bit [1]   Expansion
//          Bit [0]   Centering
//-----------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetIGAUpscalerCapability (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT UINT32 *pUpscalerCaps)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pUpscalerCaps)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (IGA_Num == IGA1)
    {
        *pUpscalerCaps = pcbe->IGA1Info.IGAUpScalerCaps;  // IGA1 centering(no scaler)
    }
    else if (IGA_Num == IGA2)
    {
        *pUpscalerCaps = pcbe->IGA2Info.IGAUpScalerCaps; // IGA2 expansion(scaler)
    }
    else
    {
        cbDbgPrint(1, "Error IGA input num!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    return CBIOS_OK;
}


//-----------------------------------------------------------------------------
// CBiosGetPanelUpscalerSetting
//      This function returns current scaler setting,  According to our hardware
// limitation, IGA1 has no upscaler. so we will return fail.
//    IN :
//      IGA_Num : IGA1 | IGA2
//   OUT : 
//      pUpscalerSetting :
//          Bit [31:3]    Reserved
//          Bit [2]   Keep Aapect Ratio
//          Bit [1]   Expansion
//          Bit [0]   Centering
//-----------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetIGAUpscalerSetting (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT UINT32 *pUpscalerSetting)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pUpscalerSetting)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    *pUpscalerSetting = 0;

    if (IGA_Num == IGA1)
    {
        *pUpscalerSetting = pcbe->IGA1Info.curUpScalerState;
    }
    else if (IGA_Num == IGA2)
    {
        *pUpscalerSetting = pcbe->IGA2Info.curUpScalerState;
    }
    else
    {
        cbDbgPrint(1, "Error IGA input num!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    return CBIOS_OK;
}


//-----------------------------------------------------------------------------
//  CBiosSetIGAUpscalerSetting
//      This function will enable/disable IGA center/expan status. According
//  to our hardware limitation, only IGA2 has up-scaler. IGA1 will return fail 
//  if sets expansion mode. 
//      Be careful, the setting will be effect after set mode flow, here we just 
//  update CBIOS info.
//    IN :
//      IGA_Num  :  IGA1 | IGA2
//      upScalerSetting :
//          Bit [31:3]    Reserved
//          Bit [2]   Keep Aapect Ratio
//          Bit [1]   Expansion
//          Bit [0]   Centering
//-----------------------------------------------------------------------------

CBIOS_STATUS CBIOSAPI CBiosSetIGAUpscalerSetting (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    IN UINT32 upScalerSetting)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    // the panel state should be center or expansion state
    ASSERT(((upScalerSetting & UPSCALER_NOT_PREFERRED)^(upScalerSetting & UPSCALER_PREFERRED)) !=0 );

    if (IGA_Num == IGA1)
    {
        // check caps is under capability
        if ((pcbe->IGA1Info.IGAUpScalerCaps & upScalerSetting) != upScalerSetting)
        {
            return CBIOS_ER_INVALID_PARAMETER;
        }
        else
        {
            pcbe->IGA1Info.curUpScalerState = upScalerSetting;
        }
    }
    else if (IGA_Num == IGA2)
    {
        // check caps is under capability
        if ((pcbe->IGA2Info.IGAUpScalerCaps & upScalerSetting) != upScalerSetting)
        {
            return CBIOS_ER_INVALID_PARAMETER;
        }
        else
        {
            pcbe->IGA2Info.curUpScalerState = upScalerSetting;
        }
    }
    else
    {
        // Incorrect IGA number, add an assert for convenient debug
        cbDbgPrint(1, "Error IGA input num!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // update scratchpad when has LCD device
    if (IGA_Num == IGA1 && pcbe->IGA1Info.dispDev & (S3_LCD+S3_LCD2))
    {
        pcbe->sPad_8.bExpansion =
            (pcbe->IGA1Info.curUpScalerState & UPSCALER_PREFERRED) ? TRUE : FALSE;
        //Write scratch pad,so update hardware registers too
        cbWriteRegBits(pcbe, CR_4E, BIT4, STRUCT_BYTE(pcbe->sPad_8, 0));
    }
    else if (IGA_Num == IGA2 && pcbe->IGA2Info.dispDev & (S3_LCD+S3_LCD2))
    {
        pcbe->sPad_8.bExpansion =
            (pcbe->IGA2Info.curUpScalerState & UPSCALER_PREFERRED) ? TRUE : FALSE;
        //Write scratch pad,so update hardware registers too
        cbWriteRegBits(pcbe, CR_4E, BIT4, STRUCT_BYTE(pcbe->sPad_8, 0));
    }

    return CBIOS_OK;
}

//----------------------------------------------------------------------------
// CBIOSCurrentModeNeedUpScaler
//      This function returns whether current mode need scaler. This verdict needn't 
//   consider the existence of scaler on the specified IGA
//
//-----------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBIOSCurrentModeNeedScaler (
    PVOID pvcbe, 
    IN DWORD IGA_Num,
    OUT IGAScaleInfo *pIGAScaleInfo)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pIGAScaleInfo)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (IGA_Num == IGA1)
    {
        pIGAScaleInfo->bNeedUpScale = pcbe->IGA1Info.bCurrentModeNeedUpScaler;
        pIGAScaleInfo->bNeedDownScale = pcbe->IGA1Info.bCurrentModeNeedDownScaler;
        pIGAScaleInfo->mScaleFactor = pcbe->IGA1Info.curScaleFactor;
    }
    else if (IGA_Num == IGA2)
    {
        pIGAScaleInfo->bNeedUpScale = pcbe->IGA2Info.bCurrentModeNeedUpScaler;
        pIGAScaleInfo->bNeedDownScale = pcbe->IGA2Info.bCurrentModeNeedDownScaler;
        pIGAScaleInfo->mScaleFactor = pcbe->IGA2Info.curScaleFactor;
    }
    else
    {
        cbDbgPrint(1, "Error IGA input num!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    return CBIOS_OK;
}

//-----------------------------------------------------------------------------
//  CBiosSetClock
//      This function will load clock to According to  clock type & IGA number 
//      
//   IN : 
//      clockFreq
//           Clock Frequency (measured in Hz)
//      clockType
//           DCLK   =  Set DCLK (PIXEL clock)
//           ECLK  =   Set Egine clock
//-----------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosSetClock (
    PVOID pvcbe, 
    IN ULONG  clockFreq, 
    IN ULONG  clockType
)
{
    
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;  
    ULONG ulPllMRN;

    ulPllMRN = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, clockFreq);
   
    switch(clockType)
    {
    case S3_DCLK1:
        // IGA1 pixel clock
        status = cbSetPixelCLK_UMA(pcbe, ulPllMRN, IGA1);
        break;
    case S3_DCLK2:
        // IGA2 pixel clock
        status = cbSetPixelCLK_UMA(pcbe, ulPllMRN, IGA2);
        break;
    case S3_ECLK:
        // engine clock
        status = cbSetECLK_UMA(pcbe, ulPllMRN);
        break;
    default:
        cbDbgPrint(1, "Error clock setting type!\n");
        status = CBIOS_ER_INVALID_PARAMETER;
        break;
    }
    
    return status;
    
}


//-----------------------------------------------------------------------------
//  CBiosGetClock
//      This function will retrun current clock according to clock type & 
//  IGA number. calculation precision, the clock frequency returned may not 
//  be the exact clock value originally generated by PLL.
//      
//   IN : 
//      clockType
//           DCLK   =  Get DCLK (PIXEL clock)
//           ECLK   =  Get Egine clock
//           MCLK   =  Get Memory clock
//   OUT :
//      clockFreq
//           Clock Frequency (.Hz)
//-----------------------------------------------------------------------------
CBIOS_STATUS CBIOSAPI CBiosGetClock (
    PVOID pvcbe, 
    OUT PULONG pClockFreq,
    IN ULONG clockType
)
{
    
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;  
    
    switch(clockType)
    {
    case S3_DCLK1:
        // IGA1 pixel clock
        status = cbGetPixelCLK_UMA(pcbe, IGA1, pClockFreq);
        break;
    case S3_DCLK2:
        // IGA2 pixel clock
        status = cbGetPixelCLK_UMA(pcbe, IGA2, pClockFreq);
        break;
    case S3_ECLK:
        // engine clock
        status = cbGetECLK_UMA(pcbe, pClockFreq);
        break;
    case S3_MCLK:
        // memory clock
        status = cbGetMCLK_UMA(pcbe, pClockFreq);
        break;
    default:
        cbDbgPrint(1, "Error clock setting type!");
        status = CBIOS_ER_INVALID_PARAMETER;
    }
     
    return status;
    
}

CBIOS_STATUS CBIOSAPI CBiosSlowDownClock(
    PVOID pvcbe,
    IN DWORD dispDev,
    IN BOOL operate
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    switch(dispDev)
    {
        case S3_LCD:
        case S3_LCD2:
            if ((0 == pcbe->pVCPInfo) || (0 == pcbe->pVCPInfo->LCDInfoHeader))
            {
                return FALSE;
            }
            else
            {
                DWORD IGA_Num = 0;
                DWORD dwPllMRN = 0;

                BYTE panelID = 0;
                WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
                if(dispDev == S3_LCD)
                {
                    panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
                }
                else if(dispDev == S3_LCD2)
                {
                    panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
                }
                else
                {
                    // Incorrect device bit, add an assert for convenient debug
                    ASSERT(0);
                    return FALSE;
                }

                if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
                {
                    // get LCD timing table
                    PFPHeaderData pLCDHeader = (PFPHeaderData)&(pcbe->RomData[offsetLCDHeader]);
                    WORD offsetLCDEntry = pLCDHeader[panelID].fpEntryPoint;
                    WORD offsetLCDTable = *( (WORD*)&(pcbe->RomData[offsetLCDEntry]));
                    PLCDInitTbl pLCDTable = (PLCDInitTbl)&(pcbe->RomData[offsetLCDTable]);
                    pLCDHeader += panelID;

                    if(operate)
                    {
                        // slowdown clock, if enable this feature, use IGA1 PLL to replace the lowest clock
                        dwPllMRN = pLCDTable->IGA1_PLL;
                    }
                    else
                    {
                        // normal clock
                        dwPllMRN = pLCDTable->IGA2_PLL;
                    }

                    if(pcbe->IGA1Info.dispDev == dispDev)
                    {
                        IGA_Num = IGA1;
                    }
                    else if(pcbe->IGA2Info.dispDev == dispDev)
                    {
                        IGA_Num = IGA2;
                    }
                    else
                    {
                        // Incorrect device bit, add an assert for convenient debug
                        ASSERT(0);
                        return FALSE;
                    }

                    cbWaitVBlank(pcbe, IGA_Num);
                    cbSetPixelCLK_UMA(pcbe, dwPllMRN, IGA_Num);
                }
            }
            break;
        default:
            cbDbgPrint(1, "error device type");
            return CBIOS_ER_INVALID_PARAMETER;
    }
    return CBIOS_OK;
}

//------------------I2C--------------------------------------------------------

//-------------------------------------------------------------
// CBiosI2COperation
//
//   This function is a DDC/CI interface for specific platform, it's used to do
// ddcci operation by command. 
//    
//  IN: 
//      I2CBusNum = 1~5, 0 means no DDCI2C port
//                  1: SR26
//                  2: SR2C
//                  3: SR31
//                  4: SR3D
//                  5: SR25
//
//      pCBiosI2COperation 
//
//  OUT:
//       
//      pCBiosI2COperation->data
//      pCBiosI2COperation->status
//
//    Return:
//            status
//--------------------------------------------------------------

CBIOS_STATUS CBIOSAPI CBiosI2COperation(
    PVOID pvcbe, 
    IN OUT PI2COperation pCBiosI2COperation
)
{
  
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE portnum;
    
    pCBiosI2COperation->Status = CBI2C_STATUS_ERROR;

    if( !cbConvert_I2CBusNum_to_I2CPortNum(pCBiosI2COperation->I2CBusNum,&portnum))
    {
        return pCBiosI2COperation->Status;
    }

    i2c.I2cPort = portnum;
    i2c.SlaveAddr = 0;
    i2c.RegIndex = 0;
    i2c.IndexData = pCBiosI2COperation->Data;
    i2c.Flags = 0;

    switch(pCBiosI2COperation->Command)
    {
    case CBI2C_COMMAND_NULL:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Null_INV(pcbe, pCBiosI2COperation->Flags, &i2c);
        break;

    case CBI2C_COMMAND_READ:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Read_INV(pcbe, pCBiosI2COperation->Flags, &i2c);
        pCBiosI2COperation->Data = i2c.IndexData;
        break;

    case CBI2C_COMMAND_WRITE:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Write_INV(pcbe, pCBiosI2COperation->Flags, &i2c);
        break;

    case CBI2C_COMMAND_RESET:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Stop_INV(pcbe, &i2c);
        break;
        
    case CBI2C_COMMAND_OPEN:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Enable_INV(pcbe, &i2c);
        break;

    case CBI2C_COMMAND_CLOSE:
        pCBiosI2COperation->Status = cbDDCCI_I2C_Disable_INV(pcbe, &i2c);
        break;

    case CBI2C_COMMAND_STATUS:
        break;

    default:
        pCBiosI2COperation->Status = CBI2C_STATUS_ERROR;
        break;
    }

    if(pCBiosI2COperation->Status == CBI2C_STATUS_NOERROR)
        return CBIOS_OK;
    else
        return CBIOS_ER_DDCRead;
}

//-------------------------------------------------------------
//  CBiosI2CDDCCIDataRead
//
//   This function is DDC/CI interface for VISTA, it's used to read ddcci data 
// by I2C read
//   IN: 
//      pI2CData->BusNum = I2CBUSNUM
//                  0: no DDCCI I2C port
//                  1: SR26
//                  2: SR2C
//                  3: SR31
//                  4: SR3D
//                  5: SR25
//--------------------------------------------------------------

CBIOS_STATUS CBIOSAPI
CBiosI2CDDCCIDataRead(PVOID pvcbe,
              IN OUT   PI2CData pI2CData)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    AUX_CONTROL_UMA AUX;
    BYTE* DataBuffer;
    ULONG BufferSize;
    ULONG Flags = 0;           //enum I2C_Flags {DATA_FETCH_DELAY,VERIFY_CHECKSUM};
    BYTE portnum;
    PDigitalPortInfo PDIPort = NULL;
    CBIOS_STATUS status = CBIOS_OK;

    if(FALSE ==  cbGetDIPortInfo(pcbe, &PDIPort, pI2CData->DeviceID))
    {
        status = CBIOS_ER_DDCRead;
    }

    if((status == CBIOS_OK) && 
        ((PDIPort->PortInfo.TXType == INTERNAL_DP) && 
        (pI2CData->DeviceID == S3_DVI || pI2CData->DeviceID == S3_HDMI)))
    {
        BufferSize = pI2CData->bufLen;
        DataBuffer = pI2CData->pBuf;
        i2c.I2cPort = 0;
        i2c.SlaveAddr = pI2CData->subAddr;
        i2c.RegIndex = pI2CData->offset;
        i2c.IndexData = 0;
        i2c.Flags = 0;

        memset(DataBuffer,0,BufferSize);
 
        if(cbHDMII2CReadDDCBytes(pcbe, &i2c, DataBuffer, BufferSize) == TRUE)
        {
            status = CBIOS_OK;
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }
    }
    else if((status == CBIOS_OK) && 
        ((PDIPort->PortInfo.TXType == INTERNAL_DP && pI2CData->DeviceID == S3_DP) ||
        (PDIPort->PortInfo.TXType == INTERNAL_DP2 && pI2CData->DeviceID == S3_DP2)))
    {
        DWORD DPIndex = (pI2CData->DeviceID == S3_DP ? DP1 : DP2);
        BufferSize = pI2CData->bufLen; 
        DataBuffer = pI2CData->pBuf;
        AUX.I2cPort = pI2CData->subAddr;
        AUX.Offset = pI2CData->offset;
        AUX.Length = 1;
        AUX.Function = I2C_READ;

        if(cbDPI2CReadDDCBytes(pcbe, DPIndex, &AUX, DataBuffer, BufferSize) == TRUE)
        {
            status = CBIOS_OK;
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }
    }
    else
    {
        if( !cbConvert_I2CBusNum_to_I2CPortNum(pI2CData->BusNum,&portnum))
        {
            status = CBIOS_ER_DDCRead;
        }    
        else
        {
           BufferSize = pI2CData->bufLen;
           DataBuffer = pI2CData->pBuf;
           i2c.I2cPort = portnum;
           i2c.SlaveAddr = pI2CData->subAddr;
           i2c.RegIndex = pI2CData->offset;
           i2c.IndexData = 0;
           i2c.Flags = 0;
   
            memset(DataBuffer,0,BufferSize);
   
           if(I2C_Data_Request_INV(pcbe, 
                                 &i2c, 
                                 BufferSize,
                                 Flags,
                                 DataBuffer))
           {                      
               status = CBIOS_OK;
           }
           else
           {
               status = CBIOS_ER_DDCRead;    
           }
        }
   
    }

    return status;  
}

//-------------------------------------------------------------
//  CBiosI2CDDCCIDataWrite
//
//   This function is DDC/CI interface for VISTA, it's used to write ddcci data 
// by I2C write
//   IN: 
//      pI2CData->BusNum = I2CBUSNUM
//                  0: no DDCCI I2C port
//                  1: SR26
//                  2: SR2C
//                  3: SR31
//                  4: SR3D
//                  5: SR25
//--------------------------------------------------------------

CBIOS_STATUS CBIOSAPI
CBiosI2CDDCCIDataWrite(PVOID pvcbe,
               IN  PI2CData pI2CData)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    AUX_CONTROL_UMA AUX;
    BYTE* DataBuffer;
    ULONG BufferSize;
    ULONG Flags = 0;
    BYTE portnum;
    PDigitalPortInfo PDIPort = NULL;
    CBIOS_STATUS status = CBIOS_OK;

    if(FALSE ==  cbGetDIPortInfo(pcbe, &PDIPort, pI2CData->DeviceID))
    {
        status = CBIOS_ER_DDCRead;
    }

    if((status == CBIOS_OK) && 
        ((PDIPort->PortInfo.TXType == INTERNAL_DP) && 
        (pI2CData->DeviceID == S3_DVI || pI2CData->DeviceID == S3_HDMI)))
    {
        BufferSize = pI2CData->bufLen; 
        DataBuffer = pI2CData->pBuf;
        i2c.I2cPort = 0;
        i2c.SlaveAddr = pI2CData->subAddr;
        i2c.RegIndex = pI2CData->offset;
        i2c.Flags = 0;

        if(cbHDMII2CWriteDDCBytes(pcbe, &i2c, DataBuffer, BufferSize) == TRUE)
        {
            status = CBIOS_OK;
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }

    }
    else if((status == CBIOS_OK) && 
        ((PDIPort->PortInfo.TXType == INTERNAL_DP && pI2CData->DeviceID == S3_DP) ||
        (PDIPort->PortInfo.TXType == INTERNAL_DP2 && pI2CData->DeviceID == S3_DP2)))
    {
        DWORD DPIndex = (pI2CData->DeviceID == S3_DP ? DP1 : DP2);
        BufferSize = pI2CData->bufLen; 
        DataBuffer = pI2CData->pBuf;
        AUX.I2cPort = pI2CData->subAddr;
        AUX.Offset = pI2CData->offset;
        AUX.Length = 1;
        AUX.Function = I2C_WRITE;

        if(cbDPI2CWriteDDCBytes(pcbe, DPIndex, &AUX, DataBuffer, BufferSize) == TRUE)
        {
            status = CBIOS_OK;
        }
        else
        {
            status = CBIOS_ER_DDCRead;
        }
    }
    else
    {

        if( !cbConvert_I2CBusNum_to_I2CPortNum(pI2CData->BusNum,&portnum))
        {
            status = CBIOS_ER_DDCRead;
        }
        else
        {
            BufferSize = pI2CData->bufLen;
            DataBuffer = pI2CData->pBuf;
            i2c.I2cPort = portnum;
            i2c.SlaveAddr = pI2CData->subAddr;
            i2c.RegIndex = pI2CData->offset;
            i2c.IndexData = 0;
            i2c.Flags = 0;
            
            if(I2C_Data_Update_INV(pcbe, 
                                  &i2c, 
                                  BufferSize,
                                  Flags,
                                  DataBuffer))
            {
                status = CBIOS_OK;
            }
            else
            {
                status = CBIOS_ER_DDCRead;
            }
        }
    
    }
    
    return status;  
}

/*------------------Misc-------------------------------------------------------
*****************************************************************************
*
* CBiosNonDestructiveDeviceDetect
*
* The function returns device attached status by Non-Destructive detection.
* Driver should not sensor an unsupported device, or we will return fail
*
* Parameters:
*      detectDev:      only one device bit can be set
*      pbAttached:     return device attached status.
* Return Value:
*      CBIOS_STATUS
*
*****************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosNonDestructiveDeviceDetect (
    PVOID pvcbe,
    IN UINT32 detectDev,
    OUT BOOL *pbAttached
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    if (!pbAttached) {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

     /* if more than one device bit set, return fail */
    if (MORE_THAN_1BIT(detectDev)) {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    /* if sensor an unsupported device, add one assert to notify driver to change */
    if(!(pcbe->SupportDevices & detectDev)) {
        *pbAttached = FALSE;
        ASSERT(0);
        return CBIOS_OK;
    }
    /* Attention: here we do not add device filter rule, if customer select more than two devices
        * if always on device, then we always report it as attached */
    if (cbIsAlwaysOnDevice(pcbe,detectDev)) {
        *pbAttached = TRUE;
        return CBIOS_OK;
    }

    switch (detectDev) {
    case S3_CRT:
        /* EDID sense, only get I2C acknowledge */
        *pbAttached = TRUE; /* assume attached */
        /* CRT is always attached for FPGA limitation */
        if(pcbe->ChipRevision != FPGA_ChipRevision) {
            if ((pcbe->pVCPInfo->version >= VCP1_6) && (pcbe->pVCPInfo->miscConfigure3 &
                (CRT_DVI_SHARE_CONNECTOR + CRT_DVI2_SHARE_CONNECTOR))) {
                EDID_MONITOR_TYPE type;
                DWORD DVIDev = (pcbe->pVCPInfo->miscConfigure3 & CRT_DVI_SHARE_CONNECTOR) ? S3_DVI : S3_DVI2;

                /* disconnected default */
                *pbAttached = FALSE;

                if (cbIsDigitalOrAnalogMonitor(pcbe, S3_CRT, &type)) {
                    if (type == EDID_ANALOG) {
                        *pbAttached = TRUE;  /* connected */
                    }                
                }
                if (*pbAttached == FALSE) {
                    if (cbIsDigitalOrAnalogMonitor(pcbe, DVIDev, &type)) {
                            if (type == EDID_ANALOG) {
                                *pbAttached = TRUE;  /* connected */
                            }
                    }
                }
            } else {
                *pbAttached = cbGetDeviceDDCStatus(pcbe, S3_CRT);            
            }
        }
        if (*pbAttached == FALSE) {
            cbClearEDIDBuf(pcbe, S3_CRT);
        }
        break;
    case S3_CRT2:
        {
            I2C_CONTROL_UMA i2c;
            ULONG encodertype = 0;

            i2c.Flags = 0;
            /* get CRT2 associated TxType */
            if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE) {
                cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
                status = CBIOS_ER_LACKOFINFO;
                break;
            }
            
            /* By now,CRT2 on VT1625,and can not read EDID
                      * So there is no NonDestructiveDeviceDetect
                      * Default set to nonconnected */
            *pbAttached = FALSE;

            if (encodertype == CH7301) {
                EDID_MONITOR_TYPE type;
                if (cbIsDigitalOrAnalogMonitor(pcbe, S3_CRT2, &type)) {
                        if(type == EDID_ANALOG) {
                            *pbAttached = TRUE;  /* connected */
                        }                
                }
            }
        }
        break;
    case S3_DVI:
        /* Transmitter then EDID sense */
        {
            I2C_CONTROL_UMA i2c;
            BYTE TxType=0;

            i2c.Flags = 0;
            /* get DVI associated TxType */
            if (cbGetDITXtype(pcbe, &TxType, S3_DVI) == FALSE) {
                cbDbgPrint(1, "Can not find TMDS transmitter!\n");
                status = CBIOS_ER_LACKOFINFO;
                break;
            }
            /* now below code is only for 353 internal TMDS hot plug sense, 
                      * 324 should be added later */
            if ((TxType == IN_TMDS) && 
                 (pcbe->ChipCaps.Inside_TMDS_Sense_SR3E)) {
                BYTE SR3E = 0x00;
                BYTE SR2A = 0x00;
                BYTE CRD2 = 0x00;
                if (pcbe->devicepowerstate[DVIbit] == S3PM_OFF) {
                    if (pcbe->ChipCaps.for_inside_tmds_sense_fail) {                              
                         SR2A = cbReadRegByte(pcbe, SR_2A);
                         CRD2 = cbReadRegByte(pcbe, CR_D2);
                         cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, BIT1+BIT0);
                         cbWriteRegBits(pcbe, CR_D2, BIT3, 0);
                         /* Clear interrupt status bit, because enable/disable TMDS will cause interrupt rise */
                         cbWriteRegBits(pcbe, SR_3E, BIT6, BIT6);
                    }
                }
                /* use SR3E[5] for internal DVI connect sense */
                SR3E = cbReadRegByte(pcbe, SR_3E);

                if (SR3E & BIT5) {
                    *pbAttached = TRUE;
                } else {
                    *pbAttached = FALSE;
                }
                if (pcbe->devicepowerstate[DVIbit] == S3PM_OFF) {
                    if (pcbe->ChipCaps.for_inside_tmds_sense_fail) {
                         cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, SR2A);
                         cbWriteRegBits(pcbe, CR_D2, BIT3, CRD2);
                         /* Clear interrupt status bit, because enable/disable TMDS will cause TMDS hotplug interrupt rise */
                         cbWriteRegBits(pcbe, SR_3E, BIT6, BIT6);
                    }
                }
                if(*pbAttached == FALSE) {
                    cbClearEDIDBuf(pcbe, S3_DVI);
                }
            } else {
                /* Below is daughter card sense and EDID sense flow */
                if (TxType == AD9389B) {
                    if (!cbHDMITxDeviceDetect(pcbe, S3_DVI, pbAttached)) {
                        *pbAttached = FALSE;
                    }
                } else if (TxType == CH7301) {
                    /* get i2c info first */
                    if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI)) {
                        *pbAttached = FALSE;  /* not connected */
                        break;
                    }

                    /* default assume not connected */
                    *pbAttached = FALSE;
                    i2c.RegIndex  = 0x20;

                    /* if I2C work properly then check return value
                                   * get i2c register index data */
                    if (I2C_Read_Byte_INV(pcbe, &i2c)) {
                        /* detect DVIT status */
                        if (i2c.IndexData & 0x20) {
                            /* check EDID Offset 14h for Analog / Digital Signal Level */
                            EDID_MONITOR_TYPE type;                            
                            if (cbIsDigitalOrAnalogMonitor(pcbe, S3_DVI, &type)) {
                                if (type == EDID_DIGITAL) {
                                    *pbAttached = TRUE;  /* DVI monitor connected */
                                }
                            }
                        } else {    
                            cbClearEDIDBuf(pcbe, S3_DVI);
                        }
                    }
                } else if (TxType == IN_TMDS) {
                    *pbAttached = cbGetDeviceDDCStatus(pcbe, S3_DVI);
                    if (*pbAttached == FALSE) {
                        cbClearEDIDBuf(pcbe, S3_DVI);
                    }
                } else if (TxType == INTERNAL_DP) {
                    cbDPDeviceDetect(pcbe, S3_DVI, pbAttached);
                    if(*pbAttached)
                        pcbe->DPSinkCaps[DP1].IsHDMIDevice = FALSE;
                }  else {
                    /* 1632
                                   * get i2c info first */
                    if (!cbGetDII2Csetting(pcbe, &i2c,S3_DVI)) {
                        *pbAttached = FALSE;  /* not connected */
                        break;
                    }
                    i2c.RegIndex  = 0x09;
                    /* if I2C work properly then check return value
                                   * get i2c register index data */
                    if (I2C_Read_Byte_INV(pcbe, &i2c)) {
                        if (i2c.IndexData & 0x04) {
                            *pbAttached = TRUE;  /* connected */
                        } else {
                            if ((pcbe->pVCPInfo->version >= VCP1_6) &&
                                (pcbe->pVCPInfo->miscConfigure3 & CRT_DVI_SHARE_CONNECTOR)) {
                                EDID_MONITOR_TYPE type;

                                /* disconnected default */
                                *pbAttached = FALSE;

                                if (cbIsDigitalOrAnalogMonitor(pcbe, S3_DVI, &type)) {
                                    if(type == EDID_DIGITAL) {
                                        *pbAttached = TRUE;  /* DVI monitor connected */
                                    }
                                }
                                if (*pbAttached == FALSE) {
                                    if (cbIsDigitalOrAnalogMonitor(pcbe, S3_CRT, &type)) {
                                        if(type == EDID_DIGITAL) {
                                            *pbAttached = TRUE;  /* DVI monitor connected */
                                        }
                                    }
                                }
                            } else {
                                /* Add EDID check for TX sense fail */
                                *pbAttached = cbGetDeviceDDCStatus(pcbe, S3_DVI);
                            }
                        }
                    } else {
                        *pbAttached = FALSE;  // not connected
                    }
                    if (*pbAttached == FALSE) {
                        cbClearEDIDBuf(pcbe, S3_DVI);
                    }
                }
            }
        }
        break;
    case S3_DVI2:
        /* Transmitter then EDID sense */
        {
            I2C_CONTROL_UMA i2c;
            BYTE TxType=0;

            i2c.Flags = 0;            
            /* get DVI2 associated TxType */
            if (cbGetDITXtype(pcbe, &TxType, S3_DVI2) == FALSE) {
                cbDbgPrint(1, "Can not find TMDS transmitter!\n");
                status = CBIOS_ER_LACKOFINFO;
                break;
            }
            /* now below code is only for 353 internal TMDS hot plug sense, 
                     * 324 should be added later */
            if ((TxType == IN_TMDS) && 
                 (pcbe->ChipCaps.Inside_TMDS_Sense_SR3E)) {
                BYTE SR3E;
                /* use SR3E[5] for internal DVI connect sense */
                SR3E = cbReadRegByte(pcbe, SR_3E);
                if(pcbe->devicepowerstate[DVI2bit] == S3PM_OFF) {
                    if(pcbe->ChipCaps.for_inside_tmds_sense_fail) {                              
                         cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, BIT1+BIT0);
                         cbWriteRegBits(pcbe, CR_D2, BIT3, 0);
                    }                    
                }
                if (SR3E & BIT5) {
                    *pbAttached = TRUE;              
                } else {
                    *pbAttached = FALSE;              
                }
                if (pcbe->devicepowerstate[DVI2bit] == S3PM_OFF) {
                    if (pcbe->ChipCaps.for_inside_tmds_sense_fail) {                              
                         cbWriteRegBits(pcbe, SR_2A, BIT1+BIT0, 0);
                         cbWriteRegBits(pcbe, CR_D2, BIT3, BIT3);
                    }                    
                }
                /* If 353 hot plug TMDS is sensed connected, break, if not, go on to do EDID sense */
                if (*pbAttached) {
                    break;
                }
            }    
            /* Below is daughter card sense and EDID sense flow */
            {
                if (TxType == AD9389B) {
                    if (!cbHDMITxDeviceDetect(pcbe, S3_DVI2, pbAttached)) {
                        *pbAttached = FALSE;
                    }
                } else if (TxType == CH7301) {
                    /* get i2c info first */
                    if (!cbGetDII2Csetting(pcbe, &i2c, S3_DVI2)) {
                        *pbAttached = FALSE;  /* not connected */
                        break;
                    }

                    /* default assume not connected */
                    *pbAttached = FALSE;
                    i2c.RegIndex  = 0x20;

                    /* if I2C work properly then check return value
                                   * get i2c register index data */
                    if (I2C_Read_Byte_INV(pcbe, &i2c)) {
                        /* detect DVIT status */
                        if (i2c.IndexData & 0x20) {
                            /*check EDID Offset 14h for Analog / Digital Signal Level */
                            EDID_MONITOR_TYPE type;                            
                            if(cbIsDigitalOrAnalogMonitor(pcbe, S3_DVI2, &type)) {
                                if(type == EDID_DIGITAL) {
                                    *pbAttached = TRUE;  /* DVI monitor connected */
                                }
                            }
                        } else {    
                            cbClearEDIDBuf(pcbe, S3_DVI2);
                        }
                    }
                } else if (TxType == IN_TMDS) {
                    *pbAttached = cbGetDeviceDDCStatus(pcbe, S3_DVI2);
                    if (*pbAttached == FALSE) {
                        cbClearEDIDBuf(pcbe, S3_DVI2);
                    }
                } else if (TxType == INTERNAL_DP) {
                    /* internal DVI */
                    cbDPDeviceDetect(pcbe, S3_DVI2, pbAttached);
                    if(*pbAttached)
                        pcbe->DPSinkCaps[DP1].IsHDMIDevice = FALSE;
                } else {
                    /* 1632
                                   * get i2c info first */
                    if (!cbGetDII2Csetting(pcbe, &i2c,S3_DVI2)) {
                        *pbAttached = FALSE;  /* not connected */
                        break;
                    }

                    i2c.RegIndex  = 0x09;

                    /* if I2C work properly then check return value
                                   * get i2c register index data */
                    if (I2C_Read_Byte_INV(pcbe, &i2c)) {
                        if (i2c.IndexData & 0x04) {
                            *pbAttached = TRUE;  /* connected */
                        } else {
                            if ((pcbe->pVCPInfo->version >= VCP1_6) &&
                                (pcbe->pVCPInfo->miscConfigure3 & CRT_DVI2_SHARE_CONNECTOR)) {
                                EDID_MONITOR_TYPE type;

                                /* disconnected default */
                                *pbAttached = FALSE;

                                if (cbIsDigitalOrAnalogMonitor(pcbe, S3_DVI2, &type)) {
                                    if (type == EDID_DIGITAL) {
                                        *pbAttached = TRUE;  /* DVI monitor connected */
                                    }
                                }
                                if (*pbAttached == FALSE) {
                                    if (cbIsDigitalOrAnalogMonitor(pcbe, S3_CRT, &type)) {
                                        if (type == EDID_DIGITAL) {
                                            *pbAttached = TRUE;  /* DVI monitor connected */
                                        }
                                    }
                                }
                            } else {
                                /* Add EDID check for TX sense fail */
                                *pbAttached = cbGetDeviceDDCStatus(pcbe, S3_DVI2);
                            }
                        }
                    } else {
                        *pbAttached = FALSE;  /* not connected */
                    }
                    if (*pbAttached == FALSE) {
                        cbClearEDIDBuf(pcbe, S3_DVI2);
                    }
                }
            }
        }
        break;
    case S3_LCD:
    case S3_LCD2:
        /* always attach */
        *pbAttached = TRUE;
        break;
    case S3_TV:
    case S3_HDTV:
    {
        ULONG encodertype;
        
        // auto sense needs V_Blank. If we open TV DI port pad, we must configure right
        // TV->GFX->TV clock path to provide TV encoder right timing
        // Since we only configure TV->GFX->TV when TV / HDTV power on case 
        // So we use TV / HDTV power state
        if (pcbe->devicepowerstate[TVbit] != S3PM_ON && pcbe->devicepowerstate[HDTVbit] != S3PM_ON)
        {
            status = CBIOS_ER_INTERNAL;
            break;
        }
        
        if (cbGetDIEncodertype(pcbe, &encodertype, detectDev) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            status = CBIOS_ER_INTERNAL;
            break;
        }
        
        if (encodertype == IN_TV)
        {
            // CBiosNonDestructiveDeviceDetect is used to sense CRT EDID, 
            // if CRT is attached, then we report TV not connected,because they share DAC
            if( (CBiosNonDestructiveDeviceDetect(pcbe, S3_CRT, pbAttached) != CBIOS_OK) ||
                (*pbAttached == FALSE) )
            {
                cbInTVSense(pcbe, pbAttached); // auto sense here for internal TV
            }
            else
            {
                // CRT sense success since VT3324 CRT and TV can not connect 
                // at the same time so just report TV does't connect
                *pbAttached = FALSE;
            }
        }
        else if (encodertype == VT1625_6 || encodertype == VT1625A_6A)
        {
            // 1625(A) TV encoder auto sense
            if (cb1625AutoSense(pcbe, pbAttached) == FALSE)
            {
                status = CBIOS_ER_INTERNAL;
                break;
            }
        }
        else if (encodertype == VT1622A)
        {
            // 1622A TV encoder auto sense
            if (cb1622AutoSense(pcbe, pbAttached) == FALSE)
            {
                status = CBIOS_ER_INTERNAL;
                break;
            }
        }
        break;
    }    
    case S3_HDMI:
    {
        I2C_CONTROL_UMA i2c;
        BYTE TxType=0;

        i2c.Flags = 0;            
        /* get DVI2 associated TxType */
        if (cbGetDITXtype(pcbe, &TxType, S3_HDMI) == FALSE) {
            cbDbgPrint(1, "Can not find HDMI transmitter!\n");
            status = CBIOS_ER_LACKOFINFO;
            break;
        }

        if (TxType == AD9389B) {
            if( !cbHDMITxDeviceDetect(pcbe, S3_HDMI, pbAttached) ) {
                *pbAttached = FALSE;
            }
        }

        /* internal HDMI */
        if (TxType == INTERNAL_DP) {
            cbDPDeviceDetect(pcbe, S3_HDMI, pbAttached);
            if (*pbAttached)
                pcbe->DPSinkCaps[DP1].IsHDMIDevice = TRUE;
        }
    }
        break;
    case S3_HDMI2:
    {
        I2C_CONTROL_UMA i2c;
        BYTE TxType=0;

        i2c.Flags = 0;            
        /* get DVI2 associated TxType */
        if (cbGetDITXtype(pcbe, &TxType, S3_HDMI2) == FALSE) {
            cbDbgPrint(1, "Can not find HDMI transmitter!\n");
            status = CBIOS_ER_LACKOFINFO;
            break;
        }

        if (TxType == AD9389B) {
            if (!cbHDMITxDeviceDetect(pcbe, S3_HDMI2, pbAttached)) {
                *pbAttached = FALSE;
            }
        }

        /* internal HDMI */
        if (TxType == INTERNAL_DP) {
            cbDPDeviceDetect(pcbe, S3_HDMI2, pbAttached);
            if (*pbAttached)
                pcbe->DPSinkCaps[DP1].IsHDMIDevice = TRUE;
        }
    }
        break;
    case S3_DP:
    {
        cbDPDeviceDetect(pcbe, S3_DP, pbAttached);
    }
        break;
    case S3_DP2:
    {
        cbDPDeviceDetect(pcbe, S3_DP2, pbAttached);
    }
        break;
    default:
        status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        break;
    }

    return status;
}

//*****************************************************************************
//
//  CBiosDestructiveDeviceDetect
//
//  The function returns device attached status by Destructive detection.
//  Driver should not sensor an unsupported device, or we will return fail
//
//  Parameters:
//      detectDev:      only one device bit can be set
//      pbAttached:     return device attached status.
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosDestructiveDeviceDetect (
    PVOID pvcbe,
    IN UINT32 detectDev,
    OUT BOOL *pbAttached
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    if (!pbAttached)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
     // if more than one device bit set, return fail
    if (MORE_THAN_1BIT(detectDev))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // if sensor an unsupported device, add one assert to notify driver to change
    ASSERT(pcbe->SupportDevices & detectDev);

    // Attention: here we do not add device filter rule, if customer select more than two devices
    // if always on device, then we always report it as attached
    if(cbIsAlwaysOnDevice(pcbe,detectDev))
    {
        *pbAttached = TRUE;
        return CBIOS_OK;
    }

    switch (detectDev)
    {
    case S3_CRT:
        {
            BYTE IGAPll, IGAClk, DPMS_State, CRT_Path;
            BOOL bNeed_Delay = FALSE;

            //If internal tv support, then we should not use DAC sense for CRT,
            //because TV&CRT share DAC,if internal tv connected, CRT DAC sense 
            //also return true, in such case, we should use EDID sense.
            if (pcbe->pVCPInfo->miscConfigure & INTERNAL_TV_SUPPORT)  //internal tv support
            {
                status = CBiosNonDestructiveDeviceDetect(pcbe, S3_CRT, pbAttached); 
            }
            else
            {
                // DAC sense: need IGA1 clock on, DPMS power on

                //Turn on CRT's IGA PLL
                CRT_Path = (cbReadRegByte(pcbe, SR_16) & BIT6) >> 6;
                if(CRT_Path == IGA1)
                {
                    
                    // IGA1 PLL Power on
                    IGAPll = cbReadRegByte(pcbe, SR_2D);
                    if(!(IGAPll & BIT5))
                    {
                        // turn on PLL
                        cbWriteRegBits(pcbe, SR_2D, BIT4+BIT5, BIT4+BIT5);
                        bNeed_Delay = TRUE;
                    }
                    IGAClk = cbReadRegByte(pcbe, SR_1B);
                    if(!(IGAClk & BIT5))
                    {
                        // turn on gate
                        cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5, BIT4+BIT5);
                        bNeed_Delay = TRUE;
                    }
                }
                else
                {
                    // IGA2 PLL Power on
                    IGAPll = cbReadRegByte(pcbe, SR_2D);
                    if(!(IGAPll & BIT3))
                    {
                        // turn on LCK
                        cbWriteRegBits(pcbe, SR_2D, BIT2+BIT3, BIT2+BIT3);
                        bNeed_Delay = TRUE;
                    }
                    IGAClk = cbReadRegByte(pcbe, SR_1B);
                    if(!(IGAClk & BIT7))
                    {
                        // turn on gate
                        cbWriteRegBits(pcbe, SR_1B, BIT6+BIT7, BIT6+BIT7);
                        bNeed_Delay = TRUE;
                    }
                }
                
                // trun on DAC(DPMS) in hardware DAC sense
                DPMS_State = cbReadRegByte(pcbe, CR_36);
                if((DPMS_State & (BIT4+BIT5)) != 0)
                {
                    // If not DPMS on, turn on DPMS
                    cbWriteRegBits(pcbe, CR_36, BIT4+BIT5+BIT6+BIT7, 0x0);
                    bNeed_Delay = TRUE;
                }
                // We found: if turn on DPMS and sensor CRT immediately, the sense will fail
                // So add a 2ms delay after turn on CR36, this is an experience value on VT5935C4
                // HW explain: PLL on/off may has this issue too, so if any of those registers are off, need delay
                if(bNeed_Delay)
                {
                    cbDelayMicroSeconds(40000);
                }
                // CRT sense sequence : 
                // For vt3290(NEW_DAC_SENSE_FLOW)  : Enable Sense(=1) --> Disable Sense(= 0)   --> check status(3C2[4])
                // For 259/204(products before 290): Enable Sense(=1) --> check status(3C2[4]) --> Disable Sense(= 0)
                // Enable CRT sensor bit
                cbWriteRegBits(pcbe, SR_40, BIT7, BIT7);
                // HW request to delay >=100 Pixel CLK according to HW sense spec
                // Suppose Minium 10M pixel CLK, then delay time need 10us.
                cbDelayMicroSeconds(10);
                if(pcbe->ChipCaps.New_crt_dac_sense_flow)
                {
                    // Disable CRT sensor bit
                    cbWriteRegBits(pcbe, SR_40, BIT7, 0);
                    if ( ReadUchar(CB_INPUT_STATUS_0_REG) & BIT4 )
                    {
                        *pbAttached = TRUE;
                    }
                    else
                    {
                        *pbAttached = FALSE;
                    }
                }
                else
                {
                    if ( ReadUchar(CB_INPUT_STATUS_0_REG) & BIT4 )
                    {
                        *pbAttached = TRUE;
                    }
                    else
                    {
                        *pbAttached = FALSE;
                    }
                    // Disable CRT sensor bit
                    cbWriteRegBits(pcbe, SR_40, BIT7, 0);
                }
    
                // This is special monitor func disable it
                // it will cause our CRT sense always destructive
                //cbDelayMicroSeconds(15000); // delay 15 ms, or some CRT crash
        
                // restore DAC status
                cbWriteRegByte(pcbe, CR_36, DPMS_State);

                // restore VCK
                cbWriteRegByte(pcbe, SR_1B, IGAClk);
                // restore IGA1 PLL Power
                cbWriteRegByte(pcbe, SR_2D, IGAPll);
            }
        }
        break;
    case S3_CRT2:
        status = cbSensorCRT2_UMA(pcbe, pbAttached);
        break;    
    case S3_LCD:
    case S3_LCD2:
        // always attach
        *pbAttached = TRUE;
        break;
    case S3_TV:
    case S3_HDTV:
    {
        ULONG encodertype;
        // Internal TV and 1625 will go different way to sense
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            status = CBIOS_ER_INTERNAL;
            *pbAttached = FALSE;
            break;
        }
        if(encodertype == IN_TV)
        {
            // CBiosNonDestructiveDeviceDetect is used to sense CRT EDID, 
            // if CRT is attached, then we report TV not connected,because they share DAC
            if( (CBiosNonDestructiveDeviceDetect(pcbe, S3_CRT, pbAttached) == CBIOS_OK) &&
                (*pbAttached == TRUE) )
            {
                *pbAttached = FALSE;
                break;
            }
            cbInTVSense(pcbe, pbAttached); //also auto sense here for internal TV
        }
        else 
        {
        // TV encoder normal sense
        // now only support 1625(A)
            I2C_CONTROL_UMA i2c;
            if(!cbGetTVI2CInfo(pcbe, &i2c))
            {
                *pbAttached = FALSE;  // not connected
                break;
            }
            i2c.RegIndex  = 0x0E;
            i2c.Flags = 0;
                
            if(I2C_Read_Byte_INV(pcbe, &i2c))
            {
                BYTE RegE, RegF, Reg1C;
                // save reg 0E
                RegE = i2c.IndexData;
                // force all DAC open
                i2c.IndexData = 0x00;
                I2C_Write_Byte_INV(pcbe, &i2c);
    
                // Normal DAC Sense
                i2c.RegIndex = 0x1C;
                I2C_Read_Byte_INV(pcbe, &i2c);
                Reg1C = i2c.IndexData;
    
                i2c.IndexData &= 0x1F;
                I2C_Write_Byte_INV(pcbe, &i2c);
    
                i2c.IndexData |= BIT7;
                I2C_Write_Byte_INV(pcbe, &i2c);
    
                // delay 5ms for register bit change
                cbDelayMicroSeconds(5000);
    
                i2c.IndexData = Reg1C;
                I2C_Write_Byte_INV(pcbe, &i2c);
    
                i2c.RegIndex = 0x0F;
                I2C_Read_Byte_INV(pcbe, &i2c);
    
                RegF = i2c.IndexData;
    
                // restore reg 0E
                i2c.RegIndex = 0x0E;
                i2c.IndexData = RegE;
                I2C_Write_Byte_INV(pcbe, &i2c);
    
                RegF &= 0x3F;
                // check if any DAC connected
                if(RegF == 0x3F)
                {
                    *pbAttached = FALSE;
                }
                else
                {
                    *pbAttached = TRUE;
                }
            }
            else
            {
                *pbAttached = FALSE;
            }
        }
        break;
    }
    default:
        status = CBIOS_ER_NOT_YET_IMPLEMENTED;
    }

    return status;
}

CBIOS_STATUS CBIOSAPI CBiosConfFileRead(PVOID pvcbe, const char * FileName, char *FileBuffer) 
{ 
   PCBIOS_EXTENSION pcbe = pvcbe;
   struct file *filp; 
   struct inode *inode; 
   mm_segment_t fs; 
   off_t fsize; 
   
   filp=filp_open(FileName,O_RDONLY,0); 

   if(IS_ERR(filp)){
        cbDbgPrint(1, "kernel conf file do not exist. \n");
        return -1;
   }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,19,0)
   inode = filp->f_path.dentry->d_inode;
#else
   inode=filp->f_dentry->d_inode;
#endif
  
   fsize=inode->i_size; 
   cbDbgPrint(0, "kernel conf file exsit. size is:%i \n",(int)fsize); 

   fs=get_fs(); 
   set_fs(KERNEL_DS); 
   filp->f_op->read(filp, FileBuffer, fsize, &(filp->f_pos)); 
   set_fs(fs); 

   FileBuffer[fsize]='\0'; 
   
    filp_close(filp,NULL); 
    
    return CBIOS_OK;
}

CBIOS_STATUS CBIOSAPI CBiosGetConfFileInfo(PVOID pvcbe, char *ConfFile, char *name, UINT32 *value)
{
    UINT32 LineEnd[30]={0};
    UINT8 OptName[30]={0};
    UINT32 i,j,k;
    UINT32 FileSize =0;
    UINT32 LineLength;
    char* p =NULL; 
    PCBIOS_EXTENSION pcbe = pvcbe;
    UINT8* FileBuffer =NULL;
    struct file *filp; 
	UINT32 HexFlag = (1<<31);

    if(name==NULL)
        return CBIOS_ER_LACKOFINFO;
    
    /* judge if file exsit first*/
    filp=filp_open(ConfFile,O_RDONLY,0); 
    if(IS_ERR(filp)){
        cbDbgPrint(0, "kernel conf file do not exist. \n");
        return -1;
    }
    else{
        filp_close(filp,NULL); 
    }    

    FileBuffer = (UINT8 *)kmalloc(1024*2, GFP_KERNEL);
    if (!FileBuffer)
        return -ENOMEM;
    memset(FileBuffer, 0, 1024*2);
    
    /*read file content to filebuffer*/
    if(CBiosConfFileRead(pcbe, ConfFile, FileBuffer)!= CBIOS_OK){
        kfree(FileBuffer);
        return CBIOS_ER_LACKOFINFO;	
    }        
    /*get confgure file size*/
    for(i=0;i<1024*2;i++){
        if(FileBuffer[i] == '\0'){
            FileSize = i;
            break;
        }
    }

    /*get every line end point*/
    for(i=0,j=1; i<FileSize; i++){
        if(FileBuffer[i]=='\n'){
            LineEnd[j] = i;
            FileBuffer[i]='\0';
            j++;
        }        
    }

    for(k=1; k<j; k++){
        /*get length of current line*/
        LineLength = LineEnd[k]-LineEnd[k-1];

        if((LineLength<3)||(LineLength>100))
        continue;
        
        /*point to  line string start address */
        if(k==1)
            p =FileBuffer;
        else
            p =FileBuffer+LineEnd[k-1]+1;
        
        /*ignore explain line */
        if(*p=='#')   
            continue;
		
        memset(OptName,0,sizeof(UINT8)*30);
		
        for(i=0;i<LineLength;i++){
            if((*(p+i))=='='){
                /*get configure name */
                strncpy(OptName , p, i);
                if(!strncmp(name, OptName, i)){
                    /*get configure value */
                    if(*(p+i+1)<='9'&&(*(p+i+1))>='0'){
                        /*case for hex*/
                        if((*(p+i+1)=='0')&&(strlen(p+i+1)>1)){
                            if((*(p+i+2)=='x')||(*(p+i+2)=='X')){
                                sscanf(p+i+3, "%x", value);
                                kfree(FileBuffer);
                                /*add hex flag for hex format configure value*/
                                *value |=HexFlag;
                                return CBIOS_OK;
                            }
                        }
                        
                        sscanf(p+i+1, "%d", value);
                        kfree(FileBuffer);
                        return CBIOS_OK;
                    } 
                }
            }
        } 
    }
    
     kfree(FileBuffer);
    /*name not found in configure file*/
    return CBIOS_ER_LACKOFINFO;
}

CBIOS_STATUS CBIOSAPI CBiosGetEdidConfInfo(PVOID pvcbe, char *ConfFile, char *name, UINT8 *ConfEdid)
{
    UINT32 LineEnd[30]={0};
    UINT8 OptName[30]={0};
    UINT32 i,j,k;
    UINT32 FileSize =0;
    UINT32 LineLength;
    UINT8* p =NULL; 
    PCBIOS_EXTENSION pcbe = pvcbe;
    UINT8* FileBuffer =NULL;
    struct file *filp;     

    if(name==NULL)
        return CBIOS_ER_LACKOFINFO;

    /* judge if file exsit first*/
    filp=filp_open(ConfFile,O_RDONLY,0); 
    if(IS_ERR(filp)){
        cbDbgPrint(0, "kernel conf file do not exist. \n");
        return -1;
    }
    else{
        filp_close(filp,NULL); 
    }    

    FileBuffer = (UINT8 *)kmalloc(1024*2, GFP_KERNEL);
    if (!FileBuffer)
        return -ENOMEM;
    memset(FileBuffer, 0, 1024*2);
    /*read file content to filebuffer*/
    CBiosConfFileRead(pcbe, ConfFile, FileBuffer);
	
    /*get confgure file size*/
    for(i=0;i<1024*2;i++){
        if(FileBuffer[i] == '\0'){
            FileSize = i;
            break;
        }
    }

    /*get every line end point*/
    for(i=0,j=1; i<FileSize; i++){
        if(FileBuffer[i]=='\n'){
            LineEnd[j] = i;
            FileBuffer[i]='\0';
            j++;
        }        
    }

    for(k=1; k<j; k++){
        /*get length of current line*/
        LineLength = LineEnd[k]-LineEnd[k-1];
        /*avoid abnormal line*/
        if((LineLength<3)||(LineLength>1000))
            continue;
        
        /*point to line string start address */
        if(k==1)
            p =FileBuffer;
        else
            p =FileBuffer+LineEnd[k-1]+1;
        
        /*ignore explain line */
        if(*p=='#')   
            continue;

        memset(OptName,0,sizeof(UINT8)*30);
    
        for(i=0;i<LineLength;i++){
            if((*(p+i))=='='){
                if((LineLength<128)||((LineLength-i-1)>520))
                    break;
                
                /*get configure name */
                strncpy(OptName , p, i);
                OptName[i]='\0';
                if(!strncmp(name, OptName, i)){
                    strncpy( ConfEdid, p+i+1, LineLength-i-1);

                    kfree(FileBuffer);
                    return CBIOS_OK;
                }	          
            }
        }        
    }

     kfree(FileBuffer);
    /*name not found in configure file*/
    return CBIOS_ER_LACKOFINFO;
}
  
    
/******************************************************************************
*
* CBiosInitialization
*
* This function initializes the CBIOS according to the event specified. The 
* actual initialization operation is hardware dependent.
*                         Primary                   MAMM secondary
*                         S1  S3  S4  OSstart   S1  S3  S4  OSstart
* Scratch Pad         O   X   X*   X*         O    X   X**  X** 
* PCBE config info   O   O   O.   X          O    O   O.    X
* other Reg            O   X   O    O          O    X   X      X
* O : need not change   X: need change
* Resume from S3  we need to restore HW scratch pad from pcbe
* Resume from S4 / OS start we need to save HW scratch pad to pcbe 
* VBIOS involved so need to save HW scratch pad to pcbe 
* pcbe info  need to be modified except for DIport info
* need to get info from CMOS for initialization   
* for MAMM secondary OSstart, there will be no scartchpad init by VBIOS
* So need to get configuration info from CMOS setting
* Parameters:
* IN :
* InitializationEvent:     
* Return Value:
* CBIOS_STATUS
******************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosInitialization (
        PVOID pvcbe,
        IN UINT32 InitializationEvent
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;

    /* When VISTA boot up, if we press power button, OS will go to sleep state before load GFX driver
        * when resume, it go on with OSstart path, but at that time, all HW registers is cleared when sleep.
        * So, we also need to do some HW reg initial, just like resume from S3.
        * Use device bits scratch pad to judge if HW has been powered off or not. */
    BOOL bHWResumeFromS3InOSBoot = FALSE;
    
    /*---------------------------------------------
        ***** 1. get VCP
        ***** needed when POST and OSStart
        *---------------------------------------------*/
    if (InitializationEvent == POST ||
        InitializationEvent == OSstart) {
        /* if fail,driver will replace the rom image with VTROM */
        if (!cbGetVCPInfo_UMA(pcbe->RomData, &pcbe->pVCPInfo)) {
            pcbe->pVCPInfo = NULL;
            cbDbgPrint(1, "Invalid ROM image,try to read from VTROM!\n");
            return CBIOS_ER_LACKOFVCPDATA;
        }
    }

    if (InitializationEvent == OSstart) {
        BYTE dev_SPad = (cbReadRegByte(pcbe, CR_3B)) | (cbReadRegByte(pcbe, CR_4D)) | 
                        (cbReadRegByte(pcbe, CR_3C));
        if (dev_SPad == 0) {
            bHWResumeFromS3InOSBoot = TRUE; /* TRUE means we should do some HW reg initial later */
        }
    }
    
    /*---------------------------------------------
        **** 2. Chip enable
        **** needed when S3, S4, POST
        *---------------------------------------------*/
    if (InitializationEvent == S3 ||
        InitializationEvent == S4 ||
        InitializationEvent == POST ||
        bHWResumeFromS3InOSBoot) {
        cbChipEnable_UMA(pcbe);
    }

    /* Restore S3 PLL power state */
    if (InitializationEvent == S3) {
        CBiosSetS3Powerstate(pcbe, ON);
    }
    
    /* -----------------------------------------------------
        ****3. clear IGA timing info
        *------------------------------------------------------*/
    pcbe->IGA1Info.HTotal  = 0;
    pcbe->IGA1Info.VTotal  = 0;
    pcbe->IGA1Info.HDisEnd = 0;
    pcbe->IGA1Info.VDisEnd = 0;
    pcbe->IGA1Info.vPLL    = 0;
    pcbe->IGA2Info.HTotal  = 0;
    pcbe->IGA2Info.VTotal  = 0;
    pcbe->IGA2Info.HDisEnd = 0;
    pcbe->IGA2Info.VDisEnd = 0;
    pcbe->IGA2Info.vPLL    = 0;

    /*----------------------------------------------------
        **** 4. Infomation & configuration in pcbe init
        **** Since info is stored in memory
        **** for OSstart need all info init
        **** for S4 just handle info which VBIOS has modified 
        **** (device on/off state)
        *----------------------------------------------------*/
    if (InitializationEvent == OSstart ||
        InitializationEvent == POST ||
        InitializationEvent == S4) {   
        /* pcbe info init includes
               * 1. get scratchpad info to pcbe 
               * 2. IGA info
               * 3. Device power state  
               * 4. Digital Port (OSstart / POST)
               * 5. TV encoder I2C
               * 6. Device Timing policy init
               * 7. FIFO specific setting */
        status = cbCBIOSInfoInit(pcbe, InitializationEvent);
    }

    /*----------------------------------------------------
        **** 5. When S3 resume , we need to restore HW scratch Pad 
        **** according to stored pcbe info
        *----------------------------------------------------*/
    if (status == CBIOS_OK && InitializationEvent == S3) {
        CBiosSyncCBiosExtensionToHWReg(pcbe);
    }
    
    /*---------------------------------------------
    **** 6. Init TX side for which may not
    **** be init by VBIOS
    *---------------------------------------------*/
    if (status == CBIOS_OK && InitializationEvent == OSstart) {
        if (pcbe->SupportDevices & S3_LCD2) {
            status = cbInitLVDS(pcbe, S3_LCD2);
            if (status != CBIOS_OK) {
                cbDbgPrint(0, "Init LCD2 TX fail!\n");
                status = CBIOS_OK;
            }
        }
    }
    
    /*---------------------------------------------
        **** 7. Reload all init register (only minipost
        **** & secondary adapter in MAMM need)
        *---------------------------------------------*/
    if (status == CBIOS_OK &&
        (bHWResumeFromS3InOSBoot || InitializationEvent == S3 || InitializationEvent == POST)) {
        BOOL bNeedLoadDefECK = FALSE;
        
        GFXTimingTable InitTimingTbl = {
            32,             /* 8 / 16 / 32 (bpp) */
            6000,           /*  Refresh Rate in Hz * 100 (decimal) */
            0xB40C03,       /* HW PLL value with format 0MRN */
            1344,           /*  HorTotalTime */
            1024,           /*  HorAddrTime */
            1024,           /*  HorBlankStart */
            1344,           /* HorBlankTime */
            1048,           /* HorSyncStart */
            1184,           /* HorSyncEnd */
            806,            /*  VerTotalTime */
            768,            /* VerAddrTime */
            768,            /*  VerBlankStart */
            806,            /* VerBlankEnd */
            771,            /* VerSyncStart */
            777,            /* VerSyncEnd */
            0,              /* VSyncOffset (in pixel clock cycle) interlace timing only */            
            1,              /* HorPolarity - 0:positive, 1:negative */
            1,              /* VorPolarity - 0:positive, 1:negative */            
            CBIOS_NONE,     /* Aspect Ratio */
            PROGRESSIVE     /* Interlace / Progressive mode */
        };
        /* 409 use different PLL formula, so need to update the value */
        if (pcbe->ChipCaps.PLL_USE_409_FORMULA) {
            InitTimingTbl.vPLL = 0xB68C85; /* 65M for 1024x768 */
        }

        /* Post init register
               * 1.GFX side
               * 2.TX  side (VT1636, VT1632 ....)
               * 3.TV encoder init (1622, 1625A...)        
               * GFX ext register init */
        if(InitializationEvent == POST || bHWResumeFromS3InOSBoot) {
            bNeedLoadDefECK = TRUE;
        }
        CbPostRegInit_UMA(pcbe, bNeedLoadDefECK);

        /* In CBIOSSyncStatusFromHW maybe record CRT power status as power on when resume from S3,
               * because of CR36=0, but after CbPostRegInit_UMA, HW DPMS was off, so here we should re-sync HW and SW status */
        if (bHWResumeFromS3InOSBoot) {
            if ((cbReadRegByte(pcbe, CR_36) & (BIT4+BIT5)) != 0) {
                pcbe->devicepowerstate[CRTbit] = S3PM_OFF;
            } else {
                pcbe->devicepowerstate[CRTbit] = S3PM_ON;
            }
        }

        /* TX init
               * do it when LCDSupport or DVISupport */
        if (pcbe->SupportDevices & (S3_LCD | S3_DVI | S3_LCD2 | S3_DVI2)) {
            cbInitOfTX(pcbe);
        }

        /* TV encoder init
               * do it when TVSupport or HDTVSupport
               * CRT2 support now uses VT1625 encoder as DAC provider so 
               * aslo need to init TV encoder */
        if (pcbe->SupportDevices & (S3_TV | S3_HDTV | S3_TV2 | S3_CRT2)) {
            cbInitOfTVencoder(pcbe);
        }
        /* minipost to set CRT timing 1024x768 on IGA1
               * inorder to aid S3 resume back, device on IGA2 case, can not wait on IGA1 vblank issue
               * driver need wait on vblank to trigger cusor shift */
#if !LINUX_PLATFORM
        /* common registers */
        cbLoadTable_UMA(pcbe, UMA_ModeCommon);
#endif
        cbSetIGA1Timing(pcbe, &InitTimingTbl);
        cbSetIGA1SrcMode(pcbe, 1024, InitTimingTbl.HDisEnd, 32);
        
	    /* CBIOS do not support IGA1 + IGA2 simultaneous
	        * so always disable simultaneous
	        * if enable simultaneous and set a vesa mode timing, driver can not wait on IGA1 vblank  */
	    cbWriteRegBits(pcbe, CR_6B, BIT3, 0x00); 

        /* or a special CRT2 */
        if (pcbe->pVCPInfo->miscConfigure2 & BIT0) {
            cbsetcrt2powerstate(pcbe, S3PM_ON);
        }
    }
    
    {
        UINT32 ConfValue;
        PCHAR ConfName = "eclk";
        PCHAR ConfFile = "/etc/X11/via_kernel.conf";
        
        /*get eclk conf value according to conf name*/
        if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
            cbDbgPrint(1, "configure eclk to %d .\n", ConfValue);
            CBiosSetClock(pcbe, ConfValue*1000*1000, S3_ECLK);
        }  

        /*get DP1 linkspeed value according to conf name*/
        ConfName = "dp1linkspeed";
        if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
            cbDbgPrint(1, "configure DP1 link speed to %d .\n", ConfValue);
            dp1LinkspeedConf = ConfValue;
        }	        

        /*get DP2 linkspeed value according to conf name*/
        ConfName = "dp2linkspeed";
        if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &ConfValue)){
            cbDbgPrint(1, "configure DP2 link speed to %d .\n", ConfValue);
            dp2LinkspeedConf = ConfValue;
        }	
    }
    
    /* Add cbios interrupt init here, because we will always reset cbios hot plug interrupt setting
        * when ACPI(S3/S4/Restart) function happened, or we can not get correct device EDID */
    cbCbiosInterruptInit(pcbe);
    
    /* Since VBIOS change IGA2 flip stategy to frame base. It will cause driver flip
        * wrong. Force IGA2 flip stategy by line to prevent wrong state. */
    cbWriteRegBits(pcbe, CR_88, 0x20, 0x20);

    /* Toggle LCK. make sure IGA1 pll will wake up normal */
    {
        BYTE bSR1B;
        bSR1B = cbReadRegByte(pcbe, SR_1B);
        cbWriteRegBits(pcbe, SR_1B, 0xC0, 0x00);
        cbWriteRegByte(pcbe, SR_1B, bSR1B);
    }

    /* We need to disable Dynamice ECK switch to pass DTM common stress I/O test */
    if (pcbe->ChipCaps.Disable_Free_Run_ECK_In_Idle_Mode) {
        cbWriteRegBits(pcbe, SR_40, 0x30, 0x00);
    }

    if (pcbe->ChipCaps.FOR_410_GTI_BURST_LENGTH) {
        cbWriteRegBits(pcbe, SR_73, 0x33, 0x33);
    }
    
    pcbe->IsFirstTimeDetecDP2onEDP = TRUE;
    
    return status;    
}

//*****************************************************************************
//
//  CBiosGetEdid
//
//      This function fills the buffer with E-EDID(Enhanced EDID) value passed 
//  by PCBIOS_PARAM_GET_EDID structure. This function likes the VBE/DDC function 
//  (spec2.0). We get E-EDID from DDC 2B level(support uni-direction I2C), and 
//  will read E-EDID from subaddress 0xA0 (general case), from 0xA2( P & D device) 
//  or 0xA6 (DFPI device). Since now our CBIOS can only parse EDID 1.3 data structure 
//  address 0xA0 takes first priority in reading.
//
//  Parameters:
//      IN :
//      pCBParamGetEdid : EDID buffer structure     
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetEdid (
        PVOID pvcbe, 
        OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid)
{

    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_ER_DDCRead;

    if (!pCBParamGetEdid)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
	
    if (!pCBParamGetEdid->EdidBuffer)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }	

    if((pcbe->pVCPInfo->version >= VCP1_6) && (pcbe->pVCPInfo->miscConfigure3 & (CRT_DVI_SHARE_CONNECTOR + CRT_DVI2_SHARE_CONNECTOR)))
    {
        EDID_MONITOR_TYPE type;
        DWORD DVIDev = (pcbe->pVCPInfo->miscConfigure3 & CRT_DVI_SHARE_CONNECTOR) ? S3_DVI : S3_DVI2;

        if(cbIsDigitalOrAnalogMonitor(pcbe, pCBParamGetEdid->DisplayDeviceDWord, &type))
        {
            if(((pCBParamGetEdid->DisplayDeviceDWord == DVIDev) && type == EDID_ANALOG) ||
               ((pCBParamGetEdid->DisplayDeviceDWord == S3_CRT) && type == EDID_DIGITAL))
            {
                cbClearEDIDBuf(pcbe, pCBParamGetEdid->DisplayDeviceDWord);
                memset(pCBParamGetEdid->EdidBuffer, 0, pCBParamGetEdid->EdidBufferLen); // clear structure
                pCBParamGetEdid->EdidBufferLen = 0;

                return status;
            }
        }
        else
        {
            if((pCBParamGetEdid->DisplayDeviceDWord == S3_CRT) || (pCBParamGetEdid->DisplayDeviceDWord == DVIDev))
            {
                pCBParamGetEdid->DisplayDeviceDWord = (pCBParamGetEdid->DisplayDeviceDWord & S3_CRT) ? DVIDev : S3_CRT;
                if(cbIsDigitalOrAnalogMonitor(pcbe, pCBParamGetEdid->DisplayDeviceDWord, &type))
                {
                    if(((pCBParamGetEdid->DisplayDeviceDWord == DVIDev) && type == EDID_ANALOG) ||
                       ((pCBParamGetEdid->DisplayDeviceDWord == S3_CRT) && type == EDID_DIGITAL))
                    {
                        pCBParamGetEdid->type = type;
                        if (TRUE == cbGetEDID_UMA(pcbe, pCBParamGetEdid))
                        {
                            PCBIOS_DEV_EDID pEDID = NULL;
                            PDigitalPortInfo PDIPort = NULL;
                            pEDID = &( pcbe->devEDID[cbGetLowestBitPos((pCBParamGetEdid->DisplayDeviceDWord & S3_CRT) ? DVIDev : S3_CRT)] );

                            if (cbGetDIPortInfo(pcbe, &PDIPort, (pCBParamGetEdid->DisplayDeviceDWord & S3_CRT) ? DVIDev : S3_CRT))
                            {
                                cbUpdateAllDevRealEDIDOnDIPort(pcbe, PDIPort, pCBParamGetEdid->EdidBuffer, pCBParamGetEdid->EdidBufferLen);
                                pEDID->realEDIDbuf.EdidBufferLen = pCBParamGetEdid->EdidBufferLen;
                                memset(pEDID->realEDIDbuf.EdidBuffer, 0, MAX_EDID_SIZE); // clear structure
                                memcpy(pEDID->realEDIDbuf.EdidBuffer, pCBParamGetEdid->EdidBuffer, pCBParamGetEdid->EdidBufferLen);

                                status = CBIOS_OK;
                            }
                        }
                        pCBParamGetEdid->DisplayDeviceDWord = (pCBParamGetEdid->DisplayDeviceDWord & S3_CRT) ? DVIDev : S3_CRT;

                        return status;
                    }
                }
                pCBParamGetEdid->DisplayDeviceDWord = (pCBParamGetEdid->DisplayDeviceDWord & S3_CRT) ? DVIDev : S3_CRT;
            }
        }
    }

    pCBParamGetEdid->type = EDID_DONT_CARE;
    if (cbGetEDID_UMA(pcbe, pCBParamGetEdid))
    {
        status = CBIOS_OK;
    }
    else
    {
        status = CBIOS_ER_DDCRead;
    }

    return status;
}

//*****************************************************************************
//
//  CBiosSetInfoFrameData
//
//      This function set correct HDMI InfoFrame data according to the CEA mode
//  we select.
//
//  Parameters:
//      IN:
//        InfoFrameData: data need to be updated of InfoFrame
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetInfoFrameData(
        PVOID pvcbe,
        IN PCBIOS_PARAM_INFOFRAME pInfoFrameData)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TxType = 0, Rx17, Rx46;
    PDigitalPortInfo PDIPort = NULL;
    CBIOS_STATUS status = CBIOS_OK;

    i2c.Flags = 0;

    pInfoFrameData->CEAModeNumber = cbGetHDMIVICByTargetTiming(pcbe, pInfoFrameData->H_Res, pInfoFrameData->V_Res, pInfoFrameData->RRateInfo);
            
    // get associated TxType
    if (cbGetDITXtype(pcbe, &TxType, pInfoFrameData->DisplayDeviceDWord) == FALSE)
    {
        return CBIOS_ER_DDCRead;
    }

    switch(TxType)
    {
    case AD9389B:
        // 1. ---------- Get device DDCPort -----------------
        // get i2c info first
        if (!cbGetDIPortInfo(pcbe, &PDIPort, pInfoFrameData->DisplayDeviceDWord))
        {
            return CBIOS_ER_DDCRead;
        }

        // 2. ---------- Set Aspect Ratio -------------------
        i2c.I2cPort = PDIPort->PortInfo.I2CPort;
        i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
        i2c.RegIndex= 0x46;
        I2C_Read_Byte_INV(pcbe, &i2c);
        Rx46 = i2c.IndexData;
        Rx46 &= 0xF3;
                    
        i2c.RegIndex = 0x17;
        I2C_Read_Byte_INV(pcbe, &i2c);
        Rx17 = i2c.IndexData;
        Rx17 &= 0xFD;
        switch(CEA861_FormatTimingTbl[pInfoFrameData->CEAModeNumber-1].AspectRatio)
        {
            case CBIOS_RATIO_4_3:
                Rx17 |= 0x00;
                Rx46 |= 0x04;
                break;
            case CBIOS_RATIO_16_9:
                Rx17 |= 0x02;
                Rx46 |= 0x08;
                break;
            default:
                break;
        }
        i2c.RegIndex = 0x17;
        i2c.IndexData = Rx17;
        I2C_Write_Byte_INV(pcbe, &i2c);
        i2c.RegIndex = 0x46;
        i2c.IndexData = Rx46;
        I2C_Write_Byte_INV(pcbe, &i2c);
        break;
        
    case INTERNAL_DP:
        cbHDMISetAVIInfoFrame(pcbe, pInfoFrameData->DisplayDeviceDWord, pInfoFrameData->CEAModeNumber);
        cbHDMISetAudioInfoFrame(pcbe, pInfoFrameData->DisplayDeviceDWord);
        break;
                   
    default:
        break;
    }
    
    return status;
}

CBIOS_STATUS CBIOSAPI CBiosSetHDAudioParameter(
        PVOID pvcbe,
        IN PCBIOS_PARAM_INFOFRAME pInfoFrameData)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD   mmC4D4 = 0, mmC4D8 = 0, mmC424 = 0,  dwSampleRate = 0, dwPixelClock = 0, vPLL = 0;
    DWORD   dispDev = pInfoFrameData->DisplayDeviceDWord;
    BOOL    enableHDMI = FALSE;
    DWORD   CTSnow = 0;

    if(!pcbe->ChipCaps.InternalDP_Support)
        return CBIOS_OK;
    
    if(dispDev == 0)
    {
        switch((ReadMMIOUlong(CB_MMIO_OFFSET(0xC424)) >> 13) & 0x3)
        {

            case 0:
                dispDev = S3_HDMI;
                break;
            case 1:
                dispDev = S3_DP;
                break;
            case 2:
                dispDev = S3_DP2;
                break;
            default:
                break;
        }

    }

    enableHDMI = (ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) & BIT1) ? TRUE : FALSE;
    if(!enableHDMI) 
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC280), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) | BIT1));

    // step 1. read out C4D8 
    mmC4D4 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D4)) & 0x00FFFFFF;
    mmC4D4 |=  0x01000000;      // stream format
    WriteMMIOUlong(CB_MMIO_OFFSET(0xC4D4), mmC4D4);

    mmC4D8 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC4D8)); // [15:0]

    //step 2. decode C4D8 by definition of C45C
    // C45C [14] Converter_Format_Base
    // BASE. Converter Format Sample Base Rate. (PCM Format structure bit 14)
    //              0: 48kHz 
    //              1: 44.1kHz
    // C45C [13:11] Converter_Format_Mult
    // MULT. Converter Format Sample Base Rate Multiple. (PCM Format structure bits 13:11)
    //              000: 48kHz/ 44.1 kHz or lesss 
    //              001: x2 (96kHz, 88.2kHz, 32kHz) 
    //              010: x3 (144kHz) 
    //              011: x4 (192kHz, 176.4kHz) 
    //              100-111: Reserved
    // C45C [10:8] Converter_Format_Div
    // DIV. Converter Format Sample Base Rate Divisor. (PCM Format structure bits 10:8)
    //              000: Divide by 1 (48kHz, 44.1 kHz) 
    //              001: Divide by 2 (24kHz, 22.05kHz) 
    //              010: Divide by 3 (16kHz, 32kHz) 
    //              011: Divide by 4 (11.025kHz) 
    //              100: Divide by 5 (9.6kHz) 
    //              101: Divide by 6 (8kHz) 
    //              110: Divide by 7 
    //              111: Divide by 8 (6kHz)
    if( mmC4D8 & 0x4000 )
        dwSampleRate = 44100;
    else 
        dwSampleRate = 48000;

    dwSampleRate *= (((mmC4D8 & 0x3800) >> 11) + 1);

    dwSampleRate /= (((mmC4D8 & 0x700) >> 8) + 1);
    
    mmC424 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC424)) & 0xFFFF9FFF; // C424[14:13] codec type. related with mm c618, mm c698
    
    if(dispDev == S3_HDMI)
    {
        mmC424 |= (0 << 13);
        vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, pcbe->Internal_HDMI_pclk);
        dwPixelClock = cbCalcClkFromDWORDMRN(pcbe, vPLL);
    }
    else if(dispDev == S3_DP)
    {
        mmC424 |= (1 << 13);
        dwPixelClock = pcbe->DPSinkCaps[DP1].LinkSpeed * 100;
    }
    else if(dispDev == S3_DP2)
    {
        mmC424 |= (2 << 13);
        dwPixelClock = pcbe->DPSinkCaps[DP2].LinkSpeed * 100;
    }

    WriteMMIOUlong(CB_MMIO_OFFSET(0xC424), mmC424);

    // step 3. calculate C400 and C410
    cbSetHDAudioSampleRate(pcbe, dwSampleRate, dwPixelClock);

    // step 4. fill CTS & N according to Table7-1, 7-2, 7-3 of HDMI spec 1.3
    pInfoFrameData->CTSInterval = cbSetHDAudioCTSandN(pcbe, dwSampleRate, dwPixelClock);
    CTSnow = (ReadMMIOUlong(CB_MMIO_OFFSET(0xC29C)) & 0xFF) << 12;
    CTSnow |= (ReadMMIOUlong(CB_MMIO_OFFSET(0xC298)) & 0xFFF00000) >> 20;
    pInfoFrameData->CTS = CTSnow;
    
    if(dispDev == S3_DP)	
        cbSetHDAudioMaudNaud(pcbe, dwSampleRate, dwPixelClock, DP1);
    if(dispDev == S3_DP2)
        cbSetHDAudioMaudNaud(pcbe, dwSampleRate, dwPixelClock, DP2);

    if(!enableHDMI)
        WriteMMIOUlong(CB_MMIO_OFFSET(0xC280), (ReadMMIOUlong(CB_MMIO_OFFSET(0xC280)) & ~BIT1));
            
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosParserEdid
//
//      This function parser the buffer with E-EDID(Enhanced EDID).
//  Now our CBIOS can only parse EDID 1.3 data structure
//
//  Parameters:
//      IN:
//        EDIDBuf:          EDID data BYTE buffer
//        EDIDBufLen:       EDID data BYTE buffer length
//      OUT:
//        pEDIDTimingInfo:  EDID parser result
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosParserEdid (
    PVOID pvcbe, 
    IN void*  EDIDBuf,
    IN UINT32 EDIDBufLen,
    OUT CBIOS_EDID_STRUCTURE_DATA* pEDIDTimingInfo)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if ( cbEDIDParser_UMA(pcbe, EDIDBuf, EDIDBufLen, (PCBIOS_EDID_INFO)pEDIDTimingInfo) )
    {
        return CBIOS_OK;
    }
    else
    {
        return CBIOS_ER_DDCRead;
    }
}

//*****************************************************************************
//
//  CBiosSetEdid
//
//      This function fills pcbe->EDIDMode for specific device with given fake
//  EDID data.
//
//  Parameters:
//      IN :
//      pCBParamGetEdid : EDID buffer structure     
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetEdid (
    PVOID pvcbe, 
    IN PCBIOS_PARAM_GET_EDID pCBParamGetEdid)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    ULONG bufferlen;
    PCBIOS_DEV_EDID pEDID = NULL;
    CBIOS_STATUS status = CBIOS_OK;
    
    if (NULL == pCBParamGetEdid)
    {
        cbDbgPrint(0, "CBiosSetEdid: pCBParamGetEdid NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    bufferlen = pCBParamGetEdid->EdidBufferLen;
    if (bufferlen > MAX_EDID_SIZE)
    {
        cbDbgPrint(0, "CBiosSetEdid: bufferlen too big!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // 1. ---------- Get device EDID store data addr -----------------
    pEDID = &( pcbe->devEDID[cbGetLowestBitPos(pCBParamGetEdid->DisplayDeviceDWord)] );

    // 2. ---------- Check EDID version and parse EDID1_X -----------------
    if ( NULL == pCBParamGetEdid->EdidBuffer || 0 == bufferlen )
    {
        // if pass null EDID to set, means clear fake EDID
        memset( &(pEDID->fakeEDIDbuf), 0, sizeof(CBIOS_EDID_BUFFER) );
        if (pEDID->bFakeEDID)
        {
            // if current use fake EDID, clear it, else do nothing (don't clear real EDID info)
            memset( &(pEDID->EDIDInfo), 0, sizeof(CBIOS_EDID_INFO) );
            pEDID->bFakeEDID = FALSE;
        }
    }
    else if ( pCBParamGetEdid->EdidBuffer[0] == 0x0 ) // EDID1_X
    {
        if ( !cbIsDevEDIDValid(pcbe, pCBParamGetEdid->DisplayDeviceDWord, pCBParamGetEdid->EdidBuffer, pCBParamGetEdid->EdidBufferLen) )
        {
            cbDbgPrint(1, "CBiosSetEdid: device EDID not valid! \n");
            status = CBIOS_ER_INVALID_PARAMETER;
        }
        // now we can parse the EDID 1_X base block & CEA extansion block
        else if ( cbEDIDParser_UMA(pcbe, pCBParamGetEdid->EdidBuffer, bufferlen, &(pEDID->EDIDInfo)) )
        {
            // copy fake edid to dev edid buffer
            memset( pEDID->fakeEDIDbuf.EdidBuffer, 0, MAX_EDID_SIZE );
            memcpy( pEDID->fakeEDIDbuf.EdidBuffer, pCBParamGetEdid->EdidBuffer, bufferlen );
            pEDID->fakeEDIDbuf.EdidBufferLen = bufferlen;
            pEDID->bFakeEDID = TRUE;
        }
        else
        {
            cbDbgPrint(1, "Wrong EDID param format! \n");
            status = CBIOS_ER_INVALID_PARAMETER;
        }
    }
    else if ( (pCBParamGetEdid->EdidBuffer[0]) == 0x20 ) // EDID2.0
    {
        cbDbgPrint(1, "Wrong EDID version ! \n");
        status = CBIOS_ER_INVALID_PARAMETER;    
    }
    else // Wrong EDID version number
    {
        cbDbgPrint(1, "Wrong EDID version ! \n");
        status = CBIOS_ER_INVALID_PARAMETER;    
    }    

    return status;
    
}

//*****************************************************************************
//
//  CBiosGetFakeEdid
//
//      This function fills fake edid for specific device with given EDID buffer & length
//
//  Parameters:
//      IN :
//      pCBParamGetEdid : EDID buffer structure     
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetFakeEdid (
    PVOID pvcbe, 
    IN OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD bufferlen;
    PCBIOS_DEV_EDID pEDID = NULL;

    if(NULL == pCBParamGetEdid)
    {
        cbDbgPrint(0, "CBiosGetFakeEdid: pCBParamGetEdid NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (NULL == pCBParamGetEdid->EdidBuffer)
    {
        cbDbgPrint(0, "CBiosGetFakeEdid: pCBParamGetEdid NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    bufferlen = pCBParamGetEdid->EdidBufferLen;
    if (bufferlen > MAX_EDID_SIZE || bufferlen < EDID1_X_BLOCKSIZE)
    {
        cbDbgPrint(0, "CBiosGetFakeEdid: bufferlen wrong!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // Get device EDID store data addr
    pEDID = &( pcbe->devEDID[cbGetLowestBitPos(pCBParamGetEdid->DisplayDeviceDWord)] );

    if (pEDID->bFakeEDID)
    {
        // fake EDID available on device
        if (pEDID->fakeEDIDbuf.EdidBufferLen < bufferlen)
        {
            bufferlen = pEDID->fakeEDIDbuf.EdidBufferLen;
        }
        // fill edid buf & change length
        memcpy(pCBParamGetEdid->EdidBuffer, pEDID->fakeEDIDbuf.EdidBuffer, bufferlen);
        pCBParamGetEdid->EdidBufferLen = bufferlen;
    }
    else
    {
        // no fake EDID on device, don't change edid buf & set length  = 0
        pCBParamGetEdid->EdidBufferLen = 0;
    }

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosSyncCBiosExtensionToHWReg
//
//      This function will extract needed scratch pad information from cbios data
//  structure, and save it to the hardware registers.
//
//  Attention !! 
//      In order to sync device power state correctly , we need to keep only one
//  device on before we call this function. Since CBIOS�support duoview case while
//  VBIOS only support Simultaneous case. There may be missmatch between CBIOS & VBIOS
//
//  Notes:We only take care of the Scratch Pad registers by now
//
//  Parameters:
//      IN :
//      pcbe : PCBIOS_EXTENSION
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSyncCBiosExtensionToHWReg(IN PVOID pvcbe)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    /****************** update active device bit ******************/
    // update to Spad 1, Spad 7[7] HDMI, Spad11[4] LCD2
    cbUpdateHWDispDeviceBits(pcbe);
    
    /****************** Scratch pad 1 ******************/
    // update scrach pad 1 in cbUpdateHWDispDeviceBits 

    /****************** Scratch pad 2 ******************/
    //Here we must set DPMS state BIT to 1(ON), in order to make vbios work properly
    //Eg. after S3,this bit was cleared to 0, and then unstall driver, vbios will work error
    cbWriteRegBits(pcbe, CR_3D, BIT2+BIT4+BIT5+BIT6+BIT7, (BIT2 | STRUCT_BYTE(pcbe->sPad_2, 0)) );

    /****************** Scratch pad 3 ******************/
    cbWriteRegByte(pcbe, CR_3E, STRUCT_BYTE(pcbe->sPad_3, 0));

    /****************** Scratch pad 4 ******************/
    cbWriteRegByte(pcbe, CR_3F, STRUCT_BYTE(pcbe->sPad_4, 0));

    /****************** Scratch pad 5 ******************/
    cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_5, 0));

    /****************** Scratch pad 6 ******************/
    cbWriteRegByte(pcbe, CR_4C, STRUCT_BYTE(pcbe->sPad_6, 0));

    /****************** Scratch pad 7 ******************/
    // update HDMI bit in cbUpdateHWDispDeviceBits 
    // update TV output type ScratchPad7[0:6]
    cbWriteRegBits(pcbe, CR_4D, (BYTE)~BIT7, STRUCT_BYTE(pcbe->sPad_7, 0));

    /****************** Scratch pad 8 ******************/
    cbWriteRegBits(pcbe, CR_4E, BIT0+BIT1+BIT2+BIT3+BIT4+BIT6, STRUCT_BYTE(pcbe->sPad_8, 0));

    /****************** Scratch pad 9 ******************/
    cbWriteRegByte(pcbe, SR_32, STRUCT_BYTE(pcbe->sPad_9, 0));

    /****************** Scratch pad C ******************/
    //By now,Cbios read this value from SR39 directly,do not use this data structure,need refine
    cbWriteRegByte(pcbe, SR_39, STRUCT_BYTE(pcbe->sPad_C, 0));

    /****************** Scratch pad D ******************/
    // if CRT used as an primary device to set timing
    if(cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_CRT) //CRT on IGA1
    {
        pcbe->sPad_D.CRT_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA1Info.RRateInfo.rRateX100/100) );
    }
    else if(cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_CRT) //CRT on IGA2
    {
        pcbe->sPad_D.CRT_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA2Info.RRateInfo.rRateX100/100) );
    }
    // if CRT2 used as an primary device to set timing
    if(cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_CRT2) //CRT2 on IGA1
    {
        pcbe->sPad_D.CRT2_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA1Info.RRateInfo.rRateX100/100) );
    }
    else if(cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_CRT2) //CRT2 on IGA2
    {
        pcbe->sPad_D.CRT2_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA2Info.RRateInfo.rRateX100/100) );
    }
    cbWriteRegByte(pcbe, SR_3A, STRUCT_BYTE(pcbe->sPad_D, 0));

    /****************** Scratch pad F ******************/
    //By now,Only take care of Bit[4:7] for DVI refresh rate
    //Bit[0:3] may be used for DVI2 or LCD,
    //So,do not take care of LCD or LCD2 or DVI2 refresh rate by now
    // if DVI used as an primary device to set timing
    if(cbGetPrimaryDevice(pcbe->IGA1Info.dispDev) == S3_DVI) //DVI on IGA1
    {
        pcbe->sPad_F.DVI_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA1Info.RRateInfo.rRateX100/100) );
    }
    else if(cbGetPrimaryDevice(pcbe->IGA2Info.dispDev) == S3_DVI) //DVI on IGA2
    {
        pcbe->sPad_F.DVI_RRIndex = (BYTE)ConvertRRValuetoRRIndex_CSR( (ULONG)(pcbe->IGA2Info.RRateInfo.rRateX100/100) );
    }
    cbWriteRegBits(pcbe, CR_4A, BIT4+BIT5+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_F, 0));

    /****************** Scratch pad 11******************/
    // update LCD2 bit in cbUpdateHWDispDeviceBits
    // update HDTV type bits
    cbWriteRegBits(pcbe, CR_3C, BIT0+BIT1+BIT2+BIT3, STRUCT_BYTE(pcbe->sPad_11, 0));

    // transfer to access shadow scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);
    /*************** Shadow Scratch pad 1 **************/
    cbWriteRegByte(pcbe, CR_3B, STRUCT_BYTE(pcbe->shPad_1, 0));

    /*************** Shadow Scratch pad 2 **************/
    if(pcbe->DPSinkCaps[DP1].DualMode)
    {
        if(pcbe->DPSinkCaps[DP1].IsHDMIDevice)
        {
            pcbe->shPad_2.DP1_CONNECTION = 2; // set HDMI connected
        }
        else
        {
            pcbe->shPad_2.DP1_CONNECTION = 3; // set DVI connected
        }
    }
    else
    {
        pcbe->shPad_2.DP1_CONNECTION = 1; // forcely set DP connected
    }
    cbWriteRegByte(pcbe, CR_3D, STRUCT_BYTE(pcbe->shPad_2, 0));

    /*************** Shadow Scratch pad 3 **************/
    // update HDMI2/DP/DP2 bit in cbUpdateHWDispDeviceBits
    // update other bits
    cbWriteRegBits(pcbe, CR_3E, BIT4+BIT5+BIT6+BIT7, STRUCT_BYTE(pcbe->shPad_3, 0));

    // transfer to access normal scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, 0);

    // Now vbios do not control IGA PLL and Gate, it will assume all IGAs are enabled
    // So, we will open both IGA when switch to vbios, to prevent system hang
    // Disable IGA1 / IGA2 power save
    // turn on VCK
    cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5+BIT6+BIT7, BIT4+BIT5+BIT6+BIT7);
    // IGA1 & IGA2 PLL Power Control
    if(pcbe->pVCPInfo->miscConfigure2 & CBIOS_PLL_Control_Enable)
    {
        cbWriteRegBits(pcbe, SR_2D, BIT2+BIT3+BIT4+BIT5, BIT2+BIT3+BIT4+BIT5);
    }

    return CBIOS_OK;    
}

//*****************************************************************************
//
//  CBiosSyncCBiosExtensionFromHWReg
//
//  This function will get needed information from hardware scratch pad,
//  and save it to cbios data structure.
//  
//
//  Notes: 1. We only take care of the Scratch Pad registers by now
//         2. We do not update Refresh rate information in Cbios data structure in STD mode case
//
//  Parameters:
//      IN :
//      pcbe : PCBIOS_EXTENSION
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSyncCBiosExtensionFromHWReg(IN PVOID pvcbe)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    BYTE RegValue;
    DWORD CurOnDevice = 0;
    DWORD bitmask = 0x01;
    DWORD IGASource;
    int i;

    // Check if system has really come back from vbios
    // Condition includes: 1. specific platform full screen & S4 & OS restart: Check Misc reg & CR6B[3]
    //                     2. Install driver case: Check cbios iga info
    //If NOT satisfy with any of below condition, that means system has coming form vbios, and need sync operation
    if ( (ReadUchar(CB_MISC_OUTPUT_READ_REG) & BIT3) &&         // If : Not in normal std mode                              AND
         !(cbReadRegByte(pcbe, CR_6B) & BIT3)          &&         //      HW is now NOT in IGA1+IGA2(For STD mode IGA1+IGA2 ) AND
         (cbReadRegByte(pcbe, CR_49) == CBIOS_SET_MODE_NUMBER)    //      CBIOS has set mode once, then just return 
       ) 
    {
        return CBIOS_OK;
    }

    //-----------------------------------------------------------------
    //--- 1.sync scratch pad info
    //-----------------------------------------------------------------
    /****************** Scratch pad 1 ******************/
    RegValue = cbReadRegByte(pcbe, CR_3B);
    STRUCT_BYTE(pcbe->sPad_1, 0) = RegValue;

    /****************** Scratch pad 2 ******************/
    //We do not sync DPMS state BIT here, because cbios will not use it
    //and will always set to 1(ON), when sync cbios to HW reg
    RegValue = cbReadRegByte(pcbe, CR_3D);
    STRUCT_BYTE(pcbe->sPad_2, 0) &= ~(BIT4+BIT5+BIT6+BIT7);
    STRUCT_BYTE(pcbe->sPad_2, 0) |= RegValue & (BIT4+BIT5+BIT6+BIT7);

    /****************** Scratch pad 3 ******************/
    RegValue = cbReadRegByte(pcbe, CR_3E);
    STRUCT_BYTE(pcbe->sPad_3, 0) = RegValue;

    /****************** Scratch pad 4 ******************/
    RegValue = cbReadRegByte(pcbe, CR_3F);
    STRUCT_BYTE(pcbe->sPad_4, 0) = RegValue;

    /****************** Scratch pad 5 ******************/
    RegValue = cbReadRegByte(pcbe, CR_4B);
    STRUCT_BYTE(pcbe->sPad_5, 0) &= ~(BIT0+BIT1+BIT2+BIT6+BIT7);
    STRUCT_BYTE(pcbe->sPad_5, 0) |= RegValue & (BIT0+BIT1+BIT2+BIT6+BIT7);

    /****************** Scratch pad 6 ******************/
    RegValue = cbReadRegByte(pcbe, CR_4C);
    STRUCT_BYTE(pcbe->sPad_6, 0) = RegValue;

    /****************** Scratch pad 7 ******************/
    RegValue = cbReadRegByte(pcbe, CR_4D);
    STRUCT_BYTE(pcbe->sPad_7, 0) = RegValue;

    /****************** Scratch pad 8 ******************/
    RegValue = cbReadRegByte(pcbe, CR_4E);
    STRUCT_BYTE(pcbe->sPad_8, 0) &= ~(BIT0+BIT1+BIT2+BIT3+BIT4+BIT6);
    STRUCT_BYTE(pcbe->sPad_8, 0) |= RegValue & (BIT0+BIT1+BIT2+BIT3+BIT4+BIT6);

    /****************** Scratch pad 9 ******************/
    RegValue = cbReadRegByte(pcbe, SR_32);
    STRUCT_BYTE(pcbe->sPad_9, 0) = RegValue;

    /****************** Scratch pad C ******************/
    //By now,Cbios read this value from SR39 directly,do not use this data structure
    RegValue = cbReadRegByte(pcbe, SR_39);
    STRUCT_BYTE(pcbe->sPad_C, 0) = RegValue;

    /****************** Scratch pad D ******************/
    RegValue = cbReadRegByte(pcbe, SR_3A);
    STRUCT_BYTE(pcbe->sPad_D, 0) = RegValue;

    /****************** Scratch pad F ******************/
    RegValue = cbReadRegByte(pcbe, CR_4A);
    STRUCT_BYTE(pcbe->sPad_F, 0) &= ~(BIT4+BIT5+BIT6+BIT7);
    STRUCT_BYTE(pcbe->sPad_F, 0) |= RegValue & (BIT4+BIT5+BIT6+BIT7);

    /****************** Scratch pad 11******************/
    RegValue = cbReadRegByte(pcbe, CR_3C);
    STRUCT_BYTE(pcbe->sPad_11, 0) &= ~(BIT0+BIT1+BIT2+BIT3+BIT4);
    STRUCT_BYTE(pcbe->sPad_11, 0) |= RegValue & (BIT0+BIT1+BIT2+BIT3+BIT4);

    // transfer to access shadow scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);
    /*************** Shadow Scratch pad 1 **************/	
    RegValue = cbReadRegByte(pcbe, CR_3B);
    STRUCT_BYTE(pcbe->shPad_1, 0) = RegValue;
    RegValue = cbReadRegByte(pcbe, CR_3D);
    STRUCT_BYTE(pcbe->shPad_2, 0) = RegValue;
    RegValue = cbReadRegByte(pcbe, CR_3E);
    STRUCT_BYTE(pcbe->shPad_3, 0) = RegValue;

    // transfer to access normal scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, 0);
	
    //----------------------------------------------------------------------
    //--- 2.  sync current device power state & IGA source info
    //----------------------------------------------------------------------
    // clear IGA Info
    pcbe->IGA1Info.dispDev = pcbe->IGA2Info.dispDev = 0;
    
    // we need to get VBIOS current enabled device combination 
    // which stored in sratchpad 1, 7, 11
    CurOnDevice = pcbe->sPad_1.Out_Dev;               //sPad_1 [6:0]
    CurOnDevice |= pcbe->sPad_11.LCD2devBit << 8;     //sPad_11[4] LCD2
    CurOnDevice |= pcbe->sPad_7.HDMIdevBit  << 9;     //sPad_7 [7] HDMI
    if(pcbe->ChipCaps.EXTEND_DEVICE_DEFINE)
    {
        // device extend to shadow sratchpad 3, 4
        CurOnDevice |= pcbe->shPad_3.HDMI2devBit << 13;     //shPad_3 [0] HDMI2
        CurOnDevice |= pcbe->shPad_3.DPdevBit    << 15;     //shPad_3 [1] DP
        CurOnDevice |= pcbe->shPad_3.DP2devBit   << 16;     //shPad_3 [2] DP2
    }
    // since CRT may used as attached device while does not exist in ScrachPad
    // here need to Update CRT power state from current HW register setting
    // CR36[5,4] DPMS power state 00 On, 01 Stand-by, 10 Suspend, 11 Off
    // !!! notice: we should add CRT to current device before check device status loop !!!
    // So we can get CRT's IGA and config IGA device right
    if ((cbReadRegByte(pcbe, CR_36) & (BIT4 + BIT5)) == 0)
    {
        CurOnDevice |= S3_CRT;
    }
    else
    {
        CurOnDevice &= ~S3_CRT;
    }

    
    // For 324, we should translate word define device to s3 define here.
    if ( (pcbe->pVCPInfo->version >= VCP1_5) && 
         (pcbe->ChipCaps.S3_device_define_for_324) )
    {
        cbTranslateWordDefineToS3Define(pcbe, &CurOnDevice);
    }

    for (i = 0; i < DeviceNumber; i++)
    {
       if (CurOnDevice & bitmask)
       {
           pcbe->devicepowerstate[i] = S3PM_ON;
           // Get current active display device attached IGA info from HW register
           // device bit 2^i
           cbGetDeviceAttachedIGAFromHW(pcbe, (1 << i), &IGASource);
           // configure to associated IGA
           if (IGASource == IGA1)
           {
               pcbe->IGA1Info.dispDev |= (1 << i);          
           }
           else
           {
               pcbe->IGA2Info.dispDev |= (1 << i);          
           }
       } 
       else
       {
           pcbe->devicepowerstate[i] = S3PM_OFF;//defualt set device power state to off
       } 
       bitmask = bitmask << 1; 
    }

    // when back from specific platform full-screen, we need to reload all AD9389B register settings.
    if(pcbe->devicepowerstate[HDMIbit] == S3PM_ON)
    {
        cbSetHDMIPowerState(pcbe, S3PM_ON);
    }

    //----------------------------------------------------------------------
    //--- 3. sync IGA Timing info
    //---    when VBIOS switch to CBIOS, need to clear IGA1, IGA2 H / V timing info
    //----------------------------------------------------------------------
    {   
        pcbe->IGA1Info.HTotal  = 0;
        pcbe->IGA1Info.VTotal  = 0;
        pcbe->IGA1Info.HDisEnd = 0;
        pcbe->IGA1Info.VDisEnd = 0;
        pcbe->IGA1Info.HRes    = 0;
        pcbe->IGA1Info.VRes    = 0;
        pcbe->IGA1Info.vPLL    = 0;
        pcbe->IGA2Info.HTotal  = 0;
        pcbe->IGA2Info.VTotal  = 0;
        pcbe->IGA2Info.HDisEnd = 0;
        pcbe->IGA2Info.HRes    = 0;
        pcbe->IGA2Info.VRes    = 0;
        pcbe->IGA2Info.VDisEnd = 0;
        pcbe->IGA2Info.vPLL    = 0;
    }

    //----------------------------------------------------------------------
    //--- 4. sync IGA Scaler info
    //----------------------------------------------------------------------
    if (cbReadRegByte(pcbe, CR_79) & BIT0)
    {   
        pcbe->IGA2Info.curUpScalerState |= UPSCALER_PREFERRED;  // set expansion bit
    }
    else
    {
        pcbe->IGA2Info.curUpScalerState &= ~UPSCALER_PREFERRED; // clear expansion bit
    }

    //----------------------------------------------------------------------------------------
    //--- Set Refresh Rate value(x100),Here we only care about STD Mode case
    //---
    //--- Vbios save Refresh rate according to device,Cbios save Refresh rate according to IGA
    //--- But in STD mode case:the device's IGA info may have been changed from Cbios case
    //--- So,do not need to save refresh rate back to cbios extension(Eg.LCD+CRT case).
    //----------------------------------------------------------------------------------------
    
    return CBIOS_OK;
}


//--------------------------------------------------------------------
//CBiosVContractionCTL
//  This function handles TV V contraction level control, now for VT1625 
// it includes three levels of contraction:
//      0. Normal Scan
//      1. Fit Scan
//      2. Over Scan
//    In fact these three tables not only modify V contraction level, but 
//  also modifies H contraction level. So this may need further modification
//  IN :
//      CtlFunc : function to be chosen
//              S3_TV_FN_SET_UMA : set V contraction level
//              S3_TV_FN_GET_UMA : get V contraction level   
//      S3_TV_FN_SET_DEFAULT_UMA : set defualt V contraction level
//  S3_TV_FN_QUERY_MAX_RANGE_UMA : get max range of V contraction level
//  OUT:
//      CBIOS_STATUS
//  INOUT :
//      pVContractionlevel : 
//     1. For set V contraction level pass contraction level from this paramenter
//     2. For get current / get Max / set default H contraction level this parameter 
//        will output defualt / Max contraction level 
//--------------------------------------------------------------------
// set Max contraction contraction range as 3
#define VT1625_V_Contraction_MAX_RANGE        0x03
#define IN_TV_V_Contraction_MAX_RANGE         0x01

CBIOS_STATUS CBIOSAPI CBiosVContractionCTL(
    PVOID pvcbe,
    IN ULONG CtlFunc,
    INOUT PULONG pVContractionlevel)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 

    if (!pVContractionlevel)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // if TV haven't config to IGAs 
    // Can not set / get V contraction level
    if ((CtlFunc != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & S3_TV) == 0))
    {
        return CBIOS_ER_LACKOFINFO;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        // if no TV exists
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(CtlFunc)
    {
    case S3_TV_FN_SET_UMA:     
        // Set V contraction level
        if (encodertype != IN_TV)
        {
            status = cbSetTVVContraction(pcbe, *pVContractionlevel);
        }
        else
        {
            status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
        break;
    
    case S3_TV_FN_GET_UMA:     
        // Get V contraction level
        *pVContractionlevel = pcbe->tvparameter.CurVContraction;
        break;

    case S3_TV_FN_SET_DEFAULT_UMA:     
        // Reset V contraction level to default
        status = cbSetTVVContraction(pcbe, pcbe->tvparameter.DefaultVContraction);
        *pVContractionlevel = pcbe->tvparameter.CurVContraction;
        break;

    case S3_TV_FN_QUERY_MAX_RANGE_UMA:     
        // Query the max. range of V contraction level
        switch (encodertype)
        {
        case VT1622:
        case VT1622A:
        case VT1623_3A:
        case VT1625_6:
        case VT1625A_6A:
            // VT1622 / 1625 all support 3 levels of V contraction
            *pVContractionlevel = VT1625_V_Contraction_MAX_RANGE;
            break;
        case IN_TV:
            // InTV support one level for vertical
            *pVContractionlevel = IN_TV_V_Contraction_MAX_RANGE;
            break;
        default:
            cbDbgPrint(1, "Error encoder type!\n");  
            status = CBIOS_ER_LACKOFINFO;
        }
        break;
   
    default:
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}


//--------------------------------------------------------------------
//CBiosHContractionCTL
//  This function handles TV H contraction level control,
//  IN :
//      CtlFunc : function to be chosen
//              S3_TV_FN_SET_UMA : set H contraction level
//              S3_TV_FN_GET_UMA : get H contraction level   
//      S3_TV_FN_SET_DEFAULT_UMA : set defualt H contraction level
//  S3_TV_FN_QUERY_MAX_RANGE_UMA : get max range of H contraction level
//  OUT:
//      CBIOS_STATUS
//  INOUT :
//      pVContractionlevel : 
//     1. For set H contraction level pass contraction level from this paramenter
//     2. For get current / get Max / set default H contraction level this parameter 
//        will output defualt / Max contraction level 
//--------------------------------------------------------------------
// set Max contraction H range as 5
#define VT1625_H_Contraction_MAXRANGE        0x05

CBIOS_STATUS CBIOSAPI CBiosHContractionCTL(
    PVOID pvcbe,
    IN ULONG CtlFunc,
    INOUT PULONG pHContractionlevel)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG encodertype;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 

    if (!pHContractionlevel)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    // if TV / HDTV haven't config to IGAs 
    // Can not set / get H contraction level
    if ((CtlFunc != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & S3_TV) == 0))
    {
        return CBIOS_ER_LACKOFINFO;
    }

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        // if no TV exists
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(CtlFunc)
    {
    case S3_TV_FN_SET_UMA:     
        // Set H contraction level
        if (encodertype != IN_TV)
        {
            status = cbSetTVHContraction(pcbe, (BYTE)*pHContractionlevel);
        }
        else
        {
            status = CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
        break;
    
    case S3_TV_FN_GET_UMA:     
        // Get H contraction level
        *pHContractionlevel = pcbe->tvparameter.CurHContraction;
        break;

    case S3_TV_FN_SET_DEFAULT_UMA:     
        // Reset H contraction level to default
        status = cbSetTVHContraction(pcbe, pcbe->tvparameter.DefaultHContraction);
        *pHContractionlevel = pcbe->tvparameter.CurHContraction;
        break;

    case S3_TV_FN_QUERY_MAX_RANGE_UMA:     
        // Query the max. range of H contraction level
        switch (encodertype)
        {
        case VT1622:
        case VT1622A:
        case VT1623_3A:
        case VT1625_6:
        case VT1625A_6A:
            // VT1622 / 1625 all support 5 level of H contraction
            *pHContractionlevel = VT1625_H_Contraction_MAXRANGE;
            break;
        case IN_TV:
            // Internal TV only does not support H contraction level by now
            *pHContractionlevel = 0x0;
        default:
            cbDbgPrint(1, "Error encoder type!\n");   
            status = CBIOS_ER_LACKOFINFO;
        }
        break;

   
    default:
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    return status;
}


//*****************************************************************************
//
//  CBiosGetSupDeviceTimingType
//
//      The function returns CBIOS supported Timing policy, CBIOS may offer more
//  than one type of device timing so that ender use can switch between diversified 
//  device timing types.
//
//  Parameters:
//    IN 
//      Device : device needed to query ( only 1 device each time)
//    OUT:
//      pSupTimingPolicy : device supported timing type
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetSupDeviceTimingType(
    PVOID pvcbe,
    IN DWORD Device,
    OUT PDWORD pSupTimingType)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pSupTimingType)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    if(MORE_THAN_1BIT(Device))
    {
        cbDbgPrint(1, "More than one device to get timing policy");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // device supported timing type
    switch(Device)
    {
    case S3_CRT:
        // CRT supports 
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. normal VESAVPIT 
        *pSupTimingType = EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_TIMING_TYPE;
        break;

    case S3_CRT2:
    {
        ULONG encodertype = 0;
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        }
        if (encodertype == CH7301)
        {
            *pSupTimingType = VESAVPIT_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE;
        }
        else //1625 only support VESAVPIT timing type
        {
            *pSupTimingType = VESAVPIT_TIMING_TYPE;
        }
    }
        break;

    case S3_LCD:
    case S3_LCD2:   
        // LCD supports 
        // 1. EDID timing 
        *pSupTimingType = EDID_DISABLEDEVSCALING_TIMING_TYPE;
        break;

    case S3_TV:
        *pSupTimingType = TV_TIMING_TYPE;
        break;

    case S3_HDTV:   
        *pSupTimingType = HDTV_TIMING_TYPE;
        break;

    case S3_DVI:   
    case S3_DVI2:
    case S3_DP:
    case S3_DP2:
        // DVI supports 
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. VESAVPIT filter by Panel size timing
        *pSupTimingType = VESAFILTERBYEDID_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE;
        break;

    case S3_HDMI:
    case S3_HDMI2:
        // HDMI will change to CEAEDID timing
        *pSupTimingType = EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE;
        break;
        
    default:
        cbDbgPrint(1, "The device has not been supported");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    return CBIOS_OK;
}


//*****************************************************************************
//
//  CBiosGetCurDeviceTimingType
//
//      The function returns Current device Timing policy according to device
//  bit
//
//  Parameters:
//    IN 
//      Device : device needed to query (only 1 device each time)
//    OUT:
//      pCurTimingType : current device timing type
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetCurDeviceTimingType(
    PVOID pvcbe,
    IN DWORD Device,
    OUT PDWORD pCurTimingType)
{
    
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pCurTimingType)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
        
    if(MORE_THAN_1BIT(Device))
    {
        cbDbgPrint(1, "More than one device to get timing policy");
        return CBIOS_ER_INVALID_PARAMETER;
    }

     // device supported timing type
    switch(Device)
    {
    case S3_CRT:
        *pCurTimingType = pcbe->devicetimingtype[CRTbit];
        break;

    case S3_CRT2:
        *pCurTimingType = pcbe->devicetimingtype[CRT2bit];
        break;

    case S3_LCD:
        *pCurTimingType = pcbe->devicetimingtype[LCDbit];
        break;

    case S3_LCD2:   
        *pCurTimingType = pcbe->devicetimingtype[LCD2bit];
        break;

    case S3_TV:
        *pCurTimingType = pcbe->devicetimingtype[TVbit];
        break;

    case S3_HDTV:   
        *pCurTimingType = pcbe->devicetimingtype[HDTVbit];
        break;

    case S3_DVI:   
        *pCurTimingType = pcbe->devicetimingtype[DVI2bit];
        break;
        
    case S3_DVI2:
        *pCurTimingType = pcbe->devicetimingtype[DVI2bit];
        break;

    case S3_HDMI:
        *pCurTimingType = pcbe->devicetimingtype[HDMIbit];
        break;

    case S3_HDMI2:
        *pCurTimingType = pcbe->devicetimingtype[HDMI2bit];
        break;

    case S3_DP:
        *pCurTimingType = pcbe->devicetimingtype[DPbit];
        break;

    case S3_DP2:
        *pCurTimingType = pcbe->devicetimingtype[DP2bit];
        break;
        
    default:
        cbDbgPrint(1, "The device has not been supported");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    return CBIOS_OK;
}


//*****************************************************************************
//
//  CBiosSetDeviceTimingType
//
//      The function sets CBIOS supported Timing policy, CBIOS may offer more
//  than one type of device timing so that ender use can switch between diversified 
//  device timing types.
//
//  Parameters:
//    IN 
//      Device : device needed to query (only 1 device each time)
//      TimingType : needed device timing type (1 timing type each time)
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetDeviceTimingType(
    PVOID pvcbe,
    IN DWORD Device,
    IN DWORD TimingType)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_ER_INVALID_PARAMETER;
    
    if(MORE_THAN_1BIT(Device) || MORE_THAN_1BIT(TimingType))
    {
        cbDbgPrint(1, "More than one device or timing type input\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    switch(Device)
    {
    case S3_CRT:
        // CRT supports 
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. normal VESAVPIT 
        if (TimingType & (EDID_ENABLEDEVSCALING_TIMING_TYPE | VESAVPIT_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
        {
            pcbe->devicetimingtype[CRTbit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_CRT2:
    {
        ULONG encodertype = 0;
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        }

        // CH7301 encoder type supports
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. normal VESAVPIT 
        if(encodertype == CH7301) 
        {
            if (TimingType & (EDID_ENABLEDEVSCALING_TIMING_TYPE | 
                 VESAVPIT_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE))
            {     
                pcbe->devicetimingtype[CRT2bit] = TimingType;
                status = CBIOS_OK;
            }
        
        }
        // 1625 CRT2 supports VESAVPIT timing type
        else
        {
            if (TimingType & VESAVPIT_TIMING_TYPE)
            {
                pcbe->devicetimingtype[CRT2bit] = TimingType;
                status = CBIOS_OK;
            }
        }
    }    
        break;

    case S3_LCD:
        // LCD supports 
        // 1. EDID timing 
        if (TimingType == EDID_DISABLEDEVSCALING_TIMING_TYPE)
        {
            pcbe->devicetimingtype[LCDbit] = TimingType;
            status = CBIOS_OK;
        }
        break;
        
    case S3_LCD2:   
        // LCD2 supports 
        // 1. EDID timing 
        if (TimingType == EDID_DISABLEDEVSCALING_TIMING_TYPE)
        {
            pcbe->devicetimingtype[LCD2bit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_TV:
        // TV supports TV timing type
        if (TimingType & TV_TIMING_TYPE)
        {
            pcbe->devicetimingtype[TVbit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_HDTV:   
        // HDTV supports HDTV timing type
        if (TimingType & HDTV_TIMING_TYPE)
        {
            pcbe->devicetimingtype[HDTVbit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_DVI:
        // DVI supports 
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. VESAVPIT filter by Panel size timing
        if (TimingType & (VESAFILTERBYEDID_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[DVIbit] = TimingType;
            status = CBIOS_OK;
        }
        break;
        
    case S3_DVI2:
        // DVI2 supports 
        // 1. EDID timing 
        // 2. EDID non device scaling timing 
        // 3. VESAVPIT filter by Panel size timing
        if (TimingType & (VESAFILTERBYEDID_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[DVI2bit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_HDMI:
        // HDMI now use VESA EDID detailed timing will change to CEAEDID timing  
        if (TimingType & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[HDMIbit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_HDMI2:
        // HDMI now use VESA EDID detailed timing will change to CEAEDID timing  
        if (TimingType & (EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[HDMI2bit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_DP:
        if (TimingType & (VESAFILTERBYEDID_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[DPbit] = TimingType;
            status = CBIOS_OK;
        }
        break;

    case S3_DP2:
        if (TimingType & (VESAFILTERBYEDID_TIMING_TYPE | EDID_ENABLEDEVSCALING_TIMING_TYPE | EDID_DISABLEDEVSCALING_TIMING_TYPE | VESAVPIT_EDID_TIMING_TYPE))
        {
            pcbe->devicetimingtype[DP2bit] = TimingType;
            status = CBIOS_OK;
        }
        break;
        
    default:
        cbDbgPrint(1, "The device has not been supported");
    }

    return status;
}
 

//*****************************************************************************
//
//  CBiosGetAlwaysOnDevice
//
//  The function is used by driver to get always light on device.
//
//  OUT: pAlwaysOnDev, definition: 
//       ============================
//       Reserved        = Bit[16~31]
//       TV2             = Bit[15]
//       HDMI(3)         = Bit[9]
//       LCD2            = Bit[8]
//       CRT attached on = Bit[7], 1 = CRT attached on, 0 = Not attached on, default value
//       CRT2            = Bit[6]
//       DVI             = Bit[5]
//       DVI2            = Bit[4]
//       HDTV            = Bit[3]
//       TV              = Bit[2]
//       LCD             = Bit[1]
//       CRT             = Bit[0]
//  Return Value:
//      CBIOS_STATUS
//  Notes: 
//      The display devices' bit definition if same with CBIOS interface, 
//      and BIT7 is used for CRT attached on judgement
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetAlwaysOnDevice (
    PVOID pvcbe, 
    OUT DWORD *pAlwaysOnDev)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pAlwaysOnDev)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if(pcbe->pVCPInfo!=NULL)
    {
        if (pcbe->pVCPInfo->version >= VCP1_4)
        {
            // filter always on device, with supported devices, Remain CRT attached on bit
            DWORD dev = pcbe->pVCPInfo->Always_On_Device & (pcbe->SupportDevices | CRT_ATTACHED_ON);
            BYTE BitNumbers;
            if(dev & CRT_ATTACHED_ON)
            {
                //if CRT attached on, then remove CRT from always on devices
                dev = dev & ~S3_CRT;
            }
            BitNumbers = cbGetBitNumbers(pcbe, dev);
            for( ; BitNumbers>2; BitNumbers--)
            {
                dev = cbFilterOneDevice(pcbe, dev);
            }
            *pAlwaysOnDev = dev;
            return CBIOS_OK;
        }
    }

    cbDbgPrint(1, "VCP info error,maybe version mismatch,make sure VCP 1.4 or above!\n");
    return CBIOS_ER_INTERNAL;
}

//*****************************************************************************
//
//  CBiosSetS1Powerstate
//
//  An interface function for S1 power saving feature, driver will call it when 
//  entering or resuming from S1
//
//  IN:
//     powerState
//  OUT:
//     NONE
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetS1Powerstate (
    PVOID pvcbe, 
    IN DWORD powerState)
{ 
    PCBIOS_EXTENSION pcbe = pvcbe;

    if(pcbe->ChipCaps.S1_power_saving_sup)
    {
        if(powerState == ON)
        {
            cbWriteRegByte(pcbe, SR_19, pcbe->S1SavingRegs.PS_REG_SR19);
            cbWriteRegBits(pcbe, SR_1B, BIT0+BIT4+BIT5+BIT6+BIT7, pcbe->S1SavingRegs.PS_REG_SR1B);
            cbWriteRegBits(pcbe, SR_2D, BIT0+BIT1+BIT2+BIT3+BIT4+BIT5, pcbe->S1SavingRegs.PS_REG_SR2D);
            cbWriteRegByte(pcbe, SR_2E, pcbe->S1SavingRegs.PS_REG_SR2E);
            cbWriteRegByte(pcbe, SR_3F, pcbe->S1SavingRegs.PS_REG_SR3F);
            cbWriteRegBits(pcbe, CR_92, BIT7, pcbe->S1SavingRegs.PS_REG_CR92);
        }
        else if(powerState == OFF)
        {
            pcbe->S1SavingRegs.PS_REG_SR19 = cbReadRegByte(pcbe, SR_19); // Interface clock control
            pcbe->S1SavingRegs.PS_REG_SR1B = cbReadRegByte(pcbe, SR_1B); // IGA1 LUT power, IGA2/IGA1 engine clock gate control
            pcbe->S1SavingRegs.PS_REG_SR2D = cbReadRegByte(pcbe, SR_2D); // VCK/LCK/ECK PLL power control
            pcbe->S1SavingRegs.PS_REG_SR2E = cbReadRegByte(pcbe, SR_2E); // Capture/Video Processor/DMA/Video playback clock control
            pcbe->S1SavingRegs.PS_REG_SR3F = cbReadRegByte(pcbe, SR_3F); // CR/3D/2D/DVD clock control
            pcbe->S1SavingRegs.PS_REG_CR92 = cbReadRegByte(pcbe, CR_92); // IGA2 LUT power down

            cbWriteRegByte(pcbe, SR_19, 0x7F);
            cbWriteRegBits(pcbe, SR_1B, BIT0+BIT4+BIT5+BIT6+BIT7, 0x01);
            cbWriteRegBits(pcbe, SR_2D, BIT2+BIT3+BIT4+BIT5, 0);
            cbWriteRegByte(pcbe, SR_2E, 0);
            cbWriteRegByte(pcbe, SR_3F, 0);
            cbWriteRegBits(pcbe, CR_92, BIT7, BIT7);
        }
        else
        {
            //Unknown power state, add an assert for debug
            ASSERT(0);
        }
    }

    return CBIOS_OK;
}

/*****************************************************************************
*
* CBiosSetS3Powerstate
*
* An interface function for S3 power saving feature, driver will call it when 
* entering or resuming from S3
*
* IN:
* powerState
* OUT:
* NONE
* Return Value:
* CBIOS_STATUS
*
******************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosSetS3Powerstate (
    PVOID pvcbe, 
    IN DWORD powerState)
{ 
    PCBIOS_EXTENSION pcbe = pvcbe;

    if (powerState == ON) {
        cbWriteRegByte(pcbe, SR_19, pcbe->S3SavingRegs.PS_REG_SR19);
        cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5+BIT6+BIT7, pcbe->S3SavingRegs.PS_REG_SR1B);
        cbWriteRegByte(pcbe, SR_2D, pcbe->S3SavingRegs.PS_REG_SR2D);
        cbWriteRegByte(pcbe, SR_2E, pcbe->S3SavingRegs.PS_REG_SR2E);
        cbWriteRegByte(pcbe, SR_3F, pcbe->S3SavingRegs.PS_REG_SR3F);
        cbWriteRegByte(pcbe, SR_68, pcbe->S3SavingRegs.PS_REG_SR68);
        cbWriteRegByte(pcbe, SR_6A, pcbe->S3SavingRegs.PS_REG_SR6A);
        cbWriteRegByte(pcbe, SR_6B, pcbe->S3SavingRegs.PS_REG_SR6B);
        cbWriteRegByte(pcbe, SR_6C, pcbe->S3SavingRegs.PS_REG_SR6C);
        cbWriteRegByte(pcbe, SR_6D, pcbe->S3SavingRegs.PS_REG_SR6D);
        cbWriteRegByte(pcbe, SR_6E, pcbe->S3SavingRegs.PS_REG_SR6E);
        cbWriteRegByte(pcbe, SR_6F, pcbe->S3SavingRegs.PS_REG_SR6F);
        cbWriteRegBits(pcbe, SR_B9, BIT1, pcbe->S3SavingRegs.PS_REG_SRB9);
        /* cbWriteRegBits(pcbe, CR_92, BIT7, pcbe->S1SavingRegs.REG_CR92); */
    } else if (powerState == OFF) {
        /* IGA1 FIFO depth
               * set display FIFO depth: {3c4.57.bit[3], 3c4.17.bit[7:0]} x 2 */
        cbWriteRegBits(pcbe, SR_57, BIT3, 0);
        cbWriteRegByte(pcbe, SR_17, 0);

        /* IGA2 FIFO depth
               * set display FIFO depth: (3d4.95.bit[7], 3d4.94.bit[7], 3d4.68.bit[7:4]) x 8 */
        cbWriteRegBits(pcbe, CR_68, 0xF0, 0);
        cbWriteRegBits(pcbe, CR_AA, BIT7, 0);
        cbWriteRegBits(pcbe, CR_95, BIT7, 0);
        cbWriteRegBits(pcbe, CR_94, BIT7, 0);
    
        pcbe->S3SavingRegs.PS_REG_SR19 = cbReadRegByte(pcbe, SR_19); /* Interface clock control */
        pcbe->S3SavingRegs.PS_REG_SR1B = cbReadRegByte(pcbe, SR_1B); /* IGA1 LUT power, IGA2/IGA1 engine clock gate control */
        pcbe->S3SavingRegs.PS_REG_SR2D = cbReadRegByte(pcbe, SR_2D); /* VCK/LCK/ECK PLL power control */
        pcbe->S3SavingRegs.PS_REG_SR2E = cbReadRegByte(pcbe, SR_2E); /* Capture/Video Processor/DMA/Video playback clock control */
        pcbe->S3SavingRegs.PS_REG_SR3F = cbReadRegByte(pcbe, SR_3F); /* CR/3D/2D/DVD clock control */
        pcbe->S3SavingRegs.PS_REG_CR92 = cbReadRegByte(pcbe, CR_92); /* IGA2 LUT power down */
        pcbe->S3SavingRegs.PS_REG_SR68 = cbReadRegByte(pcbe, SR_68);
        pcbe->S3SavingRegs.PS_REG_SR6A = cbReadRegByte(pcbe, SR_6A);
        pcbe->S3SavingRegs.PS_REG_SR6B = cbReadRegByte(pcbe, SR_6B);
        pcbe->S3SavingRegs.PS_REG_SR6C = cbReadRegByte(pcbe, SR_6C);
        pcbe->S3SavingRegs.PS_REG_SR6D = cbReadRegByte(pcbe, SR_6D);
        pcbe->S3SavingRegs.PS_REG_SR6E = cbReadRegByte(pcbe, SR_6E);
        pcbe->S3SavingRegs.PS_REG_SR6F = cbReadRegByte(pcbe, SR_6F);
        pcbe->S3SavingRegs.PS_REG_SRB9 = cbReadRegByte(pcbe, SR_B9);

        cbWriteRegByte(pcbe, SR_19, 0x7F);
        //cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5+BIT6+BIT7, 0x00);
        //cbWriteRegByte(pcbe, SR_2D, 0x03);  /* skip ECK power down */
        cbWriteRegByte(pcbe, SR_2E, 0);
        cbWriteRegByte(pcbe, SR_3F, 0);

        /* cbWriteRegBits(pcbe, CR_92, BIT7, BIT7); */
    }
    else
    {
        /* Unknown power state, add an assert for debug */
        ASSERT(0);
    }

// patch for ch7301 DVI2 discolor issue, resore 0x1c while s3 resume
{
    I2C_CONTROL_UMA i2c;
    BYTE TxType=0;
    i2c.Flags = 0;           

    if (cbGetDITXtype(pcbe, &TxType, S3_DVI2) == TRUE) {
            if (TxType == CH7301) {
                /* get i2c info first */
                if (cbGetDII2Csetting(pcbe, &i2c, S3_DVI2)) {
                i2c.RegIndex  = 0x1C;
                
                if (powerState == ON) {
                    i2c.IndexData = pcbe->S3SavingRegs.REG_CH7301_1C ;
                    I2C_Write_Bit_INV(pcbe, &i2c, BIT0+BIT2);
                    cbDbgPrint(1, "power ON write ch7301 1C= %d !\n", pcbe->S3SavingRegs.REG_CH7301_1C);
                }

                if (powerState == OFF){
                    /* if I2C work properly then check return value
                    * get i2c register index data */
                    if (I2C_Read_Byte_INV(pcbe, &i2c)) {
                        pcbe->S3SavingRegs.REG_CH7301_1C = i2c.IndexData; 
                        cbDbgPrint(1, "power OFF save ch7301 1C= 0x%x !\n", pcbe->S3SavingRegs.REG_CH7301_1C);
                    }     
                }    
            }
        }
    }
}
     
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosSetS4Powerstate
//
//  An interface function for S4 power saving feature, driver will call it when 
//  entering S4
//
//  OUT:
//     NONE
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetS4Powerstate (
    PVOID pvcbe)
{ 
    PCBIOS_EXTENSION pcbe = (PCBIOS_EXTENSION)pvcbe;

    // IGA1 FIFO depth
    // set display FIFO depth: {3c4.57.bit[3], 3c4.17.bit[7:0]} x 2
    cbWriteRegBits(pcbe, SR_57, BIT3, 0);
    cbWriteRegByte(pcbe, SR_17, 0);

    // IGA2 FIFO depth
    // set display FIFO depth: (3d4.95.bit[7], 3d4.94.bit[7], 3d4.68.bit[7:4]) x 8
    cbWriteRegBits(pcbe, CR_68, 0xF0, 0);
    cbWriteRegBits(pcbe, CR_AA, BIT7, 0);
    cbWriteRegBits(pcbe, CR_95, BIT7, 0);
    cbWriteRegBits(pcbe, CR_94, BIT7, 0);

    cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5+BIT6+BIT7, 0x00);
    // when enter S3 diable IGA2 data request signal, or it will cause system random hang
    cbWriteRegBits(pcbe, CR_6A, BIT7, 0); 
    //cbWriteRegBits(pcbe, CR_92, BIT7, BIT7);

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosPatchHW
//
//  This interface do special HW patchs for driver
//
//  IN:
//     HWPatchTag:  HW specific number
//     inBuf:       HW specific input parameter buffer
//     inBufLen:    HW specific input parameter buffer length
//  OUT:
//     outBuf:      HW specific return info output buffer
//     outBufLen:   HW specific return info output buffer length
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosPatchHW (
    PVOID pvcbe, 
    IN CbiosHWPatchTag HWPatchTag,
    IN  BYTE*   inBuf,
    IN  UINT32  inBufLen,
    OUT BYTE*   outBuf,
    OUT UINT32  outBufLen )
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
    
    switch (HWPatchTag)
    {
    case HW_PATCH_IGA1_PLL_CONTROL:
        /* for: 353
               * The IGA2 VSYNC asserted is earlier than IGA1 VSYNC asserted.
               * (Notice : IGA1's clock can't be off before HW latch mmio298[25:24]) */
        {
            BYTE IGA1State;
            if (!inBuf || inBufLen ==0) {
                cbDbgPrint(0, "Caution: NULL pointer!\n");
                ASSERT(FALSE);
                return CBIOS_ER_INVALID_PARAMETER;
            }

            IGA1State = inBuf[0];
            if (HW_PATCH_IGA1_PLL_CONTROL_ON == IGA1State) {
                /* IGA1 PLL Power On */
                cbWriteRegBits(pcbe, SR_2D, BIT4+BIT5, BIT4+BIT5);
                /* turn on VCK */
                cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5, BIT4+BIT5);
            } else if (HW_PATCH_IGA1_PLL_CONTROL_OFF == IGA1State) {
                /* turn off VCK */
                cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5, 0);
                /* IGA1 PLL Power Off */
                cbWriteRegBits(pcbe, SR_2D, BIT4+BIT5, 0);
            } else {
                status = CBIOS_ER_INVALID_PARAMETER;
            }
        }
        break;
        
    case HW_PATCH_SNAPSHOT_CONTROL:
        /* specific for 353 video informing Gfx to do snapshot state */
        {
            BYTE SnapshotState;
            if (!inBuf || inBufLen ==0) {
                cbDbgPrint(0, "Caution: NULL pointer!\n");
                ASSERT(FALSE);
                return CBIOS_ER_INVALID_PARAMETER;
            }
            
            SnapshotState = inBuf[0];
            if (HW_PATCH_SNAPSHOT_CONTROL_ENABLE == SnapshotState) {
                 /* snapshot enable */
                 cbWriteRegBits(pcbe, CR_F3, BIT2, BIT2);
            } else if (HW_PATCH_SNAPSHOT_CONTROL_DISABLE == SnapshotState) {
                 /* snapshot disable */
                 cbWriteRegBits(pcbe, CR_F3, BIT2, 0);
            } else {
                status = CBIOS_ER_INVALID_PARAMETER;
            }
                        
        }
        break;

    case HW_PATCH_DISPLAY_REQUEST_DISABLE:
        /* for 364, 353, 409 display request must disable
               * when GFX enter D3, S4 */
        { 
            /* IGA1 FIFO depth
                      * set display FIFO depth: {3c4.57.bit[3], 3c4.17.bit[7:0]} x 2 */
            cbWriteRegBits(pcbe, SR_57, BIT3, 0);
            cbWriteRegByte(pcbe, SR_17, 0);
            /* 8 IGA2 FIFO depth
                      * set display FIFO depth: (3d4.95.bit[7], 3d4.94.bit[7], 3d4.68.bit[7:4]) x 8 */
            cbWriteRegBits(pcbe, CR_68, 0xF0, 0);
            cbWriteRegBits(pcbe, CR_AA, BIT7, 0);
            cbWriteRegBits(pcbe, CR_95, BIT7, 0);
            cbWriteRegBits(pcbe, CR_94, BIT7, 0);

            cbWriteRegBits(pcbe, SR_1B, BIT4+BIT5+BIT6+BIT7, 0x00);
            /* when enter S3 diable IGA2 data request signal, or it will cause system random hang */
            cbWriteRegBits(pcbe, CR_6A, BIT7, 0);
        }
        break;
        
    case HW_PATCH_KILLNUM:
        /* for: 353
               * need adjust killnum for improve performance according OS */
        {
            BYTE killNumOS;
            if (!inBuf || inBufLen ==0) {
                cbDbgPrint(0, "Caution: NULL pointer!\n");
                ASSERT(FALSE);
                status = CBIOS_ER_INVALID_PARAMETER;
                break;
            }

            killNumOS = inBuf[0];
            if (HW_PATCH_KILLNUM_XP == killNumOS) {
                if (pcbe->ChipCaps.Is_killnumber_409_setting) {
                    /* According to system team performance messurament, 409 need to set different kill number values
                                   * Now, specific for some platform only first. */
                    cbWriteRegByte(pcbe, SR_79, 0x05);  /* P-Arb request coming T-Arb reqeust kill timer */
                    cbWriteRegByte(pcbe, SR_7A, 0x10);  /* Normal T-Arb request kill timer */
                } else {
                    cbWriteRegByte(pcbe, SR_79, 0x01);  /* P-Arb request coming T-Arb reqeust kill timer */
                    cbWriteRegByte(pcbe, SR_7A, 0x08);  /* Normal T-Arb request kill timer */
                }
            } else if (HW_PATCH_KILLNUM_VISTA == killNumOS) {
                /* for VT3353, if sum of IGA1 mode bandwidth & IGA2 bandwidth > BANDWIDTH_UP_BOUND 
                            * then set SR79=0x01, else set SR79=0x08 */
                if (pcbe->ChipCaps.for_killnumber_control) {
                    DWORD IGA_Bandwidth = 0;
                    if (pcbe->IGA1Info.PowerNowState) {
                        IGA_Bandwidth += (pcbe->IGA1Info.HTotal)
                            *(pcbe->IGA1Info.VTotal)
                            *(pcbe->IGA1Info.RRateInfo.rRateX100/100)
                            *(pcbe->IGA1Info.ColorDepth/8);
                    }
                    if (pcbe->IGA2Info.PowerNowState) {
                        IGA_Bandwidth += (pcbe->IGA2Info.HTotal)
                            *(pcbe->IGA2Info.VTotal)
                            *(pcbe->IGA2Info.RRateInfo.rRateX100/100)
                            *(pcbe->IGA2Info.ColorDepth/8);
                    }
                    if (IGA_Bandwidth >= BANDWIDTH_UP_BOUND) {
                        if (pcbe->ChipCaps.Is_killnumber_409_setting) {
                            /* According to system team performance messurament, 409 need to set different kill number values
                                                * vista also need this setting */
                            cbWriteRegByte(pcbe, SR_79, 0x05);  /* P-Arb request coming T-Arb reqeust kill timer */
                            cbWriteRegByte(pcbe, SR_7A, 0x10);  /* Normal T-Arb request kill timer */
                        } else {
                            cbWriteRegByte(pcbe, SR_79, 0x01);  /* P-Arb request coming T-Arb reqeust kill timer */
                            cbWriteRegByte(pcbe, SR_7A, 0x08);  /* Normal T-Arb request kill timer */
                        }
                    } else {
                        /* from SV test report. It seem lower kill timer will release more CPU time
                                          * it can improve DVD play CPU usage. */
                        cbWriteRegByte(pcbe, SR_79, 0x10);
                        cbWriteRegByte(pcbe, SR_7A, 0x10);
                    }
                } /* if patch_killnumber_control */
            } else {
                status = CBIOS_ER_INVALID_PARAMETER;
            }
        }
        break;

    case HW_PATCH_FORCE_HDMI_TO_DVI_MODE:
		{			
			BYTE ForceHDMItoDVIMode;
			if (!inBuf || inBufLen ==0) {
				cbDbgPrint(0, "Caution: NULL pointer!\n");
				ASSERT(FALSE);
				return CBIOS_ER_INVALID_PARAMETER;
			}

			ForceHDMItoDVIMode = inBuf[0];

			if (HW_PATCH_FORCE_HDMI_TO_DVI_MODE_ON == ForceHDMItoDVIMode)
				pcbe->ChipCaps.Force_HDMI_to_DVI_Mode = TRUE;
			else
				pcbe->ChipCaps.Force_HDMI_to_DVI_Mode = FALSE;

		}
		break;

    case HW_PATCH_NONE:

        break;
        
    default:

        break;
    }

    return status;
}


CBIOS_STATUS CBIOSAPI CBiosSetHardwareDownScaleBYIGA(
            PVOID pvcbe,
            IN DWORD IGA_Num,
            IN DWORD SrcWidth,
            IN DWORD SrcHeight,
            IN DWORD colorDepth,
            IN DWORD DstWidth,
            IN DWORD DstHeight,
            IN DWORD AutoFlip,
            IN DWORD PitchDelt,
            ULONG DstAddress0,ULONG  DstAddress1, ULONG DstAddress2
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    ULONG Hscalefactor, Vscalefactor,SrcBpp;
    ULONG sourceFBStride;
    ULONG DSDevPhysicalPitch;
    BYTE   CRE3,CRE8,CREC;

    // For 410 and later chip, don't use this kind of downscaling function
    if(pcbe->ChipCaps.IGA12_Support_Downscale)
    {
        return CBIOS_OK;    
    }

    SrcBpp=colorDepth>>3;
    Hscalefactor=((SrcWidth*10)<<12)/(DstWidth*10 + 5);
    Vscalefactor=((SrcHeight*10)<<12)/(DstHeight *10 + 5);
    sourceFBStride=(SrcWidth*SrcBpp)>>4;    
   
    // add PitchDelt to aid 353/409 hw issue,which lead left side has trasparent line when down scaling     
    DSDevPhysicalPitch=(DstWidth*SrcBpp + PitchDelt)>>3;    //8 bytes align

    //here we edit IGA pitch to deivce native mode, because the downscale 
    //destine buffer pitch is decide by IGA's pitch.
    if(IGA_Num == IGA2)
    {
        cbLoadTimingOnIGA2_UMA(pcbe, OFFSET, (WORD)DSDevPhysicalPitch);
    }
    if(IGA_Num == IGA1)
    {
        cbLoadTimingOnIGA1_UMA(pcbe, OFFSET, (WORD)DSDevPhysicalPitch);
    }
    cbWriteRegByte(pcbe,CR_D9, (BYTE)(SrcWidth & 0xFF));
    cbWriteRegByte(pcbe,CR_DA, (BYTE)(SrcHeight & 0xFF));
    cbWriteRegByte(pcbe,CR_DB, (BYTE)(((SrcWidth & (BIT8 | BIT9 | BIT10) ) >> 8 ) |((SrcHeight & (BIT8 | BIT9 | BIT10) ) >> 5 )));
    cbWriteRegByte(pcbe,CR_DC, (BYTE)(Hscalefactor & 0xFF));
    if(AutoFlip)
    {
        cbWriteRegByte(pcbe,CR_DD, (BYTE)(((Hscalefactor & 0x3F00) >> 8) |BIT6|BIT7));//bit 6: Horizontal Scale Down Enable, bit 7 DN Flip Select 
    }
    else
    {
        cbWriteRegByte(pcbe,CR_DD, (BYTE)(((Hscalefactor & 0x3F00) >> 8) |BIT6)); //bit 6: Horizontal Scale Down Enable 
    } 

    //aid 353/409 hw issue, which lead cursor shake (1280 -> 640) when downscaling eanble
    Vscalefactor -= 2;
    
    cbWriteRegByte(pcbe,CR_DE, (BYTE)(Vscalefactor & 0xFF));
    cbWriteRegByte(pcbe,CR_DF, (BYTE)(((Vscalefactor & 0x3F00) >> 8) |BIT6)); //bit 6: Virtical Scale Down Enable
    cbWriteRegByte(pcbe,CR_E0, (BYTE)((DstAddress0 >> 3) & 0xFF));// bit 10 : 3
    cbWriteRegByte(pcbe,CR_E1, (BYTE)((DstAddress0 >> 11) & 0xFF));//  bit  18 : 11
    cbWriteRegByte(pcbe,CR_E2, (BYTE)((DstAddress0 >> 19) & 0xFF));// bit 26 : 19
    CRE3=(BYTE)(((DstAddress0 >> 27) & 0x3)       //  bit  28 : 27
                |((sourceFBStride & (BIT9 |BIT8)) >> 4));     //SW source Frame Buffer Stride[9:8]
    if(SrcBpp == 2)
    {
        CRE3 |= BIT7;
    }
    else if(SrcBpp == 1)
    {
        CRE3 |= BIT6;
    }
    cbWriteRegByte(pcbe,CR_E3, CRE3);
    cbWriteRegByte(pcbe,CR_E4, (BYTE)(sourceFBStride & 0xFF));
    cbWriteRegByte(pcbe,CR_E5, (BYTE)((DstAddress1 >> 3) & 0xFF));
    cbWriteRegByte(pcbe,CR_E6, (BYTE)((DstAddress1 >> 11) & 0xFF));
    cbWriteRegByte(pcbe,CR_E7, (BYTE)((DstAddress1 >> 19) & 0xFF));
    cbWriteRegByte(pcbe,CR_E9, (BYTE)((DstAddress2 >> 3) & 0xFF));
    cbWriteRegByte(pcbe,CR_EA, (BYTE)((DstAddress2 >> 11) & 0xFF));
    cbWriteRegByte(pcbe,CR_EB, (BYTE)((DstAddress2 >> 19) & 0xFF));

    CRE8=(BYTE)(((DstAddress1 >> 27) & 0x3)       //  Destination Frame Buffer Starting Address 1[28:27]
                |(((DstAddress2 >> 27) & 0x3) << 2));    //  Destination Frame Buffer Starting Address 2[28:27].
    CREC = 0;
    if(AutoFlip)
    {
        if(IGA_Num == IGA2)
        {
            CRE8 |=  (BIT4                   //Scaling Down Enable; 1 : Enable
                             |BIT5           //FLIP. IGA2 can start to get next frame
                             |BIT6           //LINE FLIP ENABLE
                             |BIT7 );        //Which IGA run Scaling Down ; 0:IGA1 ; 1:IGA2
        }
        if(IGA_Num == IGA1)
        {
            CREC |= (BIT0                   //IGA1 Down Scalar enable
                            |BIT1           //IGA1 Down Scalar Flip
                            |BIT2);         //IGA1 Down Scalar Line Flip 
        }    
    }
    else
    {
        if(IGA_Num == IGA2)
        {
            CRE8 |=  (BIT4                  //Scaling Down Enable; 1 : Enable                         
                             |BIT7 );       //Which IGA run Scaling Down ; 0:IGA1 ; 1:IGA2
        }
        if(IGA_Num == IGA1)
        {
            CREC |= (BIT0                   //IGA1 Down Scalar enable
                            |BIT1);         //IGA1 Down Scalar Flip
        }
    }
    
    cbWriteRegByte(pcbe,CR_EC, CREC);       //ec is final kick off of iga 1
    cbWriteRegByte(pcbe,CR_E8, CRE8);       //E8 is final kick off  of iga 2

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetUnsupportedDeviceCombinations
//
//  The function returns all the unsupported device combinations in duoview case.
//  Driver will use this function to filter duoview switch device  combinations,
//  if they are unsupported duoview devices, then customer can not enable them on duoview
//
//  Parameters:
//      pDevBuf:        returns all the unsupported device combinations in the buffer
//      pBufSize:       The buffer size is passed through by Driver.
//                      Upon returned, fill bytes actually used in the pResBuf
//  Return Value:
//      CBIOS_STATUS
//
//  Notes:
//      This function will check if the devices are using same DI port, 
//      if same, then can not light on at same time
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetUnsupportedDeviceCombinations (PVOID pvcbe, INOUT DWORD *pDevBuf, INOUT DWORD *pBufSize)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD realBufSize = 0;

    if (!pDevBuf || !pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    cbGetUnsupportedDevCombBuf(pcbe, pDevBuf, *pBufSize, &realBufSize);
    if (*pBufSize > realBufSize)
    {
        // if given buf big than real buf filled, return real used buf size
        *pBufSize = realBufSize;
    }
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetUnsupportedDeviceCombinationsBufferSize
//
//  This function returns the size of "unsupported device combinations" memory buffer.
//
//  Parameters:
//      pBufSize:       returns the size of memory buffer required in bytes
//                      to hold the Device Combinations
//  Return Value:
//      CBIOS_STATUS
//
//  Notes:
//      This function will check if the devices are using same DI port, 
//      if same, then can not light on at same time
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetUnsupportedDeviceCombinationsBufferSize (PVOID pvcbe, INOUT DWORD *pBufSize)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    if (!pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    cbGetUnsupportedDevCombBuf(pcbe, NULL, 0, pBufSize);
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetHotKeySwitchDeviceCombinations
//
//  The function returns the hotkey switch device combination list with priority.
//  The index of the array of device combination indicates the priority. 
//  For example, if LCD is index 0 and CRT is 1, then LCD��s priority is higher than CRT 
//
//  Parameters:
//      pDevBuf:        returns all the supported hotkey switch device
//                      combinations with priority in the buffer
//      pBufSize:       The buffer size is passed through by Driver.
//                      Upon returned, fill bytes actually used in the pResBuf
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetHotKeySwitchDeviceCombinations (PVOID pvcbe, IN OUT DWORD *pDevBuf, INOUT DWORD *pBufSize)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD realBufSize = 0;

    if (!pDevBuf || !pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    cbGetHotKeySwitchDevCombBuf(pcbe, pDevBuf, *pBufSize, &realBufSize);
    if (*pBufSize > realBufSize)
    {
        // if given buf big than real buf filled, return real used buf size
        *pBufSize = realBufSize;
    }
    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosGetHotKeySwitchDeviceCombinationsBufferSize
//
//  This function returns the size of "HotKey switch device combinations" memory buffer.
//
//  Parameters:
//      pBufSize:       returns the size of memory buffer required in bytes
//                      to hold the Device Combinations
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetHotKeySwitchDeviceCombinationsBufferSize (PVOID pvcbe, INOUT DWORD *pBufSize)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (!pBufSize)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    cbGetHotKeySwitchDevCombBuf(pcbe, NULL, 0, pBufSize);
    return CBIOS_OK;
}

//********************************************************************************
// CBiosGetDeviceHotPlugInterruptSetting
//    This function returns device associated hot plug interrupt pin setting 
// now we have two types of interrupt 
//    USING_LVDS_HPD_INTERRUPT : MMIO 200[30](LVDS Sense Interrupt of spec)
//    USING_TMDS_HPD_INTERRUPT : MMIO 200[16](TMDS Sense Interrupt of spec)
//    USING_CRT_HPD_INTERRUPT  : MMIO 1280[04](CRT Sense Interrupt of spec)
//  IN :
//      device bit
//  OUT :
//      interrupt type
//          USING_LVDS_HPD_INTERRUPT
//          USING_TMDS_HPD_INTERRUPT
//      CBIOS_STATUS
//*******************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetDeviceHotPlugInterruptSetting(
    PVOID pvcbe, 
    IN DWORD dispDev,
    OUT PDWORD pINTtype)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_STATUS     status = CBIOS_OK;
    PDigitalPortInfo pDIportinfo = NULL;
    
    if (!pINTtype)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    // Initial to hot plug interrupt pin setting unvalid
    *pINTtype  = 0;

    if(MORE_THAN_1BIT(dispDev))
    {
        cbDbgPrint(1, "More than one device bit input\n");
        status = CBIOS_ER_INVALID_PARAMETER;
    }

    if(pcbe->pVCPInfo->version < VCP1_6)
    {
        if (dispDev & S3_HDMI)
        {
            if (cbGetDIPortInfo(pcbe, &pDIportinfo, dispDev) == TRUE)
            {
                //Note: for some device, there maybe no HPD interrupt config, but we will still return CBIOS_OK
                *pINTtype  = pDIportinfo->PortInfo.DIPORTMISC & 
                   (USING_LVDS_HPD_INTERRUPT +
                    USING_TMDS_HPD_INTERRUPT +
                    USING_DP_HPD_INTERRUPT +
                    USING_DP2_HPD_INTERRUPT +
                    USING_HDAUDIO_INTERRUPT );
            }
            else
            {
                status = CBIOS_ER_INTERNAL;
            }
        }
    }
    else
    {
        //VCP>=1.6, for CRT need check CRT valid bit, for other device check DI port valid bit
        if (( (dispDev & S3_CRT) && (pcbe->pVCPInfo->miscConfigure2 & CRT_HPD_INTERRUPT_SETTING_VALID)) ||
            (!(dispDev & S3_CRT) && (pcbe->pVCPInfo->miscConfigure2 & DIPORT_HPD_INTERRUPT_SETTING_VALID)))
        {
            if (cbGetDIPortInfo(pcbe, &pDIportinfo, dispDev) == TRUE)
            {
                //Note: for some device, there maybe no HPD interrupt config, but we will still return CBIOS_OK
                *pINTtype  = pDIportinfo->PortInfo.DIPORTMISC & 
                   (USING_LVDS_HPD_INTERRUPT +
                    USING_TMDS_HPD_INTERRUPT +
                    USING_DP_HPD_INTERRUPT +
                    USING_DP2_HPD_INTERRUPT +
                    USING_HDAUDIO_INTERRUPT );
            }
            else
            {
                status = CBIOS_ER_INTERNAL;
            }
        }
    }

    return status;
}

//********************************************************************************
// CBiosSetPWMLevel
//    This function update PWM level indicator to hardware
//    There are two type panel support different PWM control.
//    Here we define. Hardware always response with MAX duty (0xFE).
//    We can get panel control attribute to switch PWM duty for different panel
//  IN :
//      PWM level
//  OUT :
//      CBIOS_STATUS
//*******************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetPWMLevel(
            PVOID pvcbe,
            BYTE    Level)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    BYTE panelID = 0;

    // we only support one PWM, always select first panel ID
    panelID = pcbe->sPad_4.LCD_DVI2_PanelID;

    if (pcbe->pVCPInfo != NULL)
    {
        if (pcbe->pVCPInfo->LCDInfoHeader != 0)
        {
            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            PFPHeaderData pLCDHeader;

            if((pcbe->pVCPInfo->miscConfigure2 & LCDBKLIGHT_USE_INTERPWM_BIT) == 0)
            {
                return CBIOS_ER_NOT_SUPPORT;
            }
            pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
            pLCDHeader += panelID;

#if !LINUX_PLATFORM
            Level *= 2; // for Win7 only support 100 level PWM control
#endif
            if(pLCDHeader->fpControl & PWM_DUTY_POLARITY)
            {
                // inverse
                Level = PWM_MIN_DUTY + Level;
            }
            else
            {
                // normal
                Level = PWM_MAX_DUTY - Level;
            }
            
            cbWriteRegByte(pcbe, SR_77, Level); // set SR77=Brightness
            cbWriteRegBits(pcbe, SR_76, BIT0, PWM_Enable); // set SR76[0]=1 TO ENABLE BackLight control
            cbWriteRegBits(pcbe, SR_78, BIT2 | BIT1 | BIT0, PWM_CLK_DIV_64 | PWM_Fire); // SET SR78[0] TO Fire, and [1:2]=b'11 = 250mhz/64
        }
    }
    else
    {
        // disable PWM control
        ASSERT(FALSE);  // warning
        cbWriteRegBits(pcbe, SR_76, BIT0, PWM_Disable);
        return CBIOS_ER_LACKOFVCPDATA;
    }

    return CBIOS_OK;
}
//********************************************************************************
// CBiosQueryMaxPWMLevel
//    This function get maximal PWM Level which can be set. The minimal PWM Level is always 0
//  IN :
//      None
//  OUT :
//      *pLevel : the maximal PWM level
//*******************************************************************************
CBIOS_STATUS CBIOSAPI CBiosQueryMaxPWMLevel(
            PVOID pvcbe,
            BYTE  *pLevel)
{
#if LINUX_PLATFORM
    *pLevel=(PWM_MAX_DUTY-PWM_MIN_DUTY);
#else
    *pLevel=(PWM_MAX_DUTY-PWM_MIN_DUTY)/2;  // for Win7 only support 100 level PWM control
#endif
    return CBIOS_OK;
}
//********************************************************************************
// CBiosGetCurrentPWMLevel
//    This function get current PWM Level.
//  IN :
//      None
//  OUT :
//      *pLevel : current PWM level
//*******************************************************************************
CBIOS_STATUS CBIOSAPI CBiosGetCurrentPWMLevel(
            PVOID pvcbe,
            BYTE  *pLevel)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    BYTE panelID = 0, tempByte;

    if (pcbe->pVCPInfo != NULL)
    {
        if (pcbe->pVCPInfo->LCDInfoHeader != 0)
        {
            if((pcbe->pVCPInfo->miscConfigure2 & LCDBKLIGHT_USE_INTERPWM_BIT) == 0)
            {
                return CBIOS_ER_NOT_SUPPORT;
            }
            tempByte=cbReadRegByte(pcbe, SR_76);
            if(tempByte & BIT0) //if PWM control enabled
            {
                WORD offsetLCDHeader;
                PFPHeaderData pLCDHeader;
                // we only support one PWM, always select first panel ID
                panelID = pcbe->sPad_4.LCD_DVI2_PanelID;

                offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            
                pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;
                
                *pLevel=cbReadRegByte(pcbe, SR_77);
                if(pLCDHeader->fpControl & PWM_DUTY_POLARITY)
                {
                    // inverse
                    *pLevel =*pLevel - PWM_MIN_DUTY;
                }
                else
                {
                    // normal
                    *pLevel = PWM_MAX_DUTY - *pLevel;
                }
            }
            else //if PWM control disabled
            {
                *pLevel=0;
            }
        }
    }
    else
    {
        ASSERT(FALSE);  // warning
        return CBIOS_ER_LACKOFVCPDATA;
    }
#if !LINUX_PLATFORM
    *pLevel /= 2;   // for Win7 only support 100 level PWM control
#endif
    return CBIOS_OK;
}

//********************************************************************************
// CBiosPWMControl
//    This function control current PWM.
//  IN :
//      pPWMControlParams: PWM parameters want to be set
//  OUT :
//      pPWMControlParams: current status of PWM
//*******************************************************************************
CBIOS_STATUS CBIOSAPI CBiosPWMControl(
            PVOID pvcbe,
            PCBiosPWMControlParams pPWMControlParams)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    if(pcbe->pVCPInfo != NULL)
    {
        if (pcbe->pVCPInfo->LCDInfoHeader != 0)
        {
            if((pcbe->pVCPInfo->miscConfigure2 & LCDBKLIGHT_USE_INTERPWM_BIT) == 0)
            {
                return CBIOS_ER_NOT_SUPPORT;
            }

            switch(pPWMControlParams->IoControlCode)
            {
                case PWM_IOCTL_CBiosSetPWMLevel:
                    
                    {
                        if(pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL)
                        {
                            I2C_CONTROL_UMA i2c;

                            // get Device associate I2C setting
                            cbGetDII2Csetting(pcbe, &i2c, S3_LCD); // update I2C port and subaddr
                            i2c.RegIndex = 0x0A; // backlight brightness register
                            i2c.IndexWData = (BYTE)pPWMControlParams->bLevel;
                            I2C_Write_Word_INV(pcbe, &i2c);
                        }
                        else
                        {
                            BYTE panelID = 0;
                            BYTE Level   = pPWMControlParams->bLevel;
                            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
                            PFPHeaderData pLCDHeader;
                            
                            // we only support one PWM, always select first panel ID
                            panelID = pcbe->sPad_4.LCD_DVI2_PanelID;

                            pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);      
                            pLCDHeader += panelID;
#if !LINUX_PLATFORM
                            Level = (BYTE)((5*Level)/2 + (Level/25));   // for hareware limitation, level != 0xff
                                                                        //transfer the level to 0-254
#endif                      
                            if(pLCDHeader->fpControl & PWM_DUTY_POLARITY)
                            {
                                // inverse
                                Level = PWM_MAX_DUTY - Level;
                            }
                            else
                            {
                                // normal
                                Level = PWM_MIN_DUTY + Level;
                            }

                            cbWriteRegByte(pcbe, SR_77, Level); // set SR77=Brightness
                            cbWriteRegBits(pcbe, SR_76, BIT0, PWM_Enable); // set SR76[0]=1 TO ENABLE BackLight control
                            cbWriteRegBits(pcbe, SR_78, BIT0, PWM_Fire); // SET SR78[0] TO Fire
                        }
                    }
                    break;

                case PWM_IOCTL_CBiosQueryMaxPWMLevel:

#if LINUX_PLATFORM
                    pPWMControlParams->bLevel = (PWM_MAX_DUTY-PWM_MIN_DUTY);
#else
                    if(pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL)
                    {
                        pPWMControlParams->bLevel = 0xF;    // DCON only support 0~F
                    }
                    else
                    {
                        //When PWM_MIN_DUTY and PWM_MAX_DUTY = 0-254,
                        //we set PWM level as 100
                        pPWMControlParams->bLevel = 100;
                    }
#endif
                    break;

                case PWM_IOCTL_CBiosGetCurrentPWMLevel:

                    {
                        if(pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL)
                        {
                            I2C_CONTROL_UMA i2c;

                            // get Device associate I2C setting
                            cbGetDII2Csetting(pcbe, &i2c, S3_LCD); // update I2C port and subaddr
                            i2c.RegIndex = 0x0A; // screen will turn off that is "blank" and "sleep". 
                            i2c.IndexWData = 0;
                            I2C_Read_Word_INV(pcbe, &i2c);
                            pPWMControlParams->bLevel = (BYTE)i2c.IndexWData;   // backlight brightness register
                        }
                        else
                        {
                            BYTE panelID = 0, tempByte = 0, Level = 0;
                            
                            tempByte=cbReadRegByte(pcbe, SR_76);
                            
                            if(tempByte & BIT0) //if PWM control enabled
                            {
                                WORD offsetLCDHeader;
                                PFPHeaderData pLCDHeader;
                                // we only support one PWM, always select first panel ID
                                panelID = pcbe->sPad_4.LCD_DVI2_PanelID;

                                offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
                            
                                pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
                                pLCDHeader += panelID;
                                
                                tempByte=cbReadRegByte(pcbe, SR_77);
                                
                                if(pLCDHeader->fpControl & PWM_DUTY_POLARITY)
                                {
                                    // inverse
                                    Level = PWM_MAX_DUTY - tempByte;
                                }
                                else
                                {
                                    // normal
                                    Level = tempByte - PWM_MIN_DUTY;
                                }
#if !LINUX_PLATFORM
                                // beacuse of low precision, the level may not equal to actual value
                                // so , wo add 0.66 to adjust the result value.
                                Level = (BYTE)((100*50*Level/127 + 66)/100); //transfer the level to 0-100
#endif                            
                                pPWMControlParams->bLevel = Level;

                            }
                            else //if PWM control disabled
                            {
                                pPWMControlParams->bLevel = 0;
                            } 
                        }
                    }
                    break;

                case PWM_IOCTL_CBiosSetPWMCLKSrc:

                    if (pcbe->ChipCaps.NEW_PWM_SRC_CLOCK_SEL == TRUE)
                    {
                        // VT3410 SR78[2:1] new clock source selection
                        // 00: 14.318MHz / ((SRC8[7:0]+1) x 2 x 256)
                        // 01: 14.318MHz / (4 x (SRC8[7:0]+1) x 2 x 256)
                        // 02: 14.318MHz / (128 x (SRC8[7:0]+1) x 2 x 256)
                        // 03: 14.318MHz / (16384 x (SRC8[7:0]+1) x 2 x 256) 
                        // to fit the API spec, now 410 only support  14.318MHz / 512,  14.318MHz / 1024.
                        cbWriteRegByte(pcbe, SR_C8, 0);      
                        switch(pPWMControlParams->bCLKSrc)
                        {
                            case 0:
                            case 1:
                            case 2:                            
                                cbDbgPrint(0, "Want to Set PWM clock source to 14.318MHz/%d change to 14.318MHz/512\n", (pPWMControlParams->bCLKSrc+1)*128);
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_8);
                                break;

                            case 3:
                            default:                            
                                cbWriteRegByte(pcbe, SR_C8, 1);
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_8);
                                break;
                        }                    
                    }
                    else
                    {
                        switch(pPWMControlParams->bCLKSrc)
                        {
                            case 0:
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_8);
                                break;

                            case 1:
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_16);
                                break;

                            case 2:
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_32);
                                break;

                            case 3:
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_64);
                                break;

                            default:
                                cbWriteRegBits(pcbe, SR_78, BIT2+BIT1, PWM_CLK_DIV_64);
                                break;
                        }
                    }
                    break;

                case PWM_IOCTL_CBiosQueryMaxPWMCLKSrc:

                    //temp, need to refine for 353/409(SR78[2:1]) and 410(SR78+SRC8[7:0]) later
                    pPWMControlParams->bCLKSrc = 4;
                    break;

                case PWM_IOCTL_CBiosGetCurrentPWMCLKSrc:
                    if (pcbe->ChipCaps.NEW_PWM_SRC_CLOCK_SEL == TRUE)
                    {
                        switch(cbReadRegByte(pcbe, SR_78) & (BIT2+BIT1))
                        {
                            case 0:
                            case BIT1:
                            case BIT2:
                                pPWMControlParams->bCLKSrc = 2;
                                break;

                            case BIT1+BIT2:
                                pPWMControlParams->bCLKSrc = 3;
                                break;

                            default:
                                ASSERT(FALSE);
                                pPWMControlParams->bCLKSrc = 3;
                                break;
                        }                
                    }
                    else
                    {
                        switch(cbReadRegByte(pcbe, SR_78) & (BIT2+BIT1))
                        {
                            case 0:
                                pPWMControlParams->bCLKSrc = 0;
                                break;

                            case BIT1:
                                pPWMControlParams->bCLKSrc = 1;
                                break;

                            case BIT2:
                                pPWMControlParams->bCLKSrc = 2;
                                break;

                            case BIT1+BIT2:
                                pPWMControlParams->bCLKSrc = 3;
                                break;

                            default:
                                ASSERT(FALSE);
                                pPWMControlParams->bCLKSrc = 3;
                                break;
                        }
                    }
                    break;

                default:
                    
                    //invalid IOCTL
                    ASSERT(FALSE);
                    return CBIOS_ER_NOT_SUPPORT;
            }
        }
    }
    else
    {
        // disable PWM control
        ASSERT(FALSE);
        cbWriteRegBits(pcbe, SR_76, BIT0, PWM_Disable);
        return CBIOS_ER_LACKOFVCPDATA;
    }

    return CBIOS_OK;
}

/*********************************************************************************
* CBiosSetCallBackFunctions
* This function set callback function pointer from driver to CBIOS
* IN :
* callback function pointer table
* OUT :
* NULL
**********************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosSetCallBackFunctions(
    PVOID pvcbe, 
    IN PCBIOS_CALLBACK_FUNCTIONS pFnCallBack)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    if (pFnCallBack == NULL) {
        return CBIOS_ER_INVALID_PARAMETER;
    }

    cbDelayMicroSeconds = (pFnCallBack->pFnDelayMicroSeconds != NULL) ? (pFnCallBack->pFnDelayMicroSeconds) : cbDelayNull;
    cbSleepMicroSeconds = (pFnCallBack->pFnSleepMicroSeconds != NULL) ? (pFnCallBack->pFnSleepMicroSeconds) : cbSleepNull;
#if DBG    
    cbDbgPrint = (pFnCallBack->pFnDbgPrint != NULL) ? (pFnCallBack->pFnDbgPrint) : cbDbgPrintNull;
#endif    
    cbReadUchar = pFnCallBack->pFnReadUchar;
    cbWriteUchar = pFnCallBack->pFnWriteUchar;
    cbReadUshort = pFnCallBack->pFnReadUshort;
    cbWriteUshort = pFnCallBack->pFnWriteUshort;
#if !LINUX_PLATFORM
    cbReadMMIOUlong = pFnCallBack->pFnReadMMIOUlong;
    cbWriteMMIOUlong = pFnCallBack->pFnWriteMMIOUlong;
#endif

    if ((cbDelayMicroSeconds  == NULL)||
        (cbSleepMicroSeconds == NULL)||
#if DBG    
        (cbDbgPrint == NULL)||
#endif       
        (cbReadUchar == NULL)||
        (cbWriteUchar == NULL)||
        (cbReadUshort == NULL)||
        (cbWriteUshort == NULL)) {
        return CBIOS_ER_INVALID_PARAMETER;
    }
#if !LINUX_PLATFORM
    else if((cbReadMMIOUlong == NULL)||(cbWriteMMIOUlong == NULL)) {
        return CBIOS_ER_INVALID_PARAMETER;
    }
#endif
    else {
        return CBIOS_OK;
    } 
}

/* The DLL must have an entry point, but it is never called */
CBIOS_STATUS DriverEntry(
  IN PVOID DriverObject,
  IN PVOID RegistryPath
)
{
    return CBIOS_OK;
}

/********************************************************************************
* CBiosGetCBiosExtInfo
* This function is used to get independent CBIOS version and size, and report
* the information to driver
* IN :
* NULL
* OUT :
* PCBIOS_EXT_INFO: CBiosVersion & pcbe size
*********************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosGetCBiosExtInfo(
    OUT PCBIOS_EXT_INFO pCBiosExtInfo
)
{
    if (!pCBiosExtInfo) {
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    pCBiosExtInfo->CbiosVer = 0x01000001;
    pCBiosExtInfo->pcbeSize = sizeof(CBIOS_EXTENSION);
    
    return CBIOS_OK;
}

/*********************************************************************************
* CBiosInitCbiosExtParam
* This function is to initialize some basic parameters for pcbe.
* IN :
* Cbios Extension initial parameters
* OUT :
*  NULL
*********************************************************************************/
CBIOS_STATUS CBIOSAPI CBiosInitCbiosExtParam(
    PVOID pvcbe ,
    IN PCBIOS_EXTENSION_INIT_PARAM pCbiosExtInitParam
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    ULONG InitFullParam = 0;

    if (!pCbiosExtInitParam) {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if( pCbiosExtInitParam->SpecifyInitParamFlag == CBE_INIT_PARAM_FULL) {
         InitFullParam = 1;
    }

    /* Below is for CBIOS basic info */
    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_MMIO_BASE)) {
        pcbe->MmioBase = pCbiosExtInitParam->MmioBase;
    }
    
    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_VGA_MMIO_BASE)) {
        pcbe->VGAMmioBase = pCbiosExtInitParam->VGAMmioBase;
    }

    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_PCI_DEVICE_ID)) {
        pcbe->PCIDeviceID = pCbiosExtInitParam->PCIDeviceID;
    }

    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_CHIP_REVISION)) {
        pcbe->ChipRevision = pCbiosExtInitParam->ChipRevision;    
    }

    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_ROM_IMAGE)) {
        /* get RomImage */
        if (pCbiosExtInitParam->RomImage != NULL) {
            /* copy VBIOS ROM image */
            memcpy(pcbe->RomData, pCbiosExtInitParam->RomImage, ROM_SCAN_SIZE);
        } else { 
            /* NULL RomImage */
            pcbe->RomData[0] = '\0';
            cbDbgPrint(1, "Get Rom Image failed!\n");
        }
    }
    /* function cbInitCBE_csr and function:CBIOSinit have been removed
        * But need this block must be move to function:cbCBIOSInfoInit? Now we just put it here
        * because we must do check sum for SYSBIOSInfo(CMOS data) whether driver do it or not */
    if (InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_ROM_SYSTEM_INFO)) {
        if (pCbiosExtInitParam->pSysInfo != NULL) {
            /* check System BIOS information */
            {
                BYTE i;
                PSYSBIOSInfo pSysInfo = (PSYSBIOSInfo)(pCbiosExtInitParam->pSysInfo);
                BYTE length = pSysInfo->Header.Length;
                PBYTE pbyte = (PBYTE)pSysInfo;
                BYTE checksum = 0x00; /* default check sum value */

                if (length > 0) {
                    /* to prevent access violation */
                    length = length > sizeof(SYSBIOSInfo) ? sizeof(SYSBIOSInfo) : length;
                    i=length;
                    while (i-- > 0) {
                        checksum += *pbyte;
                        pbyte++;
                    }
                    
                    if (checksum) {
                        pcbe->SysBiosInfoValid = FALSE;
                        cbDbgPrint(0, "System BIOS information check sum fail!\n");  
                        ASSERT(FALSE);
                    } else {
                        /* checksum success copy system bios information */
                        pcbe->SysBiosInfoValid = TRUE;
                        memset(&pcbe->SysBiosInfo, 0, sizeof(SYSBIOSInfo)); /* clear structure */
                        memcpy(&pcbe->SysBiosInfo, ((PBYTE)pSysInfo), length);
                        /* dump System BIOS Info */
                        cbDbgPrint(0, "System info: BootUpDev = 0x%X \n", pSysInfo->BootUpDev);
                        cbDbgPrint(0, "System info: HDTV_TV_Config = 0x%X \n", pSysInfo->HDTV_TV_Config);
                        cbDbgPrint(0, "System info: FBStartingAddr = 0x%X \n", pSysInfo->FBStartingAddr);
                        cbDbgPrint(0, "System info: LCDPanelID = 0x%X \n", pSysInfo->LCDPanelID);
                        cbDbgPrint(0, "System info: FBSize = 0x%X \n", pSysInfo->FBSize);
                        cbDbgPrint(0, "System info: DRAMDataRateIdx = 0x%X \n", pSysInfo->DRAMDataRateIdx);
                        cbDbgPrint(0, "System info: DualMemoCtrl = 0x%X \n", pSysInfo->DualMemoCtrl);
                        cbDbgPrint(0, "System info: EngineClockModify = 0x%X \n", pSysInfo->EngineClockModify);
                        cbDbgPrint(0, "System info: LCD2PanelID = 0x%X \n", pSysInfo->LCD2PanelID);
                        cbDbgPrint(0, "System info: TVlayout = 0x%X \n", pSysInfo->TVLayOut);
                        cbDbgPrint(0, "System info: SSCCtrl = 0x%X \n", pSysInfo->SSCCtrl);
                        cbDbgPrint(0, "System info: ChipCapability = 0x%X \n", pSysInfo->ChipCapability);
                        cbDbgPrint(0, "System info: LowTopAddress = 0x%X \n", pSysInfo->LowTopAddress);
                        cbDbgPrint(0, "System info: RemapStartAddress = 0x%X \n", pSysInfo->RemapStartAddress);
                        cbDbgPrint(0, "System info: FSBSpeed = 0x%X \n", pSysInfo->FSBSpeed);
                    }
                }
            }
        } else {
            PSYSBIOSInfo pSysInfo = (PSYSBIOSInfo)(&pcbe->SysBiosInfo);
            cbDbgPrint(0, "A fake system info to make sure CBIOS flow normal!!!\n");  
            memset(&pcbe->SysBiosInfo, 0, sizeof(SYSBIOSInfo)); /* clear structure */
            pSysInfo->BootUpDev = 1;        /* CRT only */
            pSysInfo->LCDPanelID = 0x2;     /* 10x7 panel */
            pSysInfo->FBSize = 0x40;        /*  64M */
            pSysInfo->DRAMDataRateIdx = 0xA0;   /* DDR3-1066 */
            pcbe->SysBiosInfoValid = TRUE;
        }
    }
    /*  Below is for CBIOS basic info version 0.2 */
    if(InitFullParam || (pCbiosExtInitParam->SpecifyInitParamFlag & CBE_INIT_PARAM_BASIC_INFO_VER)) {
        if (pCbiosExtInitParam->CBiosBasicInfoVer >= 0x01000002 &&
            pCbiosExtInitParam->CBiosBasicInfoVer <= CBIOS_BASIC_INFO_VERSION) {
            return CBIOS_ER_NOT_YET_IMPLEMENTED;
        }
    }   
    return CBIOS_OK;
}

//********************************************************************************
// CBiosInterruptRoutine
//    This Cbios interface will handle all HW interrupt if Cbios wants to. 
//    If Cbios do not care about this interrupt, Cbios will just return CBIOS_OK. 
//    By now, we only care about hotplug interrupt
//  IN :
//      pHWInterrupt: pointer of CBIOS_INTERRUPT, representing the HW interrupt regs.
//  OUT :
//      NULL
//********************************************************************************
CBIOS_STATUS CBIOSAPI CBiosInterruptRoutine (
    PVOID pvcbe, 
    IN PCBIOS_INTERRUPT pHWInterrupt
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    PDigitalPortInfo PDIPort = pcbe->DIPort;
    BOOL IsInterrupted = FALSE;
    BYTE i;
    
    if (!pHWInterrupt)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if(pHWInterrupt->InterruptControlReg1 & HW_INTERRUPT_ENABLED)
    {
        for(i=0; i<DigitalPortNUM; i++)
        {
            //By now, only handle INTERRUPT0(LVDS) and INTERRUPT1(TMDS) case
            // add DP/DP2 INTERRUPT handle
            if(PDIPort[i].PortInfo.DIPORTMISC & USING_LVDS_HPD_INTERRUPT)
            {
                //LVDS Interrupt enabled on this DI port
                //This interrupt will be used in get EDID functions.
                if(pHWInterrupt->InterruptControlReg1 & HW_LVDS_HPD_INT_ENABLED)
                {
                    IsInterrupted = (pHWInterrupt->InterruptControlReg1 & HW_LVDS_HPD_INT_INTERRUPTED) ? TRUE : FALSE ;
                }
            }
            else if(PDIPort[i].PortInfo.DIPORTMISC & USING_TMDS_HPD_INTERRUPT)
            {
                //TMDS Interrupt enabled on this DI port
                //This interrupt will be used in get EDID functions.
                if(pHWInterrupt->InterruptControlReg1 & HW_TMDS_HPD_INT_ENABLED)
                {
                    IsInterrupted = (pHWInterrupt->InterruptControlReg1 & HW_TMDS_HPD_INT_INTERRUPTED) ? TRUE : FALSE ;
                }
            }
            else if(PDIPort[i].PortInfo.DIPORTMISC & USING_DP_HPD_INTERRUPT)
            {
                //DP Interrupt enabled on this DI port
                //This interrupt will be used in get EDID functions.
                if(pHWInterrupt->InterruptControlReg3 & HW_DP_HPD_INT_ENABLED)
                {
                    IsInterrupted = (pHWInterrupt->InterruptControlReg3 & HW_DP_HPD_INT_INTERRUPTED) ? TRUE : FALSE ;
                }
            }
            else if(PDIPort[i].PortInfo.DIPORTMISC & USING_DP2_HPD_INTERRUPT)
            {
                //DP2 Interrupt enabled on this DI port
                //This interrupt will be used in get EDID functions.
                if(pHWInterrupt->InterruptControlReg3 & HW_DP2_HPD_INT_ENABLED)
                {
                    IsInterrupted = (pHWInterrupt->InterruptControlReg3 & HW_DP2_HPD_INT_INTERRUPTED) ? TRUE : FALSE ;
                }
            }
            
            if(IsInterrupted)
            {
                // DI port interrupt happened, so handle it in below
                // One interrupt each time, so if finish processing, break
                cbDIPortHPDIntProcess(pcbe, &pcbe->DIPort[i]);
                break;
            }
        }
    }
    return CBIOS_OK;
}

CBIOS_STATUS CBIOSAPI CBiosIsCBiosAvailable(
    IN BYTE *pVBiosRom,
    IN ULONG RomLen,
    OUT BOOL *pbAvailable
)
{
    PVCPInfo pVCP;

    *pbAvailable=FALSE;
    if(cbGetVCPInfo_UMA(pVBiosRom, &pVCP))
    {
        if(pVCP->miscConfigure2 & DRVWRAPPER_USING_CILDRV_BIT)
        {
            *pbAvailable=TRUE;
        }
    }
    return CBIOS_OK;
}

//********************************************************************************
// CBiosGetVersion
//    This Cbios interface will get CBIOS version for driver. Driver will judge
// some interface call or new feature by CBIOS version.
//  IN :
//      pcbe
//  OUT :
//      PCBIOS_VERSION
//********************************************************************************

CBIOS_STATUS CBIOSAPI
CBiosGetVersion(PVOID pvcbe, OUT PCBIOS_VERSION pCbiosVersion)
{
    if(pCbiosVersion == NULL)
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    // Means Trunk/Branch driver.
    pCbiosVersion->BranchDriverNumber = CBIOS_VERSION_BRANCH;
    // Big change such as structure modification 
    pCbiosVersion->MajorVersionNumber = CBIOS_VERSION_MAJOR;
    // If add new feature, increase this version number
    pCbiosVersion->MediumVersionNumber = CBIOS_VERSION_FEATURE;
    // For issue fixed only. Every release, increase this version number.
    pCbiosVersion->MinorVersionNumber = CBIOS_VERSION_MINOR;      
    
    return CBIOS_OK;    
}

//********************************************************************************
//Input: strFunName: The string of function name
//       pulFuncPointer: The memory space to store function address.
//Notes: 
//       After now, Any new interface added, An entry about this new interface must
//       be added in static array FuncName[], and and new if condition must be added in 
//       this function.
//********************************************************************************
CBIOS_STATUS CBIOSAPI
CBiosGetProcAddress(PVOID pvcbe, IN char* strFunName, IN OUT CBIOSPROC *pulFuncPointer)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    CBIOS_PROC_ADDR *pfunPtr = FunctionPointerTbl;
    if (!pulFuncPointer|| !strFunName)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    while( pfunPtr->str != NULL && 
           pfunPtr->funcPointer != NULL )
    {
        if( cbStrncmp(strFunName, pfunPtr->str, pfunPtr->strLen)==0 )
        {
            *pulFuncPointer = (CBIOSPROC)pfunPtr->funcPointer;
            return CBIOS_OK;
        }
        pfunPtr++;
    }
    
    return CBIOS_ER_NOT_YET_IMPLEMENTED;
}

//-------------------------Secondary generation cbios interface definition-------------------------
// Add a dummy interface for example as below:
//********************************************************************************
// CBiosDummyFunction
//    This Cbios interface is an example for adding new CBIOS interface, only for 
// internal reference, won't updated to spec.
//  IN :
//      pcbe
//  OUT :
//      PCBIOS_DUMMY
//********************************************************************************
#if DBG    
CBIOS_STATUS CBIOSAPI
CBiosDummyFunction(void* pvcbe, IN OUT PCBIOS_DUMMY pdummy)
{
    int drv_size = pdummy->size;              //driver known size of the structure
    pdummy->size = sizeof(CBIOS_DUMMY);       //CBIOS known size of the structure
    if(drv_size < sizeof(CBIOS_DUMMY))        //CBIOS version newer than driver side
    {
        //if driver use older version cbios interface,we should provide only the info
        //that driver recognizes,or it will cause stack corruption
        pdummy->var1 = 0x10;
    }
    else                                      //CBIOS version equal or older than driver side
    {
        //if driver use equal or newer version cbios interface, we should provide
        //all info that we cbios knows.
        pdummy->var1 = 0x10;
        pdummy->var2 = 0x20;
    }
    return CBIOS_OK;
}
#endif

//********************************************************************************
// CBiosUpdateOutputDeviceToVBIOS
//    Update output device to VBIOS scratch pad register. To make sure VBIOS can 
// take accurcy action of driver wanted.
//  IN :
//      pcbe
//      outputdevice: the output device want to update to scratch pad register
//  OUT :
//      CBIOS_STATUS
//********************************************************************************
CBIOS_STATUS CBIOSAPI
CBiosUpdateOutputDeviceToVBIOS(PVOID pvcbe, IN DWORD outputdevice)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    BYTE _CR3B=0;
    BYTE _CR4D=0;
    BYTE _CR3C=0;
    BYTE _CR3E_SDW=0;

    _CR3B = (BYTE) (outputdevice & 0xFF);

    if(pcbe->pVCPInfo != NULL)
    {
        if ( (pcbe->pVCPInfo->version >= VCP1_5) &&
             (pcbe->ChipCaps.S3_device_define_for_324) )
        {
            if(outputdevice & S3_HDTV)
            {
                _CR3B &= ~S3_HDTV;
                _CR3B |= WORD_HDTV;
            }

            if(outputdevice & S3_CRT2)
            {
                _CR3B &= ~S3_CRT2;
            }
            
            if (outputdevice & S3_LCD2)
            {
                _CR3B |= WORD_LCD2;
            }
        }
    }
    cbWriteRegByte(pcbe, CR_3B, _CR3B);

    /****************** Scratch pad 7 ******************/
    if (outputdevice & S3_HDMI)    // Check bit9 for HDMI device
    {
        _CR4D |= BIT7; //scratch pad 7[7] HDMI
    }
    cbWriteRegBits(pcbe, CR_4D, BIT7, _CR4D);

    /****************** Scratch pad 11******************/
    // For 324, we should translate word define device to s3 define here.
    if(pcbe->pVCPInfo != NULL)
    {
        if ( (pcbe->pVCPInfo->version >= VCP1_5) &&
             (pcbe->ChipCaps.S3_device_define_for_324) )
        {
            if (outputdevice & S3_CRT2)  // scratch pad 11[4] CRT2
            {
                _CR3C |= BIT4;
            }
        }
        else
        {
            if (outputdevice & S3_LCD2)  // scratch pad 11[4] LCD2
            {
                _CR3C |= BIT4;
            }
        }
    }
    cbWriteRegBits(pcbe, CR_3C, BIT4, _CR3C);


    /****************** Shadow Scratch ******************/
    // transfer to access shadow scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, BIT0);

    /****************** Shadow Scratch pad 3******************/
    // ****HDMI2 device bit
    if (outputdevice & S3_HDMI2)
    {
        _CR3E_SDW |= BIT0;
    }

    // ****DP device bit
    if (outputdevice & S3_DP)
    {
        _CR3E_SDW |= BIT1;
    }

    // ****DP2 device bit
    if (outputdevice & S3_DP2)
    {
        _CR3E_SDW |= BIT2;
    }
    cbWriteRegBits(pcbe, CR_3E, BIT0+BIT1+BIT2, _CR3E_SDW);

    // transfer to access normal scratch pad
    cbWriteRegBits(pcbe, SR_5A, BIT0, 0);

    return CBIOS_OK;
}

//*****************************************************************************
//
//  CBiosSetCPUDirectAccessFB
//
//      This function set CPU direct access frame buffer from GFX
//
//  Parameters:
//      IN :
//      BOOL : Flag
//  Return Value:
//      CBIOS_STATUS
//*****************************************************************************
CBIOS_STATUS CBIOSAPI CBiosSetCPUDirectAccessFB (
    PVOID pvcbe, 
    IN OUT BOOL flag
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;

    if(flag)
    {
        // enable CPU direct access FB
        cbWriteRegBits(pcbe, SR_B9, BIT1, BIT1);
    }
    else
    {
        // disable CPU direct access FB
        cbWriteRegBits(pcbe, SR_B9, BIT1, 0);
    }
    
    return CBIOS_OK;    
}

CBIOS_STATUS CBIOSAPI CBiosSetHDMIAVMute(
    PVOID pvcbe, 
    IN PCBios_HDMI_FuncOnOff pAVMute
)
{
    PCBIOS_EXTENSION    pcbe = pvcbe;
    DWORD               dispDev = pAVMute->dispDev;
    BOOL                OnOffAVMute = pAVMute->FuncOnOff;
    BYTE                TxType;
    I2C_CONTROL_UMA     i2c;

    i2c.Flags = 0;

    // get i2c info first
    if (!cbGetDII2Csetting(pcbe, &i2c, dispDev))
    {
        return CBIOS_ER_DDCRead; 
    }

    if (cbGetDITXtype(pcbe, &TxType, dispDev) == FALSE)
    {
        return CBIOS_ER_DDCRead;
    }

    switch(TxType)
    {
       case INTERNAL_DP:
            if(OnOffAVMute)    // setAVMute
            {
                cbWriteMMIOUlongBits(pcbe, 0xC294, BIT3+BIT2, BIT2); //HDMI Avmute
                cbSleepMicroSeconds(100000);
            }
            else// unMute
            {
                cbSleepMicroSeconds(100000);
                cbWriteMMIOUlongBits(pcbe, 0xC294, BIT3+BIT2, BIT3+BIT2); //HDMI Avmute
            }
            break;
        default:
            break;
    }

    return CBIOS_OK; 
}

CBIOS_STATUS CBIOSAPI CBiosSetHDMIAudio(
    PVOID pvcbe, 
    IN PCBios_HDMI_FuncOnOff pAudioOnOff
)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    i2c.Flags = 0;

    // get i2c info first
    if (!cbGetDII2Csetting(pcbe, &i2c, pAudioOnOff->dispDev))
    {
        return CBIOS_ER_LACKOFCBIOSDATA;
    }

    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TXType, pAudioOnOff->dispDev) == FALSE)
    {
        return CBIOS_ER_LACKOFCBIOSDATA;
    }


    switch(TXType)
    {
        case AD9389B:
            i2c.RegIndex  = 0x44;     // SPDIF enable at bit 7
            if(pAudioOnOff->FuncOnOff)
                i2c.IndexData = 0xF8; // Audio on
            else
                i2c.IndexData = 0x78; // Audio off
            I2C_Write_Byte_INV(pcbe, &i2c); 

            break;
        case INTERNAL_DP:
            break;
            
        default:
            cbDbgPrint(0, "HDMI Audio not found. \n");
            break;
    }
    
    return CBIOS_OK;
}

CBIOS_STATUS CBIOSAPI CBiosSetHDACConnectStatus(
    PVOID   pvcbe,
    BOOL    *bEnable)
{
    PCBIOS_EXTENSION    pcbe = pvcbe;
    
    cbSetHDAudioConnectStatus(pcbe, *bEnable);
    return CBIOS_OK;
}

CBIOS_STATUS CBIOSAPI CBiosSetUSBHandle(
    PVOID pvcbe,
    PCBios_USB_HANDLE phUSB)
{
    PCBIOS_EXTENSION    pcbe = pvcbe;
    CBIOS_STATUS status = CBIOS_OK;
   
    pcbe->phUSB_BULKREAD = phUSB->phUSB_BULKREAD;
    pcbe->phUSB_REGWRITE = phUSB->phUSB_REGWRITE;
    pcbe->phUSB_MEMWRITE = phUSB->phUSB_MEMWRITE;
        
    return status;
}


#if !LINUX_PLATFORM
CBIOS_STATUS CBIOSAPI CBiosGetChipSSID(
    PVOID   pvcbe,
    DWORD 	*pChipSSID)
{
    PCBIOS_EXTENSION    pcbe = pvcbe;
    DWORD	tempChipSSID;
	
	if(pcbe->pVCPInfo->version >= VCP1_9)
	{
		tempChipSSID = (WORD)(pcbe->pVCPInfo->Chip_SubSysVenderID);
		tempChipSSID = (tempChipSSID << 16) + (WORD)(pcbe->pVCPInfo->Chip_SubSysemID);
		*pChipSSID = tempChipSSID;
		return CBIOS_OK;
	}
	else
	{
		return CBIOS_ER_NOT_SUPPORT;
	}
}
#endif

INT cbStrncmp(IN CONST CHAR *String1, IN CONST CHAR *String2, IN ULONG Length)
{
    if((String1 == NULL) || (String2 == NULL) || (Length == 0))
    {
        ASSERT(FALSE);
    }

    while(--Length && *String1 && (*String1 == *String2))
    {
        String1++;
        String2++;
    }

    return (*String1 - *String2);
}

CBIOS_STATUS CBIOSAPI CBiosSetIGAPitch(PVOID pvcbe, IN DWORD IGANum, IN DWORD IGAPitch)
{
    PCBIOS_EXTENSION    pcbe = pvcbe;

    if(IGANum == IGA1)
    {    
        // UnLock STD CRTC write protect    // CR11[7]=0
        cbWriteRegBits(pcbe, CR_11, BIT7, 0x00);

        // wirte offset[10:8] to cr35[7:5]
        cbWriteRegBits(pcbe, CR_35, BIT7 + BIT6 + BIT5, (BYTE)((IGAPitch >> 3) & 0xE0));

        // wirte offset[7:0] to cr13
        cbWriteRegByte(pcbe, CR_13, (BYTE)(IGAPitch & 0xFF));
    }
    else if(IGANum == IGA2)
    {
        //set bit [12:11] to CR67[1:0]
        cbWriteRegBits(pcbe, CR_67, BIT1 + BIT0, (BYTE)((IGAPitch >> 8) & 0x03));

        //set bit [13] to CR71[7]
        cbWriteRegBits(pcbe, CR_71, BIT7, (BYTE)((IGAPitch >> 3) & BIT7));

        //set bit [10:3] to CR66[7:0]
        cbWriteRegByte(pcbe, CR_66, (BYTE)(IGAPitch & 0xFF));
    }

    return CBIOS_OK;
}

CBIOS_STATUS CBIOSAPI CBiosInitUEFIInfo(PVOID pvcbe, void *pvgpd)
{

	PCBIOS_EXTENSION    pcbe = pvcbe;

	pcbe->VIA_GFX_PRIVATE_DATA = pvgpd;
	return CBIOS_OK;

}


CBIOS_STATUS CBIOSAPI CBiosGetBiosCaps(
   PVOID   pvcbe,
   DWORD   Dev,
   PVOID 	pvQueryCpas)
{
    PCBIOS_EXTENSION	pcbe = pvcbe;
    PCBIOS_QUERYCAPS  	pQueryCaps = pvQueryCpas;

    if(!pQueryCaps)
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    
    memset(pQueryCaps, 0x0, sizeof(CBIOS_QUERYCAPS));
    
    if(pcbe->ChipCaps.UseEDPOnDP2 == TRUE)
    {
        pQueryCaps->CapsBits.DP2_RequireDetaiTiming = TRUE;
    }
    
    if((pcbe->pVCPInfo->version >= VCP1_7) && (pcbe->pVCPInfo->miscConfigure3 & BIOS_CTL_CMOS_CALLBACK))
    {
        pQueryCaps->CapsBits.BiosControlCMOSCallBack = TRUE;
    }
    
    if(pcbe->pVCPInfo->miscConfigure2 & LCDBKLIGHT_USE_INTERPWM_BIT)
    {
        pQueryCaps->CapsBits.PanelUseInternelPWM = TRUE;
    }
    
    if(pcbe->pVCPInfo->miscConfigure3 & HDMI_ONLY_SUPPORT_720P)
    {
        pQueryCaps->CapsBits.HdmiOnlySupport720P = TRUE;
    }

    if((pcbe->pVCPInfo->version >= VCP1_7) && (pcbe->pVCPInfo->miscConfigure3 & RECOGNIZE_AS_EDP_CONNECT))
    {
        pQueryCaps->CapsBits.RecognizeAsEDPConnect = TRUE;
    }
    return CBIOS_OK;
}

