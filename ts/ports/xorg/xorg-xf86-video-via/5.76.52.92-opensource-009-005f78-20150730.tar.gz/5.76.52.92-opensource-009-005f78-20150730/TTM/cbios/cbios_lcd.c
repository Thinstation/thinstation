/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"
#include "cbios_sub_func.h"

// LCD Panel Information
#define DitheringEnable 1
#define DitheringDisable 0

LCD_Info LCD_Info_Tbl[] = 
{
// LCD_ID, H_Size, V_Size, Channel, bDisthering     
    {0x00, 640, 480, 1, DitheringEnable},
    {0x01, 800, 600, 1, DitheringEnable},
    {0x02, 1024, 768, 1, DitheringEnable},
    {0x03, 1280, 768, 1, DitheringEnable},
    {0x04, 1280, 1024, 2, DitheringEnable},
    {0x05, 1400, 1050, 2, DitheringEnable},
    {0x06, 1600, 1200, 2, DitheringEnable},
    {0x07, 1280, 800, 1, DitheringEnable},
    {0x08, 800, 480, 1, DitheringEnable},
    {0x09, 1024, 768, 2, DitheringEnable},
    {0x0A, 1024, 768, 1, DitheringDisable},
    {0x0B, 1024, 768, 2, DitheringDisable},
    {0x0C, 1280, 768, 1, DitheringDisable},
    {0x0D, 1280, 1024, 2, DitheringDisable},
    {0x0E, 1400, 1050, 2, DitheringDisable},
    {0x0F, 1600, 1200, 2, DitheringDisable},
    {0xFF, 0xFFFF, 0xFFFF, 0xFF, 0xFF}
};

BOOL cbGetLCDPanelInfo_UMA(PCBIOS_EXTENSION pcbe, IN DWORD device, OUT PLCD_Info pLCDInfo)
{

    BYTE panelID= 0;
    if(device == S3_LCD)
    {
        panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
    }
    else if(device == S3_LCD2)
    {
        panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
    }
    else
    {
        // Incorrect device bit, add an assert for convenient debug
        ASSERT(0);
    }

    if(NULL != pcbe->pVCPInfo)
    {
        if (0 != pcbe->pVCPInfo->LCDInfoHeader)
        {
            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
            {
                PFPHeaderData pLCDHeader = (PFPHeaderData)&(pcbe->RomData[offsetLCDHeader]);
                WORD offsetLCDEntry = pLCDHeader[panelID].fpEntryPoint;
                WORD offsetLCDTable = *( (WORD*)&(pcbe->RomData[offsetLCDEntry]));
                PLCDInitTbl pLCDTable = (PLCDInitTbl)&(pcbe->RomData[offsetLCDTable]);

                pLCDInfo->LCD_ID = panelID;
                pLCDInfo->H_Size = pLCDTable->H_DisEnd;
                pLCDInfo->V_Size = pLCDTable->V_DisEnd;
                pLCDInfo->bDithering = (pLCDHeader[panelID].fpControl & EN_DITHERING) ? TRUE :FALSE;
                pLCDInfo->Channel = (pLCDHeader[panelID].fpControl & DUAL_CHANNEL) ? 2 :1;

                return TRUE;
            }
            else // LCD 1+2
            {
                PLCDInitTbl12 pLCDInitTbl;
                PFPHeaderData12 pLCDHeader = (PFPHeaderData12)&(pcbe->RomData[offsetLCDHeader]);
                // When LCD 1+2 , always use LCD1 to get timing table
                pLCDHeader += pcbe->sPad_4.LCD_DVI2_PanelID;

                // get LCD init table pointer;
                if (cbGetLCD12InitTbl(pcbe, &pLCDInitTbl))
                {
                    pLCDInfo->LCD_ID = pcbe->sPad_4.LCD_DVI2_PanelID;
                    pLCDInfo->H_Size = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDInitTbl, H_DIS_END);
                    pLCDInfo->V_Size = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDInitTbl, V_DIS_END);
                    pLCDInfo->bDithering = (pLCDHeader->fpControl & EN_DITHERING) ? TRUE :FALSE;
                    pLCDInfo->Channel = (pLCDHeader->fpControl & DUAL_CHANNEL) ? 2 :1;
                    return TRUE;
                }
                else
                {
                    return FALSE;
                }
            }
        }
    }
    else
    {
        BYTE i;

        for(i = 0; LCD_Info_Tbl[i].LCD_ID != 0xFF; i ++)
        {
            if(LCD_Info_Tbl[i].LCD_ID == panelID)
            {
                *pLCDInfo = LCD_Info_Tbl[i];
                return TRUE;
            }
        }
    }

    return FALSE;
}

//-----------------------------------------------------------------------------
//cbGetExpandScalingFactor
//    This function calculates H / V scaling factor with given resolution & lcd
// physical size.
//  IN :
//             Resolution : Source mode H / V resolution
//   LCDPanelPhysicalSize : LCD panel Physical size
//                   Type : H_SCALING_FACTOR / V_SCALING_FACTOR
//   OUT :
//       Scaling factor value
//----------------------------------------------------------------------------
WORD cbGetExpandScalingFactor(WORD Resolution, WORD LCDPanelPhysicalSize, enum _TIMING_REG_TYPE Type)
{
    if(Type == H_SCALING_FACTOR)
    {
        return (WORD)(Resolution * 4096 / LCDPanelPhysicalSize);
    }
    else // V scaling factor
    {
        // since V scaler use line duplicate
        // if less scale case (scaler is bigger), there will be garbage on device screen
        // if over scale case (scaler is less),   the bottom line will disappear.
        // since when with driver, we are more sensitive about garbage  so we choose the second solution
        return (WORD)(Resolution * 2048 / LCDPanelPhysicalSize); 
    }
}

//-----------------------------------------------------------------------------
//cbGetDownScalingFactor
//    This function calculates H / V scaling factor with given resolution & lcd
// physical size.
//  IN :
//             Resolution : Source mode H / V resolution
//   LCDPanelPhysicalSize : LCD panel Physical size
//                   Type : H_SCALING_FACTOR / V_SCALING_FACTOR
//   OUT :
//       Scaling factor value
//----------------------------------------------------------------------------
WORD cbGetDownScalingFactor(WORD Resolution, WORD LCDPanelPhysicalSize, enum _TIMING_REG_TYPE Type)
{
    if(Type == H_SCALING_FACTOR)
    {
        return (WORD)((Resolution - LCDPanelPhysicalSize) * 4096 / LCDPanelPhysicalSize);
    }
    else // V scaling factor
    {
        return (WORD)((Resolution - LCDPanelPhysicalSize) * 2048 / LCDPanelPhysicalSize); 
    }
}

//=============================================================================
// below is new sub functions
//=============================================================================

//-----------------------------------------------------------------------------
//cbGetVBIOSPanelTimingTable
//    This function will get the LCD panel timing from vbios vcp according to the timing table
//  which our CBIOS can recognize
//  IN :
//      device : LCD or LCD2
//
//   OUT :
//       pTimingTbl: Timing table returned
//----------------------------------------------------------------------------
BOOL cbGetVBIOSPanelTimingTable(
    PCBIOS_EXTENSION pcbe,
    IN DWORD device,
    OUT PGFXTimingTable pTimingTbl
)
{

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if ((0 == pcbe->pVCPInfo) || (0 == pcbe->pVCPInfo->LCDInfoHeader))
    {
        return FALSE;
    }
    else
    {

        BYTE panelID = 0;
        WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
        if(device == S3_LCD)
        {
            panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
        }
        else if(device == S3_LCD2)
        {
            panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
        }
        else
        {
        // Incorrect device bit, add an assert for convenient debug
            ASSERT(0);
        }

        if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
        {
            // get LCD timing table
            PFPHeaderData pLCDHeader = (PFPHeaderData)&(pcbe->RomData[offsetLCDHeader]);
            WORD offsetLCDEntry = pLCDHeader[panelID].fpEntryPoint;
            WORD offsetLCDTable = *( (WORD*)&(pcbe->RomData[offsetLCDEntry]));
            PLCDInitTbl pLCDTable = (PLCDInitTbl)&(pcbe->RomData[offsetLCDTable]);
            pLCDHeader += panelID;
            
            // fill timing info
            pTimingTbl->rRateX100 = 60 * 100;
            pTimingTbl->vPLL = pLCDTable->IGA2_PLL;
            pTimingTbl->Interlaced = PROGRESSIVE;

            // horizontal
            if (pLCDHeader->fpControl & NEG_H_POLARITY)
            {
                pTimingTbl->HPolarity = CBIOS_NEGATIVE;
            }
            else
            {
                pTimingTbl->HPolarity = CBIOS_POSITIVE;
            }
            pTimingTbl->HTotal      = pLCDTable->H_Total;
            pTimingTbl->HDisEnd     = pLCDTable->H_DisEnd;
            pTimingTbl->HBlankStart = pLCDTable->H_BnkSt;
            pTimingTbl->HBlankEnd   = pLCDTable->H_BnkEnd;
            pTimingTbl->HSyncStart  = pLCDTable->H_SyncSt;
            pTimingTbl->HSyncEnd    = pLCDTable->H_SyncEnd;

            // vertical
            if (pLCDHeader->fpControl & NEG_V_POLARITY)
            {
                pTimingTbl->VPolarity = CBIOS_NEGATIVE;
            }
            else
            {
                pTimingTbl->VPolarity = CBIOS_POSITIVE;
            }
            pTimingTbl->VTotal      = pLCDTable->V_Total;
            pTimingTbl->VDisEnd     = pLCDTable->V_DisEnd;
            pTimingTbl->VBlankStart = pLCDTable->V_BnkSt;
            pTimingTbl->VBlankEnd   = pLCDTable->V_BnkEnd;
            pTimingTbl->VSyncStart  = pLCDTable->V_SyncSt;
            pTimingTbl->VSyncEnd    = pLCDTable->V_SyncEnd;
        }
        else //LCD 1+2
        {
            // When LCD 1+2 , always use LCD1 to get timing table
            PLCDInitTbl12 pLCDTbl;
            PFPHeaderData12 pLCDHeader = (PFPHeaderData12)&(pcbe->RomData[offsetLCDHeader]);
            pLCDHeader += pcbe->sPad_4.LCD_DVI2_PanelID;

            // get LCD init table pointer;
            if (cbGetLCD12InitTbl(pcbe, &pLCDTbl))
            {
                // fill timing structure by LCD 1+2 table define;
                pTimingTbl->rRateX100 = 60 * 100;
                pTimingTbl->vPLL = pLCDTbl->IGA2_PLL;
                pTimingTbl->Interlaced = PROGRESSIVE;
                
                // horizontal
                if(pLCDHeader->fpControl & NEG_H_POLARITY)
                {
                    pTimingTbl->HPolarity = CBIOS_NEGATIVE; // negative H sync
                }
                else
                {
                    pTimingTbl->HPolarity = CBIOS_POSITIVE;
                }
                pTimingTbl->HTotal = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_TOTAL);
                pTimingTbl->HDisEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_DIS_END);
                pTimingTbl->HSyncStart = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_SYNC_ST);
                pTimingTbl->HSyncEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_SYNC_END);
                pTimingTbl->HBlankStart = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_BNK_ST);
                pTimingTbl->HBlankEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, H_BNK_END);
                
                // vertical
                if(pLCDHeader->fpControl & NEG_V_POLARITY)
                {
                    pTimingTbl->VPolarity = CBIOS_NEGATIVE; // negative V sync
                }
                else
                {
                    pTimingTbl->VPolarity = CBIOS_POSITIVE;
                }
                pTimingTbl->VTotal = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_TOTAL);
                pTimingTbl->VDisEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_DIS_END);
                pTimingTbl->VSyncStart = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_SYNC_ST);
                pTimingTbl->VSyncEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_SYNC_END);
                pTimingTbl->VBlankStart = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_BNK_ST);
                pTimingTbl->VBlankEnd = cbGetCRTCValueFromLCD12Tbl(pcbe, pLCDTbl, V_BNK_END);
            }
            else
            {
                return FALSE;
            }
        }

        return TRUE;
    } // if VCP or LCD Header == 0
}

//--------------------------------------------------------------------------
//  cbSetLCDPowerState
//      change LCD PowerState & initial digital port associated
//  For LCD power sequence on / off we need also power on / off 
//   TX power control
//      For TTL 1634 / 1637          :       NB_NO_VEE
//      For VT1636                   :       Rex 09 [7]
//      For Internel LVDS1 LVDS2     :       CRD2 [7:6]
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetLCDPowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    BYTE TXType = TX_NONE;
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    i2c.I2cPort = 0x00; // defualt set I2C port to 0x00
    i2c.RegIndex = 0x01; // DCON display mode register

    if((pcbe->pVCPInfo->version >= VCP1_7) && (pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL))
    {
        if (cbGetDITXtype(pcbe, &TXType, S3_LCD) && (TXType == TTL_PANEL))
        {
            // get Device associate I2C setting
            cbGetDII2Csetting(pcbe, &i2c, S3_LCD); // update I2C port and subaddr
        }
    }

    if(powerstate == S3PM_ON) // turn on LCD
    {
        BYTE    _CR6A = 0;
        BYTE    _CR6B = 0;

        // special func
        // check IGA2 clock before we turn on LCD CL48610
        _CR6A = cbReadRegByte(pcbe, CR_6A);

        // we must check CR6B[3] to determine whether we are in standard mode
        // (specific platform full screen, LCD case) or not. If we are in standard mode,
        // we dont need to check CR6A[7] to power on LCD
        // CR6A[7] = 1 IGA2 power on, CR6B[3] IGA1+IGA2 path
        // VESA mode: CR6A[7] = 1, CR6B[3] = 0
        // standard mode: CR6A[7] = 0, CR6B[3] = 1
        _CR6B = cbReadRegByte(pcbe, CR_6B);
        
        // should aid Data Off/On too fast cause LCD show garbage issue.
        // but should in screen on/off, not here in power control

        if(pcbe->ChipCaps.IGA1_Support_Upscale)
        {
            // no need special check if IGA1 support upscale, vbios will assign IGA1 for lcd output
            cbConfigureDigitalPort(pcbe, S3_LCD, ON);
            cbPanelOnOffCTRL(pcbe, S3_LCD, ON);

            if(i2c.I2cPort != 0x00) // need to control DCON
            {
                i2c.IndexWData = 0x69; // 0x69 will turn it back on, in color mode
                I2C_Write_Word_INV(pcbe, &i2c);
            }

            //update device power statue 
            pcbe->devicepowerstate[LCDbit] = powerstate;
        }
        else
        {

#if !LINUX_PLATFORM
        if((pcbe->devicepowerstate[LCDbit] != S3PM_ON) && 
            ((_CR6A & BIT7) || (_CR6B & BIT3)))
        // Android: need to dig out more detail why LCD only can't turn on monitor after S3 resume
#endif
        {
            cbConfigureDigitalPort(pcbe, S3_LCD, ON);
            cbPanelOnOffCTRL(pcbe, S3_LCD, ON);

            if(i2c.I2cPort != 0x00) // need to control DCON
            {
                i2c.IndexWData = 0x69; // 0x69 will turn it back on, in color mode
                I2C_Write_Word_INV(pcbe, &i2c);
            }

            //update device power statue 
            pcbe->devicepowerstate[LCDbit] = powerstate;
        }
        }
    }
    else 
    {       
        // if LCD on now, we turn off it, else do nothing
        if(pcbe->devicepowerstate[LCDbit] == S3PM_ON)
        {
            cbPanelOnOffCTRL(pcbe, S3_LCD, OFF);
            cbConfigureDigitalPort(pcbe, S3_LCD, OFF);

            if(i2c.I2cPort != 0x00) // need to control DCON
            {
                i2c.IndexWData = 0x12; // screen will turn off that is "blank" and "sleep". 
                I2C_Write_Word_INV(pcbe, &i2c);
            }

            //update device power statue 
            pcbe->devicepowerstate[LCDbit] = powerstate;
        }
    } // if power on
}

//--------------------------------------------------------------------------
//  cbSetLCD2PowerState
//      change LCD2 PowerState & initial digital port associated
//  For LCD power sequence on / off we need also power on / off 
//   TX power control
//      For TTL 1634 / 1637          :       NB_NO_VEE
//      For VT1636                   :       Rex 09 [7]
//      For Internel LVDS1 LVDS2     :       CRD2 [7:6]
//     IN
//        powerstate : ON /OFF  
//--------------------------------------------------------------------------
void cbSetLCD2PowerState(PCBIOS_EXTENSION pcbe, IN PowerState powerstate)
{
    BYTE TXType = TX_NONE;
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    i2c.I2cPort = 0x00; // defualt set I2C port to 0x00
    i2c.RegIndex = 0x01; // DCON display mode register

    if((pcbe->pVCPInfo->version >= VCP1_7) && (pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL))
    {
        if (cbGetDITXtype(pcbe, &TXType, S3_LCD2) && (TXType == TTL_PANEL))
        {
            // get Device associate I2C setting
            cbGetDII2Csetting(pcbe, &i2c, S3_LCD2); // update I2C port and subaddr
        }
    }

    if(powerstate == S3PM_ON) // turn on LCD
    {
        if(pcbe->devicepowerstate[LCD2bit] != S3PM_ON)
        {
            // initial LCD2 related digital port   
            cbConfigureDigitalPort(pcbe, S3_LCD2, ON);
            cbPanelOnOffCTRL(pcbe, S3_LCD2, ON);

            if(i2c.I2cPort != 0x00) // need to control DCON
            {
                i2c.IndexWData = 0x69; // 0x69 will turn it back on, in color mode
                I2C_Write_Word_INV(pcbe, &i2c);
            }
        }
    }
    else 
    {
        // if LCD2 on now, we turn off it, else do nothing
        if(pcbe->devicepowerstate[LCD2bit] == S3PM_ON)
        {
            cbPanelOnOffCTRL(pcbe, S3_LCD2, OFF);
            // LCD2 related digital port off
            cbConfigureDigitalPort(pcbe, S3_LCD2, OFF);       

            if(i2c.I2cPort != 0x00) // need to control DCON
            {
                i2c.IndexWData = 0x12; // screen will turn off that is "blank" and "sleep". 
                I2C_Write_Word_INV(pcbe, &i2c);
            }
        }
    } // if power on
    //update device power statue 
    pcbe->devicepowerstate[LCD2bit] = powerstate;
}

//--------------------------------------------------------------------------
//  cbLCDOnOff_UMA
//  LCD SW power sequence on /off for HardWare TX or IN_LVDS1
//         _____________________________ 
//      __|                             |_______________________ Panel on/off
//              ___________________________________________
//      ___TD0_|      _______________________________      |____ VDD          
//      _________TD1_|      __________________       |_TD1______ DATA   
//      _______________TD2_|      ______      |_TD2_____________ VEE
//      _____________________TD3_|      |_TD3___________________ Back Light
//  IN 
//      device   : which device need to send power sequence
//      operate : ON/OFF
//      bSetSSC:     TRUE: need to on or off SSC acording to operate; FALSE: needn't to operate on SSC
//--------------------------------------------------------------------------
void cbPanelSWPowerSeqenceCTRL(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate, IN BOOL bSetSSC)
{
    ULONG TD0 = 200;
    ULONG TD1 = 25;
    ULONG TD2 = 0;
    ULONG TD3 = 250;
    BYTE panelID = 0;

    BYTE TXType = HARDWIRED_LVDS;
    // get Device associate TX type
    cbGetDITXtype(pcbe, &TXType, device);

    if(device == S3_LCD)
    {
        panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
    }
    else if(device == S3_LCD2)
    {
        panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
    }
    else
    {
        // Incorrect device bit, add an assert for convenient debug
        ASSERT(0);
    }
    if (NULL != pcbe->pVCPInfo)
    {
        if(0 != pcbe->pVCPInfo->LCDInfoHeader)
        {
            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
            {
                PFPHeaderData pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;

                TD0 = pLCDHeader->TD0;
                TD1 = pLCDHeader->TD1;
                TD2 = pLCDHeader->TD2;
                TD3 = pLCDHeader->TD3;
            }
            else // LCD 1+2
            {
                // When LCD 1+2 , always use LCD1 to get timing table
                PFPHeaderData12 pLCDHeader = (PFPHeaderData12)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += pcbe->sPad_4.LCD_DVI2_PanelID;

                TD0 = pLCDHeader->TD0;
                TD1 = pLCDHeader->TD1;
                TD2 = pLCDHeader->TD2;
                TD3 = pLCDHeader->TD3;
            }
        }
    }
    
    if (operate == ON)
    {
        //SW power sequence ON
        cbWriteRegBits(pcbe, CR_91, BIT4, BIT4);  // VDD
        cbDelayMicroSeconds((TD1-1) * 1000);
        // LVDS TX on in SW PS when data on for 324/353
        cbPanelTXCTRL(pcbe, TXType, ON);
       //if need to turn on ssc, ssc dispclko should sync with power sequence data signal
        if(bSetSSC)
        {
            cbOnOffSSC(pcbe, ON);
        }
        cbDelayMicroSeconds( 1000);
        cbWriteRegBits(pcbe, CR_91, BIT3, BIT3);  // Data

        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if(pcbe->ChipCaps.PAD_on_off_in_SW_PS)
        {
            PDigitalPortInfo PDIPort;
            if (cbGetDIPortInfo(pcbe, &PDIPort, device) == TRUE)
            {
                if((PDIPort->PortInfo.TXType == HARDWIRED_LVDS) || (PDIPort->PortInfo.TXType == TTL_PANEL))
                {
                    cbInitPad(pcbe, PDIPort->DIType, ON);
                }
            }
            else
            {
                ASSERT(0);
                cbDbgPrint(1, "Function: cbLCDSWPowerSeqenceCTRL, can not get DI portinfo of LCD !\n");
            }
        }
        cbDelayMicroSeconds(TD2 * 1000);
        cbWriteRegBits(pcbe, CR_91, BIT2, BIT2);  // VEE
        if(pcbe->ChipCaps.VEE_on_off_by_GPIO0)
        {
            cbWriteRegBits(pcbe, SR_25, BIT7+BIT5, BIT7+BIT5);
        }
        cbDelayMicroSeconds(TD3 * 1000);
        cbWriteRegBits(pcbe, CR_91, BIT1, BIT1);  // BLT
    }
    else
    {
        //SW power sequence OFF
        cbWriteRegBits(pcbe, CR_91, BIT1, 0); // BLT
        cbDelayMicroSeconds(TD3 * 1000);
        cbWriteRegBits(pcbe, CR_91, BIT2, 0); // VEE
        if(pcbe->ChipCaps.VEE_on_off_by_GPIO0)
        {
            cbWriteRegBits(pcbe, SR_25, BIT7+BIT5, BIT7);
        }
        cbDelayMicroSeconds(TD2 * 1000);       
        cbWriteRegBits(pcbe, CR_91, BIT3, 0); // Data
        //if need to turn off ssc, ssc dispclko should sync with power sequence data signal
        if(bSetSSC)
        {
            cbOnOffSSC(pcbe, OFF);
        }
        // LVDS TX off in SW PS when data off for 324/353
        cbPanelTXCTRL(pcbe, TXType, OFF);

        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if(pcbe->ChipCaps.PAD_on_off_in_SW_PS)
        {
            PDigitalPortInfo PDIPort;
            if (cbGetDIPortInfo(pcbe, &PDIPort, device) == TRUE)
            {
                if((PDIPort->PortInfo.TXType == HARDWIRED_LVDS) || (PDIPort->PortInfo.TXType == TTL_PANEL))
                {
                    cbInitPad(pcbe, PDIPort->DIType, OFF);
                }
            }
            else
            {
                ASSERT(0);
                cbDbgPrint(1, "Function: cbLCDSWPowerSeqenceCTRL, can not get DI portinfo of LCD !\n");
            }
        }
        cbDelayMicroSeconds(TD1 * 1000);
        cbWriteRegBits(pcbe, CR_91, BIT4, 0); // VDD

        // put VDD off <-> on delay here to speed up S3 resume
        cbDelayMicroSeconds(TD0 * 1000);
    }
}

//--------------------------------------------------------------------------
//  cbLCDSWPowerSeqenceCTRL_LVDS2
//  LCD SW power sequence on /off for IN_LVDS2
//         _____________________________ 
//      __|                             |_______________________ Panel on/off
//              ___________________________________________
//      ___TD0_|      _______________________________      |____ VDD          
//      _________TD1_|      __________________       |_TD1______ DATA   
//      _______________TD2_|      ______      |_TD2_____________ VEE
//      _____________________TD3_|      |_TD3___________________ Back Light
//  IN 
//      device   : which device need to send power sequence
//      operate : ON/OFF
//      bSetSSC:     TRUE: need to on or off SSC acording to operate; FALSE: needn't to operate on SSC
//--------------------------------------------------------------------------
void cbPanelSWPowerSeqenceCTRL_LVDS2(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate, IN BOOL bSetSSC)
{
    ULONG TD0 = 200;
    ULONG TD1 = 25;
    ULONG TD2 = 0;
    ULONG TD3 = 250;
    BYTE panelID = 0;

    BYTE TXType = HARDWIRED_LVDS;
    // get Device associate TX type
    cbGetDITXtype(pcbe, &TXType, device);

    if(device == S3_LCD)
    {
        panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
    }
    else if(device == S3_LCD2)
    {
        panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
    }
    else
    {
        // Incorrect device bit, add an assert for convenient debug
        ASSERT(0);
    }

    if (NULL != pcbe->pVCPInfo)
    {
        if((0 != pcbe->pVCPInfo->LCDInfoHeader))
        {
            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
            {
                PFPHeaderData pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;

                TD0 = pLCDHeader->TD0;
                TD1 = pLCDHeader->TD1;
                TD2 = pLCDHeader->TD2;
                TD3 = pLCDHeader->TD3;
            }
            else // LCD 1+2
            {
                PFPHeaderData12 pLCDHeader = (PFPHeaderData12)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;

                TD0 = pLCDHeader->TD0;
                TD1 = pLCDHeader->TD1;
                TD2 = pLCDHeader->TD2;
                TD3 = pLCDHeader->TD3;
            }
        }
    }

    // here do not need to modify SR25 GPIO pin since for 
    // VT3353 IN_LVDS2 no need to using GPIO reg to power 
    // on / off TX. And for VT3353 SR25 is not defined
    if (operate == ON)
    {
        //SW power sequence ON
        cbWriteRegBits(pcbe, CR_D3, BIT4, BIT4);  // VDD
        if(pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23)
        {
            cbWriteRegBits(pcbe, SR_2C, BIT4+BIT6, BIT4+BIT6);  // GPIO_3 is VDD
        }
        cbDelayMicroSeconds(TD1 * 1000);
        // LVDS TX on in SW PS when data on for 324/353
        cbPanelTXCTRL(pcbe, TXType, ON);
        //if need to turn on ssc, ssc dispclko should sync with power sequence data signal
        if(bSetSSC)
        {
            cbOnOffSSC(pcbe, ON);
        }
        cbWriteRegBits(pcbe, CR_D3, BIT3, BIT3);  // Data

        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if(pcbe->ChipCaps.PAD_on_off_in_SW_PS)
        {
            PDigitalPortInfo PDIPort;
            if (cbGetDIPortInfo(pcbe, &PDIPort, device) == TRUE)
            {
                if((PDIPort->PortInfo.TXType == HARDWIRED_LVDS) || (PDIPort->PortInfo.TXType == TTL_PANEL))
                {
                    cbInitPad(pcbe, PDIPort->DIType, ON);
                }
            }
            else
            {
                ASSERT(0);
                cbDbgPrint(1, "Function: cbLCDSWPowerSeqenceCTRL_LVDS2, can not get DI portinfo of LCD !\n");
            }
        }
        cbDelayMicroSeconds(TD2 * 1000);
        cbWriteRegBits(pcbe, CR_D3, BIT2, BIT2);  // VEE
        cbDelayMicroSeconds(TD3 * 1000);
        cbWriteRegBits(pcbe, CR_D3, BIT1, BIT1);  // BLT
        if(pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23)
        {
            cbWriteRegBits(pcbe, SR_2C, BIT5+BIT7, BIT5+BIT7);  // GPIO_2 is BLT
        }
    }
    else
    {
        //SW power sequence OFF
        cbWriteRegBits(pcbe, CR_D3, BIT1, 0); // BLT
        if(pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23)
        {
            cbWriteRegBits(pcbe, SR_2C, BIT5+BIT7, BIT7);  // GPIO_2 is BLT
        }
        cbDelayMicroSeconds(TD3 * 1000);
        cbWriteRegBits(pcbe, CR_D3, BIT2, 0); // VEE
        cbDelayMicroSeconds(TD2 * 1000);       
        cbWriteRegBits(pcbe, CR_D3, BIT3, 0); // Data
        //if need to turn off ssc, ssc dispclko should sync with power sequence data signal
        if(bSetSSC)
        {
            cbOnOffSSC(pcbe, ON);
        }
        // LVDS TX off in SW PS when data off for 324/353
        cbPanelTXCTRL(pcbe, TXType, OFF);

        // aid for PAD_ON_OFF_IN_SW_PS:
        // PCIE NBs(336/364) data enable bit do not work, So turn on/off PAD to pull up/down data&clock
        // if PAD_ON_OFF_IN_SW_PS and LCD use Software Power squence and TX is HARDWIRED_LVDS
        // Then we control PAD when loading Software PowerSquence
        if(pcbe->ChipCaps.PAD_on_off_in_SW_PS)
        {
            PDigitalPortInfo PDIPort;
            if (cbGetDIPortInfo(pcbe, &PDIPort, device) == TRUE)
            {
                if((PDIPort->PortInfo.TXType == HARDWIRED_LVDS) || (PDIPort->PortInfo.TXType == TTL_PANEL))
                {
                    cbInitPad(pcbe, PDIPort->DIType, OFF);
                }
            }
            else
            {
                ASSERT(0);
                cbDbgPrint(1, "Function: cbLCDSWPowerSeqenceCTRL_LVDS2, can not get DI portinfo of LCD !\n");
            }
        }
        cbDelayMicroSeconds(TD1 * 1000);
        cbWriteRegBits(pcbe, CR_D3, BIT4, 0); // VDD
        if(pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23)
        {
            cbWriteRegBits(pcbe, SR_2C, BIT4+BIT6, BIT6);  // GPIO_3 is VDD
        }

        // put VDD off <-> on delay here to speed up S3 resume
        cbDelayMicroSeconds(TD0 * 1000);
    }
}

//--------------------------------------------------------------------------
//  cbGetLCD12InitTbl
//  Get LCD initial table offset from vbios in LCD IGA1+IGA2 case(for twinhead project)
//     INOUT:ppLCDTbl12,offset of the panel initial table(LCD1+2 case)
//  When LCD 1+2 , always use LCD1 to get timing table
//--------------------------------------------------------------------------
BOOL cbGetLCD12InitTbl(PCBIOS_EXTENSION pcbe, PLCDInitTbl12 *ppLCDTbl12)
{
    BYTE i;
    PFPOffsetData pFPData;
    WORD offset = pcbe->pVCPInfo->LCDInfoHeader;
    BYTE LCDHeadNum = pcbe->RomData[offset-1]; // get Head info number

    // skip all head info
    offset += sizeof(FPHeaderData12) * LCDHeadNum;
    // skip head number
    offset++;
    // now offset is FP info number
    pFPData = (PFPOffsetData)(pcbe->RomData + offset+1);
    for (i=pcbe->RomData[offset]; i>0; i--, pFPData++)
    {
        // search for panel ID
        if (pcbe->sPad_4.LCD_DVI2_PanelID == pFPData->fpSize)
        {
            // panel ID match, get LCD table
            WORD tblOffset = *((PWORD)(pcbe->RomData + pFPData->fpEntryPoint));
            *ppLCDTbl12 = (PLCDInitTbl12)(pcbe->RomData + tblOffset);
            return TRUE;
        }
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbGetCRTCValueFromLCD12Tbl
//     Get CRTC timing value from panel initial timing table in LCD IGA1+IGA2 case
//     IN :
//         pLCDTbl: offset of the panel initial table(LCD1+2 case)
//         RegType: CRTC timing type
//     Return :
//         CRTC timing value
//--------------------------------------------------------------------------
WORD cbGetCRTCValueFromLCD12Tbl(PCBIOS_EXTENSION pcbe, PLCDInitTbl12 pLCDTbl, TIMING_REG_TYPE RegType)
{
    WORD value = 0;

    switch (RegType)
    {
    case H_TOTAL:
        value = pLCDTbl->CR50                               // CR50[7:0]
            + ((pLCDTbl->CR55 & (BIT3+BIT2+BIT1+BIT0)) << 8)// CR55[3:0]
            + 1;                                            // fix for H_TOTAL(-1) on IGA2
        break;

    case H_DIS_END:
        value = pLCDTbl->CR51                               // CR51[7:0]
            + ((pLCDTbl->CR55 & (BIT6+BIT5+BIT4)) << 4)     // CR55[6:4]
            + 1;                                            // fix for H_DIS_END(-1) on IGA2
        break;

    case H_BNK_ST:
        value = pLCDTbl->CR52                               // CR52[7:0]
            + ((pLCDTbl->CR54 & (BIT2+BIT1+BIT0)) << 8)     // CR54[2:0]
            + 1;                                            // fix for H_BNK_ST(-1) on IGA2
        break;

    case H_BNK_END:
        value = pLCDTbl->CR53                               // CR53[7:0]
            + ((pLCDTbl->CR54 & (BIT5+BIT4+BIT3)) << 5)     // CR54[5:3]
            + ((pLCDTbl->CR5D & BIT6) << 5)                 // CR5D[6]
            + 1;                                            // fix for H_BNK_END(-1) on IGA2
        break;

    case H_SYNC_ST:
        value = pLCDTbl->CR56                               // CR56[7:0]
            + ((pLCDTbl->CR54 & (BIT7+BIT6)) << 2)          // CR54[7:6]
            + ((pLCDTbl->CR5C & BIT7) << 3)                 // CR5C[7]
            + ((pLCDTbl->CR5D & BIT7) << 4)                 // CR5D[7]
            + 1;                                            // fix for H_SYNC_ST(-1) on IGA2
        break;

    case H_SYNC_END:
        value = pLCDTbl->CR57                               // CR57[7:0]
            + ((pLCDTbl->CR5C & BIT6) << 2)                 // CR5C[6]
            + ((pLCDTbl->CR54 & BIT7) << 2)                 // CR54[7]
            + ((pLCDTbl->CR5C & BIT7) << 3)                 // CR5C[7]
            + ((pLCDTbl->CR5D & BIT7) << 4)                 // CR5D[7]
            + 1;                                            // fix for H_SYNC_END(-1) on IGA2
        break;

    case V_TOTAL:
        value = pLCDTbl->CR58                               // CR58[7:0]
            + ((pLCDTbl->CR5D & (BIT2+BIT1+BIT0)) << 8)     // CR5D[2:0]
            + 1;                                            // fix for V_TOTAL(-1) on IGA2
        break;

    case V_DIS_END:
        value = pLCDTbl->CR59                               // CR59[7:0]
            + ((pLCDTbl->CR5D & (BIT5+BIT4+BIT3)) << 5)     // CR5D[5:3]
            + 1;                                            // fix for V_DIS_END(-1) on IGA2
        break;

    case V_BNK_ST:
        value = pLCDTbl->CR5A                               // CR5A[7:0]
            + ((pLCDTbl->CR5C & (BIT2+BIT1+BIT0)) << 8)     // CR5C[2:0]
            + 1;                                            // fix for V_BNK_ST(-1) on IGA2
        break;

    case V_BNK_END:
        value = pLCDTbl->CR5B                               // CR5B[7:0]
            + ((pLCDTbl->CR5C & (BIT5+BIT4+BIT3)) << 5)     // CR5C[5:3]
            + 1;                                            // fix for V_BNK_END(-1) on IGA2
        break;

    case V_SYNC_ST:
        value = pLCDTbl->CR5E                               // CR5E[7:0]
            + ((pLCDTbl->CR5F & (BIT7+BIT6+BIT5)) << 3)     // CR5F[7:5]
            + 1;                                            // fix for V_SYNC_ST(-1) on IGA2
        break;

    case V_SYNC_END:
        value = (pLCDTbl->CR5F & (BIT4+BIT3+BIT2+BIT1+BIT0))// CR5F[4:0]
            + (pLCDTbl->CR5E & (BIT7+BIT6+BIT5))            // CR5E[7:5]
            + ((pLCDTbl->CR5F & (BIT7+BIT6+BIT5)) << 3)     // CR5F[7:5]
            + 1;                                            // fix for V_SYNC_END(-1) on IGA2
        break;

    default:
        break;
    }

    return value;
}

void cbPanelTXCTRL(PCBIOS_EXTENSION pcbe, IN LCD_DVI_TX_TYPE TXType, IN BOOL operate)
{
    LCD_Info LCDinfo;
    cbGetLCDPanelInfo_UMA(pcbe,S3_LCD,&LCDinfo);
    
    // 2.----------- power on LCD TX 
    switch (TXType)
    {
    case IN_LVDS1:
        if(operate == ON)
        {
            //INVERSE_LVDS_POWER.	
	        //For 3353 A0, A1 LVDS power is inversed
            if (pcbe->pVCPInfo->miscConfigure2 & BIT4) 
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT7, BIT7);
            }
            else
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT7, 0);
            }
            //if in dual channel, we have to turn on LVDS2, too.
            if(LCDinfo.Channel == 2) 
            {
                cbWriteRegBits(pcbe, CR_D2, BIT6, 0);
            }
        }
        else
        {
            //INVERSE_LVDS_POWER.	
	        //For 3353 A0, A1 LVDS power is inversed
            if (pcbe->pVCPInfo->miscConfigure2 & BIT4) 
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT7, 0);
            }
            else
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT7, BIT7);
            }
            //if in dual channel, we have to turn off LVDS2,too.
            if(LCDinfo.Channel == 2) 
            {
                cbWriteRegBits(pcbe, CR_D2, BIT6, BIT6);
            }    
        }
        break;
    case IN_LVDS2:
        if(operate == ON)
        {
            //INVERSE_LVDS_POWER.	
	        //For 3353 A0, A1 LVDS power is inversed
            if (pcbe->pVCPInfo->miscConfigure2 & BIT4) 
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT6, BIT6);
            }
            else
            {
                // IN_LVDS1 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT6, 0);
            }
        }
        else
        {
            //INVERSE_LVDS_POWER.	
	        //For 3353 A0, A1 LVDS power is inversed
            if (pcbe->pVCPInfo->miscConfigure2 & BIT4) 
            {
                // IN_LVDS2 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT6, 0);
            }
            else
            {
                // IN_LVDS2 TX Power Trigger bit
                cbWriteRegBits(pcbe, CR_D2, BIT6, BIT6);
            }
        }
        break;    
    case TTL_PANEL:
		if(operate == ON)
        {
                // For TTL_PANEL use LVDS1
            if(pcbe->pVCPInfo->miscConfigure2 & BIT6)
            {
                cbWriteRegBits(pcbe, CR_D2, BIT7, 0);
            }
         }   
        else
        {
                // For TTL_PANEL use LVDS1
            if(pcbe->pVCPInfo->miscConfigure2 & BIT6)
            {        
                cbWriteRegBits(pcbe, CR_D2, BIT7, BIT7);
            }    
        }
        break;
    case VT1636:
	case CH7305_VT1636:
    case HARDWIRED_LVDS: 
        break;	
    default:
        {
            cbDbgPrint(1, "Function: cLCDTXCTRL, Wrong TX. type of LCD !\n");
            ASSERT(0);
        }
    } // switch TX type
}

/*--------------------------------------------------------------------------
* cbPanelOnOffCTRL:
*                       turn on/off panel
* IN
*      device   : which device need to send power sequence
*      operate : ON/OFF
*-------------------------------------------------------------------------- */
void cbPanelOnOffCTRL(PCBIOS_EXTENSION pcbe, IN DWORD device, IN BOOL operate)
{
    BYTE TXType = HARDWIRED_LVDS;
    DWORD devTemp;
    BOOL bSetSSC;
    DWORD HW_PSOffDelaySec = 0;
	
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    if ((device & (S3_LCD+S3_LCD2)) == 0) {
        cbDbgPrint(0, "Wrong device, should be LCD or LCD2 !\n");
        ASSERT(FALSE);
        return;
    }
    /* get Device associate TX type */
    if (cbGetDITXtype(pcbe, &TXType, device) == FALSE) {
        /* get TX type fail, add an assert for convenient debug */
        ASSERT(0);
        return;
    }
    bSetSSC = FALSE;

    cbOnOffSSC(pcbe, OFF); // disable LVDS1 and LVDS2 SSC first

    if (pcbe->ChipCaps.SSC_Enable) {
        /* if ssc needs to control */
        if (operate==ON) {
            /* if ssc should turn on, we turn on ssc */          
            if(cbIsSSCAvailable(pcbe)) {
                bSetSSC=TRUE;
            }
        } else {
            /* off */
            /* one lcd power sequence off, need to check if another lcd still on */
            devTemp=pcbe->IGA2Info.dispDev;
            /* assume this lcd is on iga2, if not, this assume won't affect the result of (devTemp&(S3_LCD+S3_LCD2)) */
            devTemp&=~device; //remove lcd wiil be off  from iga2 temp for cbIsSSCAvailable function
            if ((devTemp&(S3_LCD+S3_LCD2))==0) {
               bSetSSC=TRUE;
            }
        }
    }

    /* when system shutdown, need delay for let HW power sequence finish */
    if (OFF == operate) {
        BYTE panelID;
        if(device == S3_LCD) {
            panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
        }
        else {
            /* (device == S3_LCD2) */
            panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
        }
        if (0 != pcbe->pVCPInfo->LCDInfoHeader) {
            WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            if (pcbe->pVCPInfo->miscConfigure & BIT4) {
                /* LCD on IGA2 ONLY */
                PFPHeaderData pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;

                HW_PSOffDelaySec = pLCDHeader->TD1 + pLCDHeader->TD2 + pLCDHeader->TD3;
            } else {
                /* LCD 1+2 */
                /* When LCD 1+2 , always use LCD1 to get timing table */
                PFPHeaderData12 pLCDHeader = (PFPHeaderData12)(pcbe->RomData + offsetLCDHeader);
                pLCDHeader += panelID;

                HW_PSOffDelaySec = pLCDHeader->TD1 + pLCDHeader->TD2 + pLCDHeader->TD3;
            }

        }
    }

    /* 3. LCD power sequence on */
    if (!cbGetDII2Csetting(pcbe, &i2c, device))
    {
        cbDbgPrint(1, "Function: cbLCDPowerSequenceCTRL, Can not get DI-I2C setting of LCD !\n");
        return;
    }	
    cbCheck_CH7305orVT1636(pcbe, &TXType, &i2c);
		
    switch(TXType)
    {
    case VT1636:
    {
        I2C_CONTROL_UMA i2c;
        i2c.Flags = 0;
        /* get Device associate LVDS I2C setting */
        if (!cbGetDII2Csetting(pcbe, &i2c, device)) {
            cbDbgPrint(1, "Function: cbLCDPowerSequenceCTRL, Can not get DI-I2C setting of LCD !\n");
            return;
        }
        if (operate == ON) {
            /* Hw pwer sequence, turn ssc first */
            if (bSetSSC) {
                cbOnOffSSC(pcbe, ON);
            }
            i2c.IndexData = 0x33;
            i2c.RegIndex = 0x10;
            I2C_Write_Bit_INV(pcbe, &i2c, 0x33);    /* Turn on back light and VDD */

            if (device & S3_LCD) {
                /* Since many code check CR6A as LCD on/off status, CR6A will alway */
                /* be updated whether SW/HW power sequence */
                cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
            } else if (device & S3_LCD2) {
                cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
            }
        } else {
            /* if hw power sequence, off ssc first */
            if(bSetSSC) {
                cbOnOffSSC(pcbe, OFF);
            }
            i2c.IndexData = 0x00;
            i2c.RegIndex = 0x10;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT5);    /* Turn off back light and VDD */

            if (device & S3_LCD) {
                /* Since many code check CR6A as LCD on/off status, CR6A will always */
                /* be updated whether SW/HW power sequence */
                cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
            } else if (device & S3_LCD2) {
                cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
            }
			
            /* when system shutdown, need delay for let HW power sequence finish */
            cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
        }
    }
    break;
    
    case CH7305_VT1636:
    {
    	int counter_PLL_check = 0;
        I2C_CONTROL_UMA i2c;
        i2c.Flags = 0;
        /* get Device associate LVDS I2C setting */
        if (!cbGetDII2Csetting(pcbe, &i2c, device)) {
            cbDbgPrint(1, "Function: cbLCDPowerSequenceCTRL, Can not get DI-I2C setting of LCD !\n");
            return;
        }
        if(operate == ON) {
            /* Hw pwer sequence, turn ssc first */
            if(bSetSSC) {
                cbOnOffSSC(pcbe, ON);
            }
            //set RX14[2] = 1
            i2c.IndexData = BIT2;
            i2c.RegIndex = 0x14;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT2);	// Turn on back light and VDD
            
            //1. Set Reg0x66[4:3] to ''11'' // Override lock detect sentry.
            i2c.IndexData = BIT4 + BIT3;
            i2c.RegIndex = 0x66;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT4 + BIT3);
            
            //2. Set EMI operation // Refer to the applications note for more additional information.
            
            //3. Set Reg0x63[6] to -0~ // Set the LVDS path ON
            i2c.IndexData = 0;
			i2c.RegIndex = 0x63;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT6);
            
            //4. Reset Reg0x63[6] to -1~ and then -0~ // Set the LVDS path ON
			i2c.IndexData = BIT6;
			i2c.RegIndex = 0x63;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT6);
            
            i2c.IndexData = 0;
			i2c.RegIndex = 0x63;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT6);
            
            //5. Set Reg0x66[5] to -1~ //Enable Backlight
			i2c.IndexData = BIT5;
			i2c.RegIndex = 0x66;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT5);
			
			//6. Set Reg0x73[4:3] to -1~ or -11~. // enable output channel path.
			i2c.IndexData = BIT4 + BIT3;
			i2c.RegIndex = 0x73;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT4 + BIT3);	
			
			//7. Set Reg0x76[1:0] to -01~ or -11~ // turn on output channel power.
			i2c.IndexData = BIT1 + BIT0;
			i2c.RegIndex = 0x76;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT1 + BIT0);	
			
			//8. Set Reg0x66[4:3] to -00~
			i2c.IndexData = 0;
			i2c.RegIndex = 0x66;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT4 + BIT3);	
			
			//9. Get Reg0x66[2] // Check the status of the PLL Lock
			for(counter_PLL_check = 0; counter_PLL_check<=5;counter_PLL_check++)
			{
				i2c.RegIndex = 0x66;
				I2C_Read_Byte_INV(pcbe, &i2c);
				if(i2c.IndexData & BIT2)
				{
					// PLL is locked, exit the loop (max =5 times)
					break;
				}
				else
				{
					// PLL is not stable
					// Reset LVDS PLL
					i2c.IndexData = 0;
					i2c.RegIndex = 0x76;
					I2C_Write_Bit_INV(pcbe, &i2c, BIT2); 
					
					cbDelayMicroSeconds(10000);
					
					// Set LVDS PLL to normal operation
					i2c.IndexData = BIT2;
					i2c.RegIndex = 0x76;
					I2C_Write_Bit_INV(pcbe, &i2c, BIT2); 
					
					cbDelayMicroSeconds(20000);	
				}
			}
			//disable ch7305 clk detective fuction module
			i2c.IndexData = BIT4 + BIT3 + BIT1;
			i2c.RegIndex = 0x66;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT4 + BIT3 + BIT1); 
							
			//11. Set Reg0x66[0] to -1~ // LVDS panel power-on
			i2c.IndexData = BIT0;
			i2c.RegIndex = 0x66;
			I2C_Write_Bit_INV(pcbe, &i2c, BIT0);

            if(device & S3_LCD) {
                /* Since many code check CR6A as LCD on/off status, CR6A will alway
                * be updated whether SW/HW power sequence */
                cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
            }
            else if(device & S3_LCD2) {
                cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
            }
        } else {
            /* if hw power sequence, off ssc first */
            if (bSetSSC) {
                cbOnOffSSC(pcbe, OFF);
            }
            /*  Turn off back light and VDD */
            i2c.IndexData = 0x00;
            i2c.RegIndex = 0x66;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT0);

            if (device & S3_LCD) {
                /* Since many code check CR6A as LCD on/off status, CR6A will always
                * be updated whether SW/HW power sequence */
                cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
            } else if (device & S3_LCD2) {
                cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
            }
            /* when system shutdown, need delay for let HW power sequence finish */
            cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
        }
    }
    break;
        
    case IN_LVDS1:
    case HARDWIRED_LVDS:
        if(operate == ON) {
            
            /* LVDS1 HW / SW power sequence: ON
             * Since many code check CR6A as LCD on/off status, CR6A will always
             * be updated whether SW/HW power sequence 
             * For IN_LVDS1 / HARDWIRED_LVDS HW / SW power sequence control CR91[0] */
            if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                /* SW power sequence: ON
                  * LVDS TX on in SW PS when data on for 324/353 */
                cbPanelSWPowerSeqenceCTRL(pcbe, device, ON, bSetSSC);
                /* CR6A[3] is used to record LCD power status */
                cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
            } else {
                /* Hw pwer sequence, turn ssc first */
                if(bSetSSC) {
                    cbOnOffSSC(pcbe, ON);
                }
                /* If on operation, we must first on TX */
                cbPanelTXCTRL(pcbe, TXType, ON);
                /* For LVDS1 hardware powersequence CR6A[3] */
                cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
            }
        } else {            
            /* HW / SW power sequence: OFF
              * Since many code check CR6A as LCD on/off status, CR6A will always
              * be updated whether SW/HW power sequence */
            if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                /* SW power sequence: OFF
                 * LVDS TX off in SW PS when data off for 324/353 */
                cbPanelSWPowerSeqenceCTRL(pcbe, device, OFF, bSetSSC);
                /* CR6A[3] is used to record LCD power status */
                cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
            } else {
                /* if hw power sequence, off ssc first */
                if (bSetSSC) {
                    cbOnOffSSC(pcbe, OFF);
                }
                /* For LVDS1 hardware powersequence CR6A[3]  */
                cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
                /* when system shutdown, need delay for let HW power sequence finish */
				cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
                /* If off operation, we must turn off TX after turn off device */
                cbPanelTXCTRL(pcbe, TXType, OFF);
            }
        }
        break;
    case IN_LVDS2:
        if (operate == ON) {
            /* For IN_LVDS2 HW / SW power sequence control CRD3[0]
                     * LVDS1 HW / SW power sequence: ON
                     * Since many code check CRD4 as LCD on/off status, CRD4 will always
                     * be updated whether SW/HW power sequence  */
            if (cbReadRegByte(pcbe, CR_D3) & BIT0) {
                /* IN_LVDS2 SW power sequence: ON
                            * LVDS TX on in SW PS when data on for 324/353 */
                cbPanelSWPowerSeqenceCTRL_LVDS2(pcbe, device, ON, bSetSSC);
                /* CRD4[1] is used to record LCD power status */
                cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
            } else {
                /* Hw pwer sequence, turn ssc first */
                if (bSetSSC) {
                    cbOnOffSSC(pcbe, ON);
                }
                /* If on operation, we must first on TX */
                cbPanelTXCTRL(pcbe, TXType, ON);
                /* For IN_LVDS2 hardware powersequence CRD4[1] */
                cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
            }
        } else {
            /* For IN_LVDS2 HW / SW power sequence control CRD3[0]
                     * LVDS1 HW / SW power sequence: ON
                     * Since many code check CRD4 as LCD on/off status, CRD4 will always
                     * be updated whether SW/HW power sequence */
            if (cbReadRegByte(pcbe, CR_D3) & BIT0) {
                /* IN_LVDS2 SW power sequence: OFF
                            * LVDS TX off in SW PS when data off for 324/353 */
                cbPanelSWPowerSeqenceCTRL_LVDS2(pcbe, device, OFF, bSetSSC);
                /* CRD4[1] is used to record LCD power status */
                cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
            } else {
                 /* if hw power sequence, off ssc first */
                if(bSetSSC) {
                    cbOnOffSSC(pcbe, OFF);
                }
                /* For IN_LVDS2 hardware powersequence CRD4[1] */
                cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
                /* when system shutdown, need delay for let HW power sequence finish */
				cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
                /* If off operation, we must turn off TX after turn off device */
                cbPanelTXCTRL(pcbe, TXType, OFF);
            }
        }
        break;
    case TTL_PANEL:
        /* For 353 layout, TTL_PANEL use LVDS1 */ 
        if (pcbe->pVCPInfo->miscConfigure2 & BIT6) {
            if(operate == ON) {
                
                /* LVDS1 HW / SW power sequence: ON
                            * Since many code check CR6A as LCD on/off status, CR6A will always
                            * be updated whether SW/HW power sequence 
                            * For IN_LVDS1 / HARDWIRED_LVDS HW / SW power sequence control CR91[0] */
                if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                    /* SW power sequence: ON
                                   * LVDS TX on in SW PS when data on for 324/353 */
                    cbPanelSWPowerSeqenceCTRL(pcbe, device, ON, bSetSSC);
                    /* CR6A[3] is used to record LCD power status */
                    cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
                } else {
                    /* Hw pwer sequence, turn ssc first */
                    if (bSetSSC) {
                        cbOnOffSSC(pcbe, ON);
                    }
                    /* If on operation, we must first on TX */
                    cbPanelTXCTRL(pcbe, TXType, ON);
                    /* For LVDS1 hardware powersequence CR6A[3] */
                    cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
                }
            } else {
                
                /* HW / SW power sequence: OFF
                            * Since many code check CR6A as LCD on/off status, CR6A will always
                            * be updated whether SW/HW power sequence */
                if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                    /* SW power sequence: OFF
                                   * LVDS TX off in SW PS when data off for 324/353 */
                    cbPanelSWPowerSeqenceCTRL(pcbe, device, OFF, bSetSSC);
                    /* CR6A[3] is used to record LCD power status */
                    cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
                } else {
                    /* if hw power sequence, off ssc first */
                    if (bSetSSC) {
                        cbOnOffSSC(pcbe, OFF);
                    }
                    /* For LVDS1 hardware powersequence CR6A[3] */
                    cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
                    /* when system shutdown, need delay for let HW power sequence finish */
    				cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
                    /* If off operation, we must turn off TX after turn off device */
                    cbPanelTXCTRL(pcbe, TXType, OFF);
                }
            }
        } else if (pcbe->ChipCaps.FOR_409_TTL_PANEL) {
            /* For 409 layout, TTL_PANEL use LVDS2
                      * For 409A1 TTL panel may use PS1 or PS2
                      * TTL use PS2 when SW_PS2_BLT_VDD_BY_GPIO23 is true */
            if (pcbe->pVCPInfo->miscConfigure3 & SW_PS2_BLT_VDD_BY_GPIO23) {
                if (operate == ON) {
                    /* For 409A1 TTL panel, use SW PS2, control by CRD3[0]
                                   * SW power sequence2: ON
                                   * Since many code check CRD4 as LCD on/off status, CRD4 will always
                                   * be updated whether SW/HW power sequence */
                    if (cbReadRegByte(pcbe, CR_D3) & BIT0) {
                        /* SW power sequence2: ON
                                          * LVDS TX on in SW PS when data on for 324/353 */                     
                        cbPanelSWPowerSeqenceCTRL_LVDS2(pcbe, device, ON, bSetSSC);
                        /* CRD4[1] is used to record LCD power status */
                        cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
                    } else {
                        /* Hw pwer sequence, turn ssc first */
                        if (bSetSSC) {
                            cbOnOffSSC(pcbe, ON);
                        }
                        /* If on operation, we must first on TX, 409 TTL_PANEL don't need to control TX */
                        cbPanelTXCTRL(pcbe, TXType, ON);
                        /* For hardware powersequence 2 CRD4[1] */
                        cbWriteRegBits(pcbe, CR_D4, BIT1, BIT1);
                    }
                } else {
                    /* For 409A1 TTL panel, use SW PS2, control by CRD3[0]
                                   * SW power sequence2: OFF
                                   * Since many code check CRD4 as LCD on/off status, CRD4 will always
                                   * be updated whether SW/HW power sequence */
                    if (cbReadRegByte(pcbe, CR_D3) & BIT0) {
                        /* SW power sequence1: OFF
                                          * LVDS TX on in SW PS when data on for 324/353 */
                        cbPanelSWPowerSeqenceCTRL_LVDS2(pcbe, device, OFF, bSetSSC);
                        /* CRD4[1] is used to record LCD power status */
                        cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
                    } else {
                        /* if hw power sequence, off ssc first */
                        if (bSetSSC) {
                            cbOnOffSSC(pcbe, OFF);
                        }
                        /* For hardware powersequence2 CRD4[1] */
                        cbWriteRegBits(pcbe, CR_D4, BIT1, 0);
                        /* when system shutdown, need delay for let HW power sequence finish */
    		    		cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
                        /* If off operation, we must turn off TX after turn off device,409 TTL_PANEL don't need to control TX */
                        cbPanelTXCTRL(pcbe, TXType, OFF);
                    }
                }
            } else {
                if (operate == ON) {
                    /* For 409A1 TTL panel, use SW PS1, control by CR91[0]
                                   * SW power sequence1: ON
                                   * Since many code check CR6A as LCD on/off status, CR6A will always
                                   * be updated whether SW/HW power sequence  */
                    if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                        /* SW power sequence1: ON
                                          * LVDS TX on in SW PS when data on for 324/353 */
                        cbPanelSWPowerSeqenceCTRL(pcbe, device, ON, bSetSSC);
                        /* CR6A[3] is used to record LCD power status */
                        cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
                    } else {
                        /* Hw pwer sequence, turn ssc first */
                        if (bSetSSC) {
                            cbOnOffSSC(pcbe, ON);
                        }
                        /* If on operation, we must first on TX, 409 TTL_PANEL don't need to control TX */
                        cbPanelTXCTRL(pcbe, TXType, ON);
                        /* For hardware powersequence 1 CR6A[3] */
                        cbWriteRegBits(pcbe, CR_6A, BIT3, BIT3);
                    }
                } else {
                    /* For 409A1 TTL panel, use SW PS1, control by CR91[0]
                                   * SW power sequence1: OFF
                                   * Since many code check CR6A as LCD on/off status, CR6A will always
                                   * be updated whether SW/HW power sequence */
                    if (cbReadRegByte(pcbe, CR_91) & BIT0) {
                        /* SW power sequence1: OFF
                                          * LVDS TX on in SW PS when data on for 324/353 */
                        cbPanelSWPowerSeqenceCTRL(pcbe, device, OFF, bSetSSC);
                        /* CR6A[3] is used to record LCD power status */
                        cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
                    } else {
                         /* if hw power sequence, off ssc first */
                        if (bSetSSC) {
                            cbOnOffSSC(pcbe, OFF);
                        }
                        /* For hardware powersequence1 CR6A[3] */
                        cbWriteRegBits(pcbe, CR_6A, BIT3, 0);
                        /* when system shutdown, need delay for let HW power sequence finish */
    		    		cbDelayMicroSeconds(HW_PSOffDelaySec * 1000);
                        /* If off operation, we must turn off TX after turn off device,409 TTL_PANEL don't need to control TX */
                        cbPanelTXCTRL(pcbe, TXType, OFF);
                    }
                }
            }
        } else {
            cbDbgPrint(1, "Check your chip,till now, only 353 & 409 support TTL panel !\n");
            ASSERT(0);
        }
        break;
        
    default:
        cbDbgPrint(1, "Function: cbLCDPowerSequenceCTRL, Wrong TX. type of LCD !\n");
        ASSERT(0);
        break;
    }
}
//-----------------------------------------------------------------------
// cbInitSSC
//  Init ssc related registers according to ssc works mode
//  IN :
//    None
//  OUT :
//    None
//----------------------------------------------------------------------
VOID cbInitSSC(PCBIOS_EXTENSION pcbe)
{
    //init of ssc
    if(!pcbe->ChipCaps.SSC_Using_External) // Internal SSC
    {
        // init of Internal SSC        
        GFXTimingTable TimingTbl;
        RefreshRateInfo RRateInfo;
        BOOL status = FALSE;
        BYTE bData = 0;
        RRateInfo.rRateX100 = 60 * 100;
        RRateInfo.interlaced = PROGRESSIVE;            
        if((status = cbGetMaxTarTimingFromEDIDandCusTiming(pcbe, S3_LCD, RRateInfo, &TimingTbl)) == FALSE)
            status = cbGetVBIOSPanelTimingTable(pcbe, S3_LCD, &TimingTbl);
        if(status)
        {
            BYTE M = (BYTE)(TimingTbl.vPLL >> 16);
            BYTE R = (BYTE)(TimingTbl.vPLL >>  8);
            BYTE N = (BYTE)(TimingTbl.vPLL);
            ULONG ClockFreq = cbCalcClkFromMRN(pcbe, M, R, N);
            if(ClockFreq <= 40000000)
                bData = 0;
            else if(ClockFreq <= 65000000)
                bData = BIT4;
            else if(ClockFreq <= 110000000)
                bData = BIT5;
            else
                bData = BIT5 + BIT4;
        }
        bData |= (BIT7+BIT6);
        bData |= (pcbe->SSC_Spreading_Range << 2);
        cbWriteRegByte(pcbe, CR_F7, bData);
    }    

    // CR 88 bit 7        
    // No matter SSC is FIFO or original mode, this bit should be set to 1 after PCIRST_N=1.
    // ssc reset enable    
    cbWriteRegBits(pcbe, CR_88, BIT7, BIT7);
    // ssc adjust
    cbWriteRegByte(pcbe, CR_A4, 8);
}
//-----------------------------------------------------------------------
// cbOnOffSSC
//  Enable ssc and switch gpio to ssc 
//  IN :
//    BOOL bOn: ON:enable ssc
//                     OFF: disable ssc
//  OUT :
//    TRUE: operation succeed
//    FALSE: operation failed
//----------------------------------------------------------------------
BOOL cbOnOffSSC(PCBIOS_EXTENSION pcbe, BOOL bOn)
{
    BYTE SSCOrigPortAddr;
    BYTE SSCFifoPortAddr;
    BOOL status=FALSE;

    if(pcbe->pVCPInfo->version>=VCP1_5)
    {
        SSCOrigPortAddr=pcbe->pVCPInfo->Orig_SSC_ClockOut_Reg;
        SSCFifoPortAddr=pcbe->pVCPInfo->FIFO_SSC_ClockOut_Reg;
    }
    else
    {
        SSCOrigPortAddr=0x2C;
        SSCFifoPortAddr=0x2C;
    }

    if(bOn==ON)
    {
       //only support for 409 later, path control
       //because SR7D can't be configed when boot not LCD only and we are primary adapter
       //need to config it each time, don't move them to cbInitSSC
       if(pcbe->ChipCaps.SSC_PATH_CONTROL)
       {
           BYTE bData = 0;
           BYTE bMask = pcbe->ChipCaps.SSC_INTERNAL_PATH_CONTROL ? (BIT7 + BIT6 + BIT5 + BIT4) : (BIT3 + BIT2 + BIT1 + BIT0);

           if(pcbe->IGA2Info.dispDev & (S3_LCD+S3_LCD2))
               bData = pcbe->ChipCaps.SSC_INTERNAL_PATH_CONTROL ? BIT6 : BIT1;
           else
               bData = 0;

           // Internal SSC
           if(!pcbe->ChipCaps.SSC_Using_External)
               bData += (pcbe->ChipCaps.SSC_INTERNAL_PATH_CONTROL ? (BIT7 + BIT5) : (BIT2 + BIT0));
           // Original mode
           if(!pcbe->ChipCaps.SSC_Using_Fifo_Mode)
               bData += (pcbe->ChipCaps.SSC_INTERNAL_PATH_CONTROL ? BIT4 : BIT3);
           cbWriteRegBits(pcbe, SR_7D, bMask, bData);
       }
       // fifo mode
       if(pcbe->ChipCaps.SSC_Using_Fifo_Mode)
       {
           cbWriteRegBits(pcbe, (ZSR<<8) + SSCFifoPortAddr, BIT0, BIT0);

           // enable fifo mode SSC
           cbWriteRegBits(pcbe, SR_2A, BIT6, BIT6);
       }
       else
       {
           // CR97[4] is also original SSC clock source
           if(pcbe->IGA2Info.dispDev & (S3_LCD+S3_LCD2))
           {
               // if not TTL Panel, need to aid
               if(!pcbe->ChipCaps.FOR_409_TTL_PANEL)
               {
                   // In original mode, switch SSC clock source to LCK
                   cbWriteRegBits(pcbe, CR_97, BIT4, BIT4);
               }

               // enable original mode SSC
               cbWriteRegBits(pcbe, SR_1E, BIT3, BIT3);
           }
           else
           {
               // if not TTL Panel, need to aid
               if(!pcbe->ChipCaps.FOR_409_TTL_PANEL)
               {
                   // In original mode, switch SSC clock source to VCK           
                   cbWriteRegBits(pcbe, CR_97, BIT4, 0);
               }

               // enable original mode SSC
               cbWriteRegBits(pcbe, SR_2A, BIT7, BIT7);
           }
           // CRD0[6:5]: PLL1 charge pump current set bits
           cbWriteRegBits(pcbe, CR_D0, BIT5+BIT6, BIT6);
           cbWriteRegBits(pcbe, (ZSR<<8) + SSCOrigPortAddr, BIT0, BIT0);
       }

       // enable Internal SSC
       if(!pcbe->ChipCaps.SSC_Using_External)	   	
           cbWriteRegBits(pcbe, CR_F7, BIT6+BIT0, BIT0);
       status=TRUE;
    }
    else
    {
        // disable original & fifo mode SSC
        cbWriteRegBits(pcbe, SR_2A, BIT7+BIT6, 0);
        cbWriteRegBits(pcbe, SR_1E, BIT3, 0);
        // disable Internal SSC                            
        if(!pcbe->ChipCaps.SSC_Using_External) 
           cbWriteRegBits(pcbe, CR_F7, BIT6+BIT0, BIT6);
        // fifo mode		
        if(pcbe->ChipCaps.SSC_Using_Fifo_Mode)
        {
            cbWriteRegBits(pcbe, (ZSR<<8) + SSCFifoPortAddr, BIT0, 0);
        }
        else
        {
            cbWriteRegBits(pcbe, (ZSR<<8) + SSCOrigPortAddr, BIT0, 0);
        }
        status=TRUE;
    }
    return status;
}
//-----------------------------------------------------------------------
// cbIsSSCAvailable
//  determine whether SSC can turn on
//  IN :
//    pcbe:
//    
//  OUT :
//    TRUE: ssc need to be on
//    FALSE: ssc need to be off
//----------------------------------------------------------------------
BOOL cbIsSSCAvailable(PCBIOS_EXTENSION pcbe)
{
    BOOL bSSCOn=FALSE;     
    if(pcbe->ChipCaps.SSC_Using_Fifo_Mode) //ssc fifo mode
    {
        if((pcbe->IGA2Info.dispDev & (S3_LCD+S3_LCD2)) ||
           (pcbe->IGA1Info.dispDev & (S3_LCD+S3_LCD2))) //if has lcd, then turn on
        {
            bSSCOn=TRUE;
        }
    }
    else //ssc original mode
    {
        // if no device other than lcd simultaneous with lcd in IGA2,then turn on ssc
        if(((pcbe->IGA2Info.dispDev & (S3_LCD+S3_LCD2)) && ((pcbe->IGA2Info.dispDev & ~(S3_LCD+S3_LCD2))==0)) ||
           ((pcbe->IGA1Info.dispDev & (S3_LCD+S3_LCD2)) && ((pcbe->IGA1Info.dispDev & ~(S3_LCD+S3_LCD2))==0)))
        {
            bSSCOn=TRUE;
        }
    }
    return bSSCOn;
}
//----------------------------------------------------------------
//cbIsSSCOnNow:
//         Get SSC state
//----------------------------------------------------------------
BOOL cbIsSSCOnNow(PCBIOS_EXTENSION pcbe)
{
    return (cbReadRegByte(pcbe, SR_1E)&BIT3);
}
//-----------------------------------------------------------------
//cbIsLcd1OnNow:
//cbIsLcd2OnNow:
//       Get Lcd real power state from CR6A[3] and CRD4[1]
//-----------------------------------------------------------------
BOOL cbIsLcd1OnNow(PCBIOS_EXTENSION pcbe)
{
    return (cbReadRegByte(pcbe, CR_6A)&BIT3);
}
BOOL cbIsLcd2OnNow(PCBIOS_EXTENSION pcbe)
{
    return (cbReadRegByte(pcbe, CR_D4)&BIT1);
}

BOOL cbGetRefreshRatesForLCD (
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN OUT RefreshRateInfo *pRRatesInfoBuf,
    IN OUT DWORD *pBufSize
)
{

    if (!pRRatesInfoBuf || !pBufSize)
    {
        cbDbgPrint(0, "cbGetRefreshRatesForLCD: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if(dispDev == S3_LCD)
    {
        if (pcbe->devicetimingtype[LCDbit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_LCD,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                // if EDID failed all the resolution for LCD / LCD2 just report 60Hz refresh rate 
                pRRatesInfoBuf[0].rRateX100 = 60 * 100;
                pRRatesInfoBuf[0].interlaced = PROGRESSIVE;
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else if (pcbe->devicetimingtype[LCDbit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_LCD,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {    
                // if EDID failed all the resolution for LCD / LCD2 just report 60Hz refresh rate 
                pRRatesInfoBuf[0].rRateX100 = 60 * 100;
                pRRatesInfoBuf[0].interlaced = PROGRESSIVE;
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else
        {
            return FALSE;
        }
    }
    else if(dispDev == S3_LCD2)
    {
        if (pcbe->devicetimingtype[LCD2bit] == EDID_ENABLEDEVSCALING_TIMING_TYPE)
        {
            if (!cbGetEDIDRefreshRatesForResolution(pcbe, 
                                                    S3_LCD2,
                                                    H_Res,
                                                    V_Res,
                                                    pRRatesInfoBuf,
                                                    *pBufSize,
                                                    NULL))
            {
                 // if EDID failed all the resolution for LCD / LCD2 just report 60Hz refresh rate 
                 pRRatesInfoBuf[0].rRateX100 = 60 * 100;
                 pRRatesInfoBuf[0].interlaced = PROGRESSIVE;
                 *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else if (pcbe->devicetimingtype[LCD2bit] == EDID_DISABLEDEVSCALING_TIMING_TYPE) 
        {
            // no device scaling timing type
            // When EDID or customize timing valid
            // Center all the mode on the biggest target timing from EDID or customize timing
            if (!cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(pcbe,
                                                                  S3_LCD2,
                                                                  pRRatesInfoBuf,
                                                                  *pBufSize,
                                                                  NULL))
            {    
                // if EDID failed all the resolution for LCD / LCD2 just report 60Hz refresh rate 
                pRRatesInfoBuf[0].rRateX100 = 60 * 100;
                pRRatesInfoBuf[0].interlaced = PROGRESSIVE;
                *pBufSize = 1 * sizeof(RefreshRateInfo);
            }
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        cbDbgPrint(1, "cbGetRefreshRatesForLCD: Error, incorrectly parameter !\n");
        return FALSE;
    }

    return TRUE;
}
