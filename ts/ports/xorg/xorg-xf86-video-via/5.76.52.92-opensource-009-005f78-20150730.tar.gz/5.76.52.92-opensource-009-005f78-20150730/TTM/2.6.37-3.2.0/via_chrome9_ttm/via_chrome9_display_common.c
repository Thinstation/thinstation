/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_drv.h"
#include "via_chrome9_display_common.h"
#include "via_chrome9_mode.h"

unsigned char *mmio_map_base;
unsigned char *mmio_mb1;
spinlock_t vga_reg_read_lock;


/*
 * Function Name: via_chrome9_get_vga_address
 * Description: Transfer the IO name(CRXX/SRXX to the address in MMIO base)
 * Parameters:
 * IN: IO name
 * OUT: null
 * Status Return: the address of the register in MMIO
 * */
inline unsigned long via_chrome9_get_vga_address(u16 io_name)
{
	unsigned long  io_address;

	if (IS_ZSR & io_name)
		io_address = REG_ZSR;
	else if (IS_ZGR & io_name)
		io_address = REG_ZGR;
	else if (IS_ZAR & io_name)
		io_address = REG_ZAR;
	else
		io_address = REG_ZCR;
	io_address = (unsigned long)(mmio_map_base + io_address);

	return io_address;
}


/*
 * Function Name:
 * Description:
 * Parameters:
 * IN:
 * OUT:
 * Status Return:
 * Note:
 * */
u8  via_chrome9_read_vga_io(u16 io_name)
{
	u8  io_port_index;
	u8  ret_val = 0xFF;
	u16  io_data;
	unsigned long io_address;
	unsigned long flags;

	io_port_index = io_name & REG_INDEX_MASK;
	io_address = via_chrome9_get_vga_address(io_name);
	spin_lock_irqsave(&vga_reg_read_lock, flags);
	MMIO_WR8(io_address, io_port_index);
	rmb();
	io_data = MMIO_RD16(io_address);	
	spin_unlock_irqrestore(&vga_reg_read_lock, flags);
	ret_val = (u8)(io_data >> 8);
	return ret_val;
}

/*
 * Function Name:
 * Description:
 * Parameters:
 * IN:
 * OUT:
 * Status Return:
 * Note:
 * */
u32   via_chrome9_write_vga_io(u16 io_name, u8 data)
{
	u8 io_port_index;
	u16 val;
	unsigned long io_address;

	io_port_index = io_name & REG_INDEX_MASK;
	val = (data << 8) | io_port_index;
	io_address = via_chrome9_get_vga_address(io_name);
	MMIO_WR16(io_address, val);
	return true;
}

/*
 * Function Name:
 * Description:
 * Parameters:
 * IN:
 * OUT:
 * Status Return:
 * Note:
 * */
u32   via_chrome9_write_vga_io_bits(u16 io_name, u8 data, u8 bits_mask)
{
	u8  tmpio_data;

	tmpio_data = via_chrome9_read_vga_io(io_name);
	data = (data & bits_mask) | (tmpio_data & (~bits_mask));
	via_chrome9_write_vga_io(io_name, data);
	return true;
}

/*
 * Function Name:
 * Description:
 * Parameters:
 * IN:
 * OUT:
 * Status Return:
 * Note:
 * */
u32   via_chrome9_write_vga_io_multi_bits(struct via_chrome9_io_reg reg_table[],
		u32 item_num)
{
	u32 i;

	for (i = 0; i < item_num; i++)
		via_chrome9_write_vga_io_bits(reg_table[i].index,
			reg_table[i].value, reg_table[i].mask);

	return true;
}

/*
 * Function Name: via_chrome9_load_regs
 * Description: Write centain value to some bits of multiple register
 * Parameters:
 * IN:
 * reg_value: centain value
 * reg_amount: the amount of multiple register
 * p_regbit: the struct indicated which bits of register should be written
 * OUT:
 * Status Return:
 * Note:
 * */
void via_chrome9_load_regs(u32 reg_value, u32 reg_amount,
	struct via_chrome9_io_bit *p_regbit)
{
	u32 reg_mask;
	u32 bit_num = 0;
	u32 data;
	u32 i, j;
	u32 shift_next_reg;
	u32 start_index, end_index;
	u32 cr_index;
	u32 get_bit;

	for (i = 0; i < reg_amount; i++) {
		reg_mask = 0;
		data = 0;
		start_index = p_regbit[i].start_bit;
		end_index = p_regbit[i].end_bit;
		cr_index = p_regbit[i].io_addr;

		shift_next_reg = bit_num;

		for (j = start_index; j <= end_index; j++) {
			reg_mask = reg_mask | (BIT0 << j);
			get_bit = (reg_value & (BIT0 << bit_num));
			data = data |
				((get_bit >> shift_next_reg) << start_index);
			bit_num++;
		}

		via_chrome9_write_vga_io_bits(cr_index, data, reg_mask);
	}
}

