/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_drv.h"
#include "via_chrome9_display_common.h"
#include "via_chrome9_hdac_renew.h"

extern bool hdtv_enabled;

static struct internal_encoder_list via_chrome9_internal_encoder_list[] = {
	{ VIA_CHROME9_DEVICE_ENCODER_DAC,
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "DAC" },
	{ VIA_CHROME9_DEVICE_ENCODER_DAC_2,
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "DAC" },
	{ VIA_CHROME9_DEVICE_ENCODER_LVDS,
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "LVDS" },
	{ VIA_CHROME9_DEVICE_ENCODER_HDMI,
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "HDMI" },
	{ VIA_CHROME9_DEVICE_ENCODER_HDMI_2,
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "HDMI" },
	{ VIA_CHROME9_DEVICE_ENCODER_DP_1, 
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "DP_1" },
	{ VIA_CHROME9_DEVICE_ENCODER_DP_2, 
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "DP_2" },
	{ VIA_CHROME9_DEVICE_ENCODER_TMDS, 
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "TMDS" },
	{ VIA_CHROME9_DEVICE_ENCODER_LVDS_2, 
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "LVDS" },
	//{ VIA_CHROME9_DEVICE_ENCODER_TV, 0, "TV" },
	{ VIA_CHROME9_DEVICE_ENCODER_TV, 
			VX900_INDEX, "TV" },
	{ VIA_CHROME9_DEVICE_ENCODER_TMDS_2, 
			VX800_INDEX | VX855_INDEX | VX900_INDEX, "TMDS" },
};

const int via_chrome9_encoder_convert[] = {
	DRM_MODE_ENCODER_NONE,
	/* VIA_CHROME9_ENCODER_DAC_INDEX */
	DRM_MODE_ENCODER_DAC,
	/* VIA_CHROME9_ENCODER_LVDS_INDEX */
	DRM_MODE_ENCODER_LVDS,
	/* VIA_CHROME9_ENCODER_TMDS_INDEX */
	DRM_MODE_ENCODER_TMDS,
	/* VIA_CHROME9_ENCODER_DP_1_INDEX */
	DRM_MODE_ENCODER_TMDS,
	/* VIA_CHROME9_ENCODER_DP_2_INDEX */
	DRM_MODE_ENCODER_TMDS,
	/* VIA_CHROME9_ENCODER_TV_INDEX */
	DRM_MODE_ENCODER_TVDAC,
	/* VIA_CHROME9_ENCODER_HDMI_INDEX */
	DRM_MODE_ENCODER_TMDS,
	/* VIA_CHROME9_ENCODER_LVDS_2_INDEX */
	DRM_MODE_ENCODER_LVDS,
	/* VIA_CHROME9_ENCODER_TMDS_2_INDEX */
	DRM_MODE_ENCODER_TMDS, 
	/* VIA_CHROME9_ENCODER_DAC_2_INDEX */
	DRM_MODE_ENCODER_DAC,
	/* VIA_CHROME9_ENCODER_HDMI_2_INDEX */
	DRM_MODE_ENCODER_TMDS,
	DRM_MODE_ENCODER_NONE,
};

struct display_timing_table via_lcd_modes[] = {
	/* Panel 480x640 (Special) */
	{ VIA_480X640, REFRESH_60, CLK_22_000M, NEGATIVE, POSITIVE,
	{ 520, 480, 480, 40, 504, 8, 648, 640, 640, 8, 644, 2 } },

	/* Panel 640x480 (DMT) */
	{ VIA_640X480, REFRESH_60, CLK_25_175M, NEGATIVE, NEGATIVE,
	{ 800, 640, 640, 160, 656, 96, 525, 480, 480, 45, 490, 2 } },

	/* The LCD can't accept the VESA's 640x480 timing, because
	 *  The VESA's 640x480 timing has border and LCD doesn't have.
	 *  Modify hbs and hbe to eliminate the border.
	 */

	/* Panel 800x480 (CVT) */
	{ VIA_800X480, REFRESH_60, CLK_29_581M, NEGATIVE, POSITIVE,
	{ 992, 800, 800, 192, 824, 72, 500, 480, 480, 20, 483, 7 } },

	/* Panel 800x600 (DMT) */
	{ VIA_800X600, REFRESH_60, CLK_40_000M, POSITIVE, POSITIVE,
	{ 1056, 800, 800, 256, 840, 128, 628, 600, 600, 28, 601, 4 } },

	/* Panel 1024x600 */
	{ VIA_1024X600, REFRESH_60, CLK_48_875M, NEGATIVE, POSITIVE,
	{ 1312, 1024, 1024, 288, 1064, 104, 622, 600, 600, 22, 601, 3 } },

	/* Panel 1024x768 (CVT Reduce) */
	{ VIA_1024X768, REFRESH_60, CLK_56_250M, POSITIVE, NEGATIVE,
	{ 1184, 1024, 1024, 160, 1072, 32, 790, 768, 768, 22, 771, 4 } },

	/* Panel 1280x768 (GTF) */
	{ VIA_1280X768, REFRESH_60, CLK_80_136M, NEGATIVE, POSITIVE,
	{ 1680, 1280, 1280, 400, 1344, 136, 795, 768, 768, 27, 769, 3 } },

	/* Panel 1280x800 (CVT Reduce) */
	{ VIA_1280X800, REFRESH_60, CLK_72_000M, POSITIVE, NEGATIVE,
	{ 1440, 1280, 1280, 160, 1328, 32, 823, 800, 800, 23, 803, 6 } },

	/* Panel 1280x1024 (DMT) */
	{ VIA_1280X1024, REFRESH_60, CLK_108_000M, POSITIVE, POSITIVE,
	{ 1688, 1280, 1280, 408, 1328, 112, 1066, 1024, 1024, 42, 1025, 3 } },

	/* Panel 1366x768 (GTF) */
	{ VIA_1366X768, REFRESH_60, CLK_85_860M, NEGATIVE, POSITIVE,
	{ 1800, 1368, 1368, 432, 1440, 144, 795, 768, 768, 27, 769, 3 } },

	/* Panel 1360x768 (DMT) */
	{ VIA_1360X768, REFRESH_60, CLK_85_500M, POSITIVE, POSITIVE,
	{ 1792, 1360, 1360, 432, 1424, 112, 795, 768, 768, 27, 771, 6 } },

	/* Panel 1400x1050 (CVT Reduce) */
	{ VIA_1400X1050, REFRESH_60, CLK_101_000M, POSITIVE, NEGATIVE,
	{ 1560, 1400, 1400, 160, 1448, 32, 1080, 1050, 1050, 30, 1053, 4 } },

	/* Panel 1440x900*/
	{ VIA_1440X900, REFRESH_60, CLK_88_750M, POSITIVE, NEGATIVE,
	{ 1760, 1440, 1440, 320, 1495, 105, 912, 900, 900, 12, 901, 2 } },

	/* Panel 16x12 (CVT Reduce)*/
	{ VIA_1600X1200, REFRESH_60, CLK_130_250M, POSITIVE, NEGATIVE,
	{ 1760, 1600, 1600, 160, 1648, 32, 1235, 1200, 1200, 35, 1203, 4 } },

	/* AUO Panel 1920x1080 */
	{ VIA_1920X1080, REFRESH_60, CLK_150_340M, POSITIVE, POSITIVE,
	{ 2120, 1920, 1920, 200, 1951, 48, 1120, 1080, 1080, 40, 1082, 6 } }
};

#define   NUM_VIA_LCD_TIMING_TBL   CMDISP_ARRAYSIZE(via_lcd_modes)
struct via_cea_timing_info_rec via_cea_timing_table[] = {
	/* ID   H_Res    V_Res   Refresh  Inter/Prog  VSynOff   Ratio  Use */
	{ 1,    640,   480,    60,    PROGRESSIVE,     0, RATIO_4_3, true },
	{ 2,    720,   480,    60,    PROGRESSIVE,     0, RATIO_4_3, true },
	{ 3,    720,   480,    60,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 4,  1280,   720,    60,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 5,  1920,   1080,   60,   INTERLACE,    1100, RATIO_16_9, true },
	{ 6,    720,   480,    60,   INTERLACE,        22, RATIO_4_3, false },
	{ 7,    720,   480,    60,   INTERLACE,        22, RATIO_16_9, false },
	{ 8,    720,   240,    60,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 9,    720,   240,    60,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 10,  2880,   480,    60,   INTERLACE,        22, RATIO_4_3, false},
	{ 11,  2880,   480,    60,   INTERLACE,        22, RATIO_16_9, false},
	{ 12,  2880,   240,    60,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 13,  2880,   240,    60,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 14,  1440,   480,    60,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 15,  1440,   480,    60,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 16,  1920,   1080,    60,    PROGRESSIVE,    0, RATIO_16_9, true },
	{ 17,    720,   576,    50,    PROGRESSIVE,     0, RATIO_4_3,  true },
	{ 18,    720,   576,    50,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 19,  1280,   720,    50,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 20,  1920,   1080,  50,     INTERLACE,    1320, RATIO_16_9, true },
	{ 21,    720,   576,    50,    INTERLACE,      864, RATIO_4_3, false},
	{ 22,    720,   576,    50,    INTERLACE,      864, RATIO_16_9, false},
	{ 23,    720,   288,    50,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 24,    720,   288,    50,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 25,  2880,   576,    50,    INTERLACE,     1728, RATIO_4_3, false},
	{ 26,  2880,   576,    50,    INTERLACE,     1728, RATIO_16_9, false},
	{ 27,  2880,   288,    50,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 28,  2880,   288,    50,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 29,  1440,   576,    50,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 30,  1440,   576,    50,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 31,  1920,   1080,  50,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 32,  1920,   1080,  24,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 33,  1920,   1080,  25,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 34,  1920,   1080,  30,    PROGRESSIVE,     0, RATIO_16_9, true },
	{ 35,  2880,   480,    60,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 36,  2880,   480,    60,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 37,  2880,   576,    50,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 38,  2880,   576,    50,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 39,  1920,   1080,    50,   INTERLACE,   1152,  RATIO_16_9, true },
	{ 40,  1920,   1080,   100,  INTERLACE,   1320,  RATIO_16_9, false},
	{ 41,  1280,   720,   100,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 42,   720,    576,   100,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 43,   720,    576,   100,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 44,   720,    576,   100,   INTERLACE,       864, RATIO_16_9, false},
	{ 45,   720,    576,   100,   INTERLACE,       864, RATIO_4_3, false},
	{ 46,  1920,   1080,   120,  INTERLACE,     1100, RATIO_16_9, false},
	{ 47,  1280,   720,   120,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 48,   720,    480,   120,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 49,   720,    480,   120,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 50,   720,    480,   120,    INTERLACE,     1134, RATIO_4_3, false},
	{ 51,   720,    480,   120,    INTERLACE,     1134, RATIO_16_9, false},
	{ 52,   720,    576,   200,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 53,   720,    576,   200,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 54,   720,    576,   200,    INTERLACE,      864, RATIO_4_3, false},
	{ 55,   720,    576,   200,    INTERLACE,      864, RATIO_16_9, false},
	{ 56,   720,    480,   240,    PROGRESSIVE,     0, RATIO_4_3, false},
	{ 57,   720,    480,   240,    PROGRESSIVE,     0, RATIO_16_9, false},
	{ 58,   720,    480,   240,    INTERLACE,     1134, RATIO_4_3, false},
	{ 59,   720,    480,   240,    INTERLACE,     1134, RATIO_16_9, false},
};

extern bool via_chrome9_mode_fixup_helper(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode, 
		int dwDevice );

extern int via_chrome9_set_active_disp_dev_config(struct drm_crtc *crtc,
		unsigned int  SetDevice);


static void via_chrome9_device_dpms(struct drm_encoder *encoder, 
		int mode, unsigned int DisplayDevice)
{
	struct drm_device *dev = encoder->dev;
	struct drm_connector *connector;
	struct via_chrome9_connector* via_conn = NULL;

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		if(encoder ==  connector->encoder) {
			via_conn = to_via_chrome9_connector(connector);
			break;
		}
	}
	if (!via_conn)
		return;

	KMS_DEBUG("DisplayDevice 0x%x dpms mode is 0x%x. \n", DisplayDevice, mode);

	switch (mode) {
	case DRM_MODE_DPMS_ON:
		via_chrome9_set_disp_dev_power_state(DisplayDevice, true);
		break;
	case DRM_MODE_DPMS_STANDBY:
	case DRM_MODE_DPMS_SUSPEND:
	case DRM_MODE_DPMS_OFF:
		via_chrome9_set_disp_dev_power_state(DisplayDevice, false);
		break;
	}
	return;
}


void via_chrome9_enc_destroy(struct drm_encoder *encoder)
{
	struct via_chrome9_encoder *via_chrome9_encoder =
		to_via_chrome9_encoder(encoder);

	kfree(via_chrome9_encoder->encoder_private);
	drm_encoder_cleanup(encoder);
	kfree(via_chrome9_encoder);
}

static void via_chrome9_encoder_disable(struct drm_encoder *encoder)
{
	struct drm_encoder_helper_funcs *encoder_funcs;

	encoder_funcs = encoder->helper_private;
	encoder_funcs->dpms(encoder, DRM_MODE_DPMS_OFF);
}

static void via_chrome9_dac_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_CRT);
}

static bool via_chrome9_dac_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_CRT);
	return true;
}

static void via_chrome9_dac_prepare(struct drm_encoder *encoder)
{
	via_chrome9_dac_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_CRT);
}

static void via_chrome9_dac_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_dac_commit(struct drm_encoder *encoder)
{
	via_chrome9_dac_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_dac_helper_funcs = {
	.dpms = via_chrome9_dac_dpms,
	.mode_fixup = via_chrome9_dac_mode_fixup,
	.prepare = via_chrome9_dac_prepare,
	.mode_set = via_chrome9_dac_mode_set,
	.commit = via_chrome9_dac_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_dac_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};


static void via_chrome9_dac_2_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_CRT2);
}

static bool via_chrome9_dac_2_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_CRT2);
	return true;
}

static void via_chrome9_dac_2_prepare(struct drm_encoder *encoder)
{
	via_chrome9_dac_2_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_CRT2);
}

static void via_chrome9_dac_2_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_dac_2_commit(struct drm_encoder *encoder)
{
	via_chrome9_dac_2_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_dac_2_helper_funcs = {
	.dpms = via_chrome9_dac_2_dpms,
	.mode_fixup = via_chrome9_dac_2_mode_fixup,
	.prepare = via_chrome9_dac_2_prepare,
	.mode_set = via_chrome9_dac_2_mode_set,
	.commit = via_chrome9_dac_2_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_dac_2_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};


static void via_chrome9_lvds_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_PANEL);
}

static void via_chrome9_lvds_prepare(struct drm_encoder *encoder)
{
	via_chrome9_lvds_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_PANEL);
}

bool via_chrome9_lvds_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_PANEL);
	return true;
}

static void via_chrome9_lvds_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_lvds_commit(struct drm_encoder *encoder)
{
	via_chrome9_lvds_dpms(encoder, DRM_MODE_DPMS_ON);
}

static enum drm_connector_status via_chrome9_lvds_detect(
		struct drm_encoder *encoder,
		struct drm_connector *connector)
{
	return connector_status_connected;
}

static const struct drm_encoder_helper_funcs via_chrome9_lvds_helper_funcs = {
	.dpms = via_chrome9_lvds_dpms,
	.mode_fixup = via_chrome9_lvds_mode_fixup,
	.prepare = via_chrome9_lvds_prepare,
	.mode_set = via_chrome9_lvds_mode_set,
	.commit = via_chrome9_lvds_commit,
	.detect = via_chrome9_lvds_detect,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_lvds_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_lvds_2_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_PANEL2);
}

static void via_chrome9_lvds_2_prepare(struct drm_encoder *encoder)
{
	via_chrome9_lvds_2_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_PANEL2);
}

bool via_chrome9_lvds_2_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_PANEL2);
	return true;
}


static void via_chrome9_lvds_2_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}


static void via_chrome9_lvds_2_commit(struct drm_encoder *encoder)
{
	via_chrome9_lvds_2_dpms(encoder, DRM_MODE_DPMS_ON);
}


static enum drm_connector_status via_chrome9_lvds_2_detect(
		struct drm_encoder *encoder,
		struct drm_connector *connector)
{
	return connector_status_connected;
}

static const struct drm_encoder_helper_funcs via_chrome9_lvds_2_helper_funcs = {
	.dpms = via_chrome9_lvds_2_dpms,
	.mode_fixup = via_chrome9_lvds_2_mode_fixup,
	.prepare = via_chrome9_lvds_2_prepare,
	.mode_set = via_chrome9_lvds_2_mode_set,
	.commit = via_chrome9_lvds_2_commit,
	.detect = via_chrome9_lvds_2_detect,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_lvds_2_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_hdmi_enc_dpms(struct drm_encoder *encoder, int mode)
{
	struct drm_device *dev = encoder->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_HDMI);

	/* CTS renew for VT3410 HDMI-1 only */
	if(dev->pci_device == VX900_DEVICE) {
		switch (mode) {
		case DRM_MODE_DPMS_ON:
			CTS_RENEW_ON((p_priv->hdmi_cts_renew));
			break;
		case DRM_MODE_DPMS_STANDBY:
		case DRM_MODE_DPMS_SUSPEND:
		case DRM_MODE_DPMS_OFF:
			CTS_RENEW_OFF((p_priv->hdmi_cts_renew));
			break;
		}
	}
}

bool via_hdmi_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_HDMI);
	return true;
}

static bool via_chrome9_internal_hdmi_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return via_hdmi_mode_fixup(encoder, mode, adjusted_mode);
}

static bool via_chrome9_hdmi_enc_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct via_chrome9_encoder *via_chrome9_encoder =
		to_via_chrome9_encoder(encoder);
	struct via_chrome9_crtc *via_chrome9_crtc =
		to_via_chrome9_crtc(encoder->crtc);
	struct via_hdmi_encoder_private_info *via_hdmi_enc_info = NULL;
	bool ret = false;
	via_hdmi_enc_info = (struct via_hdmi_encoder_private_info *)
		via_chrome9_encoder->encoder_private;
	via_chrome9_crtc->crtc_scale_status = 0;
	KMS_DEBUG("\n");
	ret =via_chrome9_internal_hdmi_mode_fixup(
			encoder, mode, adjusted_mode);
	KMS_DEBUG("internal hdmi connector\n");
	return ret;
}


static void via_chrome9_hdmi_enc_prepare(struct drm_encoder *encoder)
{
	via_chrome9_hdmi_enc_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_HDMI);
}

static void via_chrome9_hdmi_enc_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_hdmi_enc_commit(struct drm_encoder *encoder)
{
	via_chrome9_hdmi_enc_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs
	via_chrome9_hdmi_enc_helper_funcs = {
	.dpms = via_chrome9_hdmi_enc_dpms,
	.mode_fixup = via_chrome9_hdmi_enc_mode_fixup,
	.prepare = via_chrome9_hdmi_enc_prepare,
	.mode_set = via_chrome9_hdmi_enc_mode_set,
	.commit = via_chrome9_hdmi_enc_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_hdmi_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};


static void via_chrome9_hdmi_2_enc_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_HDMI2);
}

bool via_hdmi_2_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_HDMI2);
	return true;
}

static bool via_chrome9_hdmi_2_enc_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct via_chrome9_crtc *via_chrome9_crtc =
		to_via_chrome9_crtc(encoder->crtc);
	bool ret = false;

	KMS_DEBUG("hdmi_2 connector\n");

	via_chrome9_crtc->crtc_scale_status = 0;

	ret =via_hdmi_2_mode_fixup(encoder, mode, adjusted_mode);

	return ret;
}


static void via_chrome9_hdmi_2_enc_prepare(struct drm_encoder *encoder)
{
	via_chrome9_hdmi_2_enc_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_HDMI2);
}

static void via_chrome9_hdmi_2_enc_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_hdmi_2_enc_commit(struct drm_encoder *encoder)
{
	via_chrome9_hdmi_2_enc_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs
	via_chrome9_hdmi_2_enc_helper_funcs = {
	.dpms = via_chrome9_hdmi_2_enc_dpms,
	.mode_fixup = via_chrome9_hdmi_2_enc_mode_fixup,
	.prepare = via_chrome9_hdmi_2_enc_prepare,
	.mode_set = via_chrome9_hdmi_2_enc_mode_set,
	.commit = via_chrome9_hdmi_2_enc_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_hdmi_2_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_DP_1_enc_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_DP);
}

static bool via_chrome9_DP_1_enc_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_DP);
	return true;
}

static void via_chrome9_DP_1_enc_prepare(struct drm_encoder *encoder)
{
	via_chrome9_DP_1_enc_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_DP);
}

static void via_chrome9_DP_1_enc_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_DP_1_enc_commit(struct drm_encoder *encoder)
{
	via_chrome9_DP_1_enc_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs
	via_chrome9_DP_1_enc_helper_funcs = {
	.dpms = via_chrome9_DP_1_enc_dpms,
	.mode_fixup = via_chrome9_DP_1_enc_mode_fixup,
	.prepare = via_chrome9_DP_1_enc_prepare,
	.mode_set = via_chrome9_DP_1_enc_mode_set,
	.commit = via_chrome9_DP_1_enc_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_DP_1_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_DP_2_enc_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_DP2);
}

static bool via_chrome9_DP_2_enc_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_DP2);
	return true;
}

static void via_chrome9_DP_2_enc_prepare(struct drm_encoder *encoder)
{
	via_chrome9_DP_2_enc_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_DP2);
}

static void via_chrome9_DP_2_enc_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_DP_2_enc_commit(struct drm_encoder *encoder)
{
	via_chrome9_DP_2_enc_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs
	via_chrome9_DP_2_enc_helper_funcs = {
	.dpms = via_chrome9_DP_2_enc_dpms,
	.mode_fixup = via_chrome9_DP_2_enc_mode_fixup,
	.prepare = via_chrome9_DP_2_enc_prepare,
	.mode_set = via_chrome9_DP_2_enc_mode_set,
	.commit = via_chrome9_DP_2_enc_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_DP_2_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_tmds_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_DVI);
}

static bool via_chrome9_tmds_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_DVI);
	return true;
}

static void via_chrome9_tmds_prepare(struct drm_encoder *encoder)
{
	via_chrome9_tmds_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_DVI);
}

static void via_chrome9_tmds_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_tmds_commit(struct drm_encoder *encoder)
{
	via_chrome9_tmds_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_tmds_helper_funcs = {
	.dpms = via_chrome9_tmds_dpms,
	.mode_fixup = via_chrome9_tmds_mode_fixup,
	.prepare = via_chrome9_tmds_prepare,
	.mode_set = via_chrome9_tmds_mode_set,
	.commit = via_chrome9_tmds_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_tmds_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_tmds_2_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_DVI2);
}

static bool via_chrome9_tmds_2_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_DVI2);
	return true;
}

static void via_chrome9_tmds_2_prepare(struct drm_encoder *encoder)
{
	via_chrome9_tmds_2_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_DVI2);
}

static void via_chrome9_tmds_2_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_tmds_2_commit(struct drm_encoder *encoder)
{
	via_chrome9_tmds_2_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_tmds_2_helper_funcs = {
	.dpms = via_chrome9_tmds_2_dpms,
	.mode_fixup = via_chrome9_tmds_2_mode_fixup,
	.prepare = via_chrome9_tmds_2_prepare,
	.mode_set = via_chrome9_tmds_2_mode_set,
	.commit = via_chrome9_tmds_2_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_tmds_2_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_tv_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_TV);
}

static bool via_chrome9_tv_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_TV);
	return true;
}

static void via_chrome9_tv_prepare(struct drm_encoder *encoder)
{
	via_chrome9_tv_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_TV);
}

static void via_chrome9_tv_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_tv_commit(struct drm_encoder *encoder)
{
	via_chrome9_tv_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_tv_helper_funcs = {
	.dpms = via_chrome9_tv_dpms,
	.mode_fixup = via_chrome9_tv_mode_fixup,
	.prepare = via_chrome9_tv_prepare,
	.mode_set = via_chrome9_tv_mode_set,
	.commit = via_chrome9_tv_commit,
	.disable = via_chrome9_encoder_disable,
};

static const struct drm_encoder_funcs via_chrome9_tv_enc_funcs = {
	.destroy = via_chrome9_enc_destroy,
};

static void via_chrome9_hdtv_dpms(struct drm_encoder *encoder, int mode)
{
	via_chrome9_device_dpms(encoder, mode, ACTIVE_TYPE_HDTV);
}

static bool via_chrome9_hdtv_mode_fixup(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	via_chrome9_crtc->crtc_scale_status = 0;

	via_chrome9_mode_fixup_helper(encoder, mode, adjusted_mode, 
			ACTIVE_TYPE_HDTV);
	return true;
}

static void via_chrome9_hdtv_prepare(struct drm_encoder *encoder)
{
	via_chrome9_hdtv_dpms(encoder, DRM_MODE_DPMS_OFF);
	via_chrome9_set_active_disp_dev_config(encoder->crtc, ACTIVE_TYPE_HDTV);
}

static void via_chrome9_hdtv_mode_set(struct drm_encoder *encoder,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return;
}

static void via_chrome9_hdtv_commit(struct drm_encoder *encoder)
{
	via_chrome9_hdtv_dpms(encoder, DRM_MODE_DPMS_ON);
}

static const struct drm_encoder_helper_funcs via_chrome9_hdtv_helper_funcs = {
	.dpms = via_chrome9_hdtv_dpms,
	.mode_fixup = via_chrome9_hdtv_mode_fixup,
	.prepare = via_chrome9_hdtv_prepare,
	.mode_set = via_chrome9_hdtv_mode_set,
	.commit = via_chrome9_hdtv_commit,
	.disable = via_chrome9_encoder_disable,
};

void via_chrome9_add_encoder(
		struct drm_device *dev, int encoder_id,
		enum via_chrome9_encoder_type type,
		uint32_t supported_connect_types)
{
	struct drm_encoder *encoder;
	struct via_chrome9_encoder *via_chrome9_encoder;
	struct via_dp_encoder_private_info
		*via_dp_1_encoder_private_info = NULL;
	struct via_dp_encoder_private_info
		*via_dp_2_encoder_private_info = NULL;
	struct via_hdmi_encoder_private_info
		*via_hdmi_encoder_private_info = NULL;
	struct via_hdmi_encoder_private_info
		*via_hdmi_2_encoder_private_info = NULL;
	int encoder_index;

	list_for_each_entry(encoder, &dev->mode_config.encoder_list, head) {
		via_chrome9_encoder = to_via_chrome9_encoder(encoder);
		if ((via_chrome9_encoder->encoder_id == encoder_id) &&
			(via_chrome9_encoder->encoder_type == type)) {
			via_chrome9_encoder->supported_connect_types |=
				supported_connect_types;
			return;
		}
	}

	via_chrome9_encoder = kzalloc(sizeof(struct via_chrome9_encoder),
		GFP_KERNEL);
	if (!via_chrome9_encoder) {
		DRM_INFO("allocate the encoder error\n");
		return;
	}

	via_chrome9_encoder->encoder_id = encoder_id;
	via_chrome9_encoder->supported_connect_types = supported_connect_types;
	via_chrome9_encoder->encoder_type = type;

	encoder = &via_chrome9_encoder->base;
	encoder->possible_crtcs = 0x3;

	switch (via_chrome9_encoder->encoder_id) {
	case VIA_CHROME9_DEVICE_ENCODER_DAC:
		encoder_index = VIA_CHROME9_ENCODER_DAC_INDEX;
		via_chrome9_encoder->di_port = DISP_DI_NONE;
		drm_encoder_init(dev, encoder, &via_chrome9_dac_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_dac_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_DAC_2:
		encoder_index = VIA_CHROME9_ENCODER_DAC_2_INDEX;
		via_chrome9_encoder->di_port = DISP_DI_NONE;
		drm_encoder_init(dev, encoder, &via_chrome9_dac_2_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_dac_2_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_LVDS:
		encoder_index = VIA_CHROME9_ENCODER_LVDS_INDEX;
		if (VX900_DEVICE != dev->pci_device)
			encoder->possible_crtcs = 0x2;

		via_chrome9_encoder->di_port = DISP_DI_DFPL;
		drm_encoder_init(dev, encoder, &via_chrome9_lvds_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_lvds_helper_funcs);
		break;
        case VIA_CHROME9_DEVICE_ENCODER_LVDS_2:
                encoder_index = VIA_CHROME9_ENCODER_LVDS_2_INDEX;
		if(VX900_DEVICE != dev->pci_device)
			encoder->possible_crtcs = 0x2;

		via_chrome9_encoder->di_port = DISP_DI_DFPH;
		drm_encoder_init(dev, encoder,  &via_chrome9_lvds_2_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_lvds_2_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_HDMI:
		via_hdmi_encoder_private_info = kzalloc(
			sizeof(struct via_hdmi_encoder_private_info), GFP_KERNEL);
		if (!via_hdmi_encoder_private_info) {
			DRM_INFO("allocate the hdmi private info error\n");
			return;
		}else{
			via_chrome9_encoder->encoder_private =
				(void *)via_hdmi_encoder_private_info;
		}	
		/* 
		 * need to check other hdmi enabled or not, 
		 * and modify the possiable crtc,
		 * the first hdmi default is 0x2 and the second hdmi is 0x1 
		 */
		encoder_index = VIA_CHROME9_ENCODER_HDMI_INDEX;
		if(VX900_DEVICE != dev->pci_device) {
			encoder->possible_crtcs = 0x2;
		}
		via_chrome9_encoder->di_port = DISP_DI_NONE;
		drm_encoder_init(dev, encoder, &via_chrome9_hdmi_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_hdmi_enc_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_HDMI_2:
		via_hdmi_2_encoder_private_info = kzalloc(
			sizeof(struct via_hdmi_encoder_private_info), GFP_KERNEL);
		if (!via_hdmi_2_encoder_private_info) {
			DRM_INFO("allocate the hdmi private info error\n");
			return;
		} else {
			via_chrome9_encoder->encoder_private =
				(void *)via_hdmi_2_encoder_private_info;
		}
		/* 
		 * need to check other hdmi enabled or not, 
		 * and modify the possiable crtc,
		 * the first hdmi default is 0x2 and the second hdmi is 0x1 
		 */
		encoder_index = VIA_CHROME9_ENCODER_HDMI_2_INDEX;
		if(VX900_DEVICE != dev->pci_device)
			encoder->possible_crtcs = 0x2;
		via_chrome9_encoder->di_port = DISP_DI_NONE;
		drm_encoder_init(dev, encoder, &via_chrome9_hdmi_2_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_hdmi_2_enc_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_DP_1:
		via_dp_1_encoder_private_info = kzalloc(
			sizeof(struct via_dp_encoder_private_info), GFP_KERNEL);
		if (!via_dp_1_encoder_private_info) {
			DRM_INFO("allocate the dp1 private info error\n");
			return;
		}
		via_chrome9_encoder->encoder_private =
			(void *)via_dp_1_encoder_private_info;

		encoder_index = VIA_CHROME9_ENCODER_DP_1_INDEX;
		drm_encoder_init(dev, encoder, &via_chrome9_DP_1_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_DP_1_enc_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_DP_2:
		via_dp_2_encoder_private_info = kzalloc(
			sizeof(struct via_dp_encoder_private_info), GFP_KERNEL);
		if (!via_dp_2_encoder_private_info) {
			DRM_INFO("allocate the dp2 private info error\n");
			return;
		}
		via_chrome9_encoder->encoder_private =
			(void *)via_dp_2_encoder_private_info;

		encoder_index = VIA_CHROME9_ENCODER_DP_2_INDEX;
		drm_encoder_init(dev, encoder, &via_chrome9_DP_2_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_DP_2_enc_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_TMDS:
		encoder_index = VIA_CHROME9_ENCODER_TMDS_INDEX;
		via_chrome9_encoder->di_port = DISP_DI_DFPL;
		drm_encoder_init(dev, encoder, &via_chrome9_tmds_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_tmds_helper_funcs);
		break;
		case VIA_CHROME9_DEVICE_ENCODER_TMDS_2:
		encoder_index = VIA_CHROME9_ENCODER_TMDS_2_INDEX;
		via_chrome9_encoder->di_port = DISP_DI_DFPL;
		drm_encoder_init(dev, encoder, &via_chrome9_tmds_2_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		drm_encoder_helper_add(encoder, &via_chrome9_tmds_2_helper_funcs);
		break;
	case VIA_CHROME9_DEVICE_ENCODER_TV:

     	encoder_index = VIA_CHROME9_ENCODER_TV_INDEX;
		drm_encoder_init(dev, encoder, &via_chrome9_tv_enc_funcs,
			via_chrome9_encoder_convert[encoder_index]);
		if(hdtv_enabled)
			drm_encoder_helper_add(encoder, &via_chrome9_hdtv_helper_funcs); 
		else
			drm_encoder_helper_add(encoder, &via_chrome9_tv_helper_funcs);        
		break;
	default:
		DRM_INFO("invalid encoder type\n");
		break;
	}
}

int via_chrome9_internal_encoder_init(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct internal_encoder_list encoder_prementer;
	int encoder_type, supported_connect_types, i;

	for (i = 0; i < ARRAY_SIZE(via_chrome9_internal_encoder_list); i++) {
		encoder_prementer = via_chrome9_internal_encoder_list[i];
		if (!(p_priv->mode_info.chip_index &
			encoder_prementer.support_chip_id))
			continue;
		encoder_type = encoder_prementer.encoder_type;

		KMS_DEBUG(" i=%x  encoder_type=%x  name=%s\n",
			i, encoder_type, encoder_prementer.name);

		switch (encoder_type) {
		case VIA_CHROME9_DEVICE_ENCODER_DAC:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_CRT;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev,VIA_CHROME9_DEVICE_CONNECTOR_CRT,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_DAC_2:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_CRT_2;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_CRT_2,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_LVDS:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_LCD;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_LCD,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_HDMI:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_HDMI ;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_HDMI,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_HDMI_2:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_DP_1:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_DP_1;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_DP_1,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_DP_2:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_DP_2;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_DP_2,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_TMDS:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_DVI_D;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_DVI_D,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_TMDS_2:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_DVI_D_2;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev,VIA_CHROME9_DEVICE_CONNECTOR_DVI_D_2,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_LVDS_2:
			supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_LCD_2;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev, VIA_CHROME9_DEVICE_CONNECTOR_LCD_2,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		case VIA_CHROME9_DEVICE_ENCODER_TV:
                    supported_connect_types = VIA_CHROME9_DEVICE_CONNECTOR_TV;
			via_chrome9_add_encoder(dev, encoder_type,
				VIA_CHROME9_INTERNAL_ENCODER, supported_connect_types);
			via_chrome9_add_connector(dev,VIA_CHROME9_DEVICE_CONNECTOR_TV,
				VIA_CHROME9_INTERNAL_CONNECTOR);
			break;
		default:
			DRM_INFO("unknow encoder type\n");
			break;
		}
	}
	return 0;
}
