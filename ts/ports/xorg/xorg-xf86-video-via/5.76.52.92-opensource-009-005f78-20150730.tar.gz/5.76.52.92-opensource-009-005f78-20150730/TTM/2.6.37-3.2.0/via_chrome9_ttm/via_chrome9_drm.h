/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_DRM_H_
#define _VIA_CHROME9_DRM_H_

#include "via_chrome9_drv.h"

/* Driver specific ioctl number */
#define DRM_VIA_CHROME9_ALLOCMEM                    0x00
#define DRM_VIA_CHROME9_FREEMEM                     0x01
#define DRM_VIA_CHROME9_FREE                        0x02
#define DRM_VIA_CHROME9_ALLOCATE_EVENT_TAG          0x03
#define DRM_VIA_CHROME9_FREE_EVENT_TAG              0x04
#define DRM_VIA_CHROME9_ALLOCATE_APERTURE           0x05
#define DRM_VIA_CHROME9_FREE_APERTURE               0x06
#define DRM_VIA_CHROME9_ALLOCATE_VIDEO_MEM          0x07
#define DRM_VIA_CHROME9_FREE_VIDEO_MEM              0x08
#define DRM_VIA_CHROME9_WAIT_CHIP_IDLE              0x09
#define DRM_VIA_CHROME9_PROCESS_EXIT                0x0A
#define DRM_VIA_CHROME9_RESTORE_PRIMARY             0x0B
#define DRM_VIA_CHROME9_FLUSH_CACHE                 0x0C
#define DRM_VIA_CHROME9_INIT                        0x0D
#define DRM_VIA_CHROME9_FLUSH                       0x0E
#define DRM_VIA_CHROME9_CHECKVIDMEMSIZE             0x0F
#define DRM_VIA_CHROME9_PCIEMEMCTRL                 0x10
#define DRM_VIA_CHROME9_AUTH_MAGIC	            0x11
#define DRM_VIA_CHROME9_GET_PCI_ID	            0x12
#define DRM_VIA_CHROME9_INIT_JUDGE		    0x16
#define DRM_VIA_CHROME9_DMA				    0x17
#define DRM_VIA_CHROME9_QUERY_BRANCH	    0x18
#define DRM_VIA_CHROME9_REQUEST_BRANCH_BUF	    0x19
#define DRM_VIA_CHROME9_BRANCH_BUF_FLUSH	    0x1A
/* GEM-interfaced TTM core parts */
#define DRM_VIA_CHROME9_GEM_CREATE		    0x20
#define DRM_VIA_CHROME9_GEM_MMAP		    0x21
#define DRM_VIA_CHROME9_GEM_PREAD		    0x22
#define DRM_VIA_CHROME9_GEM_PWRITE		    0x23
#define DRM_VIA_CHROME9_GEM_SET_DOMAIN		    0x24
#define DRM_VIA_CHROME9_GEM_FLUSH		    0x25
#define DRM_VIA_CHROME9_GEM_WAIT		    0x26
#define DRM_VIA_CHROME9_SHADOW_INIT		    0x27
#define DRM_VIA_CHROME9_GEM_CPU_GRAB		    0x28
#define DRM_VIA_CHROME9_GEM_CPU_RELEASE		    0x29
#define DRM_VIA_CHROME9_GEM_USER_CREATE		    0x2C
#define DRM_VIA_CHROME9_GEM_PIN			    0x30
#define DRM_VIA_CHROME9_GEM_UNPIN		    0x31
#define DRM_VIA_CHROME9_GEM_CHIPINFO                0x32
#define DRM_VIA_CHROME9_XORG_OPTIONS		    0x33
#define DRM_VIA_CHROME9_GET_CRTC_ID	            0x34
#define DRM_VIA_CHROME9_GET_BO_INFO                 0x35
#define DRM_VIA_CHROME9_SET_EDID				0x36
#define DRM_VIA_CHROME9_OUTPUT_MODE_VALID           0x37
#define DRM_VIA_CHROME9_CRTC_DPMS                   0x38
#define DRM_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO    0x39
#define DRM_VIA_CHROME9_PASS_MODE_LINE              0x40
#define DRM_VIA_CHROME9_HELPER_SET_MODE             0x41
#define DRM_VIA_CHROME9_GET_CLOCKS                  0x42
#define DRM_VIA_CHROME9_GET_TV_CONFIGURE                  0x43

/* The memory type for ttm */
#define VIA_CHROME9_GEM_DOMAIN_CPU		0x1
#define VIA_CHROME9_GEM_DOMAIN_GTT		0x2
#define VIA_CHROME9_GEM_DOMAIN_VRAM		0x4
#define VIA_CHROME9_GEM_DOMAIN_MASK		\
	(VIA_CHROME9_GEM_DOMAIN_CPU | VIA_CHROME9_GEM_DOMAIN_GTT | \
	VIA_CHROME9_GEM_DOMAIN_VRAM)		\
/* The memory flag for ttm */
#define VIA_CHROME9_GEM_FLAG_NO_EVICT    (1 << 21)

/* VIA Chrome9 FLUSH flag*/
#define VIA_CHROME9_FLUSH_RING_BUFFER		0x1
#define VIA_CHROME9_FLUSH_BRANCH_BUFFER		0x2

/*
 * VIA Chrome9 BO read/write domain
 */
/* read/write by GPU */
#define VIA_CHROME9_OBJ_DOMAIN_CPU		0x10
/* read/write by 2D engine */
#define VIA_CHROME9_OBJ_DOMAIN_2D		0x20
/* read/write by 3D engine */
#define VIA_CHROME9_OBJ_DOMAIN_3D		0x40
#define VIA_CHROME9_OBJ_DOMAIN_HQV0		0x80
#define VIA_CHROME9_OBJ_DOMAIN_HQV1		0x100
#define VIA_CHROME9_OBJ_DOMAIN_VD		0x200
#define VIA_CHROME9_OBJ_DOMAIN_VIDEO	0x400
/* read/write by HQV engine */
#define VIA_CHROME9_OBJ_DOMAIN_HQV \
	(VIA_CHROME9_OBJ_DOMAIN_HQV0 | VIA_CHROME9_OBJ_DOMAIN_HQV1)	\
/* read/write by GFX engine */
#define VIA_CHROME9_OBJ_DOMAIN_GFX \
	(VIA_CHROME9_OBJ_DOMAIN_2D | VIA_CHROME9_OBJ_DOMAIN_3D)	\
/* read/write by GPU */
#define VIA_CHROME9_OBJ_DOMAIN_GPU \
		(VIA_CHROME9_OBJ_DOMAIN_2D|VIA_CHROME9_OBJ_DOMAIN_3D |\
		VIA_CHROME9_OBJ_DOMAIN_VD | VIA_CHROME9_OBJ_DOMAIN_HQV |\
		VIA_CHROME9_OBJ_DOMAIN_VIDEO)

#define VIA_CHROME9_OBJ_DOMAIN_MASK		0x00000FF0

/* VIA Chrome9 BO flags */
#define VIA_CHROME9_BO_FLAG_CMD_FLUSHING	0x1

/* Define the R/W mode of each ioctl */
#define DRM_IOCTL_VIA_CHROME9_GEM_CREATE	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CREATE, \
	struct drm_via_chrome9_gem_create)
#define DRM_IOCTL_VIA_CHROME9_GEM_USER_CREATE	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_USER_CREATE, \
	struct drm_via_chrome9_gem_user_create)
#define DRM_IOCTL_VIA_CHROME9_GEM_MMAP	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_MMAP, \
	struct drm_via_chrome9_gem_mmap)
#define DRM_IOCTL_VIA_CHROME9_GEM_PREAD	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PREAD, \
	struct drm_via_chrome9_gem_pread)
#define DRM_IOCTL_VIA_CHROME9_GEM_PWRITE	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PWRITE, \
	struct drm_via_chrome9_gem_pwrite)
#define DRM_IOCTL_VIA_CHROME9_GEM_SET_DOMAIN	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_SET_DOMAIN, \
	struct drm_via_chrome9_gem_set_domain)
#define DRM_IOCTL_VIA_CHROME9_GEM_FLUSH	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_FLUSH, \
	struct drm_via_chrome9_gem_flush)
#define DRM_IOCTL_VIA_CHROME9_GEM_WAIT	\
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_WAIT, \
	struct drm_via_chrome9_gem_wait)
#define DRM_IOCTL_VIA_CHROME9_SHADOW_INIT \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_SHADOW_INIT, \
	struct drm_via_chrome9_shadow_init)
#define DRM_IOCTL_VIA_CHROME9_WAIT_CHIP_IDLE \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_WAIT_CHIP_IDLE, \
	struct drm_via_chrome9_shadow_init)
#define DRM_IOCTL_VIA_CHROME9_ALLOCATE_EVENT_TAG \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_ALLOCATE_EVENT_TAG, \
	struct drm_via_chrome9_event_tag)
#define DRM_IOCTL_VIA_CHROME9_FREE_EVENT_TAG \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_FREE_EVENT_TAG, \
	struct drm_via_chrome9_event_tag)
#define DRM_IOCTL_VIA_CHROME9_GEM_CPU_GRAB \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CPU_GRAB,\
	struct drm_via_chrome9_cpu_grab)
#define DRM_IOCTL_VIA_CHROME9_GEM_CPU_RELEASE \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CPU_RELEASE,\
	struct drm_via_chrome9_cpu_release)
#define DRM_IOCTL_VIA_CHROME9_GEM_PIN \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PIN, \
	struct drm_via_chrome9_gem_pin)
#define DRM_IOCTL_VIA_CHROME9_GEM_UNPIN \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_UNPIN, \
	struct drm_via_chrome9_gem_unpin)
#define DRM_IOCTL_VIA_CHROME9_GEM_CHIPINFO \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CHIPINFO, \
	struct drm_via_chip_info)
#define DRM_IOCTL_VIA_CHROME9_XORG_OPTIONS\
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_XORG_OPTIONS, \
	struct drm_via_chrome9_xorg_options)
#define DRM_IOCTL_VIA_CHROME9_GET_CRTC_ID \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CRTC_ID, \
	struct drm_get_crtc_id_info)
#define DRM_IOCTL_VIA_CHROME9_GET_BO_INFO \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_BO_INFO,\
	struct drm_get_bo_info)
#define DRM_IOCTL_VIA_CHROME9_SET_EDID\
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_SET_EDID, \
	struct drm_via_chrome9_edid)
#define DRM_IOCTL_VIA_CHROME9_OUTPUT_MODE_VALID\
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_OUTPUT_MODE_VALID, \
	struct drm_via_chrome9_output_kmode)
#define DRM_IOCTL_VIA_CHROME9_CRTC_DPMS  \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_CRTC_DPMS, \
	struct drm_crtc_dpms_info)
#define DRM_IOCTL_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO  \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO, \
	struct drm_get_customize_timing_info)
#define DRM_IOCTL_VIA_CHROME9_PASS_MODE_LINE  \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_PASS_MODE_LINE, \
	struct drm_pass_customize_timing)
#define DRM_IOCTL_VIA_CHROME9_HELPER_SET_MODE \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_HELPER_SET_MODE, \
	struct drm_via_chrome9_mode_set_par)
#define DRM_IOCTL_VIA_CHROME9_GET_CLOCKS \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CLOCKS, \
	struct drm_via_chrome9_clocks)
#define DRM_IOCTL_VIA_CHROME9_GET_TV_CONFIGURE \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_TV_CONFIGURE, \
	struct drm_via_chrome9_tv_type)

/* The data structure of each ioctl, which is used to
 * communicate between user mode and kernel mode
 */
struct drm_via_chrome9_gem_create {
	uint64_t	size;
	uint64_t	alignment;
	uint32_t	handle;
	uint32_t	initial_domain;
	uint32_t	flags;
	uint32_t	offset;
};

struct drm_via_chrome9_gem_user_create {
	uint64_t	size;
	uint64_t  start_addr;
	uint64_t	alignment;
	uint32_t	handle;
	uint32_t	initial_domain;
	uint32_t	flags;
	uint32_t	offset;
};

struct drm_via_chrome9_gem_mmap {
	uint32_t	handle;
	uint32_t	pad;
	uint64_t	offset;
	uint64_t	size;
	uint64_t	addr_ptr;
	void	*virtual;
};

struct drm_via_chrome9_gem_pread {
	/** Handle for the object being read. */
	uint32_t handle;
	uint32_t pad;
	/** Offset into the object to read from */
	uint64_t offset;
	/** Length of data to read */
	uint64_t size;
	/** Pointer to write the data into. */
	/* void *, but pointers are not 32/64 compatible */
	uint64_t data_ptr;
};

struct drm_via_chrome9_gem_pwrite {
	/** Handle for the object being written to. */
	uint32_t handle;
	uint32_t pad;
	/** Offset into the object to write to */
	uint64_t offset;
	/** Length of data to write */
	uint64_t size;
	/** Pointer to read the data from. */
	/* void *, but pointers are not 32/64 compatible */
	uint64_t data_ptr;
};

struct drm_via_chrome9_gem_set_domain {
	uint32_t	handle;
	uint32_t	read_domains;
	uint32_t	write_domain;
};

struct drm_via_chrome9_gem_wait {
	/* the buffer object handle */
	uint32_t handle;
	uint32_t no_wait;
};

struct drm_via_chrome9_gem_flush {
	/* the pointer to this exec buffer */
	uint64_t buffer_ptr;
	uint32_t num_cliprects;
	/* This is a struct drm_clip_rect *cliprects */
	uint64_t cliprects_ptr;
	uint32_t flag;
};

enum drm_via_chrome9_reloc_type {
	/* the reloc type for 2D command */
	VIA_RELOC_2D,
	/* the reloc type for 3D command */
	VIA_RELOC_3D,
	/* the reloc type for video*/
	VIA_RELOC_HQV0,
	VIA_RELOC_HQV1,
	VIA_RELOC_VIDEO,
	VIA_RELOC_VERTEX_STREAM_L,
	VIA_RELOC_VERTEX_STREAM_H,
	VIA_RELOC_VD
};

struct drm_via_chrome9_gem_relocation_entry {
	/* the target bo handle which add at the reloc list */
	uint32_t target_handle;
	/* the additional offset to this bo */
	uint32_t delta;
	/* this offset to command buffer */
	uint64_t offset;
	/* the target bo offset */
	uint64_t presumed_offset;
	/* the mask indicate this bo location */
	uint32_t location_mask;
	/* the command type for this target bo*/
	enum drm_via_chrome9_reloc_type type;
	/* read write domain by this operation*/
	uint32_t	read_domains;
	uint32_t	write_domain;
	/* for multi-level branch buffer
	 * '0' for cpu access
	 */
	uint32_t    access_engine_type;
};

struct drm_via_chrome9_gem_exec_object {
	/* the command buffer pointer */
	union {
		uint64_t buffer_ptr;
		uint32_t cmd_bo_handle;
	};
	/* the reloc list pointer */
	uint64_t relocs_ptr;
	/* the buffer length we want to exec (dword) */
	uint32_t buffer_length;
	/* the bo count for reloc list */
	uint32_t relocation_count;
};

struct drm_via_chrome9_shadow_init {
	/*for shadow & event tag*/
	unsigned int   shadow_size;
	unsigned long   shadow_handle;
};

struct drm_via_chrome9_cpu_release {
	uint32_t   handle;
};

struct drm_via_chrome9_cpu_grab {
	uint32_t handle;
	uint32_t flags;
};

/* @handle: bo handle
 * @location_mask: to which location bo pinned
 * @offset: the updated offset deliver to user
 * After pin, user mode process should fetch the updated
 * vram address from @offset
 */
struct drm_via_chrome9_gem_pin {
	uint32_t handle;
	uint32_t location_mask;
	uint64_t offset;
};

struct drm_via_chrome9_gem_unpin {
	uint32_t handle;
};

struct event_value {
	int event_low;
	int event_high;
};

struct drm_via_chrome9_event_tag {
	unsigned int  event_size;         /* event tag size */
	int	 event_offset;                /* event tag id */
	struct event_value last_sent_event_value;
	struct event_value current_event_value;
	int         query_mask0;
	int         query_mask1;
	int         query_Id1;
};

/*when dri2 enable,__glS3InvInitialize need some chip info,
 * so get it througth drm.
 */
struct drm_via_chip_info {
	unsigned short vendor;
	unsigned short device_id;
	unsigned short subsystem_vendor;
	unsigned short subsystem_device_id;
	unsigned long shadowSize;
	unsigned long shadowHandle;
	unsigned long mmioSize;
	unsigned long mmioHandle;
	unsigned long fbSize;
};

struct drm_get_bo_info {
	uint32_t handle;
	unsigned long offset;
	uint32_t domains;
};

struct drm_via_chrome9_xorg_options {
	uint32_t connector_id;
	void *xorg_options;
	uint32_t options_size;
};

struct drm_get_crtc_id_info {
	int crtc_id;
	int crtc_hw_id;
};

struct drm_via_chrome9_edid {
	uint32_t connector_id;
	void *edid;
	uint32_t edid_size;
};

struct drm_via_chrome9_output_kmode {
	uint32_t connector_id;	
	uint32_t mode_status;
	void *output_kmode;
};

struct drm_crtc_dpms_info {
	uint32_t crtc_id;
	uint32_t status;
};

struct drm_get_customize_timing_info {
	int crtc_id;
	uint32_t connector_id;
	uint32_t pixel_clock;

	uint32_t disp_dev;
	uint32_t color_depth;
	uint32_t v_pll;
};

struct drm_pass_customize_timing {
	void *ml_pkg;
	uint32_t pkg_size;

	void *cust_tm_aux_info_ptr;
	uint32_t  cust_tm_aux_info_len;
};

struct drm_via_chrome9_mode_set_par {
	uint32_t connector_id;
};

// define a structure for Clocks
struct drm_via_chrome9_clocks{
    unsigned int  eng_clock;
    unsigned int  gpu_clock;
    unsigned int  mem_clock;
};

// define a structure for TV
struct drm_via_chrome9_tv_type{
    unsigned int  hdtv_enabled;
};


extern int via_chrome9_ioctl_gem_create(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_user_create(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_mmap(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_pread(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_pwrite(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_set_domain(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_wait(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_flush(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_shadow_init(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_shadow_fini(
		struct drm_device *dev);
extern int via_chrome9_ioctl_alloc_event(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_free_event(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_wait_chip_idle(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_cpu_grab(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_cpu_release(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_pin(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_gem_unpin(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_chipinfo_gem(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_xorg_options(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_get_crtc_id(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_get_bo_info(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_set_edid(
		struct drm_device *dev, void *data, struct drm_file *file_priv);
extern int via_chrome9_ioctl_output_mode_valid(struct drm_device *dev, void *data,
		struct drm_file *file_priv);
extern int via_chrome9_ioctl_crtc_dpms(struct drm_device *dev, void *data,
		struct drm_file *file_priv);
extern int via_chrome9_ioctl_get_customize_timing_info(struct drm_device *dev, void *data,
		struct drm_file *file_priv);
extern int via_chrome9_ioctl_pass_customize_timing(struct drm_device *dev, void *data,
		struct drm_file *file_priv);
extern int via_chrome9_ioctl_helper_set_mode(struct drm_device *dev, void *data,
            struct drm_file *file_priv);
extern int via_chrome9_ioctl_get_clocks(struct drm_device *dev, void *data,
		struct drm_file *file_priv);
extern int via_chrome9_ioctl_get_tv_configure(struct drm_device *dev, void *data,
		struct drm_file *file_priv);

int via_chrome9_drm_resume(struct drm_device *dev);
int  via_chrome9_drm_suspend(struct drm_device *dev, pm_message_t state);
void via_chrome9_init_gart_table(struct drm_device *dev);
void set_agp_ring_buffer_stop(struct drm_device *dev);
void set_agp_ring_cmd_inv(struct drm_device *dev);
extern void via_chrome9_drm_restore_bos(struct drm_device *dev);
extern void via_chrome9_drm_save_bos(struct drm_device *dev);
void via_chrome9_preclose(struct drm_device *dev, struct drm_file *file_priv);
void via_chrome9_lastclose(struct drm_device *dev);
void via_chrome9_driver_irq_preinstall(struct drm_device *dev);
int via_chrome9_driver_irq_postinstall(struct drm_device *dev);
void via_chrome9_driver_irq_uninstall(struct drm_device *dev);
irqreturn_t via_chrome9_driver_irq_handler(DRM_IRQ_ARGS);
void via_chrome9_irq_preinstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv);
void via_chrome9_irq_uninstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv);
void via_chrome9_irq_postinstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv);
irqreturn_t via_chrome9_driver_irq_handler_nonKMS(DRM_IRQ_ARGS);
extern int via_chrome9_enable_vblank(struct drm_device *dev, int crtc);
extern void via_chrome9_disable_vblank(struct drm_device *dev, int crtc);
extern int waitchipidle_inv(struct drm_via_chrome9_private *dev_priv);
long via_chrome9_compat_ioctl(
		struct file *filp, unsigned int cmd, unsigned long arg);
extern void via_chrome9_parse_customize_timing_pkg(struct drm_device *dev, 
		u8 *cust_tm_buf_ptr, u32 *disp_devs_and_mls, uint32_t disp_devs_and_mls_len);

#endif				/* _VIA_CHROME9_DRM_H_ */
