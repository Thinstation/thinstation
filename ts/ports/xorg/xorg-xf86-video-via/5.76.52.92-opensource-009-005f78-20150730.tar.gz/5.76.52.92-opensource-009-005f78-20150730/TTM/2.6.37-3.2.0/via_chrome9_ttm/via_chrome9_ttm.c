/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_ttm.h"
#include "via_chrome9_fence.h"
#include "via_chrome9_object.h"
#include <linux/version.h>


static struct ttm_backend *via_chrome9_create_ttm_backend_entry(
		struct ttm_bo_device *bdev)
{
	struct drm_via_chrome9_private *p_priv;

	p_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	return via_chrome9_pcie_backend_init(p_priv);
}

static int via_chrome9_invalidate_caches(struct ttm_bo_device *bdev,
		uint32_t flags)
{
	return 0;
}

static int via_chrome9_init_mem_type(struct ttm_bo_device *bdev, uint32_t type,
				struct ttm_mem_type_manager *man)
{
	struct drm_via_chrome9_private *p_priv;

	p_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	switch (type) {
	case TTM_PL_SYSTEM:
		/* System memory */
		man->flags = TTM_MEMTYPE_FLAG_MAPPABLE;
		man->available_caching = TTM_PL_FLAG_CACHED;
		man->default_caching = TTM_PL_FLAG_CACHED;
		break;
	case TTM_PL_TT:
		/* Pcie memory */
		man->func = &ttm_bo_manager_func;
		man->flags = TTM_MEMTYPE_FLAG_MAPPABLE | TTM_MEMTYPE_FLAG_CMA;
		man->gpu_offset = 0;
		man->available_caching = TTM_PL_FLAG_UNCACHED | TTM_PL_FLAG_WC |
			TTM_PL_FLAG_CACHED;
		man->default_caching = TTM_PL_FLAG_CACHED;
		break;
	case TTM_PL_VRAM:
		/* Frame buffer memory */
		man->func = &ttm_bo_manager_func;
		man->flags = TTM_MEMTYPE_FLAG_MAPPABLE |
				TTM_MEMTYPE_FLAG_FIXED;
		man->gpu_offset = 0;
		man->available_caching = TTM_PL_FLAG_UNCACHED | TTM_PL_FLAG_WC;
		man->default_caching = TTM_PL_FLAG_WC;
		break;
	default:
		DRM_ERROR("Unsupported memory type %u\n", (unsigned)type);
		return -EINVAL;
	}
	return 0;
}

/* set the default flag for evict memory */
static void via_chrome9_evict_flags(struct ttm_buffer_object *bo,
					struct ttm_placement *placement)
{
	struct via_chrome9_object *vbo;

	vbo = container_of(bo, struct via_chrome9_object, bo);
	via_ttm_placement_from_domain(vbo, VIA_CHROME9_GEM_DOMAIN_CPU);

	*placement = vbo->placement;
}


static int via_chrome9_verify_access(struct ttm_buffer_object *bo,
	struct file *filp)
{
	return 0;
}

static inline bool via_chrome9_sync_obj_signaled(void *sync_obj, void *sync_arg)
{
	struct via_chrome9_fence_object *p_fence_object =
		(struct via_chrome9_fence_object *)sync_obj;
	struct drm_via_chrome9_private *dev_priv = p_fence_object->p_priv;
	struct via_chrome9_fence_ops *fence_ops =
		&dev_priv->engine_ops.fence_ops;
	return fence_ops->fence_signaled(sync_obj, sync_arg);
}

static inline int via_chrome9_sync_obj_wait(void *sync_obj, void *sync_arg,
		bool lazy, bool interruptible)
{
	struct via_chrome9_fence_object *p_fence_object =
		(struct via_chrome9_fence_object *)sync_obj;
	struct drm_via_chrome9_private *dev_priv = p_fence_object->p_priv;
	struct via_chrome9_fence_ops *fence_ops =
		&dev_priv->engine_ops.fence_ops;

	return fence_ops->fence_wait(sync_obj, sync_arg, lazy, interruptible);
}

static inline int via_chrome9_sync_obj_flush(void *sync_obj, void *sync_arg)
{
	return via_chrome9_fence_flush(sync_obj, sync_arg);
}

static inline void via_chrome9_sync_obj_unref(void **sync_obj)
{
	via_chrome9_fence_unref((struct via_chrome9_fence_object **)sync_obj);
}

static inline void *via_chrome9_sync_obj_ref(void *sync_obj)
{
	return via_chrome9_fence_ref(sync_obj);
}
/*
 * Flush cpu cache, may also invalidate it
 */
static void via_chrome9_flush_cpu_cache(struct ttm_buffer_object *bo)
{
	struct ttm_tt *ttm = bo->ttm;

	if (ttm == NULL)
		return;

	if (ttm->caching_state == tt_cached)
		drm_clflush_pages(ttm->pages, ttm->num_pages);
}

static void via_chrome9_invlidate_cpu_cache(struct ttm_buffer_object *bo)
{
	/* do nothing */
}

/*
 * domain - flush domain
 */
static void via_chrome9_flush_gpu_cache(uint32_t domain,
		struct ttm_buffer_object *bo)
{
}
static void via_chrome9_invlidate_gpu_cache(uint32_t domain,
	struct ttm_buffer_object *bo)
{
	/* do nothing */
}
/*
 * Set BO to GPU access domain
 * and handle cache coherence
 */
void via_chrome9_set_gpu_domain(struct ttm_buffer_object *bo)
{
	uint32_t flush_domains = 0, invalidate_domains = 0;
	struct ttm_bo_device *bdev = bo->bdev;
	struct drm_via_chrome9_private *p_priv;
	struct via_chrome9_object *vobj = container_of(bo,
		struct via_chrome9_object, bo);
	struct via_chrome9_coherence_ops *cache_coherence_ops;
	p_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	cache_coherence_ops = &p_priv->engine_ops.cache_coherence_ops;

	BUG_ON(vobj->pending_write_domain == VIA_CHROME9_OBJ_DOMAIN_CPU);

	if (0 == (vobj->pending_write_domain | vobj->pending_read_domain))
		return;

	if (vobj->pending_write_domain == 0)
			vobj->pending_read_domain |= vobj->read_domain;

	 /* Flush the current write domain if
	 * the new read domains don't match. Invalidate
	 * any read domains which differ from the old
	 * write domain
	 */

	if (vobj->write_domain &&
		vobj->write_domain != vobj->pending_read_domain) {
		flush_domains |= vobj->write_domain;
		invalidate_domains |= vobj->pending_read_domain &
			~vobj->write_domain;
	}
	/* Invalidate read cache if previous cached
	 */
	invalidate_domains |= vobj->pending_read_domain & ~vobj->read_domain;

	/* Flush cpu cache unless bo cache snoop enable*/
	if ((flush_domains & VIA_CHROME9_OBJ_DOMAIN_CPU) && !vobj->cache_snoop)
		via_chrome9_flush_cpu_cache(bo);

	/* Invalidate GPU cache if possible */
	if (invalidate_domains & VIA_CHROME9_OBJ_DOMAIN_GPU)
		via_chrome9_invlidate_gpu_cache(invalidate_domains, bo);

	/* Add to unsnoop list, disable it after GPU access */
	if (vobj->cache_snoop && cache_coherence_ops->disable_bo_cache_snoop) {
		BUG_ON(!(vobj->bo.mem.placement & VIA_CHROME9_GEM_DOMAIN_GTT));
		list_add_tail(&vobj->snoop_list, &p_priv->snoop_list);
	}

	vobj->write_domain = vobj->pending_write_domain;
	vobj->read_domain = vobj->pending_read_domain;
}

/*
 * Disable BO cache snoop(PCIE memory)
 */
void via_chrome9_unsnoop_bos(struct drm_via_chrome9_private *p_priv)
{
	struct via_chrome9_object *vbo, *temp;
	struct via_chrome9_coherence_ops *cache_coherence_ops;
	cache_coherence_ops = &p_priv->engine_ops.cache_coherence_ops;

	list_for_each_entry_safe(vbo, temp, &p_priv->snoop_list, snoop_list) {
		cache_coherence_ops->disable_bo_cache_snoop(&vbo->bo);
		list_del_init(&vbo->snoop_list);
	}
}

/*
 * set to cpu read/write domain
 * @bo -object
 * @domain -dest domain, TTM BO domain (sys gtt vram)
 */
void via_chrome9_set_cpu_domain(struct ttm_buffer_object *bo, uint32_t domain)
{
	uint32_t flush_domains = 0, invalidate_domains = 0;
	struct ttm_bo_device *bdev = bo->bdev;
	struct drm_via_chrome9_private *p_priv;
	struct via_chrome9_object *vobj = container_of(bo,
		struct via_chrome9_object, bo);
	struct via_chrome9_coherence_ops *cache_coherence_ops;
	p_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	cache_coherence_ops = &p_priv->engine_ops.cache_coherence_ops;

	BUG_ON(vobj->pending_write_domain == VIA_CHROME9_OBJ_DOMAIN_GPU);

	if (vobj->pending_write_domain == 0)
			vobj->pending_read_domain |= vobj->read_domain;

	if (vobj->write_domain &&
		vobj->write_domain != vobj->pending_read_domain) {
		flush_domains |= vobj->write_domain;
		invalidate_domains |= vobj->pending_read_domain &
			~vobj->write_domain;
	}

	/* Invalidate read cache if previous cached
	 */
	invalidate_domains |= vobj->pending_read_domain & ~vobj->read_domain;

	/* Flush GPU cache */
	if (flush_domains & VIA_CHROME9_OBJ_DOMAIN_GPU)
			via_chrome9_flush_gpu_cache(flush_domains, bo);

	/* Invalidate CPU cache */
	if (invalidate_domains & VIA_CHROME9_OBJ_DOMAIN_CPU)
			via_chrome9_invlidate_cpu_cache(bo);

	/* Enable GPU cache snoop(PCIE) when CPU write*/
	if ((domain & VIA_CHROME9_GEM_DOMAIN_GTT) &&
		vobj->pending_write_domain &&
		!vobj->cache_snoop &&
	       cache_coherence_ops->enable_bo_cache_snoop) {
		cache_coherence_ops->enable_bo_cache_snoop(bo);
		vobj->cache_snoop = true;
	}

	vobj->write_domain = vobj->pending_write_domain;
	vobj->read_domain = vobj->pending_read_domain;
#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
	vobj->access_engine_type = 0;
#endif
}

/*
 * handle GPU cache coherence between sys<->gtt &
 * GPU cache coherence between 3d and other engine && gpu<->cpu
 */
void via_chrome9_bo_move_notify(struct ttm_buffer_object *bo,
			  struct ttm_mem_reg *mem)
{
	struct via_chrome9_object *vobj = container_of(bo,
					struct via_chrome9_object, bo);

	/* handle cache coherence if BO is cached */
	if (mem->placement & bo->mem.placement & TTM_PL_FLAG_CACHED) {
		if ((vobj->pending_read_domain | vobj->pending_write_domain) &
			VIA_CHROME9_OBJ_DOMAIN_GPU)
			via_chrome9_set_gpu_domain(bo);
		else
			via_chrome9_set_cpu_domain(bo, mem->placement);
	} else {
		/*via_chrome9_gpu_coherence(bo);*/
		vobj->read_domain = vobj->pending_read_domain;
		vobj->write_domain = vobj->pending_write_domain;
	}
}

int via_chrome9_bo_fault_reserve_notify(struct ttm_buffer_object *bo)
{
	struct via_chrome9_object *vbo;
	int ret = 0;
	vbo = container_of(bo, struct via_chrome9_object, bo);

	/*If this BO is flushing command by CR,
	user space should wait to access it*/
	if (test_bit(VIA_CHROME9_BO_FLAG_CMD_FLUSHING, &vbo->flags)) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
		spin_lock(&vbo->bo.bdev->fence_lock);
#else
		spin_lock(&vbo->bo.lock);
#endif
		if (vbo->bo.sync_obj)
			ret = ttm_bo_wait(&vbo->bo, true, false, false);
		if (!ret)
			clear_bit(VIA_CHROME9_BO_FLAG_CMD_FLUSHING,
				&vbo->flags);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
		spin_unlock(&vbo->bo.bdev->fence_lock);
#else
		spin_unlock(&vbo->bo.lock);
#endif
	}

	return ret;
}

static int via_chrome9_io_mem_reserve(struct ttm_bo_device *bdev,
		struct ttm_mem_reg *mem)
{
	struct ttm_mem_type_manager *man = &bdev->man[mem->mem_type];
	struct drm_via_chrome9_private *p_priv;
	p_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);

	mem->bus.addr = NULL;
	mem->bus.offset = 0;
	mem->bus.size = mem->num_pages << PAGE_SHIFT;
	mem->bus.base = 0;
	mem->bus.is_iomem = false;
	if (!(man->flags & TTM_MEMTYPE_FLAG_MAPPABLE))
		return -EINVAL;
	switch (mem->mem_type) {
	case TTM_PL_SYSTEM:
		/* system memory */
		return 0;
	case TTM_PL_TT:
		/* TT memory*/
		return 0;
	case TTM_PL_VRAM:
		mem->bus.offset = mem->start << PAGE_SHIFT;
		/* check if it's visible */
		if ((mem->bus.offset + mem->bus.size) > p_priv->vram_size)
			return -EINVAL;
		mem->bus.base = p_priv->vram_start;
		mem->bus.is_iomem = true;
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static void via_chrome9_io_mem_free(struct ttm_bo_device *bdev,
		struct ttm_mem_reg *mem)
{
}

static struct ttm_bo_driver via_chrome9_bo_driver = {
	.create_ttm_backend_entry = via_chrome9_create_ttm_backend_entry,
	.invalidate_caches = via_chrome9_invalidate_caches,
	.init_mem_type = via_chrome9_init_mem_type,
	.evict_flags = via_chrome9_evict_flags,
	.move = via_chrome9_bo_move,
	.verify_access = via_chrome9_verify_access,
	.sync_obj_signaled = via_chrome9_sync_obj_signaled,
	.sync_obj_wait = via_chrome9_sync_obj_wait,
	.sync_obj_flush = via_chrome9_sync_obj_flush,
	.sync_obj_unref = via_chrome9_sync_obj_unref,
	.sync_obj_ref = via_chrome9_sync_obj_ref,
	.move_notify = via_chrome9_bo_move_notify,
	.fault_reserve_notify = via_chrome9_bo_fault_reserve_notify,
	.io_mem_reserve = &via_chrome9_io_mem_reserve,
	.io_mem_free = &via_chrome9_io_mem_free,
};

static int via_chrome9_ttm_mem_global_init(struct drm_global_reference *ref)
{
	return ttm_mem_global_init(ref->object);
}

static void via_chrome9_ttm_mem_global_release(struct drm_global_reference *ref)
{
	ttm_mem_global_release(ref->object);
}

int via_chrome9_ttm_global_init(struct drm_via_chrome9_private *dev_priv)
{
	struct drm_global_reference *global_ref;
	int ret;

	global_ref = &dev_priv->mem_global_ref;
	global_ref->global_type = DRM_GLOBAL_TTM_MEM;
	global_ref->size = sizeof(struct ttm_mem_global);
	global_ref->init = &via_chrome9_ttm_mem_global_init;
	global_ref->release = &via_chrome9_ttm_mem_global_release;
	ret = drm_global_item_ref(global_ref);
	if (ret != 0) {
		DRM_ERROR("Failed setting up TTM memory accounting\n");
		return ret;
	}

	dev_priv->bo_global_ref.mem_glob =
		dev_priv->mem_global_ref.object;
	global_ref = &dev_priv->bo_global_ref.ref;
	global_ref->global_type = DRM_GLOBAL_TTM_BO;
	global_ref->size = sizeof(struct ttm_bo_global);
	global_ref->init = &ttm_bo_global_init;
	global_ref->release = &ttm_bo_global_release;
	ret = drm_global_item_ref(global_ref);
	if (ret != 0) {
		DRM_ERROR("Failed setting up TTM BO subsystem.\n");
		drm_global_item_unref(&dev_priv->mem_global_ref);
		return ret;
	}

	return 0;
}

static void via_chrome9_ttm_global_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	drm_global_item_unref(&dev_priv->bo_global_ref.ref);
	drm_global_item_unref(&dev_priv->mem_global_ref);
}

/* In this function, we should do things below:
 * 1: initialize global information of TTM mem and TTM bo
 * 2: initialize ttm BO device data structure
 * 3: initialize VRAM and PCIE memory heap manager
 */
int via_chrome9_init_ttm(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int ret;

	if (!dev_priv)
		return -EINVAL;

	ret = via_chrome9_ttm_global_init(dev_priv);
	if (ret)
		return ret;
	/* for pae kernel ram>4G */
	dev_priv->need_dma32 = true;
	ret = ttm_bo_device_init(&dev_priv->bdev,
		dev_priv->bo_global_ref.ref.object, &via_chrome9_bo_driver,
		DRM_FILE_PAGE_OFFSET, dev_priv->need_dma32);
	if (ret) {
		DRM_ERROR("failed initializing buffer object driver(%d).\n",
			ret);
		return ret;
	}

	/* TTM allocate memory space based on page_size unit, so the
	 * memory heap manager should get the memory size based on page_size
	 * refer to @ttm_bo_mem_space function for the details
	 */
	ret = ttm_bo_init_mm(&dev_priv->bdev, TTM_PL_VRAM,
		dev_priv->vram_size >> PAGE_SHIFT);
	if (ret) {
		DRM_ERROR("Failed initializing VRAM heap manager.\n");
		return ret;
	}

	ret = ttm_bo_init_mm(&dev_priv->bdev, TTM_PL_TT,
		 dev_priv->pcie_mem_size >> PAGE_SHIFT);
	if (ret) {
		DRM_ERROR("Failed initializing PCIE heap manager.\n");
		return ret;
	}


	return 0;
}

void via_chrome9_ttm_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	ttm_bo_clean_mm(&dev_priv->bdev, TTM_PL_VRAM);
	ttm_bo_clean_mm(&dev_priv->bdev, TTM_PL_TT);
	ttm_bo_device_release(&dev_priv->bdev);
	via_chrome9_ttm_global_fini(dev);
}

static void via_chrome9_move_null(struct ttm_buffer_object *bo,
				struct ttm_mem_reg *mem)
{
	struct ttm_mem_reg *old_mem = &bo->mem;

	BUG_ON(old_mem->mm_node != NULL);
	*old_mem = *mem;
	mem->mm_node = NULL;
}



int wait_dma_idle(struct drm_via_chrome9_private *dev_priv, int engine)
{
	unsigned int r400, rcs;

	r400 = getmmioregister(dev_priv->mmio_map, 0x400);

	/*20 bit of R400 is DMA Engine status(4 channel), 1--busy;0--idle*/
	if (r400 & 0x100000) {
		rcs = getmmioregister(dev_priv->mmio_map,
			CHROME9_DMA_CSR0 + 0x8 * engine);
		while (!(rcs & 0x8)) {
			msleep(1);
#if DMA_DEBUG
			printk(KERN_ALERT "[chrome9_move] wait DMA engine IDLE");
#endif
			r400 = getmmioregister(dev_priv->mmio_map, 0x400);
			if (!(r400 & 0x100000))
				break;
			rcs = getmmioregister(dev_priv->mmio_map,
					CHROME9_DMA_CSR0 + 0x8 * engine);

		}
	} /*Engine Idle*/

	return 0;
}

/*Fire DMA Engine (Chainning Mode) through PCI path*/
static void chrome9_h6_dma_fire(struct drm_device *drm_dev,
		struct chrome9_sg_info *sg, int engine)
{
/*	uint32_t *p_cmd = sg->dma_cmd_tmp; */
	unsigned char sr4f = 0;
	uint32_t dprl = 0, dprh = 0;
#if DMA_DEBUG
	uint32_t  r04 = 0;
#endif
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *) drm_dev->dev_private;

	dprl = (uint32_t)sg->chain_start;

	/*Set Transfer direction*/
	if (sg->direction == DMA_TO_DEVICE)
		dprl |= 1 << 3;
	dprh = CHROME9_DMA_DPRH_EB_CM | ((sg->chain_start) >> 32 & 0xfff);

	/*DMA CMD from CBU Path*/
	sr4f = via_chrome9_read_vga_io(0x14f);
	sr4f &= ~(1 << 7 | 1 << 6);
	via_chrome9_write_vga_io(0x14f, sr4f);

	/*Clear TD(Transfer Done) bit*/
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_CSR0,
		CHROME9_DMA_CSR_DE | CHROME9_DMA_CSR_TD);

#if DMA_DEBUG
	r04 = getmmioregister(dev_priv->mmio_map, CHROME9_DMA_CSR0);
	printk(KERN_ALERT "[chrome9_move] dma engine status = 0x%08x"
		" chain_star addr =0x%llx\n", r04, sg->chain_start);
	printk(KERN_INFO "[chrome9_move] DPR value dprl=0x%x dprh=0x%x\n",
		dprl, dprh);
#endif

	/*Set chaining mode reg and fire*/
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_MR0, CHROME9_DMA_MR_CM);
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_DQWCR0, 0);
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_DPRL0, dprl);
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_DPRH0, dprh);
	setmmioregister(dev_priv->mmio_map, CHROME9_DMA_CSR0,
		CHROME9_DMA_CSR_DE | CHROME9_DMA_CSR_TS);

}


/*write fence sequce to DMA buffer, then fire*/
static void chrome9_write_fence_buffer(struct via_chrome9_fence_object
		*p_fence_object)
{
	struct via_chrome9_sg_move_manager *sg_man =
		p_fence_object->p_priv->sg_manager;
	/*TODO, if use more than 1 DMA engine*/
	writel(p_fence_object->sequence, sg_man->sg_fence_vaddr[0]);
	mb();
}

static int chrome9_free_desc_pages(struct chrome9_sg_info *sg)
{
	int num_desc_pages, i;
	num_desc_pages = (sg->num_desc + sg->desc_per_page - 1) /
		sg->desc_per_page;

	for (i = 0; i < num_desc_pages; ++i) {
		if (sg->chrome9_desc[i] != NULL)
			free_page((unsigned long)sg->chrome9_desc[i]);
	}

	kfree(sg->chrome9_desc);
	sg->chrome9_desc = NULL;

	return 0;
}

/*Prepare fence which use DMA Engine to blit */
/*Add it to the last chain                         */
/*We use DMA engine blit fence from VRAM TO SYS*/

static void chrome9_build_dma_fence_info(
		struct via_chrome9_fence_object *p_fence_object,
		struct chrome9_descriptor *chrome9_desc, uint64_t next_dpr)
{
	struct via_chrome9_sg_move_manager *sg_man =
		p_fence_object->p_priv->sg_manager;

	chrome9_desc->mem_addr_l = (uint32_t)sg_man->sg_sync_bus_addr_align;
	chrome9_desc->mem_addr_h = sg_man->sg_sync_bus_addr_align >> 32;

	chrome9_desc->size = 1;
	/*device address needs 16 byte align*/
	chrome9_desc->dev_addr = sg_man->sg_fence[0]->bo.offset;

	/*For DPRL bit 3 is transfer direction.
	bit 0 must be 1 to enable DMA Engine in Chaining mode*/
	chrome9_desc->next_l = (uint32_t)next_dpr | 1 << 0;
	chrome9_desc->next_h = next_dpr >> 32 & 0xfff;
	chrome9_desc->tile_mode = 0;
	chrome9_desc->null = 0x0;

}

/*Calculate and Allocate Pages for desc used by DMA chainning Mode*/
static int chrome9_alloc_desc_pages(struct ttm_tt *ttm,
		struct chrome9_sg_info *sg)
{
	int num_desc_pages, i;
	sg->desc_per_page = PAGE_SIZE / sizeof(struct chrome9_descriptor);
	num_desc_pages = (sg->num_desc + sg->desc_per_page - 1) /
		sg->desc_per_page;
#if DMA_DEBUG
	printk(KERN_ALERT
		"[chrome9_move] dma alloc desc_pages num_des_pages= 0x%x  "
		"sg->num_desc =%d\n", num_desc_pages, sg->num_desc);
#endif
	sg->chrome9_desc = kzalloc(num_desc_pages * sizeof(void *),
		GFP_KERNEL);
	if (NULL == sg->chrome9_desc) {
		printk(KERN_ALERT "[chrome9_move] dma alloc desc_pages error!\n ");
		return -ENOMEM;
	}
	/*Alloc pages for Chrome9_descriptor*/
	for (i = 0; i < num_desc_pages; ++i) {
		sg->chrome9_desc[i] = (struct chrome9_descriptor *)
			__get_free_page(GFP_KERNEL);
		if (NULL == sg->chrome9_desc[i]) {
			printk(KERN_ALERT "[chrome9_move] dma alloc desc_pages __get_free_page error !\n");
			return -ENOMEM;
		}
	}
	return 0;
}


static int chrome9_build_sg_info(struct ttm_buffer_object *bo,
		struct pci_dev *pdev, struct chrome9_sg_info *sg,
		dma_addr_t dev_start, int direction,
		struct via_chrome9_fence_object *p_fence_object)
{
	struct chrome9_descriptor *chrome9_desc;
	int pnum = 0;
	int cur_desc_page = 0, desc_num_in_page = 0;
	/*set to EC=1(End of Chain)*/
	uint64_t  next = 1 << 1;
	uint64_t   sys_addr = 0;
	unsigned char direct = 0;

	/*use for DMA Engine setting, 1 means sys memory to device*/
	if (direction == DMA_TO_DEVICE)
		direct = 1;

	sg->direction = direction;
	if (NULL == bo->ttm->pages)
		return -ENOMEM;

	if (!bo->ttm->num_pages || !bo->ttm)
		return -ENOMEM;

	/*Add a desc for DMA fence using DMA move*/
	sg->num_desc = bo->ttm->num_pages + 1;

	/*Allocate pages to store chrome9_descriptor info*/
	if (chrome9_alloc_desc_pages(bo->ttm, sg)) {
		printk(KERN_ALERT
			"[chrome9_move] dma build sg_info alloc desc_pages error!\n");
		goto out_err1;
	}

	/*Alloc Buffer for wait command using APG*/
	sg->dma_cmd_tmp = kzalloc(DMA_CMD_TMP_BUFFER, GFP_KERNEL);
	if (NULL == sg->dma_cmd_tmp) {
		printk(KERN_ALERT
			"[chrome9_move] dma alloc command temp buffer error!\n");
		goto out_err2;
	}

	/*bulid DMA fence desc*/
	chrome9_desc = sg->chrome9_desc[0];
	chrome9_build_dma_fence_info(p_fence_object, chrome9_desc, next);
	next = dma_map_single(&pdev->dev, sg->chrome9_desc[0],
				sizeof(struct chrome9_descriptor),
				DMA_TO_DEVICE);
	desc_num_in_page++;
	chrome9_desc++;

	for (pnum = 0; pnum < bo->ttm->num_pages; ++pnum) {
		/*Map system pages*/
		if (bo->ttm->pages[pnum] == NULL)
			goto out_err2;

		sys_addr = dma_map_page(&pdev->dev,
				bo->ttm->pages[pnum], 0, PAGE_SIZE, direction);
		chrome9_desc->mem_addr_l = (uint32_t)sys_addr;
		chrome9_desc->mem_addr_h = sys_addr>>32;

		/*size count in 16byte*/
		chrome9_desc->size = PAGE_SIZE / 16;

		/*device address needs 16 byte align*/
		chrome9_desc->dev_addr = dev_start;

		/*For DPRL bit 3 is transfer direction.
		bit 0 must be 1 to enable DMA Engine in Chaining mode*/
		chrome9_desc->next_l = (uint32_t)next | direct << 3 | 1 << 0;
		chrome9_desc->next_h = next >> 32 & 0xfff;
		chrome9_desc->tile_mode = 0;
		chrome9_desc->null = 0x0;
#if DMA_DEBUG
		printk(KERN_INFO "[chrome9_move] dma sys page phy addr 0x%llx, "
			"next desc phy addr 0x%llx chrome9_desc vaddr 0x%lx\n",
			sys_addr, next, chrome9_desc);
#endif
		/*Map decriptors for Chaining mode*/
		next = dma_map_single(&pdev->dev, chrome9_desc,
			sizeof(struct chrome9_descriptor),
			DMA_TO_DEVICE);
		chrome9_desc++;

		if (++desc_num_in_page >= sg->desc_per_page) {
			chrome9_desc = sg->chrome9_desc[++cur_desc_page];
			desc_num_in_page = 0;
#if DMA_DEBUG
		printk(KERN_ALERT "[chrome9_move] cur_desc_page = %d\n",
			cur_desc_page);
#endif
		}

		dev_start += PAGE_SIZE;
	}

	sg->chain_start = next;

	return 0;

out_err2:
	kfree(sg->dma_cmd_tmp);
out_err1:
	chrome9_free_desc_pages(sg);
	return -ENOMEM;

}


static int chrome9_unmap_from_device(struct pci_dev *pdev,
		struct chrome9_sg_info *sg)
{
	int num_desc = sg->num_desc;
	int cur_desc_page = num_desc / sg->desc_per_page;
	int desc_this_page = num_desc % sg->desc_per_page;
	dma_addr_t next = (dma_addr_t)sg->chain_start;
	dma_addr_t addr;
	struct chrome9_descriptor *cur_desc = sg->chrome9_desc[cur_desc_page]
						+ desc_this_page - 1;

	while (num_desc--) {
		if (desc_this_page-- == 0) {
			cur_desc_page--;
			desc_this_page = sg->desc_per_page - 1;
			cur_desc = sg->chrome9_desc[cur_desc_page] +
				desc_this_page;
		}

		addr = (cur_desc->mem_addr_l) |
			((uint64_t)(cur_desc->mem_addr_h & 0xfff)
			<< 32);
		dma_unmap_single(&pdev->dev, next,
			sizeof(struct chrome9_descriptor),
			DMA_TO_DEVICE);
		dma_unmap_page(&pdev->dev, addr, cur_desc->size,
			sg->direction);

		next = (cur_desc->next_l & 0xfffffff0) |
			(uint64_t)(cur_desc->next_h & 0xfff) << 32;
#if DMA_DEBUG
	printk(KERN_INFO "[dma_move] umap desc and page  0x%x  0x%x",
		next, addr);
#endif
		cur_desc--;
	}

	return 0;
}


static void chrome9_free_sg_info(struct pci_dev *pdev,
		struct chrome9_sg_info *sg)
{
	chrome9_unmap_from_device(pdev, sg);
	chrome9_free_desc_pages(sg);
	kfree(sg->dma_cmd_tmp);
}

/*Build SG obj for DMA move (chainning mode) usage*/
static int via_chrome9_build_sg_obj(struct ttm_buffer_object *bo,
		struct pci_dev *pdev, struct via_chrome9_sg_obj **sg_info,
		dma_addr_t dev_start, int direction,
		struct via_chrome9_fence_object *p_fence_object)
{
	struct via_chrome9_sg_obj *sg;
	struct drm_via_chrome9_private *dev_priv;
	struct ttm_bo_device *bdev = bo->bdev;
	int ret;

	dev_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);

	sg  = kzalloc(sizeof(struct via_chrome9_sg_obj), GFP_KERNEL);
	if (unlikely(!sg)) {
		printk(KERN_ALERT
			"[chrome9_move] ERROR!, Alloc via_chrome9_sg_obj"
			" fail, No MEM!!\n");
		return -ENOMEM;
	}

	ret = chrome9_build_sg_info(bo, pdev, &sg->via_chrome9_sg_info,
		dev_start, direction, p_fence_object);
	if (ret) {
		printk(KERN_ALERT "[chrome9_move] ERROR!, bulid sg info ERROR\n");
		return ret;
	}
	INIT_LIST_HEAD(&sg->ddestory);
	spin_lock_init(&sg->lock);
	sg->p_fence = p_fence_object;
	sg->dev_priv = dev_priv;

	/*Add fence to sg object*/
	via_chrome9_fence_ref(p_fence_object);
	*sg_info = sg;

	return 0;
}


/*Release SG Object function*/
static int via_chrome9_release_sg_obj(struct pci_dev *pdev,
		struct via_chrome9_sg_obj *sg_obj)
{
	struct via_chrome9_fence_object *chrome9_fence = sg_obj->p_fence;
	struct via_chrome9_sg_move_manager *sg_man =
		sg_obj->dev_priv->sg_manager;
	struct via_chrome9_fence_ops *fence_ops =
		&sg_obj->dev_priv->engine_ops.fence_ops;
	int ret = 0;

	if (fence_ops->fence_signaled(chrome9_fence, NULL)) {
		via_chrome9_fence_unref(&chrome9_fence);
		chrome9_free_sg_info(pdev, &sg_obj->via_chrome9_sg_info);

		spin_lock(&sg_man->lock);
		/* If in delay destory list, delete it*/
		if (!list_empty(&sg_obj->ddestory))
			list_del_init(&sg_obj->ddestory);
		spin_unlock(&sg_man->lock);
		kfree(sg_obj);
	} else {
		/* If sg not in ddestory list yet, add it */
		if (list_empty(&sg_obj->ddestory)) {
			spin_lock(&sg_man->lock);
			list_add_tail(&sg_obj->ddestory, &sg_man->ddestory);
			spin_unlock(&sg_man->lock);

			schedule_delayed_work(&sg_man->sg_wq,
				((HZ / 100) < 1) ? 1 : HZ / 100);
		} else {
			ret = -EBUSY;
		}
	}

	return ret;
}

static int chrome9_sg_delay_remove(struct via_chrome9_sg_move_manager *sg_man)
{
	struct via_chrome9_sg_obj *sg_obj = NULL;
	struct pci_dev *pdev = sg_man->dev_priv->ddev->pdev;
	int ret = 0;

	spin_lock(&sg_man->lock);
	if (list_empty(&sg_man->ddestory)) {
		spin_unlock(&sg_man->lock);
		return 0;
	}

	spin_unlock(&sg_man->lock);
retry:
	list_for_each_entry(sg_obj, &sg_man->ddestory, ddestory) {
		ret = via_chrome9_release_sg_obj(pdev, sg_obj);
		if (ret)
			break;
		else
			goto retry;
	}

	 return ret;
}

static void chrome9_sg_delayed_workqueue(struct work_struct *work)
{
	struct via_chrome9_sg_move_manager *sg_man =
		container_of(work, struct via_chrome9_sg_move_manager,
			sg_wq.work);

	if (chrome9_sg_delay_remove(sg_man)) {
		schedule_delayed_work(&sg_man->sg_wq,
				((HZ / 100) < 1) ? 1 : HZ / 100);
	}
}



static int via_chrome9_move(struct ttm_buffer_object *bo,
		bool evict, bool interruptible, bool no_wait_reserve,
		bool no_wait_gpu, struct ttm_mem_reg *new_mem)
{
	struct drm_via_chrome9_private *dev_priv;
	struct ttm_bo_device *bdev = bo->bdev;
	struct ttm_mem_reg *old_mem = &bo->mem;
	struct via_chrome9_fence_object *fence;
	uint64_t old_start, new_start;
	uint32_t dev_addr = 0;
	struct drm_device *drm_dev;
	struct via_chrome9_sg_obj *sg_obj = NULL;
	int r = 0, direction;
	struct via_chrome9_fence_ops *fence_ops;

#if DMA_DEBUG
	unsigned int r04;
#endif

	dev_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	drm_dev = dev_priv->ddev;
	fence_ops = &dev_priv->engine_ops.fence_ops;
	via_chrome9_fence_object_create(dev_priv, &fence, true);

	if (new_mem->mem_type == TTM_PL_VRAM) {
		new_start = new_mem->start << PAGE_SHIFT;
		direction = DMA_TO_DEVICE;
		dev_addr = new_start;
	}
	if (old_mem->mem_type == TTM_PL_VRAM) {
		old_start = old_mem->start << PAGE_SHIFT;
		direction = DMA_FROM_DEVICE;
		dev_addr = old_start;
	}
#if DMA_DEBUG
	printk(KERN_INFO "[chrome9_move] dma debug  dev_addr =0x%x\n",
		dev_addr);
#endif
	/*device addr must be 16 byte align*/
	if (0 != (dev_addr & 0xF)) {
		printk(KERN_ALERT "[chrome9_move] error!device addr must be 16 byte align!\n");
		return -ENOMEM;
	}
	if (via_chrome9_build_sg_obj(bo, drm_dev->pdev, &sg_obj, dev_addr,
		direction, fence)) {
		printk(KERN_ALERT "[chrome9_move]chrome9 build sg info error!\n");
		return -ENOMEM;
	}

	/*Only use engine 0*/
	/*TODO, No need Wait here*/
	wait_dma_idle(dev_priv, 0);

	r = fence_ops->fence_emit(dev_priv, fence);

	/*write fence buffer & fire must be atomic*/
	spin_lock(&sg_obj->dev_priv->sg_manager->lock);
	chrome9_write_fence_buffer(fence);
	chrome9_h6_dma_fire(drm_dev, (struct chrome9_sg_info *)sg_obj, 0);
	spin_unlock(&sg_obj->dev_priv->sg_manager->lock);

	r = ttm_bo_move_accel_cleanup(bo, (void *)fence, NULL,
		evict, no_wait_reserve, no_wait_gpu, new_mem);

#if DMA_DEBUG
	r04 = getmmioregister(dev_priv->mmio_map, 0xE04);
	printk(KERN_ALERT "[chrome9_move] dma engine status done  = 0x%08x\n",
		r04);
#endif
	/*release resources & unmap dma*/
	via_chrome9_release_sg_obj(drm_dev->pdev, sg_obj);

	return r;

}

int via_chrome9_bo_move(struct ttm_buffer_object *bo,
		bool evict, bool interruptible, bool no_wait_reserve,
		bool no_wait_gpu, struct ttm_mem_reg *new_mem)
{
	struct ttm_mem_reg *old_mem = &bo->mem;
	int r = 1;
	struct ttm_mem_reg tmp_mem;
	struct ttm_placement placement;
	uint32_t proposed_placement;

	struct ttm_bo_device *bdev = bo->bdev;
	struct drm_via_chrome9_private *dev_priv =
		container_of(bdev, struct drm_via_chrome9_private, bdev);

	if (dev_priv->sg_manager == NULL)
		goto out;

	if (old_mem->mem_type == TTM_PL_SYSTEM && bo->ttm == NULL) {
		via_chrome9_move_null(bo, new_mem);
		return 0;
	}

	if ((old_mem->mem_type == TTM_PL_TT &&
		new_mem->mem_type == TTM_PL_FLAG_SYSTEM) ||
		(old_mem->mem_type == TTM_PL_FLAG_SYSTEM &&
		new_mem->mem_type == TTM_PL_TT)) {
		/*need bind/unbind? not here*/
		via_chrome9_move_null(bo, new_mem);
		return 0;
	}

	if (old_mem->mem_type == TTM_PL_SYSTEM &&
		new_mem->mem_type == TTM_PL_VRAM) {
		/*flush cache if needed*/
		ttm_tt_set_placement_caching(bo->ttm, TTM_PL_FLAG_WC);
		r = via_chrome9_move(bo, evict, interruptible, no_wait_reserve,
			no_wait_gpu, new_mem);
	}

	if (old_mem->mem_type == TTM_PL_VRAM &&
		new_mem->mem_type == TTM_PL_SYSTEM) {
		/*VRAM -> SYSTEM MEM, first move VRAM to TT
		For We can't alloc dest system pages*/
		tmp_mem = *new_mem;
		tmp_mem.mm_node = NULL;
		placement.fpfn = 0;
		placement.lpfn = 0;
		placement.num_placement = 1;
		placement.placement = &proposed_placement;
		placement.num_busy_placement = 1;
		placement.busy_placement = &proposed_placement;
		proposed_placement = TTM_PL_FLAG_TT | TTM_PL_MASK_CACHING;
		r = ttm_bo_mem_space(bo, &placement, &tmp_mem,
			     interruptible, no_wait_reserve, no_wait_gpu);
		if (unlikely(r))
			return r;

		r = ttm_tt_set_placement_caching(bo->ttm, tmp_mem.placement);
		if (unlikely(r)) {
			printk(KERN_ALERT "sheldon via move ttm_tt_set_placement_caching!\n");
			return r;
		}
		ttm_tt_bind(bo->ttm, &tmp_mem);
		r = via_chrome9_move(bo, evict, interruptible, no_wait_reserve,
				no_wait_gpu, &tmp_mem);
		/*move TT to SYSTEM*/
		r = ttm_bo_move_ttm(bo, true, no_wait_reserve, no_wait_gpu,
			new_mem);
	}
out:
	if (r)
		r = ttm_bo_move_memcpy(bo, evict, no_wait_reserve,
			no_wait_gpu, new_mem);
	return r;

}



int via_chrome9_sg_move_init(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int ret;


	if (unlikely(!p_priv)) {
		printk(KERN_ALERT "via_chrome9 private not initialized!\n");
		return -EINVAL;
	}

	p_priv->sg_manager =
		kzalloc(sizeof(struct via_chrome9_sg_move_manager), GFP_KERNEL);

	if (unlikely(!p_priv->sg_manager)) {
		printk(KERN_ALERT "In via_chrome9_sg_move_init, NOT ENOUGH MEM!\n");
		return -ENOMEM;
	}

		/* allocate dma fence  src bo in VRAM */
	ret = via_chrome9_buffer_object_create(&p_priv->bdev,
				VIA_CHROME9_FENCE_SYNC_BO_SIZE,
				ttm_bo_type_kernel,
				TTM_PL_FLAG_VRAM | TTM_PL_FLAG_NO_EVICT,
				0, 0, false, NULL,
				&p_priv->sg_manager->sg_fence[0]);
	if (unlikely(ret)) {
		printk(KERN_ERR "allocate dma fence src bo error.\n");
		goto out_err0;
	}
	/*TODO , if use more than 1 DMA engine*/
	ret = via_chrome9_buffer_object_kmap(p_priv->sg_manager->sg_fence[0],
		(void **)&p_priv->sg_manager->sg_fence_vaddr[0]);
	if (unlikely(ret)) {
		printk(KERN_ERR "kmap fence sync bo error.\n");
		goto out_err1;
	}
	/*alloc DMA blit dest space, for DMA fence*/
	p_priv->sg_manager->sg_sync_vaddr = dma_alloc_coherent(&dev->pdev->dev,
		VIA_CHROME9_DMA_FENCE_SIZE,
		&p_priv->sg_manager->sg_sync_bus_addr, GFP_KERNEL);

	/*set to 16 byte align, for the limitation of DAM HW*/
	p_priv->sg_manager->sg_sync_bus_addr_align =  (~(dma_addr_t)0xF) &
		p_priv->sg_manager->sg_sync_bus_addr;
	p_priv->sg_manager->sg_sync_vaddr_align =
		(uint32_t *)((~(unsigned long)0xF) &
		(unsigned long)p_priv->sg_manager->sg_sync_vaddr);

	spin_lock_init(&p_priv->sg_manager->lock);
	INIT_LIST_HEAD(&p_priv->sg_manager->ddestory);
	INIT_DELAYED_WORK(&p_priv->sg_manager->sg_wq,
		chrome9_sg_delayed_workqueue);
	p_priv->sg_manager->dev_priv = p_priv;
	p_priv->sg_manager->initialized = true;
	return 0;

out_err1:
	/*TODO, if use more than 1 DMA engine*/
	via_chrome9_buffer_object_kunmap(p_priv->sg_manager->sg_fence[0]);
out_err0:
	via_chrome9_buffer_object_unref(&p_priv->sg_manager->sg_fence[0]);

	return ret;
}

int  via_chrome9_sg_move_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (!cancel_delayed_work(&p_priv->sg_manager->sg_wq))
		flush_scheduled_work();

	/*TODO, just use 1 DMA Engine Now*/
	via_chrome9_buffer_object_kunmap(p_priv->sg_manager->sg_fence[0]);
	via_chrome9_buffer_object_unref(&p_priv->sg_manager->sg_fence[0]);

	dma_free_coherent(&dev->pdev->dev, VIA_CHROME9_DMA_FENCE_SIZE,
			p_priv->sg_manager->sg_sync_vaddr,
			p_priv->sg_manager->sg_sync_bus_addr);

	p_priv->sg_manager->initialized = false;
	kfree(p_priv->sg_manager);
	p_priv->sg_manager = NULL;

	return 0;
}
