/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_drv.h"
#include "via_chrome9_cursor.h"
#include "via_chrome9_display_common.h"
#include "via_chrome9_object.h"
#include "via_chrome9_mode.h"

static struct via_offset_regs via_chrome9_offset_regs = {
	/* IGA Offset Register */
	{ VIA_IGA1_OFFSET_REG_NUM, { { REG_CR13, 0, 7 }, { REG_CR35, 5, 7 } } },
	/* IGA2 Offset Register */
	{ VIA_IGA2_OFFSET_REG_NUM, { { REG_CR66, 0, 7 }, { REG_CR67, 0, 1 } } }
};

static struct via_iga2_offset_13bit_regs via_chrome9_iga2_offset_13bit_regs = {
	VIA_IGA2_OFFSET_13BIT_REG_NUM, { { REG_CR66, 0, 7 },
		{ REG_CR67, 0, 1 }, { REG_CR71, 7, 7 } }
};

static struct via_iga_fetch_count_regs via_chrome9_fetch_count_regs = {
	/* IGA Fetch Count Register */
	{ VIA_IGA1_FETCH_COUNT_REG_NUM, {{ REG_SR1C, 0, 7 },{ REG_SR1D, 0, 1 } } },
	/* IGA2 Fetch Count Register */
	{ VIA_IGA2_FETCH_COUNT_REG_NUM, {{ REG_CR65, 0, 7 },{ REG_CR67, 2, 3 } } }
};

extern bool via_chrome9_cbios_set_mode(struct drm_crtc *crtc,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode,
		unsigned long colorDepth);
extern bool via_chrome9_set_iga_screen_on_off(unsigned int IGA_Num, 
		unsigned int screenState);
extern void via_chrome_restore_previous_vsync(unsigned int mmio200_int_old);

/* Load offset registers */
static void via_chrome9_load_offset_regs(struct drm_crtc *crtc, u32 offset)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;

	int iga_path = via_chrome9_crtc->crtc_id;
	u32 reg_value = offset;
	u8 reg_amount = 0;
	struct via_chrome9_io_bit *reg = NULL;

	/* Check input variable iga_path */
	if ((iga_path != IGA1) && (iga_path != IGA2))
		return;

	if (IGA1 == iga_path) {
		reg_amount = via_chrome9_offset_regs.iga1.reg_num;
		reg = via_chrome9_offset_regs.iga1.reg;
	} else {
		switch (dev->pci_device) {
		case VX800_DEVICE:
		case VX855_DEVICE:
		case VX900_DEVICE:
			reg_amount = via_chrome9_iga2_offset_13bit_regs.reg_num;
			reg = via_chrome9_iga2_offset_13bit_regs.reg;
			break;
		default:
			reg_amount = via_chrome9_offset_regs.iga2.reg_num;
			reg = via_chrome9_offset_regs.iga2.reg;
			break;
		}
	}
	via_chrome9_load_regs(reg_value, reg_amount, reg);
}

/* Load fetch count registers */
static void via_chrome9_load_fetch_count_regs(
		struct drm_crtc *crtc, u32 fetch_count)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);

	int iga_path = via_chrome9_crtc->crtc_id;
	u32 reg_value = fetch_count;
	u32 reg_amount = 0;
	struct via_chrome9_io_bit *reg = NULL;

	/* Check input variable iga_path */
	if ((iga_path != IGA1) && (iga_path != IGA2))
		return;

	if (IGA1 == iga_path) {
		reg_amount = via_chrome9_fetch_count_regs.iga1.reg_num;
		reg = via_chrome9_fetch_count_regs.iga1.reg;
	} else {
		reg_amount = via_chrome9_fetch_count_regs.iga2.reg_num;
		reg = via_chrome9_fetch_count_regs.iga2.reg;
	}
	via_chrome9_load_regs(reg_value, reg_amount, reg);
}

static void via_chrome9_set_lut(struct drm_crtc *crtc)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	u8 sr1a, sr1b, cr67;
	int i;

	sr1a = via_chrome9_read_vga_io(REG_SR1A);
	sr1b = via_chrome9_read_vga_io(REG_SR1B);
	cr67 = via_chrome9_read_vga_io(REG_CR67);

	if (IGA2 == via_chrome9_crtc->crtc_id) {
		/* Prepare for IGA2's LUT initialization: */
		/* 1. Change Shadow to Secondary Display's LUT. */
		via_chrome9_write_vga_io(REG_SR1A, sr1a | 0x01);
		/* 2. Enable Secondary Display Engine. */
		via_chrome9_write_vga_io(REG_SR1B, sr1b | 0x80);
		/* 3. Second Display Color Depth should be 8bpp. */
		via_chrome9_write_vga_io(REG_CR67, cr67 & 0x3F);

		if (!(via_chrome9_read_vga_io(REG_CR6A) & BIT7))
			/* to enable second display channel. */
			via_chrome9_write_vga_io_bits(REG_CR6A, BIT7, BIT7);

		/* Fill in IGA2's LUT. */
		for (i = 0; i < 256; i++) {
			STANDVGA_W8(REG_PEL, i);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_r[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_g[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_b[i]);
		}
		/* Disable gamma in case it was enabled previously */
		via_chrome9_write_vga_io_bits(REG_CR6A, 0x0, BIT1);
	}

	if (IGA1 == via_chrome9_crtc->crtc_id) {
		/* Prepare for initialize IGA1's LUT: */
		/* Change to Primary Display's LUT. */
		via_chrome9_write_vga_io(REG_SR1A, sr1a & 0xFE);
		via_chrome9_write_vga_io(REG_SR1B, sr1b);
		via_chrome9_write_vga_io(REG_CR67, cr67);

		/* Fill in IGA1's LUT. */
		for (i = 0; i < 256; i++) {
			STANDVGA_W8(REG_PEL, i);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_r[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_g[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_b[i]);
		}
		/* enable LUT */
		via_chrome9_write_vga_io_bits(REG_SR1B, 0x0, BIT0);
		/* Disable gamma in case it was enabled previously */
		via_chrome9_write_vga_io_bits(REG_CR33, 0x0, BIT7);
	}

	/* access Primary Display's LUT. */
	via_chrome9_write_vga_io(REG_SR1A, sr1a & 0xFE);
}

static void via_chrome9_set_gamma(struct drm_crtc *crtc)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);

	int i, sr1a;

	sr1a = via_chrome9_read_vga_io(REG_SR1A);

	if (IGA1 == via_chrome9_crtc->crtc_id) {
		/* Enable Gamma */
		via_chrome9_write_vga_io_bits(REG_CR33, 0x80, BIT7);
		via_chrome9_write_vga_io_bits(REG_SR1A, 0x0, BIT0);

		/* Fill in IGA1's gamma. */
		for (i = 0; i < 256; i++) {
			STANDVGA_W8(REG_PEL, i);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_r[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_g[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_b[i]);
		}
	}

	if (IGA2 == via_chrome9_crtc->crtc_id) {
		via_chrome9_write_vga_io_bits(REG_SR1A, 0x01, BIT0);
		/* Enable Gamma */
		via_chrome9_write_vga_io_bits(REG_CR6A, 0x02, BIT1);

		/* Before we fill the second LUT, we have to enable
		 *  second display channel. If it's enabled before,
		 *  we don't need to do that, or else the secondary
		 *  display will be dark for about 1 sec and then be
		 *  turned on again.
		 */
		if (!(via_chrome9_read_vga_io(REG_CR6A) & BIT7))
			/* to enable second display channel. */
			via_chrome9_write_vga_io_bits(REG_CR6A, BIT7, BIT7);

		/* Fill in IGA2's gamma. */
		for (i = 0; i < 256; i++) {
			STANDVGA_W8(REG_PEL, i);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_r[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_g[i]);
			STANDVGA_W8(REG_PEL + 1, via_chrome9_crtc->lut_b[i]);
		}
	}
	via_chrome9_write_vga_io(REG_SR1A, sr1a);
}

/**
 * via_chrome9_get_mrn
 * This function gets the best frequency M, R, N value according to
 * the input clock frequence
 * IN :
 * frequency : Clock frequence (.Hz)
 * OUT :
 * pll_mrn : PLL registers M, R, N value
 * [31:16]  DM[7:0]
 * [15:8 ]  DR[2:0]
 * [7 :0 ]  DN[6:0]
 */
u32 via_chrome9_get_mrn(u32 pll_type, u32 frequency)
{
	u32 pll_mplus2, pll_r, pll_nplus2;
	u32 best_clk_diff = frequency;
	u32 best_pll_mplus2 = 2;
	u32 best_pll_nplus2 = 2;
	u32 best_pll_r = 0;
	u32 clk_diff;
	u32 pll_fout;
	u32 pll_fvco;
	u32 pll_mrn = 0;

#define VIA_CHROME9_CLK_REFERENCE	14318180
#ifndef CSR_VCO_UP
#define CSR_VCO_UP  600000000
#endif
#ifndef CSR_VCO_DOWN
#define CSR_VCO_DOWN  300000000
#endif
/*
 * PLL DTZ default setting
 * default DTZ to 2b'11 for PLL output stable by HW suggestion
 * VCK, LCK, ECK all use same value
 */
#ifndef PLL_DTZ_DEFAULT
#define PLL_DTZ_DEFAULT  (BIT0 + BIT1)
#endif

	struct pll_mrn_value pll_temp_array[5] = {
		{ 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 } };
	int counter_pll_temp_array = 0;

	/* Fout = Fin * (M+2) / [(N+2) * 2^R]
	Fin = 14318180Hz  */
	/* N[6:0] */
	for (pll_nplus2 = 2; pll_nplus2 < 6; pll_nplus2++) {
		/* R[2:0] */
		for (pll_r = 0; pll_r < 6; pll_r++) {
			/* M[9:0] */
			for (pll_mplus2 = 2; pll_mplus2 < 512; pll_mplus2++) {
				/* first divide pll_nplus2 then multiply
				pll_mplus2 We have to reduce pll_mplus2
				to 512 to get rid of the overflow */
				pll_fvco =
					(VIA_CHROME9_CLK_REFERENCE /
					pll_nplus2) * pll_mplus2;
				if ((pll_fvco >= CSR_VCO_DOWN) &&
					(pll_fvco <= CSR_VCO_UP)) {
					pll_fout = pll_fvco >> pll_r;
					if (pll_fout < frequency)
						clk_diff = frequency - pll_fout;
					else
						clk_diff = pll_fout - frequency;

					/* if frequency(which is the PLL we want
					to set) > 150MHz, the MRN value we
					write in register must < frequency, and
					get MRN value whose M is the largeset */
					/**
					 * origin code :
					 * if (pll_fout <= frequency &&
					 * frequency >= 150000000) {
					 * because there may be an issue here:
					 * 1920x1200@60Hz 193.25MHz
					 * we get 86 04 05 as PLL,
					 * this PLL caused 191.86MHz,
					 * the deviation may be too large
					 * so that there will be some lines
					 * at right of desktop.
					 * This change is much risk,
					 * if there is not suitable,
					 * can be revert back.
					 */
					if (frequency >= 150000000) {
						if ((clk_diff <=
							pll_temp_array[0].diff_clk) ||
							pll_temp_array[0].pll_fout == 0) {
							for (counter_pll_temp_array =
								((sizeof(pll_temp_array) /
								sizeof(struct pll_mrn_value)) - 1);
								counter_pll_temp_array >= 1;
								counter_pll_temp_array--)

								pll_temp_array[counter_pll_temp_array] =
									pll_temp_array[counter_pll_temp_array - 1];

							pll_temp_array[0].pll_m = pll_mplus2;
							pll_temp_array[0].pll_r = pll_r;
							pll_temp_array[0].pll_n = pll_nplus2;
							pll_temp_array[0].diff_clk = clk_diff;
							pll_temp_array[0].pll_fout = pll_fout;
						}
					}

					if (clk_diff < best_clk_diff) {
						best_clk_diff = clk_diff;
						best_pll_mplus2 = pll_mplus2;
						best_pll_nplus2 = pll_nplus2;
						best_pll_r = pll_r;
					}
				} /* if pll_fvco in VCO range */
			} /* for PLL M */
		} /* for PLL R */
	} /* for PLL N */

	/* if frequency(which is the PLL we want to set) > 150MHz,
	the MRN value we write in register must < frequency,
	and get MRN value whose M is the largeset */
	if (frequency > 150000000) {
		counter_pll_temp_array = 0;
		best_pll_mplus2 = pll_temp_array[counter_pll_temp_array].pll_m;
		best_pll_r = pll_temp_array[counter_pll_temp_array].pll_r;
		best_pll_nplus2 = pll_temp_array[counter_pll_temp_array].pll_n;
	}

	if (VIA_PLL_TYPE_PLL_3_ADV == pll_type) {
		/* Clcok Synthesizer Value 0 : DM[7:0] */
		pll_mrn = ((best_pll_mplus2) & 0xFF) << 16;
		/* Clcok Synthesizer Value 1[1:0] : DM[9:8]
		Clcok Synthesizer Value 1[4:2] : DR[2:0]
		Clcok Synthesizer Value 1[7] : DTZ[0] */
		pll_mrn |= (((PLL_DTZ_DEFAULT & 0x1) << 7) |
			((best_pll_r & 0x7) << 2) |
			(((best_pll_mplus2) >> 8) & 0x3)) << 8;
		/* Clcok Synthesizer Value 2[6:0] : DN[6:0]
		Clcok Synthesizer Value 2[7] : DTZ[1] */
		pll_mrn |= (((PLL_DTZ_DEFAULT >> 1) & 0x1) << 7) |
			((best_pll_nplus2) &
			0x7F);
	} else {
		/* Clcok Synthesizer Value 0 : DM[7:0] */
		pll_mrn = ((best_pll_mplus2 - 2) & 0xFF) << 16;
		/* Clcok Synthesizer Value 1[1:0] : DM[9:8]
		Clcok Synthesizer Value 1[4:2] : DR[2:0]
		Clcok Synthesizer Value 1[7] : DTZ[0] */
		pll_mrn |= (((PLL_DTZ_DEFAULT & 0x1) << 7) |
			((best_pll_r & 0x7) << 2) |
			(((best_pll_mplus2 - 2) >> 8) & 0x3)) << 8;
		/* Clcok Synthesizer Value 2[6:0] : DN[6:0]
		Clcok Synthesizer Value 2[7] : DTZ[1] */
		pll_mrn |= (((PLL_DTZ_DEFAULT >> 1) & 0x1) << 7) |
			((best_pll_nplus2 - 2)
			& 0x7F);
	}

	return pll_mrn;
}


#define VIA_REG_DUMP_CRSR  0
#if VIA_REG_DUMP_CRSR
void via_chrome9_dump_sr_cr(void)
{
	int dumpdata, dumpidx;
	int numbersprint = 16;
	int iii = 0;

	printk("\n");
	printk("dump register Sr Cr\n");
	printk("SR  00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
	printk("----------------------------------------------------\n");

	for(dumpidx = 0; dumpidx < 0x100; dumpidx +=numbersprint) {
		printk("%02X  ", dumpidx/numbersprint);
		for (iii = 0; iii < numbersprint; iii ++) {
			dumpdata = via_chrome9_read_vga_io(dumpidx + iii+0x100);
			printk("%02X ", dumpdata);
		}
		printk("\n");
	}

	printk("\n");
	printk("CR  00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");
	printk("----------------------------------------------------\n");

	for(dumpidx = 0; dumpidx < 0x100; dumpidx +=numbersprint) {
		printk("%02X  ", dumpidx/numbersprint);
		for (iii = 0; iii < numbersprint; iii ++) {
			dumpdata = via_chrome9_read_vga_io(dumpidx + iii);
			printk("%02X ", dumpdata);
		}
		printk("\n");
	}

}
#endif

/* Load color depth registers */
static void via_chrome9_load_color_depth_regs(struct drm_crtc *crtc, int bpp)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	int iga_path = via_chrome9_crtc->crtc_id;
	/* Check input variable a_iga_path */
	if ((iga_path != IGA1) && (iga_path != IGA2))
		return;

	if (IGA1 == iga_path) {
		switch (bpp) {
		case BPP8:
			via_chrome9_write_vga_io_bits(REG_SR15, 0xA2, 0xFE);
			break;
		case BPP16:
			via_chrome9_write_vga_io_bits(REG_SR15, 0xB6, 0xFE);
			break;
		case BPP32:
			via_chrome9_write_vga_io_bits(REG_SR15, 0xAE, 0xFE);
			break;
		default:
			break;
		}
	} else {
		switch (bpp) {
		case BPP8:
			via_chrome9_write_vga_io_bits(REG_CR67, 0x00, 0xC0);
			break;
		case BPP16:
			via_chrome9_write_vga_io_bits(REG_CR67, 0x40, 0xC0);
			break;
		case BPP32:
			via_chrome9_write_vga_io_bits(REG_CR67, 0xC0, 0xC0);
			break;
		default:
			break;
		}
	}
}

void via_chrome9_set_gamma_or_lut(struct drm_crtc *crtc)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;
	struct drm_framebuffer *fb = NULL;
	int iga_path = via_chrome9_crtc->crtc_id;
	int bits_per_pixel = 0;

	if (!drm_helper_crtc_in_use(crtc))
		return;

	fb = crtc->fb;
	if (fb == NULL) {
		DRM_INFO("warning crtc has no fb, crtc id=%x\n", iga_path);
		return;
	}
	bits_per_pixel = fb->bits_per_pixel;

	if (BPP8 == bits_per_pixel)
		via_chrome9_set_lut(crtc);
	/* Note:
	 *   It is probably VT3409 hardware issue,
	 *   when we enable IGA1 gamma,
	 *   the display color will become bad if playing video.
	 *   Solution: disable IGA1 gamma on VT3409 (16/32bpp)
	 */
	else if ((iga_path != IGA1) || (dev->pci_device != VX855_DEVICE))
		via_chrome9_set_gamma(crtc);
}

void via_chrome9_crtc_load_lut(struct drm_crtc *crtc)
{
	via_chrome9_set_gamma_or_lut(crtc);
}

void via_chrome9_crtc_dpms(struct drm_crtc *crtc, int mode)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;

	switch (mode) {
	case DRM_MODE_DPMS_ON:
		via_chrome9_set_iga_screen_on_off(via_chrome9_crtc->crtc_id, true);
		via_chrome9_crtc_load_lut(crtc);
		via_chrome9_crtc->enabled = true;
		break;
	case DRM_MODE_DPMS_STANDBY:
	case DRM_MODE_DPMS_SUSPEND:
	case DRM_MODE_DPMS_OFF:
		if (dev->num_crtcs)
			drm_vblank_pre_modeset(dev, via_chrome9_crtc->crtc_id);

		via_chrome9_set_iga_screen_on_off(via_chrome9_crtc->crtc_id, false);
		via_chrome9_crtc->enabled = false;
		break;
	}
}

static bool via_chrome9_crtc_mode_fixup(struct drm_crtc *crtc,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode)
{
	return true;
}

static void via_chrome9_set_iga_start_addr(struct drm_crtc *crtc,
		struct drm_framebuffer *drm_fb,
		u64 gpu_addr, int x, int y)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	unsigned int start_addr = 0;
	int pitch = drm_fb->pitch;
	int bits_per_pixel = drm_fb->bits_per_pixel;
	int iga_path = via_chrome9_crtc->crtc_id;

	start_addr = gpu_addr + (pitch * y) + x * (bits_per_pixel / 8);
	if (IGA1 == iga_path) {
		start_addr = start_addr >> 1;
		via_chrome9_write_vga_io(REG_CR0D,
			(u8)(start_addr & 0x000000FF));
		via_chrome9_write_vga_io(REG_CR0C,
			(u8)((start_addr & 0x0000FF00) >> 8));
		via_chrome9_write_vga_io_bits(REG_CR48,
			(u8)((start_addr & 0xFF000000) >> 24) & 0x1f, 0x1f);
		/*Note: For 353,the register 3X5.48, 3x5.0C, 3x5.0D, 3x5.EC
		must ready before 3x5.34*/
		via_chrome9_write_vga_io(REG_CR34,
			(u8)((start_addr & 0x00FF0000) >> 16));
	} else {
		start_addr = start_addr >> 3;
		via_chrome9_write_vga_io_bits(REG_CR62,
			(u8)((start_addr & 0x0000007F) << 1), 0xFE);
		via_chrome9_write_vga_io(REG_CR63,
			(u8)((start_addr & 0x00007F80) >> 7));
		via_chrome9_write_vga_io(REG_CR64,
			(u8)((start_addr & 0x007F8000) >> 15));
		via_chrome9_write_vga_io(REG_CRA3,
			(u8)((start_addr & 0x03800000) >> 23));
	}
}


static int via_chrome9_crtc_do_set_base(struct drm_crtc *crtc,
		struct drm_framebuffer *fb,
		int x, int y, int atomic)
{
	struct via_chrome9_framebuffer *via_chrome9_fb;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	int iga_path = via_chrome9_crtc->crtc_id;
	struct drm_framebuffer *drm_fb;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vbo;
	u64 gpu_addr;
	int ret;
	u32 offset = 0;
	u32 fetch_count = 0;

	if (iga_path != IGA1 && iga_path != IGA2)
		return false;

	KMS_DEBUG("\n");
	if (!atomic && !crtc->fb) {
		KMS_DEBUG("there is no FB find\n");
		return -1;
	}

	if (atomic) {
		via_chrome9_fb = to_via_chrome9_framebuffer(fb);
		drm_fb = fb;
	} else {
		via_chrome9_fb = to_via_chrome9_framebuffer(crtc->fb);
		drm_fb = crtc->fb;
	}

	KMS_DEBUG(
		"width=%d  height=%d  pitch=%d  bits_per_pixel=%d depth=%d\n",
		drm_fb->width, drm_fb->height,
		drm_fb->pitch, drm_fb->bits_per_pixel, drm_fb->depth);

	gobj = via_chrome9_fb->obj;
	vbo = gobj->driver_private;
	ret = via_chrome9_bo_pin(vbo, TTM_PL_FLAG_VRAM, &gpu_addr);
	if (unlikely(ret != 0)) {
		KMS_DEBUG("pin the bo error\n");
		return -EINVAL;
	}

	KMS_DEBUG("gpu_addr=%llx , x=%d , y=%d\n", gpu_addr, x, y);
	via_chrome9_set_iga_start_addr(crtc, drm_fb, gpu_addr, x, y);

	offset = CMDISP_ALIGN_TO(drm_fb->pitch, 16) / 8;
	via_chrome9_load_offset_regs(crtc, offset);

	/* Load fetch count register */
	fetch_count = CMDISP_ALIGN_TO(
			crtc->mode.hdisplay * drm_fb->bits_per_pixel / 8, 16) / 16;
	fetch_count += 1;
	via_chrome9_load_fetch_count_regs(crtc, fetch_count);

	/* Load color depth */
	via_chrome9_load_color_depth_regs(crtc, drm_fb->bits_per_pixel);

	KMS_DEBUG(" mode hdisplay = %d, mode vdisplay = %d\n",
		crtc->mode.hdisplay, crtc->mode.vdisplay);
	KMS_DEBUG(" offset = %d, fetchcount=%d, pixelformat=%d\n",
		offset, fetch_count, drm_fb->bits_per_pixel);

	return 0;
}


static int via_chrome9_crtc_set_base(struct drm_crtc *crtc, int x, int y,
		struct drm_framebuffer *old_fb)
{
	return via_chrome9_crtc_do_set_base(crtc, old_fb, x, y, 0);
}

static int via_chrome9_crtc_mode_set(struct drm_crtc *crtc,
		struct drm_display_mode *mode,
		struct drm_display_mode *adjusted_mode,
		int x, int y,
		struct drm_framebuffer *old_fb)
{
	int ret = 0;
	struct drm_device *dev = crtc->dev;
	struct drm_encoder *encoder;
	struct drm_connector *connector;
	struct drm_encoder  *currentCrtcEncoder = NULL;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	bool bFondCorrectConnect = false;
	unsigned int mmio200_int_old = 0;

	list_for_each_entry(encoder, &dev->mode_config.encoder_list, head) {
		if(encoder->crtc == crtc) {
			currentCrtcEncoder = encoder;
			break;
		}
	}

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		if (currentCrtcEncoder && (connector->encoder == currentCrtcEncoder)) {
			via_chrome9_crtc->currentActiveConnector = connector;
			bFondCorrectConnect = true;
			break;
		}
	} 

	if(bFondCorrectConnect== false) {
		via_chrome9_crtc->currentActiveConnector  = NULL;
		KMS_DEBUG("no connect for this crtc!!!! mode set skip!!!\n");
		return -1;
	}

	mmio200_int_old = MMIO_RD(0x200);

	ret = via_chrome9_cbios_set_mode(crtc, mode, 
			adjusted_mode, crtc->fb->bits_per_pixel);
	if(false == ret)
		KMS_DEBUG("cbios set mode failed\n");

	/*
	 * vsync only enable once, 
	 * since cbios will re-init it to off, dirver should 
	 * save/restore it.
	 */
	via_chrome_restore_previous_vsync(mmio200_int_old);
    
	ret = via_chrome9_crtc_set_base(crtc, x, y, old_fb);
	if (ret)
		KMS_DEBUG("set base failed!\n");

	return ret;
}


static int via_chrome9_crtc_set_base_atomic(struct drm_crtc *crtc,
		struct drm_framebuffer *fb,
		int x, int y,
		enum mode_set_atomic state)
{
	return 0;
}


static void via_chrome9_crtc_prepare(struct drm_crtc *crtc)
{
	if (crtc->enabled)
		via_chrome9_crtc_dpms(crtc, DRM_MODE_DPMS_OFF);
}

static void via_chrome9_crtc_commit(struct drm_crtc *crtc)
{
	if (crtc->enabled)
		via_chrome9_crtc_dpms(crtc, DRM_MODE_DPMS_ON);
}

static void via_chrome9_crtc_gamma_set(struct drm_crtc *crtc, u16 *red,
		u16 *green, u16 *blue,
		uint32_t start, uint32_t size)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	int end = (start + size > 256) ? 256 : start + size, i;

	/* userspace palettes are always correct as is */
	/* this should be study later */
	for (i = start; i < end; i++) {
		via_chrome9_crtc->lut_r[i] = red[i] >> 8;
		via_chrome9_crtc->lut_g[i] = green[i] >> 8;
		via_chrome9_crtc->lut_b[i] = blue[i] >> 8;
	}

	via_chrome9_set_gamma_or_lut(crtc);
}

static void via_chrome9_crtc_destroy(struct drm_crtc *crtc)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);

	drm_crtc_cleanup(crtc);
	kfree(via_chrome9_crtc);
}

static const struct drm_crtc_funcs via_chrome9_crtc_funcs = {
	.cursor_set = via_chrome9_crtc_cursor_set,
	.cursor_move = via_chrome9_crtc_cursor_move,
	.gamma_set = via_chrome9_crtc_gamma_set,
	.set_config = drm_crtc_helper_set_config,
	.destroy = via_chrome9_crtc_destroy,
};

static const struct drm_crtc_helper_funcs via_chrome9_crtc_helper_funcs = {
	.dpms = via_chrome9_crtc_dpms,
	.mode_fixup = via_chrome9_crtc_mode_fixup,
	.mode_set = via_chrome9_crtc_mode_set,
	.mode_set_base = via_chrome9_crtc_set_base,
	.mode_set_base_atomic = via_chrome9_crtc_set_base_atomic,
	.prepare = via_chrome9_crtc_prepare,
	.commit = via_chrome9_crtc_commit,
	.load_lut = via_chrome9_crtc_load_lut,
};

void via_chrome9_crtc_init(struct drm_device *dev, int index)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_chrome9_crtc *via_chrome9_crtc;
	int i;

	via_chrome9_crtc =
		kzalloc(sizeof(struct via_chrome9_crtc) +
		(4 * sizeof(struct drm_connector *)), GFP_KERNEL);
	if (via_chrome9_crtc == NULL)
		return;

	drm_crtc_init(dev, &via_chrome9_crtc->base, &via_chrome9_crtc_funcs);
	drm_crtc_helper_add(&via_chrome9_crtc->base,
		&via_chrome9_crtc_helper_funcs);

	drm_mode_crtc_set_gamma_size(&via_chrome9_crtc->base, 256);
	via_chrome9_crtc->crtc_id = index;
	p_priv->mode_info.crtcs[index] = via_chrome9_crtc;
	for (i = 0; i < 256; i++) {
		via_chrome9_crtc->lut_r[i] = i << 8 | i;
		via_chrome9_crtc->lut_g[i] = i << 8 | i;
		via_chrome9_crtc->lut_b[i] = i << 8 | i;
	}
}
