/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <linux/seq_file.h>
#include <asm/atomic.h>
#include <linux/wait.h>
#include <linux/list.h>
#include <linux/kref.h>
#include "drmP.h"
#include "drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_fence.h"
#include "via_chrome9_object.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_ttm.h"

static void via_chrome9_fence_work_h5s2vp1(struct work_struct *work);

static void via_chrome9_fence_object_destroy(struct kref *kref)
{
	struct via_chrome9_fence_object *p_fence;
	p_fence = container_of(kref, struct via_chrome9_fence_object, kref);

	spin_lock(&p_fence->p_priv->p_fence->fence_pool_lock);
	list_del(&p_fence->list);
 	INIT_LIST_HEAD(&p_fence->list);
	spin_unlock(&p_fence->p_priv->p_fence->fence_pool_lock);

	kfree(p_fence);
	p_fence = NULL;
}

static bool
via_chrome9_fence_poll_locked(struct via_chrome9_fence_object *p_fence)
{
	uint32_t seq_queried;
	struct list_head *cur_p, *n, *pfence_emited, *pfence_signaled;
	struct drm_via_chrome9_private *p_priv = p_fence->p_priv;
	struct via_chrome9_fence_object *p_fence_obj;					

	if(p_fence->is_dma) {
		pfence_emited = &p_priv->p_fence->dma_emited;				
		pfence_signaled = &p_priv->p_fence->dma_signaled;
		seq_queried = readl(p_fence->p_priv->sg_manager->sg_sync_vaddr_align);		
	}
	else{
		pfence_emited = &p_priv->p_fence->emited[0];
		pfence_signaled = &p_priv->p_fence->signaled;
		seq_queried = readl(p_priv->p_fence->fence_sync_virtual);
	}

	n = NULL;
	list_for_each(cur_p, pfence_emited) {										
		p_fence_obj = container_of(cur_p,
			struct via_chrome9_fence_object, list);		
		if (p_fence_obj->sequence <= seq_queried)
			n = cur_p;						
		else
			break;			
	}								
	if (n) {		
		cur_p = n;		
		while (cur_p != pfence_emited) {
			n = cur_p->prev;
			list_del(cur_p);
			list_add_tail(cur_p, pfence_signaled);
			p_fence_obj = container_of(cur_p,
				struct via_chrome9_fence_object, list);
			p_fence_obj->signaled = true;
			cur_p = n;
		}
		return true;
	}
	return false;
}
/* The TTM bo driver specific function */
bool via_chrome9_fence_signaled_h6(struct via_chrome9_fence_object *p_fence,
	void *sync_arg)
{
	if(!p_fence)
		return true;		

	spin_lock(&p_fence->p_priv->p_fence->fence_pool_lock);
	if (p_fence->signaled || !p_fence->emited) { 
		spin_unlock(&p_fence->p_priv->p_fence->fence_pool_lock);
		return true;	
	}

	via_chrome9_fence_poll_locked(p_fence);	
	spin_unlock(&p_fence->p_priv->p_fence->fence_pool_lock);

	return p_fence->signaled;
}
/*The TTM bo driver specific function*/
bool via_chrome9_fence_signaled_h5s2vp1(struct via_chrome9_fence_object *p_fence,
	void *arg)
{
	if(!p_fence)
		return true;
	if(p_fence->is_dma) {
		spin_lock(&p_fence->p_priv->p_fence->fence_pool_lock);
		if (p_fence->signaled) { 
			spin_unlock(&p_fence->p_priv->p_fence->fence_pool_lock);
			return true;	
		}
		via_chrome9_fence_poll_locked(p_fence);	
		spin_unlock(&p_fence->p_priv->p_fence->fence_pool_lock);
	}
	if (!p_fence->signaled) {
		p_fence->waited = true;
		via_chrome9_fence_work_h5s2vp1(&p_fence->p_priv->p_fence->fence_work);
	}
	return p_fence->signaled;
}

/* The TTM bo driver specific function */
/* Can solve fence sequence wrap  */
int via_chrome9_fence_wait_h6(struct via_chrome9_fence_object *p_fence,
	void *sync_arg,	bool lazy, bool interruptible)
{
	struct drm_via_chrome9_private *dev_priv = p_fence->p_priv;
	struct via_chrome9_fence_ops *fence_ops = &dev_priv->engine_ops.fence_ops;
	int ret;
	int timeout = HZ / 100;

	if(fence_ops->fence_signaled(p_fence, sync_arg))
		return 0;
retry:
	if (time_after(jiffies, p_fence->timeout)) {
		DRM_INFO("The fence wait timeout timeout = %u, jiffies \
			= %u.\n",
			(uint32_t)p_fence->timeout, (uint32_t)jiffies);
		return -EBUSY;
	}

	if (interruptible) {
		ret = wait_event_interruptible_timeout(
			p_fence->p_priv->p_fence->fence_wait_queue,
			fence_ops->fence_signaled(p_fence, sync_arg),
			timeout);
		if (ret < 0) {
			return ret;
		}
	} else
		ret = wait_event_timeout(
			p_fence->p_priv->p_fence->fence_wait_queue,
			fence_ops->fence_signaled(p_fence, sync_arg),
			timeout);

	if (unlikely(!(ret = fence_ops->fence_signaled(p_fence, sync_arg)))) {
		goto retry;
	}

	return 0;
}

#if 0
int via_chrome9_fence_wait_h5s2vp1(struct via_chrome9_fence_object *p_fence,
	void *sync_arg,	bool lazy, bool interruptible)
{
	struct drm_via_chrome9_private *dev_priv = p_fence->p_priv;
	struct via_chrome9_fence_ops *fence_ops = &dev_priv->engine_ops.fence_ops;
	int ret;

	if(fence_ops->fence_signaled(p_fence, sync_arg))
		return 0;

	if (interruptible) {
		ret = wait_event_interruptible(
			p_fence->p_priv->p_fence->fence_wait_queue,
			fence_ops->fence_signaled(p_fence, sync_arg));
		if (ret < 0) {
			return ret;
		}
	} else
		wait_event(
			p_fence->p_priv->p_fence->fence_wait_queue,
			fence_ops->fence_signaled(p_fence, sync_arg));	

	if (unlikely(!(ret = fence_ops->fence_signaled(p_fence, sync_arg)))) {
		printk(KERN_ERR "fence wait function out with fence un-signaled.\n");
		return -EBUSY;
	}

	return 0;
}
#endif
/* The TTM bo driver specific function */
int via_chrome9_fence_flush(struct via_chrome9_fence_object *p_fence,
	void *sync_arg)
{
	return 0;
}

/* The TTM bo driver specific function */
void via_chrome9_fence_unref(struct via_chrome9_fence_object **pp_fence)
{
	struct via_chrome9_fence_object *p_fence = *pp_fence;

	*pp_fence = NULL;
	if (p_fence)
		kref_put(&p_fence->kref, &via_chrome9_fence_object_destroy);
}

/* The TTM bo driver specific function */
void *via_chrome9_fence_ref(struct via_chrome9_fence_object *p_fence)
{
	kref_get(&p_fence->kref);
	return p_fence;
}
static void via_chrome9_blit_h6(struct via_chrome9_fence_object * p_fence_object)
{
	uint32_t *p_cmd = p_fence_object->p_priv->p_fence->p_cmd_tmp;

	unsigned int cmd_type = p_fence_object->type;

	unsigned int wait_flag = 0;
	unsigned int i,  FenceCfg0, FenceCfg1, FenceCfg2, FenceCfg3;
	unsigned long fence_phy_address = 
		p_fence_object->p_priv->p_fence->fence_bus_addr;

	FenceCfg0 = (INV_SubA_HFCWBasH | (fence_phy_address & 0xFF000000)>>24);
	FenceCfg1 = (INV_SubA_HFCWBasL2 | (fence_phy_address & 0x00FFFFF0));
	FenceCfg2 = (INV_SubA_HFCIDL2 | (p_fence_object->sequence & 0x00FFFFFF));
	FenceCfg3 = (INV_SubA_HFCTrig2 | INV_HFCTrg |  INV_HFCMode_Idle |  
			INV_HFCMode_SysWrite | ((p_fence_object->sequence & 0xff000000) >> 16)); 
	/* set wait flag */
	if (cmd_type & VIA_CHROME9_CMD_2D)
		wait_flag |= INV_CR_WAIT_2D_IDLE;
	if (cmd_type & VIA_CHROME9_CMD_3D)
		wait_flag |= INV_CR_WAIT_3D_IDLE;

	/* sync the engine*/
	addcmdheader0_invi(p_cmd, 1);
	add2dcmd_invi(p_cmd, 0x0000006C, wait_flag);
	addcmddata_invi(p_cmd, 0xCC000000);
	addcmddata_invi(p_cmd, 0xCC000000);
	/* use CR fence mechanism */
	addcmdheader2_invi(p_cmd, INV_REG_CR_TRANS,
			INV_ParaType_CR);
	addcmddata_invi(p_cmd, FenceCfg0);
	addcmddata_invi(p_cmd, FenceCfg1);
	addcmddata_invi(p_cmd, FenceCfg2);
	addcmddata_invi(p_cmd, FenceCfg3);

	for (i = 0 ; i < AGP_REQ_FIFO_DEPTH/2; i++) {
		addcmdheader2_invi(p_cmd, INV_REG_CR_TRANS,				
			INV_ParaType_Dummy);
		addcmddata_invi(p_cmd, 0xCC0CCCCC);
	}

	/* Do command size 128 bits alignment */
	if ((p_cmd - p_fence_object->p_priv->p_fence->p_cmd_tmp) & 0xF) {
		*(p_cmd)++ = 0xCC000000;
		*(p_cmd)++ = 0xCC000000;   
	}
	via_chrome9_ringbuffer_flush(p_fence_object->p_priv->ddev,
		p_fence_object->p_priv->p_fence->p_cmd_tmp,
		p_cmd - p_fence_object->p_priv->p_fence->p_cmd_tmp,
		false, NULL);
}

static void via_chrome9_blit_h5s2vp1(struct via_chrome9_fence_object * p_fence_object)
{
	uint32_t *p_cmd = p_fence_object->p_priv->p_fence->p_cmd_tmp;
	unsigned int cmd_type = p_fence_object->type;
	unsigned int i,fenceID,sysfence_phyaddr;
	unsigned int dwFenceWait,dwFenceCfg, dwFenceMode;
	unsigned long fence_phy_address = 
		p_fence_object->p_priv->p_fence->fence_bus_addr;
	int video_related = 0;

	/* XXX: The CR interrupt can't generate correctly in Multi-core CPU
	** The reason is still unknown
	*/
	dwFenceMode = NEW_HENFCMode_IntGen;
	
	dwFenceWait = 0;
	dwFenceCfg = dwFenceMode;
	dwFenceCfg |= NEW_HENFCMode_SysWrite ;//| NEW_FENCE_HEnFCIntWait; 

	sysfence_phyaddr = fence_phy_address;
	fenceID = p_fence_object->sequence;

	switch (cmd_type & VIA_CHROME9_CMD_MASK) {
		case VIA_CHROME9_CMD_2D:
			dwFenceWait |= NEW_FENCE_WAIT2D;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeader2D;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_2D * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_2D;
			break;
		case VIA_CHROME9_CMD_3D:
			dwFenceWait |= NEW_FENCE_WAIT3D;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeader3D;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_3D * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_3D;
			break;
		case VIA_CHROME9_CMD_VD:
			dwFenceWait |= NEW_FENCE_WAITVD;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderVD;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_VD* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_VD;
			break;
		case VIA_CHROME9_CMD_HQV0:
			dwFenceWait |= NEW_FENCE_WAITHQV0;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_HQV0* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		case VIA_CHROME9_CMD_HQV1:
			dwFenceWait |= NEW_FENCE_WAITHQV1;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_HQV1* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		case VIA_CHROME9_CMD_VIDEO:
			dwFenceWait = 0;
			dwFenceCfg |=  NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_VIDEO* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = 0;
			break;
		case VIA_CHROME9_CMD_DMA0:
			dwFenceWait |= NEW_FENCE_WAITDMA0;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderDMA;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_DMA* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_DMA;
			break;
		case VIA_CHROME9_CMD_DMA1:
			dwFenceWait |= NEW_FENCE_WAITDMA1;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderDMA;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_DMA* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_DMA;
			break;
		case VIA_CHROME9_CMD_DMA2:
			dwFenceWait |= NEW_FENCE_WAITDMA2;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderDMA;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_DMA* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_DMA;
			break;
		case VIA_CHROME9_CMD_DMA3:
			dwFenceWait |= NEW_FENCE_WAITDMA3;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderDMA;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_DMA* VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_DMA;
			break;
		case VIA_CHROME9_CMD_3D | VIA_CHROME9_CMD_2D:
			dwFenceWait |= NEW_FENCE_WAIT3D | NEW_FENCE_WAIT2D;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeader3D;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_3D * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_3D | FCFOLLOW_2D;
			break;
		case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_VIDEO:
			dwFenceWait |= NEW_FENCE_WAITHQV0;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address + 
				VIA_FENCE_VIDEO * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_HQV1:
			dwFenceWait |= NEW_FENCE_WAITHQV0|NEW_FENCE_WAITHQV1;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address +
				VIA_FENCE_HQV1 * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		 case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_HQV1 | VIA_CHROME9_CMD_VIDEO:
			dwFenceWait |= NEW_FENCE_WAITHQV0|NEW_FENCE_WAITHQV1;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address +
				 VIA_FENCE_VIDEO * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		case VIA_CHROME9_CMD_HQV1 | VIA_CHROME9_CMD_VIDEO:
			dwFenceWait |= NEW_FENCE_WAITHQV1;
			dwFenceCfg |= p_fence_object->p_priv->prev_cmd_type | NEW_FENCEHeaderHQV;
			sysfence_phyaddr = fence_phy_address + 
				VIA_FENCE_VIDEO * VIA_CHROME9_FENCE_SIZE;
			p_fence_object->p_priv->prev_cmd_type = FCFOLLOW_HQV;
			break;
		default:
			BUG();
	}

	ADDCmdHeader3X_INVI(p_cmd, sysfence_phyaddr,
			fenceID, dwFenceWait, dwFenceCfg, video_related);

	for (i = 0 ; i < AGP_REQ_FIFO_DEPTH/2; i++) {
		addcmdheader2_invi(p_cmd, INV_REG_CR_TRANS,				
			INV_ParaType_Dummy);
		addcmddata_invi(p_cmd, 0xCC0CCCCC);
	}

	/* Do command size 128 bits alignment */
	if ((p_cmd - p_fence_object->p_priv->p_fence->p_cmd_tmp) & 0xF) {
		*(p_cmd)++ = 0xCC000000;
		*(p_cmd)++ = 0xCC000000;   
	}
	via_chrome9_ringbuffer_flush(p_fence_object->p_priv->ddev,
		p_fence_object->p_priv->p_fence->p_cmd_tmp,
		p_cmd - p_fence_object->p_priv->p_fence->p_cmd_tmp,
		false, NULL);
}

struct list_head *
via_chrome9_get_emit_list(struct via_chrome9_fence_object *p_fence_obj)
{
	struct via_chrome9_fence_pool *p_fence = p_fence_obj->p_priv->p_fence;
	switch (p_fence_obj->type & VIA_CHROME9_CMD_MASK) {
		case VIA_CHROME9_CMD_2D:
			return &p_fence->emited[VIA_FENCE_2D];
		case VIA_CHROME9_CMD_3D:
			return &p_fence->emited[VIA_FENCE_3D];
		case VIA_CHROME9_CMD_VD:
			return &p_fence->emited[VIA_FENCE_VD];
		case VIA_CHROME9_CMD_HQV0:
			return &p_fence->emited[VIA_FENCE_HQV0];
		case VIA_CHROME9_CMD_HQV1:
			return &p_fence->emited[VIA_FENCE_HQV1];
		case VIA_CHROME9_CMD_VIDEO:
			return &p_fence->emited[VIA_FENCE_VIDEO];
		case VIA_CHROME9_CMD_DMA0:
		case VIA_CHROME9_CMD_DMA1:
		case VIA_CHROME9_CMD_DMA2:
		case VIA_CHROME9_CMD_DMA3:
			return &p_fence->emited[VIA_FENCE_DMA];
		case VIA_CHROME9_CMD_2D | VIA_CHROME9_CMD_3D:
			return &p_fence->emited[VIA_FENCE_3D];
		case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_VIDEO:
			return &p_fence->emited[VIA_FENCE_VIDEO];
		case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_HQV1:
			 return &p_fence->emited[VIA_FENCE_HQV1];
		case VIA_CHROME9_CMD_HQV0 | VIA_CHROME9_CMD_HQV1|VIA_CHROME9_CMD_VIDEO:
			return &p_fence->emited[VIA_FENCE_VIDEO];
		case VIA_CHROME9_CMD_HQV1 | VIA_CHROME9_CMD_VIDEO:
			return &p_fence->emited[VIA_FENCE_VIDEO];
	}
	return NULL;
}

/* the api function exposed for other parts */
int via_chrome9_fence_emit_h6(struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object *p_fence_object)
{
	if (!p_fence_object) {
		printk(KERN_ERR "Invalid parameters passed in.\n");
		return -EINVAL;
	}

	spin_lock(&p_priv->p_fence->fence_pool_lock);
	if (p_fence_object->emited) {
		spin_unlock(&p_priv->p_fence->fence_pool_lock);
		printk(KERN_INFO "the fence object has already set up\n");
		return 0;
	}

	list_del(&p_fence_object->list);
	if (p_fence_object->is_dma)
		p_fence_object->sequence = atomic_add_return(1, &p_priv->p_fence->dma_seq);
	else
		p_fence_object->sequence = atomic_add_return(1, &p_priv->p_fence->seq);

	if (p_fence_object->is_dma) 
		list_add_tail(&p_fence_object->list, &p_priv->p_fence->dma_emited);
	else
		list_add_tail(&p_fence_object->list, &p_priv->p_fence->emited[0]);
	spin_unlock(&p_priv->p_fence->fence_pool_lock);

	/* blit out the sequence using CR */
	if (!p_fence_object->is_dma)
		via_chrome9_blit_h6(p_fence_object);

	p_fence_object->emited = true;
	p_fence_object->timeout = jiffies + 6 * HZ;

	return 0;
}

/* the api function exposed for other parts */
int via_chrome9_fence_emit_h5s2vp1(struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object *p_fence_object)
{
	struct list_head *emited;
	if (!p_fence_object) {
		printk(KERN_ERR "Invalid parameters passed in.\n");
		return -EINVAL;
	}

	spin_lock(&p_priv->p_fence->fence_pool_lock);
	if (p_fence_object->emited) {
		spin_unlock(&p_priv->p_fence->fence_pool_lock);
		printk(KERN_INFO "the fence object has already set up\n");
		return 0;
	}
	list_del(&p_fence_object->list);
	if (p_fence_object->is_dma)
		p_fence_object->sequence = atomic_add_return(1, &p_priv->p_fence->dma_seq);
	else
		p_fence_object->sequence = atomic_add_return(1, &p_priv->p_fence->seq);
	
	if (p_fence_object->is_dma) 
		list_add_tail(&p_fence_object->list, &p_priv->p_fence->dma_emited);
	else {
		emited = via_chrome9_get_emit_list(p_fence_object);
		BUG_ON(!emited);
		list_add_tail(&p_fence_object->list, emited);
	}
	spin_unlock(&p_priv->p_fence->fence_pool_lock);

	/* blit out the sequence using enhance fence mechanism */
	if (!p_fence_object->is_dma)
		via_chrome9_blit_h5s2vp1(p_fence_object);

	p_fence_object->emited = true;
	p_fence_object->timeout = jiffies + 6 * HZ;

	return 0;
}

/* the api function exposed for other parts */
int
via_chrome9_fence_object_create(struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object **pp_fence_object, bool is_dma)
{	
	struct via_chrome9_fence_object *p_fence;

	p_fence = kzalloc(sizeof(struct via_chrome9_fence_object), GFP_KERNEL);
	if (!p_fence) {
		printk(KERN_ERR " fence object create out of memory.\n");
		return -ENOMEM;
	}
	p_fence->p_priv = p_priv;
	kref_init(&p_fence->kref);
	INIT_LIST_HEAD(&p_fence->list);   
	p_fence->sequence = 0;
	p_fence->timeout = 0;
	p_fence->emited = false;
	p_fence->signaled = false;
	
	spin_lock(&p_priv->p_fence->fence_pool_lock);
	if (is_dma) {
		p_fence->is_dma = true;
		list_add_tail(&p_fence->list, &p_priv->p_fence->dma_created);
	}else	
		list_add_tail(&p_fence->list, &p_priv->p_fence->created);
	
	spin_unlock(&p_priv->p_fence->fence_pool_lock);
	*pp_fence_object = p_fence;
	return 0;
}

static void via_chrome9_fence_work_h5s2vp1(struct work_struct *work)
{
	unsigned int seq_queried, seq_prev, i;
	struct list_head *cur_p, *pfence_signaled, *pfence_emited, *tmp;
	struct via_chrome9_fence_object *cur_fence_object, *fence_object;
	struct via_chrome9_fence_pool *p_fence =
		container_of(work, struct via_chrome9_fence_pool,
			fence_work);

		pfence_signaled = &p_fence->signaled;
		spin_lock(&p_fence->fence_pool_lock);

		for (i = 0; i < VIA_FENCE_NUM; i++) {
			tmp = NULL;
			cur_fence_object = NULL;
			pfence_emited = &p_fence->emited[i];
			seq_queried = readl(p_fence->fence_sync_virtual +
						VIA_CHROME9_FENCE_SIZE/4 * i);
			/* If sequence changed, this engine's fence comes */
			if (seq_queried == p_fence->eng_fence[i])
				continue;
			else
				p_fence->eng_fence[i] = seq_queried;

			list_for_each(cur_p, pfence_emited) {
				cur_fence_object = container_of(cur_p,
				struct via_chrome9_fence_object, list);

				if (cur_fence_object->sequence <= seq_queried)
					tmp = cur_p;
				else
					break;
			}
retry:
			if (likely(cur_fence_object && tmp)) {
				cur_p = tmp;
				while (cur_p != pfence_emited) {
					tmp = cur_p->prev;
					list_del_init(cur_p);
					list_add_tail(cur_p, pfence_signaled);
					cur_fence_object  = container_of(cur_p,
						struct via_chrome9_fence_object, list);
					cur_fence_object->signaled = true;
					if (cur_fence_object->waited) {
						wake_up_all(&p_fence->fence_wait_queue);
						cur_fence_object->waited = false;
					}
					cur_p = tmp;
				}
			} else {
				/* Whether sequence wraped ? */
				if (!list_empty(pfence_emited)) {
					tmp = pfence_emited->next;
					fence_object = container_of(tmp,
						struct via_chrome9_fence_object, list);
					/* if sequence wraped */
					if (unlikely(seq_queried - fence_object->sequence < 1UL<<28)) {
						tmp = NULL;
						seq_prev = fence_object->sequence;
						list_for_each(cur_p, pfence_emited) {
							cur_fence_object = container_of(cur_p,
							struct via_chrome9_fence_object, list);
							if (cur_fence_object->sequence >= seq_prev)
								tmp = cur_p;
							else
								break;
							seq_prev = cur_fence_object->sequence;
						}
						if (tmp && cur_fence_object)
							goto retry;
					}
				}
			}
		}

		spin_unlock(&p_fence->fence_pool_lock);
}

int via_chrome9_fence_mechanism_init(struct drm_device *dev)
{
	int ret, i;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (unlikely(!p_priv || p_priv->p_fence)) {
		printk(KERN_ERR
			"fence mechanism called with invalid parameters or \
			the fence mechanism has been already initilized!\n");
		return -EINVAL;
	}

	p_priv->p_fence =
		kzalloc(sizeof(struct via_chrome9_fence_pool), GFP_KERNEL);
	if (unlikely(!p_priv->p_fence)) {
		printk(KERN_INFO " In fence mechanism init function, \
			not enough system memory.\n");
		return -ENOMEM;
	}

	/* allocate fence sync bo */
	ret = via_chrome9_buffer_object_create(&p_priv->bdev,
				VIA_CHROME9_FENCE_SYNC_BO_SIZE,
				ttm_bo_type_kernel,
#ifndef USE_2D_ENGINE_BLT
				TTM_PL_FLAG_TT| TTM_PL_FLAG_NO_EVICT,
#else
				TTM_PL_FLAG_VRAM | TTM_PL_FLAG_NO_EVICT,
#endif
				0, 0, false, NULL,
				&p_priv->p_fence->fence_sync);
	if (unlikely(ret)) {
		printk("allocate fence sync bo error.\n");
		goto out_err0;
	}

	/* change fence bo to TTM_PL_FLAG_WC */
	ttm_tt_set_placement_caching(p_priv->p_fence->fence_sync->bo.ttm, TTM_PL_FLAG_WC);
	p_priv->p_fence->fence_sync->bo.mem.placement &= ~TTM_PL_MASK_CACHING;
	p_priv->p_fence->fence_sync->bo.mem.placement |= TTM_PL_FLAG_WC;

	ret = via_chrome9_buffer_object_kmap(p_priv->p_fence->fence_sync,
				(void **)&p_priv->p_fence->fence_sync_virtual);
	if (unlikely(ret)) {
		printk(KERN_ERR "kmap fence sync bo error.\n");
		goto out_err1;
	}
#ifndef USE_2D_ENGINE_BLT
	p_priv->p_fence->fence_bus_addr = dma_map_page(
			&p_priv->ddev->pdev->dev,
			p_priv->p_fence->fence_sync->bo.ttm->pages[0], 0, 
			PAGE_SIZE, DMA_BIDIRECTIONAL);
#endif
#define FENCE_CMD_TMP_BUFFER (256 * sizeof(uint32_t))
	/* We assert 30 * sizeof(uint32_t) is enough for emit fence sequence */
	p_priv->p_fence->p_cmd_tmp = kzalloc(FENCE_CMD_TMP_BUFFER, GFP_KERNEL);
	if (!p_priv->p_fence->p_cmd_tmp) {
		printk(KERN_ERR "fence tmp cmd buffer allocate error. out of memory.\n");
		goto out_err2;
	}
#undef FENCE_CMD_TMP_BUFFER
	
	spin_lock_init(&p_priv->p_fence->fence_pool_lock);
	writel(0, p_priv->p_fence->fence_sync_virtual);
	atomic_set(&p_priv->p_fence->seq, 0);
	atomic_set(&p_priv->p_fence->dma_seq, 0);

	init_waitqueue_head(&p_priv->p_fence->fence_wait_queue);
	INIT_LIST_HEAD(&p_priv->p_fence->created);
	for (i = 0; i < VIA_FENCE_NUM; i++) {
		INIT_LIST_HEAD(&p_priv->p_fence->emited[i]);
		p_priv->p_fence->eng_fence[i] = 0xFFFFFFFFFULL;
	}
	INIT_LIST_HEAD(&p_priv->p_fence->signaled);
	INIT_LIST_HEAD(&p_priv->p_fence->dma_created);
	INIT_LIST_HEAD(&p_priv->p_fence->dma_emited);
	INIT_LIST_HEAD(&p_priv->p_fence->dma_signaled);

	p_priv->p_fence->fence_wq =
		create_singlethread_workqueue("via_fence_wq");

	INIT_WORK(&p_priv->p_fence->fence_work, via_chrome9_fence_work_h5s2vp1);

	return 0;

	out_err2:
		via_chrome9_buffer_object_kunmap(p_priv->p_fence->fence_sync);
	out_err1:
		via_chrome9_buffer_object_unref(&p_priv->p_fence->fence_sync);
	out_err0:
		kfree(p_priv->p_fence);
		p_priv->p_fence = NULL;

	return ret;
}

void via_chrome9_fence_mechanism_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	/* How about the waked up process to touch fence context?
	 * The context will be destroyed immediately in this function.
	 */
	wake_up_all(&p_priv->p_fence->fence_wait_queue);
#ifndef USE_2D_ENGINE_BLT
	dma_unmap_page(	&p_priv->ddev->pdev->dev,p_priv->p_fence->fence_bus_addr,
			PAGE_SIZE, DMA_BIDIRECTIONAL);
#endif
	destroy_workqueue(p_priv->p_fence->fence_wq);
	via_chrome9_buffer_object_kunmap(p_priv->p_fence->fence_sync);
	via_chrome9_buffer_object_unref(&p_priv->p_fence->fence_sync);
	kfree(p_priv->p_fence->p_cmd_tmp);
	kfree(p_priv->p_fence);	
	p_priv->p_fence->p_cmd_tmp = NULL;
	p_priv->p_fence = NULL;
}
