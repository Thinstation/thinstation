/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_ttm.h"
#include "via_chrome9_dmablit.h"
#include <ttm/ttm_bo_api.h>
#include <ttm/ttm_bo_driver.h>
#include <ttm/ttm_placement.h>
#include <ttm/ttm_module.h>

struct via_chrome9_ttm_backend {
	struct ttm_backend	backend; /* the class's method */
	struct drm_via_chrome9_private	*p_priv; /* hook driver informaiton */
	unsigned long		num_pages;
	/* series of pages' data structure for binding */
	struct page		**pages;
	struct page		*dummy_read_page;
	/* indicate that the pages are populated */
	bool			populated;
	/* indicated whether the pages have been bound */
	bool			bound;
	/* GART start entry to which the pages bind */
	unsigned long		start_entry;
};



static int via_chrome9_pcie_populate(struct ttm_backend *backend,
			    unsigned long num_pages, struct page **pages,
			    struct page *dummy_read_page)
{
	struct via_chrome9_ttm_backend *p_backend;

	p_backend = container_of(backend,
		struct via_chrome9_ttm_backend, backend);

	p_backend->populated = true;
	p_backend->pages = pages;
	p_backend->num_pages = num_pages;
	p_backend->dummy_read_page = dummy_read_page;

	return 0;
}

/* The reversion of function via_chrome9_pcie_populate */
static void via_chrome9_pcie_clear(struct ttm_backend *backend)
{
	struct via_chrome9_ttm_backend *p_backend;

	p_backend = container_of(backend,
		struct via_chrome9_ttm_backend, backend);
	p_backend->bound = false;
	p_backend->populated = false;
	p_backend->num_pages = 0;
	p_backend->pages = 0;
	p_backend->dummy_read_page = 0;
}

/* Update GART table relevant entry based on the parameters */
static int via_chrome9_pcie_bind(struct ttm_backend *backend,
	struct ttm_mem_reg *bo_mem)
{
	struct via_chrome9_ttm_backend *p_backend;
	struct drm_via_chrome9_private *p_priv;
	unsigned long entry;
	u32 max_entries, i;
	u8 sr6c, sr6f;

	p_backend = container_of(backend,
		struct via_chrome9_ttm_backend, backend);
	p_priv = p_backend->p_priv;

	if (!p_priv || !backend) {
		DRM_ERROR("Pass a invalid value into via_chrome9_pcie_bind.\n");
		return -EINVAL;
	}

	/* bo_mem->mm_node record the mem space of pcie
	 * whose memory manager is based on page_size unit
	 */
	entry = bo_mem->mm_node->start;
	max_entries = p_priv->pcie_mem_size >> PAGE_SHIFT;

	/* sanity check */
	if (!p_backend->populated || p_backend->bound)
		DRM_ERROR("TTM bind a un-populated ttm_backend or an \
		already bound ttm_backend.\n");

	if (entry + p_backend->num_pages > max_entries) {
		DRM_ERROR("bind a page range exceeding the PCIE space.\n");
		return -EINVAL;
	}

	/* begin to bind pcie memory
	 * 1.disable gart table HW protect
	 * 2.update the relevant entries
	 * 3.invalide GTI cache
	 * 4.enable gart table HW protect
	 */
	/* 1.*/
	sr6c = via_chrome9_read_vga_io(0x16c);
	sr6c &= 0x7F;
	via_chrome9_write_vga_io(0x16c, sr6c);
	/* 2.*/
	for (i = 0; i < p_backend->num_pages; i++) {
		writel(page_to_pfn(p_backend->pages[i]) & 0x3FFFFFFF,
			p_priv->pcie_gart_map + entry + i);
	}
	/* 3.*/
	sr6f = via_chrome9_read_vga_io(0x16f);
	sr6f |= 0x80;
	via_chrome9_write_vga_io(0x16f, sr6f);
	/* 4.*/
	sr6c = via_chrome9_read_vga_io(0x16c);
	sr6c |= 0x80;
	via_chrome9_write_vga_io(0x16c, sr6c);

	/* update the flag */
	p_backend->bound = true;
	p_backend->start_entry = entry;

	return 0;
	
}

static int via_chrome9_pcie_unbind(struct ttm_backend *backend)
{
	struct via_chrome9_ttm_backend *p_backend;
	struct drm_via_chrome9_private *p_priv;
	unsigned long i;
	u8 sr6c, sr6f;

	p_backend = container_of(backend,
		struct via_chrome9_ttm_backend, backend);
	p_priv = p_backend->p_priv;

	if (!backend || !p_priv) {
		DRM_ERROR("unbind function called with invalid parameters.\n");
		return -EINVAL;
	}

	if (!p_backend->bound || !p_backend->populated) {
		DRM_ERROR("unbind a ttm_backend which hasn't bound yet.\n");
		return -EINVAL;
	}

	/* begin to unbind pcie memory
	 * 1. disable gart table HW protect
	 * 2. unbind relevant entries
	 * 3. invalide GTI cache
	 * 4. enable gart table HW protect
	 */
	/* 1.*/
	sr6c = via_chrome9_read_vga_io(0x16c);
	sr6c &= 0x7F;
	via_chrome9_write_vga_io(0x16c, sr6c);
	/* 2.*/
	for (i = 0; i < p_backend->num_pages; i++) {
		writel(0x80000000,
			p_priv->pcie_gart_map + p_backend->start_entry + i);
	}
	/* 3.*/
	sr6f = via_chrome9_read_vga_io(0x16f);
	sr6f |= 0x80;
	via_chrome9_write_vga_io(0x16f, sr6f);
	/* 4.*/
	sr6c = via_chrome9_read_vga_io(0x16c);
	sr6c |= 0x80;
	via_chrome9_write_vga_io(0x16c, sr6c);
	/* update some flags */
	p_backend->bound = false;
	p_backend->start_entry = -1;

	return 0;	
}

/* unbind pcie memory first if it is bound, free the memory */
static void via_chrome9_pcie_destroy(struct ttm_backend *backend)
{
	struct via_chrome9_ttm_backend *p_backend;

	p_backend = container_of(backend,
		struct via_chrome9_ttm_backend, backend);

	if (p_backend->bound)
		via_chrome9_pcie_unbind(backend);

	kfree(p_backend);
	p_backend = NULL;
}

static struct ttm_backend_func via_chrome9_pcie_func = {
	.populate = via_chrome9_pcie_populate,
	.clear = via_chrome9_pcie_clear,
	.bind = via_chrome9_pcie_bind,
	.unbind = via_chrome9_pcie_unbind,
	.destroy = via_chrome9_pcie_destroy,
};

/* allocate memory for struct via_chrome9_ttm_backend and do intialization */
struct ttm_backend *
via_chrome9_pcie_backend_init(struct drm_via_chrome9_private *p_priv)
{
	struct via_chrome9_ttm_backend *p_backend;

	if (!p_priv)
		return 0;

	p_backend = kzalloc(sizeof(struct via_chrome9_ttm_backend), GFP_KERNEL);
	if (!p_backend)
		return 0;

	p_backend->backend.bdev = &p_priv->bdev;
	p_backend->backend.flags = 0;
	p_backend->backend.func = &via_chrome9_pcie_func;
	p_backend->bound = false;
	p_backend->populated = false;
	p_backend->p_priv = p_priv;
	p_backend->dummy_read_page = 0;
	p_backend->num_pages = 0;
	p_backend->pages = 0;

	return &p_backend->backend;
}
