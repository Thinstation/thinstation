/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef __VIA_CHROME9_DISPLAY_COMMON_H__
#define __VIA_CHROME9_DISPLAY_COMMON_H__

#include "drm.h"
#include "drm_edid.h"
#include "drm_crtc.h"

struct via_chrome9_io_reg {
	u16    index;
	u8     mask;
	u8     value;
};

struct via_chrome9_io_bit {
	u16     io_addr;
	u8      start_bit;
	u8      end_bit;
};

/*Bit Defination*/
#ifndef BIT0
#define BIT0        0x00000001
#endif

#ifndef BIT1
#define BIT1        0x00000002
#endif

#ifndef BIT2
#define BIT2        0x00000004
#endif

#ifndef BIT3
#define BIT3        0x00000008
#endif

#ifndef BIT4
#define BIT4        0x00000010
#endif

#ifndef BIT5
#define BIT5        0x00000020
#endif

#ifndef BIT6
#define BIT6        0x00000040
#endif

#ifndef BIT7
#define BIT7        0x00000080
#endif

#ifndef BIT8
#define BIT8        0x00000100
#endif

#ifndef BIT9
#define BIT9        0x00000200
#endif

#ifndef BIT10
#define BIT10       0x00000400
#endif

#ifndef BIT11
#define BIT11       0x00000800
#endif

#ifndef BIT12
#define BIT12       0x00001000
#endif

#ifndef BIT13
#define BIT13       0x00002000
#endif

#ifndef BIT14
#define BIT14       0x00004000
#endif

#ifndef BIT15
#define BIT15       0x00008000
#endif

#ifndef BIT16
#define BIT16       0x00010000
#endif

#ifndef BIT17
#define BIT17       0x00020000
#endif

#ifndef BIT18
#define BIT18       0x00040000
#endif

#ifndef BIT19
#define BIT19       0x00080000
#endif

#ifndef BIT20
#define BIT20       0x00100000
#endif

#ifndef BIT21
#define BIT21       0x00200000
#endif

#ifndef BIT22
#define BIT22       0x00400000
#endif

#ifndef BIT23
#define BIT23       0x00800000
#endif

#ifndef BIT24
#define BIT24       0x01000000
#endif

#ifndef BIT25
#define BIT25       0x02000000
#endif

#ifndef BIT26
#define BIT26       0x04000000
#endif

#define REG_ZCR      0x3D4
#define REG_ZSR      0x3C4
#define REG_ZGR      0x3CE
#define REG_ZAR      0x3C0
#define REG_STATUS   0x3DA
#define REG_PEL      0x3C8

#define IS_ZSR       0x0100
#define IS_ZGR       0x0200
#define IS_ZAR       0x0400
#define REG_INDEX_MASK  0xff
#define VGAIO_BASE   0x8000

#define REG_SR15         0x0115
#define REG_SR1A         0x011A
#define REG_SR1B         0x011B
#define REG_SR1C         0x011C
#define REG_SR1D         0x011D
#define REG_SR26         0x0126
#define REG_SR2C         0x012C
#define REG_SR31         0x0131
#define REG_SR3B         0x013B
#define REG_SR3D         0x013D
#define REG_SR3E         0x013E

#define REG_CR0C         0x000C
#define REG_CR0D         0x000D
#define REG_CR11         0x0011
#define REG_CR13         0x0013
#define REG_CR33         0x0033
#define REG_CR34         0x0034
#define REG_CR35         0x0035
#define REG_CR48         0x0048
#define REG_CR62         0x0062
#define REG_CR63         0x0063
#define REG_CR64         0x0064
#define REG_CR65         0x0065
#define REG_CR66         0x0066
#define REG_CR67         0x0067
#define REG_CR71         0x0071
#define REG_CR6A         0x006A
#define REG_CRA2         0x00A2
#define REG_CRA3         0x00A3
#define REG_CRF3         0x00F3
#define REG_CRFD         0x00FD
#define REG_CRFF         0x00FF

#define DP_DATA_PASS_ENABLE_REG	0xC000

#define    VIA_IRQ_DP_HOT_IRQ	0xC0000000
#define    VIA_IRQ_DP_HOT_UNPLUG	0x80000000
#define    VIA_IRQ_DP_HOT_PLUG	0x40000000
#define    VIA_IRQ_DP_NO_INT	0x00000000

#define SPEED_NONE	0
#define SPEED_162MHz	1
#define SPEED_270MHz	2

#define LANE	4

struct via_cea_timing_info_rec {
	u16 id;
	u16 hor_size;
	u16 ver_size;
	u16 refresh_rate;
	int scan_type;
	u16 vsync_offset;
	int ratio;
	 /* If the timing table exists. */
	bool is_built;
};

struct via_hdmi_encoder_private_info {
	u32 connector_type;
};

struct via_hdmi_connector_private_info {
	u32 physical_width;
	u32 physical_height;
	u32 connector_type;
	u8 ext_edid[128];
};

struct via_dp_encoder_private_info {
	bool link_training_done;
};

struct via_dp_connector_private_info {
	u32 physical_width;
	u32 physical_height;
};

struct via_dvi_connector_private_info {
	u32 physical_width;
	u32 physical_height;
	u32 connector_type;
	bool read_edid;
	u8 std_edid[128];
	u8 ext_edid[128];
};

struct via_tv_feature
{
	u32 default_brightness;
	u32 current_brightness;
	u32 brightness_level;

	u32 default_contrast;
	u32 current_contrast;
	u32 contrast_level;

	u32 default_saturation;
	u32 current_saturation;
	u32 saturation_level;

	u32 default_hue;
	u32 current_hue;
	u32 hue_level;

	/* Scale Level (only useful for integrated TV) */
	/* Horizontal */
	u32 default_hor_scale;
	u32 current_hor_scale;
	u32 hor_scale_interval;
	/* Vertical */
	u32 default_ver_scale;
	u32 current_ver_scale;
	u32 ver_scale_interval;

	u32 default_position_h;
	u32 current_position_h;
	u32 position_h_level;
	u32 default_position_v;
	u32 current_position_v;
	u32 position_v_level;

	u32 default_adaptive_deflicker;
	u32 current_adaptive_deflicker;
	u32 adaptive_deflicker_level;
	u32 adaptive_defliker_on;

	u32 default_deflicker_filter;
	u32 current_deflicker_filter;
	u32 deflicker_filter_level;
	u32 deflicker_filter_on;
};

struct via_tv_connector_private_info
{
	bool auto_detect;
	u32 tv_supported_caps;
	struct via_tv_feature via_tv_feature;
};

struct via_dot_clock {
	int dot_clock;
	u32 pll3;
	u32 pll3_409;
};

#define RATIO_4_3	1
#define RATIO_5_4	2
#define RATIO_16_10	3
#define RATIO_16_9	4


#define INTERLACE	1
#define PROGRESSIVE	0

#define DISP_DI_NONE	0x0000
#define DISP_DI_DVP0	BIT0
#define DISP_DI_DVP1	BIT1
#define DISP_DI_DFPL	BIT2
#define DISP_DI_DFPH	BIT3
#define DISP_DI_DFP	BIT4
#define DISP_DI_DAC	BIT5
#define DISP_DI_ALL	(DISP_DI_DVP0 | DISP_DI_DVP1 | DISP_DI_DFPL |  \
		DISP_DI_DFPH | DISP_DI_DFP | DISP_DI_DAC)
/* read */
#define VGA_MISC_OUT_R		0x3CC
/* write */
#define VGA_MISC_OUT_W		0x3C2

extern unsigned char *mmio_map_base;
extern unsigned char *mmio_mb1;

#define MON_NAME_MAX_LEN    32
/* MISC */
#define CMDISP_ARRAYSIZE(x)   (sizeof(x) / sizeof(*(x)))
#define HIGH_BYTE_OF_WORD(x)    (u8)((x) >> 8)
#define LOW_BYTE_OF_WORD(x)     (u8)((x) & 0x00FF)
#define CMDISP_ALIGN_TO(val, al) (((val) + ((al) - 1)) & ~((al) - 1))

/*temply use globle variable mmio_map_base, we should refine it laterly*/
#define MMIO_WR8(address, data)	\
do {		\
	*((__volatile__ u8*)((address))) = (data); \
} while (0)
#define MMIO_WR16(address, data)		\
do {		\
	*((__volatile__ u16*)((address))) = (data); \
} while (0)
#define MMIO_WR32(address, data)		\
do {		\
	*((__volatile__ u32*)((address))) = (data); \
} while (0)
#define MMIO_WRBITS8(address, data, mask)	\
do {		\
	*((__volatile__ u8*)((address))) = ((data) & (mask)); \
} while (0)
#define MMIO_WRBITS16(address, data, mask)	\
do {		\
	*((__volatile__ u16*)((address))) = ((data) & (mask)); \
} while (0)
#define MMIO_WRBITS32(address, data, mask)	\
do {		\
	*((__volatile__ u32*)((address))) = ((data) & (mask)); \
} while (0)
#define MMIO_RD8(address)	(*((__volatile__ u8*)(address)))
#define MMIO_RD16(address)	(*((__volatile__ u16*)(address)))
#define MMIO_RD32(address)	(*((__volatile__ u32*)(address)))
#define STANDVGA_R8(address)	MMIO_RD8(mmio_map_base + address)
#define STANDVGA_W8(address, data)	MMIO_WR8(mmio_map_base + address, data)
#define REG_R32(address)		MMIO_RD32(mmio_map_base + address)
#define REG_W32(address, data)	MMIO_WR32(mmio_map_base + address, data)
#define MMIO_WR(addr, data) (*(volatile unsigned int *)(mmio_mb1 + (addr)) = (data))
#define MMIO_RD(addr) (*(volatile unsigned int *)(mmio_mb1 + (addr)))
#define MMIO_WR_MASK(addr, data, mask) \
do {		\
	*(volatile unsigned int *)(mmio_mb1 + (addr)) = \
		(data & mask) | (MMIO_RD(addr) & (~mask)); \
} while (0)

extern u8   via_chrome9_read_vga_io(u16 io_name);
extern u32 via_chrome9_write_vga_io(u16 io_name, u8 data);
extern u32 via_chrome9_write_vga_io_bits(u16 io_name, u8 data, u8 bits_mask);
extern u32 via_chrome9_write_vga_io_multi_bits(
		struct via_chrome9_io_reg reg_table[], u32 item_num);
extern void via_chrome9_load_regs(u32 reg_value, u32 reg_amount,
		struct via_chrome9_io_bit *p_regbit);
extern void via_chrome9_helper_set_mode(struct drm_encoder  *encoder);
#endif
