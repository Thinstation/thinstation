/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

 /*
 * EDID info by :
 *    http://en.wikipedia.org/wiki/Extended_display_identification_data
 */

#include "via_chrome9_drv.h"
#include "drm_crtc.h"
#include "via_chrome9_mode.h"
#include "via_chrome9_hdac_renew.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"

extern struct via_cea_timing_info_rec via_cea_timing_table[];
extern struct display_timing_table via_lcd_modes[];

extern struct edid * via_chrome9_connector_get_edid(
	struct drm_connector *connector, unsigned int connector_id);
extern bool  via_chrome9_force_hdmi_to_dvi_mode(u8 is_dvi_mode_on);
extern PVOID pcbe;

static struct drm_display_mode via_lcd_video_modes[] = {
	{ DRM_MODE("480x640", DRM_MODE_TYPE_DRIVER,
		DCLK_22_000M, 480, 504,
		512, 520, 0, 640, 644, 646, 648, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("640x480", DRM_MODE_TYPE_DRIVER,
		DCLK_25_175M, 640, 656,
		752, 800, 0, 480, 490, 492, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("800x480", DRM_MODE_TYPE_DRIVER,
		DCLK_29_581M, 800, 824,
		896, 992, 0, 480, 483, 490, 500, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("800x600", DRM_MODE_TYPE_DRIVER,
		DCLK_40_000M, 800, 840,
		968, 1056, 0, 600, 601, 605, 628, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("1024x600", DRM_MODE_TYPE_DRIVER,
		DCLK_48_875M, 1024, 1064,
		1168, 1312, 0, 600, 601, 604, 622, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("1024x768", DRM_MODE_TYPE_DRIVER,
		DCLK_56_250M, 1024, 1072,
		1104, 1184, 0, 768, 771, 775, 790, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("1280x768", DRM_MODE_TYPE_DRIVER,
		DCLK_80_136M, 1280, 1344,
		1480, 1680, 0, 768, 769, 772, 795, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("1280x800", DRM_MODE_TYPE_DRIVER,
		DCLK_72_000M, 1280, 1328,
		1360, 1440, 0, 800, 803, 809, 823, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("1280x1024", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 1280, 1328,
		1440, 1688, 0, 1024, 1025, 1028, 1066, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("1366x768", DRM_MODE_TYPE_DRIVER,
		DCLK_85_860M, 1368, 1440,
		1584, 1800, 0, 768, 769, 772, 795, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_PVSYNC)},
#if 0
	/**
	 * 1366x768 timing supported by DMTv1r12.pdf .
	 * Prepare for 1366x768 IGA2 LCD complete support .
	 */
	{ DRM_MODE("1366x768", DRM_MODE_TYPE_DRIVER, DCLK_85_860M, 1366, 1436,
		1579, 1792, 0, 768, 771, 774, 798, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC)},
#endif
	{ DRM_MODE("1360x768", DRM_MODE_TYPE_DRIVER,
		DCLK_85_500M, 1360, 1424,
		1436, 1792, 0, 768, 771, 777, 795, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC)},
	{ DRM_MODE("1400x1050", DRM_MODE_TYPE_DRIVER,
		DCLK_101_000M, 1400, 1448,
		1480, 1560, 0, 1050, 1053, 1057, 1080, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("1440x900", DRM_MODE_TYPE_DRIVER,
		DCLK_88_750M, 1440, 1495,
		1600, 1760, 0, 900, 901, 903, 912, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("1600x1200", DRM_MODE_TYPE_DRIVER,
		DCLK_130_250M, 1600, 1648,
		1680, 1760, 0, 1200, 1203, 1207, 1235, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC)},
	{ DRM_MODE("1920x1080", DRM_MODE_TYPE_DRIVER,
		DCLK_150_340M, 1920, 1951,
		1999, 2120, 0, 1080, 1082, 1088, 1120, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC)}
};

#define VIA_LCD_VIDEO_MODES_NUM	15

static struct drm_display_mode via_cea_video_modes[] = {
	{ DRM_MODE("640x480", DRM_MODE_TYPE_DRIVER,
		DCLK_25_200M, 640, 656,
		752, 800, 1, 480,  490,  492,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 720, 736,
		798, 858, 2, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 720, 736,
		798, 858, 3, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1280x720P", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1280, 1390,
		1430, 1650, 4, 720,  725,  730,  750, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("1920x1080I", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1920, 2008,
		2052, 2200, 5, 1080, 1084, 1094, 1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x480I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1478,
		1602, 1716, 6, 480, 488, 494, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x480I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1478,
		1602, 1716, 7, 480, 488, 494, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x240P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1478,
		1602, 1716, 8, 240, 244, 247, 262, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x240P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1478,
		1602, 1716, 9, 240, 244, 247, 262, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x480I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2956,
		3204, 3432, 10, 480, 488, 494, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("2880x480I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2956,
		3204, 3432, 11, 480, 488, 494, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("2880x240P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2956,
		3204, 3432, 12, 240, 244, 247, 262, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x240P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2956,
		3204, 3432, 13, 240, 244, 247, 262, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1440x480P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1472,
		1596, 1716, 14, 480, 489, 495, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1440x480P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1472,
		1596, 1716, 15, 480, 489, 495, 525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1920x1080P", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1920, 2008,
		2052, 2200, 16, 1080, 1084, 1089, 1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("720x576P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 720, 732,
		796, 864, 17, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x576P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 720, 732,
		796, 864, 18, 576,  581,  586,  625, 0,
		   DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1280x720P", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1280, 1720,
		1760, 1980, 19, 720,  725,  730,  750, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("1920x1080I", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1920, 2448,
		2492, 2640, 20, 1080,  1084,  1094,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x576I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1464,
		1590, 1728, 21, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x576I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1464,
		1590, 1728, 22, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x288P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1464,
		1590, 1728, 23, 288,  290,  293,  312, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x288P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_27_000M, 1440, 1464,
		1590, 1728, 24, 288,  290,  293,  312, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x576I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2928,
		3180, 3456, 25, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("2880x576I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2928,
		3180, 3456, 26, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("2880x288P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2928,
		3180, 3456, 27, 288,  290,  293,  312, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x288P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 2880, 2928,
		3180, 3456, 28, 288,  290,  293,  312, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1440x576P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1464,
		1592, 1728, 29, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1440x576P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1464,
		1592, 1728, 30, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1920x1080P", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1920, 2448,
		2492, 2640, 31, 1080,  1084,  1089,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("1920x1080P", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1920, 2558,
		2602, 2750, 32, 1080,  1084,  1089,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("1920x1080P", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1920, 2448,
		2492, 2640, 33, 1080,  1084,  1089,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("1920x1080P", DRM_MODE_TYPE_DRIVER,
		DCLK_74_250M, 1920, 2008,
		2052, 2200, 34, 1080,  1084,  1089,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("2880x480P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 2880, 2944,
		3192, 3432, 35, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x480P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 2880, 2944,
		3192, 3432, 36, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x576P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 2880, 2928,
		3184, 3456, 37, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("2880x576P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 2880, 2928,
		3184, 3456, 38, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("1920x1080I", DRM_MODE_TYPE_DRIVER,
		DCLK_72_000M, 1920, 1952,
		2120, 2304, 39, 1080,  1126,  1136,  1250, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("1920x1080I", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1920, 2448,
		2492, 2640, 40, 1080,  1084,  1094,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("1280x720P", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1280, 1720,
		1760, 1980, 41, 720,  725,  730,  750, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("720x576P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 720, 732,
		796, 864, 42, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x576P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 720, 732,
		796, 864, 43, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x576I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1464,
		1590, 1728, 44, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x576I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1464,
		1590, 1728, 45, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("1920x1080I", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1920, 2008,
		2052, 2200, 46, 1080,  1084,  1094,  1125, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("1280x720P", DRM_MODE_TYPE_DRIVER,
		DCLK_148_500M, 1280, 1390,
		1430, 1650, 47, 720,  725,  730,  750, 0,
		DRM_MODE_FLAG_PHSYNC | DRM_MODE_FLAG_PVSYNC) },
	{ DRM_MODE("720x480P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 720, 736,
		798, 858, 48, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 720, 736,
		798, 858, 49, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1478,
		1602, 1716, 50, 480,  488,  494,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x480I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_54_000M, 1440, 1478,
		1602, 1716, 51, 480,  488,  494,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x576P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 720, 732,
		796, 864, 52, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x576P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 720, 732,
		796, 864, 53, 576,  581,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x576I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 1440, 1464,
		1590, 1728, 54, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x576I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 1440, 1464,
		1590, 1728, 55, 576,  580,  586,  625, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x480P_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 720, 736,
		798, 858, 56, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480P_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 720, 736,
		798, 858, 57, 480,  489,  495,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC) },
	{ DRM_MODE("720x480I_4_3", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 1440, 1478,
		1602, 1716, 58, 480,  488,  494,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) },
	{ DRM_MODE("720x480I_16_9", DRM_MODE_TYPE_DRIVER,
		DCLK_108_000M, 1440, 1478,
		1602, 1716, 59, 480,  488,  494,  525, 0,
		DRM_MODE_FLAG_NHSYNC | DRM_MODE_FLAG_NVSYNC |
		DRM_MODE_FLAG_INTERLACE) }
};

#define VIA_CEA_VIDEO_MODES_NUM	59

const int via_chrome9_connector_convert[] = {
	DRM_MODE_CONNECTOR_Unknown,
	/* VIA_CHROME9_CONNECTOR_CRT_INDEX */
	DRM_MODE_CONNECTOR_VGA,
	/* VIA_CHROME9_CONNECTOR_LCD_INDEX */
	DRM_MODE_CONNECTOR_LVDS,
	/* VIA_CHROME9_CONNECTOR_DVI_D_INDEX */
	DRM_MODE_CONNECTOR_DVID,
	/* VIA_CHROME9_CONNECTOR_DP_1_INDEX */
	DRM_MODE_CONNECTOR_DisplayPort,
	/* VIA_CHROME9_CONNECTOR_DP_2_INDEX */
	DRM_MODE_CONNECTOR_DisplayPort,
	/* VIA_CHROME9_CONNECTOR_TV_INDEX */
	DRM_MODE_CONNECTOR_SVIDEO,
	/* VIA_CHROME9_CONNECTOR_HDMI_INDEX */
	DRM_MODE_CONNECTOR_HDMIA,
	/* VIA_CHROME9_CONNECTOR_LCD_2_INDEX */
	DRM_MODE_CONNECTOR_LVDS,
	/* VIA_CHROME9_CONNECTOR_DVI_D_2_INDEX */
	DRM_MODE_CONNECTOR_DVID,
	/* VIA_CHROME9_CONNECTOR_CRT_2_INDEX */
	DRM_MODE_CONNECTOR_VGA,
	/* VIA_CHROME9_CONNECTOR_HDMI_2_INDEX */
	DRM_MODE_CONNECTOR_HDMIA,
	DRM_MODE_CONNECTOR_Unknown,
};

void via_chrome9_helper_set_mode(struct drm_encoder  *encoder)
{
	struct drm_crtc *crtc = encoder->crtc;

	KMS_DEBUG("\n");
	if (crtc && crtc->enabled) {
		drm_crtc_helper_set_mode(crtc, &crtc->mode,
			crtc->x, crtc->y, crtc->fb);
	}
}

static void via_chrome9_property_change_mode(struct drm_encoder  *encoder)
{
	KMS_DEBUG("\n");
	via_chrome9_helper_set_mode(encoder);
}


void via_chrome9_get_monitor_physical_size(struct drm_connector *connector,
		u32 *width, u32 *height)
{
	struct list_head *mode_list =  &connector->probed_modes;
	struct drm_display_mode *mode, *t;

	*width = 0;
	*height = 0;
	list_for_each_entry_safe(mode, t, mode_list, head) {
		if (mode->hdisplay > *width)
			*width = mode->hdisplay;

		if (mode->vdisplay > *height)
			*height = mode->vdisplay;
	}

	if (0 == *width || 0 == *height) {
		*width = 1024;
		*height = 768;
	}
}

static void via_chrome9_connector_destory(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);

	kfree(via_conn->edid);
	via_conn->edid = NULL;
	kfree(via_conn->connector_private);
	via_conn->connector_private = NULL;
	kfree(via_conn->options);
	via_conn->options = NULL;
	kfree(via_conn->connector_info);
	via_conn->connector_info = NULL;

	drm_sysfs_connector_remove(connector);
	drm_connector_cleanup(connector);
	kfree(connector);
	KMS_DEBUG("via_chrome9_connector_destory %s\n",
		drm_get_connector_name(connector));
}

struct drm_encoder *via_chrome9_best_single_encoder(
		struct drm_connector *connector)
{
	int enc_id = connector->encoder_ids[0];
	struct drm_mode_object *obj;
	struct drm_encoder *encoder;
	/* pick the encoder ids */
	if (enc_id) {
		obj = drm_mode_object_find(connector->dev, enc_id,
			DRM_MODE_OBJECT_ENCODER);
		if (!obj) {
			KMS_DEBUG("can not find the encoder\n");
			return NULL;
		}
		encoder = obj_to_encoder(obj);
			return encoder;
	}
	KMS_DEBUG("there is no encoder for this connector\n");
	return NULL;
}

int via_chrome9_ddc_get_modes(struct via_chrome9_connector *via_conn)
{
	int ret = 0;
	if (!via_conn->edid) {
		via_conn->edid = via_chrome9_connector_get_edid(
				&via_conn->base,
				via_conn->connector_id);
	}

	if (via_conn->edid) {

		drm_mode_connector_update_edid_property(
				&via_conn->base,
				via_conn->edid);
		ret = drm_add_edid_modes(&via_conn->base,
			via_conn->edid);
		return ret;
	}

	return ret;
}

static enum drm_connector_status via_chrome9_connector_detect(
		struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn = 
			to_via_chrome9_connector(connector);
	enum drm_connector_status ret = connector_status_disconnected;
	bool result = false;   
	unsigned int device = 0;
	struct drm_device *dev = connector->dev;

	device = via_chrome9_connector_to_cbios_device(via_conn->connector_id);
	
	result = via_chrome9_cbios_help_device_detect(dev, device);
	if (true == result) 
		ret = connector_status_connected;
	return ret;
}

static enum drm_mode_status via_chrome9_connector_mode_valid(
		struct drm_connector *connector, struct drm_display_mode *mode)
{
	enum drm_mode_status status = MODE_BAD;
	struct via_chrome9_connector *via_conn = 
			to_via_chrome9_connector(connector);
	unsigned int device = 0;

	device = via_chrome9_connector_to_cbios_device(via_conn->connector_id);
	status = via_chrome9_mode_valid_helper(connector, mode, device);
	return status;
}

static int via_chrome9_device_set_property(struct drm_connector *connector,
				    struct drm_property *property, uint64_t value)
{
	struct via_chrome9_connector *via_conn = 
			to_via_chrome9_connector(connector);
	unsigned int device = 0;
	struct drm_device *dev = connector->dev;
	struct drm_via_chrome9_private *p_priv =
			(struct drm_via_chrome9_private *)dev->dev_private;
	device = via_chrome9_connector_to_cbios_device(
			via_conn->connector_id);

	KMS_DEBUG("enter device 0x%x, property: %s\n", device, property->name);

	if (device == ACTIVE_TYPE_HDMI) {
		struct via_hdmi_options *via_hdmi_option =
				(struct via_hdmi_options *)via_conn->options;
		struct drm_connector_helper_funcs *via_hdmi_helper_funcs =
				(struct drm_connector_helper_funcs *)connector->helper_private;
		struct drm_encoder  *encoder =
				via_hdmi_helper_funcs->best_encoder(connector);

		if (property == p_priv->mode_info.left_border_property) {
			if (!encoder) {
				KMS_DEBUG("encoder is NULL\n");
				return 0;
			}

			if (value < 0 || value > MAX_SUPPORTED_HOR_BORDER)
				return 0;

			if(via_hdmi_option->left_border != value) {
				via_hdmi_option->left_border = value;
				KMS_DEBUG("hdmi left border : %lld !\n", value);
				via_chrome9_property_change_mode(encoder);
			}
		}

		if (property == p_priv->mode_info.right_border_property) {
			if (!encoder) {
				KMS_DEBUG("encoder is NULL\n");
				return 0;
			}

			if (value < 0 || value > MAX_SUPPORTED_HOR_BORDER)
				return 0;

			if (via_hdmi_option->right_border != value) {
				via_hdmi_option->right_border = value;
				KMS_DEBUG("hdmi right border : %lld !\n", value);
				via_chrome9_property_change_mode(encoder);
			}
		}

		if (property == p_priv->mode_info.top_border_property) {
			if (!encoder) {
				KMS_DEBUG("encoder is NULL\n");
				return 0;
			}

			if (value < 0 || value > MAX_SUPPORTED_VER_BORDER)
				return 0;

			if (via_hdmi_option->top_border != value) {
				via_hdmi_option->top_border = value;
				KMS_DEBUG("hdmi top border : %lld!\n",value);
				via_chrome9_property_change_mode(encoder);
			}
		}

		if (property == p_priv->mode_info.bottom_border_property) {
			if (!encoder) {
				KMS_DEBUG("encoder is NULL\n");
				return 0;
			}

			if (value < 0 || value > MAX_SUPPORTED_VER_BORDER)
				return 0;

			if (via_hdmi_option->bottom_border != value) {
				via_hdmi_option->bottom_border = value;
				KMS_DEBUG("hdmi bottom border: %lld !\n",value);
				via_chrome9_property_change_mode(encoder);
			}
		}
	}

	return 0;
}

void via_chrome9_set_vga_xorg_options(void *options, int size,
		struct drm_connector *connector)
{

}

int via_vga_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_chrome9_connector =
		to_via_chrome9_connector(connector);
	int ret = 0;
	struct via_vga_options *via_vga_options =
		(struct via_vga_options *)via_chrome9_connector->options;
	KMS_DEBUG("\n");
	if (!via_vga_options->no_ddc_value) {
		ret = via_chrome9_ddc_get_modes(via_chrome9_connector);
	} else {
		kfree(via_chrome9_connector->edid);
		via_chrome9_connector->edid = NULL;
		connector->display_info.raw_edid = NULL;
	}
	return ret;
}

static int via_chrome9_vga_get_modes(struct drm_connector *connector)
{
	return via_vga_get_modes(connector);
}

static struct drm_connector_funcs via_chrome9_vga_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_vga_connector_helper_funcs = {
	.get_modes = via_chrome9_vga_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

void via_chrome9_set_vga_2_xorg_options(void *options, int size,
		struct drm_connector *connector)
{
}

int via_vga_2_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_chrome9_connector =
		to_via_chrome9_connector(connector);
	int ret = 0;
	struct via_vga_options *via_vga_2_options =
		(struct via_vga_options *)via_chrome9_connector->options;
	KMS_DEBUG("\n");
	if (!via_vga_2_options->no_ddc_value) {
		ret = via_chrome9_ddc_get_modes(via_chrome9_connector);
	} else {
		kfree(via_chrome9_connector->edid);
		via_chrome9_connector->edid = NULL;
		connector->display_info.raw_edid = NULL;
	}
	return ret;
}

static int via_chrome9_vga_2_get_modes(struct drm_connector *connector)
{
	return via_vga_2_get_modes(connector);
}

static struct drm_connector_funcs via_chrome9_vga_2_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_vga_2_connector_helper_funcs = {
	.get_modes = via_chrome9_vga_2_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

/* Get a build-in mode record according to panel id. */
int via_chrome9_get_panel_mode_record(struct drm_connector *connector,
		u32 panel_index)
{
	struct drm_device *dev = connector->dev;
	struct drm_display_mode *new_mode = NULL;
	int ret = 0;
	int i = 0;

	for (i = 0; i < VIA_LCD_VIDEO_MODES_NUM; i++) {
		if (panel_index == via_lcd_modes[i].mode_index) {
			new_mode = drm_mode_create(dev);
			if (new_mode) {
				memcpy(new_mode->name,
					via_lcd_video_modes[i].name,
					DRM_DISPLAY_MODE_LEN);
				/* When we using panel 1366x768,
				want to light mode 1366x768
				but in our mode list we just have 1368x768,
				so change the name to 1366x768 */

				if (1368 == new_mode->hdisplay &&
					768 == new_mode->vdisplay)
					memcpy(new_mode->name, "1366x768",
						DRM_DISPLAY_MODE_LEN);

				new_mode->type = via_lcd_video_modes[i].type;
				new_mode->clock = via_lcd_video_modes[i].clock;
				new_mode->hdisplay =
					via_lcd_video_modes[i].hdisplay;
				new_mode->hsync_start =
					via_lcd_video_modes[i].hsync_start;
				new_mode->hsync_end =
					via_lcd_video_modes[i].hsync_end;
				new_mode->htotal =
					via_lcd_video_modes[i].htotal;
				new_mode->vdisplay =
					via_lcd_video_modes[i].vdisplay;
				new_mode->vsync_start =
					via_lcd_video_modes[i].vsync_start;
				new_mode->vsync_end =
					via_lcd_video_modes[i].vsync_end;
				new_mode->vtotal =
					via_lcd_video_modes[i].vtotal;
				new_mode->vscan = via_lcd_video_modes[i].vscan;
				new_mode->flags = via_lcd_video_modes[i].flags;
				drm_mode_probed_add(connector, new_mode);
				ret++;
			}
		}
	}
	return ret;
}

void via_chrome9_set_lcd_xorg_options(void *options, int size,
		struct drm_connector *connector)
{
}

int via_lcd_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_chrome9_connector =
		to_via_chrome9_connector(connector);
	struct via_lcd_options *via_lcd_options =
		(struct via_lcd_options *)via_chrome9_connector->options;
	int ret = 0;

	if (via_lcd_options->panel_index) {
		ret = via_chrome9_get_panel_mode_record(connector,
			via_lcd_options->panel_index);
	} else {
		ret = via_chrome9_ddc_get_modes(via_chrome9_connector);
		via_chrome9_get_monitor_physical_size(connector,
			&via_lcd_options->physical_width,
			&via_lcd_options->physical_height);
	}
	return ret;
}

int via_chrome9_lcd_get_modes(struct drm_connector *connector)
{
	KMS_DEBUG("\n");
	return via_lcd_get_modes(connector);
}

static struct drm_connector_funcs via_chrome9_lcd_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_lcd_connector_helper_funcs = {
	.get_modes = via_chrome9_lcd_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

int via_chrome9_lcd_2_get_modes(struct drm_connector *connector)
{
	KMS_DEBUG("\n");
	return via_lcd_get_modes(connector);
}

static struct drm_connector_funcs via_chrome9_lcd_2_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_lcd_2_connector_helper_funcs = {
	.get_modes = via_chrome9_lcd_2_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

void via_chrome9_set_hd_audio_connect_status(bool enable)
{
	u32 present_bit, un_solicited;
	u32 pin_sense_response = 0x80000000;
	u32 pin_sense_response_mask = 0x80000000;
	if ((MMIO_RD(0xC468) & 0x00f00000) == 0x00100000) {
		pin_sense_response = 0x80778866;
		pin_sense_response_mask = 0xfffffffe;
	}
	present_bit = enable ? pin_sense_response : 0;
	if((MMIO_RD(0xC464) & pin_sense_response_mask) == present_bit)
		return;
	/* Change PresentBit */
	MMIO_WR(0xC464, (MMIO_RD(0xC464) & ~pin_sense_response_mask)|present_bit);
	MMIO_WR(0xC4D0, (MMIO_RD(0xC4D0) | 0x20));
	MMIO_WR(0xC4D0, (MMIO_RD(0xC4D0) & ~0x00000020));
	MMIO_WR(0xC4D4, (MMIO_RD(0xC4D4) & 0x00ffffff) | 0x06000000);
	if((MMIO_RD(0xC4D8) & pin_sense_response_mask) == present_bit) {
		/*enable Unsolicited response, set tag as 0x3, which is the pin value */
		MMIO_WR(0xC460,(MMIO_RD(0xC460) & 0xC3000000) | 0xC3000000 );
		MMIO_WR(0xC4D0,(MMIO_RD(0xC4D0) & 0xfffffff7) | 0x00000008 );
		/* change PresentBit success, Send Unsolicited response */
		MMIO_WR(0xC4D4,(MMIO_RD(0xC4D4) & 0x00ffffff) | 0x04000000 );
		un_solicited = MMIO_RD(0xC4D8);
		if(un_solicited & 0x80) {
			/* Unsolicited response enabled */
			MMIO_WR(0xC420,((un_solicited&0x3f) << 26) | enable<<1 | enable);
			MMIO_WR(0xC418, MMIO_RD(0xC418) | 0x8);
		}
	}
	MMIO_WR(0xC4D4,(MMIO_RD(0xC4D4) & 0x00ffffff));
}

void via_chrome9_send_unsolicited_response(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_chrome9_connector =
		to_via_chrome9_connector(connector);
	u32 mm_c730;
	
	if (VIA_CHROME9_DEVICE_CONNECTOR_DP_1 == 
			via_chrome9_connector->connector_id ||
		VIA_CHROME9_DEVICE_CONNECTOR_HDMI == 
			via_chrome9_connector->connector_id) {
		mm_c730 = MMIO_RD(0xc730);
		switch (mm_c730 & 0xC0000000) {
		case VIA_IRQ_DP_HOT_IRQ:
			KMS_DEBUG("DP1(HDMI)_HOT_IRQ_STATUS!\n");
			break;
		case VIA_IRQ_DP_HOT_UNPLUG:
			KMS_DEBUG("DP1(HDMI)_HOT_UNPLUG_STATUS!\n");
			via_chrome9_set_hd_audio_connect_status(false);
			break;
		case VIA_IRQ_DP_HOT_PLUG:
			KMS_DEBUG("DP1(HDMI)_HOT_PLUG_STATUS!\n");
			via_chrome9_set_hd_audio_connect_status(true);
			break;
		case VIA_IRQ_DP_NO_INT:
			KMS_DEBUG("DP1(HDMI)_NO_STATUS!\n");
			break;
		}
	}
}

void via_chrome9_set_hdmi_xorg_options(void *options, int size,
		struct drm_connector *connector)
{
	struct via_chrome9_connector *via_chrome9_connector =
		to_via_chrome9_connector(connector);
	struct via_hdmi_options *via_hdmi_options =
		(struct via_hdmi_options *)via_chrome9_connector->options;
	struct drm_connector_helper_funcs *connector_func =
		connector->helper_private;
	struct drm_encoder *encoder = connector_func->best_encoder(connector);
	struct drm_device *dev = connector->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	bool is_need_set_mode = false;

	/* bak old hdmi borders options. */
	u32 left_border_bak = via_hdmi_options->left_border;
	u32 right_border_bak = via_hdmi_options->right_border;
	u32 top_border_bak = via_hdmi_options->top_border;
	u32 bottom_border_bak = via_hdmi_options->bottom_border;

	u8 is_hdmi_audio_disable_bak = via_hdmi_options->is_hdmi_audio_disable;

	copy_from_user(via_hdmi_options, options, size);
	KMS_DEBUG("\n");

	if (NULL == encoder)
		return;
	/**
	 * set hdmi overscan adjust borders property init values.
	 * only VX900 support this option... need iga downscaling
	 */
	if ((p_priv->chip_caps & CAPS_IGA2_DOWNSCALING) ||
		(p_priv->chip_caps & CAPS_IGA1_DOWNSCALING)) {
		KMS_DEBUG(
			"via_hdmi_options->borders = %d, %d, %d, %d\n",
			via_hdmi_options->left_border,
			via_hdmi_options->right_border,
			via_hdmi_options->top_border,
			via_hdmi_options->bottom_border);

		/* step1: refresh properties value. */
		drm_connector_property_set_value(
			&via_chrome9_connector->base,
			p_priv->mode_info.left_border_property,
			via_hdmi_options->left_border);
		drm_connector_property_set_value(
			&via_chrome9_connector->base,
			p_priv->mode_info.right_border_property,
			via_hdmi_options->right_border);
		drm_connector_property_set_value(
			&via_chrome9_connector->base,
			p_priv->mode_info.top_border_property,
			via_hdmi_options->top_border);
		drm_connector_property_set_value(
			&via_chrome9_connector->base,
			p_priv->mode_info.bottom_border_property,
			via_hdmi_options->bottom_border);

		/* step2: re-set mode. */
		if( ( left_border_bak != via_hdmi_options->left_border ) || 
		    ( right_border_bak != via_hdmi_options->right_border ) ||
		    ( top_border_bak != via_hdmi_options->top_border ) ||
		    ( bottom_border_bak != via_hdmi_options->bottom_border ) ) {
			KMS_DEBUG("borders option changed!\n");
			is_need_set_mode = true;
		}
	}
	
	if (is_hdmi_audio_disable_bak != via_hdmi_options->is_hdmi_audio_disable){
		KMS_DEBUG( "hdmi audio on/off changed! old = %d, now = %d\n",
		is_hdmi_audio_disable_bak, via_hdmi_options->is_hdmi_audio_disable);
		is_need_set_mode = true;
		via_chrome9_force_hdmi_to_dvi_mode(
			via_hdmi_options->is_hdmi_audio_disable);
	}

	if ( is_need_set_mode ) {
		KMS_DEBUG("do set mode!\n");
		via_chrome9_helper_set_mode(encoder);
	}
}
void via_chrome9_set_hdmi_2_xorg_options(void *options, int size,
		struct drm_connector *connector)
{

}

void via_chrome9_set_tv_xorg_options(void *options, int size,
		struct drm_connector *connector)
{

}

/**
 * via_chrome9_mode_equal - test modes for equality
 * @mode1: first mode
 * @mode2: second mode
 *
 * proting from drm_mode_equal
 * do not care hskew, TODO if any trouble
 *
 * Check to see if @mode1 and @mode2 are equivalent.
 *
 * RETURNS:
 * True if the modes are equal, false otherwise.
 */
bool via_chrome9_mode_equal(struct drm_display_mode *mode1,
		struct drm_display_mode *mode2)
{
	if (mode1->clock && mode2->clock &&
	     mode1->hdisplay == mode2->hdisplay &&
	     mode1->hsync_start == mode2->hsync_start &&
	     mode1->hsync_end == mode2->hsync_end &&
	     mode1->htotal == mode2->htotal &&
	     mode1->vdisplay == mode2->vdisplay &&
	     mode1->vsync_start == mode2->vsync_start &&
	     mode1->vsync_end == mode2->vsync_end &&
	     mode1->vtotal == mode2->vtotal &&
	     mode1->vscan == mode2->vscan &&
	     mode1->flags == mode2->flags)
		return true;

	return false;
}

void via_chrome9_set_cea_modes_id(struct drm_device *dev,
		struct list_head *mode_list)
{
	int i;
	struct drm_display_mode *mode, *t;
	list_for_each_entry_safe(mode, t, mode_list, head) {
		for (i = 0; i < VIA_CEA_VIDEO_MODES_NUM; i++) {
			if (via_chrome9_mode_equal(mode,
				&via_cea_video_modes[i])) {
				mode->hskew = via_cea_video_modes[i].hskew;
				break;
			}
		}
	}
}

static int via_chrome9_add_cea_mode_line(struct drm_connector *connector,
		u8 *ext_edid)
{
	int i = 0;
	int mode_count = 0;
	u8 tmp = 0;
	u8 video_block_index = 0;
	u32 descriptor_num = 0;
	u8 hdmi_mode_index;
	struct via_chrome9_connector *via_con =
		to_via_chrome9_connector(connector);
	struct via_hdmi_options *via_hdmi_options =
		(struct via_hdmi_options *)via_con->options;
	struct drm_device *dev = connector->dev;
	struct drm_display_mode *new_mode = NULL;

	if (!via_hdmi_options->attach_all_modes) {
		video_block_index = 4;
		tmp = ext_edid[4];
		while (((tmp & 0xE0) != 0x40)
			&& (video_block_index < (ext_edid[2]))) {
			tmp &= 0x1F;
			video_block_index += (tmp + 1);
			tmp = ext_edid[video_block_index];
		}
		if ((tmp & 0xE0) == 0x40) {
			descriptor_num = tmp & 0x1F;
			for (i = 0; i < descriptor_num; i++) {
				tmp = ext_edid[video_block_index+1+i];
				hdmi_mode_index = tmp & 0x7F;
				if (via_cea_timing_table[hdmi_mode_index-1].is_built &&
					via_cea_video_modes[hdmi_mode_index-1].name != NULL) {
					new_mode = drm_mode_create(dev);
					if (new_mode) {
						memcpy(new_mode->name, 
							via_cea_video_modes[hdmi_mode_index-1].name, 
							strlen(via_cea_video_modes[hdmi_mode_index-1].name));
						new_mode->status = 
							via_cea_video_modes[hdmi_mode_index-1].status;
						new_mode->type = 
							via_cea_video_modes[hdmi_mode_index-1].type;
						new_mode->clock = 
							via_cea_video_modes[hdmi_mode_index-1].clock;
						new_mode->hdisplay = 
							via_cea_video_modes[hdmi_mode_index-1].hdisplay;
						new_mode->hsync_start = 
							via_cea_video_modes[hdmi_mode_index-1].hsync_start;
						new_mode->hsync_end = 
							via_cea_video_modes[hdmi_mode_index-1].hsync_end;
						new_mode->htotal = 
							via_cea_video_modes[hdmi_mode_index-1].htotal;
						new_mode->hskew = 
							via_cea_video_modes[hdmi_mode_index-1].hskew;
						new_mode->vdisplay = 
							via_cea_video_modes[hdmi_mode_index-1].vdisplay;
						new_mode->vsync_start = 
							via_cea_video_modes[hdmi_mode_index-1].vsync_start;
						new_mode->vsync_end = 
							via_cea_video_modes[hdmi_mode_index-1].vsync_end;
						new_mode->vtotal = 
							via_cea_video_modes[hdmi_mode_index-1].vtotal;
						new_mode->vscan = 
							via_cea_video_modes[hdmi_mode_index-1].vscan;
						new_mode->flags = 
							via_cea_video_modes[hdmi_mode_index-1].flags;
						new_mode->vrefresh = 
							via_cea_video_modes[hdmi_mode_index-1].vrefresh;
						drm_mode_probed_add(connector,new_mode);
						mode_count++;
					}
				}
			}
		}
	}

	if (0 == mode_count) {
		i = 0;
		while (via_cea_video_modes[i].name &&
			via_cea_timing_table[i].is_built) {
			new_mode = drm_mode_create(dev);
			if (new_mode) {
				memcpy(new_mode->name, 
					via_cea_video_modes[i].name, 
					strlen(via_cea_video_modes[i].name));
				new_mode->status = via_cea_video_modes[i].status;
				new_mode->type = via_cea_video_modes[i].type;
				new_mode->clock = via_cea_video_modes[i].clock;
				new_mode->hdisplay = via_cea_video_modes[i].hdisplay;
				new_mode->hsync_start = via_cea_video_modes[i].hsync_start;
				new_mode->hsync_end = via_cea_video_modes[i].hsync_end;
				new_mode->htotal = via_cea_video_modes[i].htotal;
				new_mode->hskew = via_cea_video_modes[i].hskew;
				new_mode->vdisplay = via_cea_video_modes[i].vdisplay;
				new_mode->vsync_start = via_cea_video_modes[i].vsync_start;
				new_mode->vsync_end = via_cea_video_modes[i].vsync_end;
				new_mode->vtotal = via_cea_video_modes[i].vtotal;
				new_mode->vscan = via_cea_video_modes[i].vscan;
				new_mode->flags = via_cea_video_modes[i].flags;
				new_mode->vrefresh = via_cea_video_modes[i].vrefresh;
				drm_mode_probed_add(connector, new_mode);
				mode_count++;
				KMS_DEBUG(
					"Driver add CEA mode ID:%d %dx%d@%d I:%d\n",
					i,
					via_cea_timing_table[i].hor_size,
					via_cea_timing_table[i].ver_size,
					via_cea_timing_table[i].refresh_rate,
					via_cea_timing_table[i].scan_type);
			}
			i++;
		}
	}
	return mode_count;
}

u32 via_chrome9_detect_connect_type(u8 *ext_edid)
{
	u8  vendor_block_index = 0;
	u8  tmp = 0;
	u32 ret = VIA_CHROME9_DEVICE_CONNECTOR_DVI_D;
	if (!(ext_edid[2] == 0 || ext_edid[2] == 4)) {
		vendor_block_index = 4;
		tmp = ext_edid[vendor_block_index];
		while (((tmp & 0xE0) != 0x60) &&
			(vendor_block_index < (ext_edid[2]))) {
			tmp &= 0x1F;
			vendor_block_index += (tmp+1);
			tmp = ext_edid[vendor_block_index];
		}

		if (0x60 == (tmp & 0xE0)) {
			if ((ext_edid[vendor_block_index+1] == 0x03)
			&& (ext_edid[vendor_block_index+2] == 0x0C)
			&& (ext_edid[vendor_block_index+3] == 0x00)) {
				ret =  VIA_CHROME9_DEVICE_CONNECTOR_HDMI;
			} else {
				ret = VIA_CHROME9_DEVICE_CONNECTOR_DVI_D;
			}
		}
	}
	return ret;
}


int via_chrome9_hdmi_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_hdmi_connector_private_info *via_hdmi_con_info =
		(struct via_hdmi_connector_private_info *)
		via_conn->connector_info;

	struct drm_device *dev = connector->dev;
	int ret = 0;

	if(via_conn->edid) {
		kfree((u8 *)via_conn->edid);
		connector->display_info.raw_edid = NULL;
		via_conn->edid = NULL;
	}
    
	via_conn->edid = via_chrome9_connector_get_edid(
			&via_conn->base, via_conn->connector_id);

	if (!via_conn->edid) {
		KMS_DEBUG("get edid fail! \n");
		via_hdmi_con_info->connector_type =
			VIA_CHROME9_DEVICE_CONNECTOR_UNKNOW;
	} else {
		memcpy(via_hdmi_con_info->ext_edid, (u8 *)(via_conn->edid) + 128, 128);

		via_hdmi_con_info->connector_type =
			VIA_CHROME9_DEVICE_CONNECTOR_HDMI;
		ret = connector_status_connected;
	}
    
	if (via_conn->edid) {
		drm_mode_connector_update_edid_property(
			&via_conn->base,
			via_conn->edid);
		ret = drm_add_edid_modes(
			&via_conn->base,
			via_conn->edid);
		/* take use of the member of hskew record the cea mode id temporarily */
		via_chrome9_set_cea_modes_id(dev, &(connector->probed_modes));
		/*
		 * the cea modes interpreted by drm is nor comprehensive, 
		 * here we interprete cea modes by ourself 
		 */
		ret += via_chrome9_add_cea_mode_line(connector, 
				via_hdmi_con_info->ext_edid);
		via_chrome9_get_monitor_physical_size(connector,
			&via_hdmi_con_info->physical_width,
			&via_hdmi_con_info->physical_height);
		
	} else {
		via_hdmi_con_info->physical_width = 4096;
		via_hdmi_con_info->physical_height = 2048;
		ret = via_chrome9_add_cea_mode_line(connector, 
				via_hdmi_con_info->ext_edid);
	}
	KMS_DEBUG("connector name: %s\n",drm_get_connector_name(connector));
	return ret;
}

static struct drm_connector_funcs
	via_chrome9_hdmi_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_hdmi_connector_helper_funcs = {
	.get_modes = via_chrome9_hdmi_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};


int via_chrome9_hdmi_2_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_hdmi_connector_private_info *via_hdmi_2_con_info =
		(struct via_hdmi_connector_private_info *)
		via_conn->connector_info;

	struct drm_device *dev = connector->dev;
	int ret = 0;

	if(via_conn->edid) {
		kfree((u8 *)via_conn->edid);
		connector->display_info.raw_edid = NULL;
		via_conn->edid = NULL;
	}
    
	via_conn->edid = via_chrome9_connector_get_edid(
			&via_conn->base, via_conn->connector_id);
        
	if (!via_conn->edid)  {
		KMS_DEBUG("get edid fail! \n");
		via_hdmi_2_con_info->connector_type =
			VIA_CHROME9_DEVICE_CONNECTOR_UNKNOW;
	} else {
		memcpy(via_hdmi_2_con_info->ext_edid, 
				(u8 *)(via_conn->edid) + 128, 128);
		via_hdmi_2_con_info->connector_type =
			VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2;
		ret = connector_status_connected;
	}
    
	if (via_conn->edid) {
		drm_mode_connector_update_edid_property(
				&via_conn->base, via_conn->edid);
		ret = drm_add_edid_modes(&via_conn->base, via_conn->edid);
		/* take use of the member of hskew record the cea mode id temporarily */
		via_chrome9_set_cea_modes_id(dev, &(connector->probed_modes));        
		/*
		 * the cea modes interpreted by drm is nor comprehensive, 
		 * here we interprete cea modes by ourself 
		 */
		ret += via_chrome9_add_cea_mode_line(connector, 
			via_hdmi_2_con_info->ext_edid);
		via_chrome9_get_monitor_physical_size(connector,
			&via_hdmi_2_con_info->physical_width,
			&via_hdmi_2_con_info->physical_height);
		
	} else {	
		via_hdmi_2_con_info->physical_width = 4096;
		via_hdmi_2_con_info->physical_height = 2048;
		ret = via_chrome9_add_cea_mode_line(connector, 
			via_hdmi_2_con_info->ext_edid);
	}
	KMS_DEBUG("connector name: %s\n",drm_get_connector_name(connector));
	return ret;
}

static struct drm_connector_funcs
	via_chrome9_hdmi_2_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_hdmi_2_connector_helper_funcs = {
	.get_modes = via_chrome9_hdmi_2_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

void via_chrome9_set_dp_xorg_options(
		void *options, int size, struct drm_connector *connector)
{

}

int via_chrome9_dp_1_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_dp_connector_private_info *dp_private_info =
		(struct via_dp_connector_private_info *)
		via_conn->connector_private;
	struct via_dp_options *via_dp_options =
		(struct via_dp_options *)via_conn->options;
	int ret = 0;

	if (via_dp_options->no_ddc_value) {
		dp_private_info->physical_width = 4096;
		dp_private_info->physical_height = 4096;
	} else {
		if (!via_conn->edid) {
			via_conn->edid = via_chrome9_connector_get_edid(
				&via_conn->base, via_conn->connector_id);
		}

		if (via_conn->edid) {
			drm_mode_connector_update_edid_property(
				&via_conn->base, via_conn->edid);
			ret = drm_add_edid_modes(&via_conn->base, via_conn->edid);
		}

		via_chrome9_get_monitor_physical_size(connector,
			&dp_private_info->physical_width,
			&dp_private_info->physical_height);
	}
	return ret;
}

static struct drm_connector_funcs
	via_chrome9_dp_1_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_dp_1_connector_helper_funcs = {
	.get_modes = via_chrome9_dp_1_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

int via_chrome9_dp_2_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_dp_connector_private_info *dp_private_info =
		(struct via_dp_connector_private_info *)
		via_conn->connector_private;
	struct via_dp_options *via_dp_options =
		(struct via_dp_options *)via_conn->options;
	int ret = 0;

	if (via_dp_options->no_ddc_value) {
		dp_private_info->physical_width = 4096;
		dp_private_info->physical_height = 4096;
	} else {
		if (!via_conn->edid) {
			via_conn->edid = via_chrome9_connector_get_edid(
				&via_conn->base,via_conn->connector_id);
		}
		if (via_conn->edid) {
			drm_mode_connector_update_edid_property(
				&via_conn->base, via_conn->edid);
			ret = drm_add_edid_modes(&via_conn->base, via_conn->edid);
		}

		via_chrome9_get_monitor_physical_size(connector,
			&dp_private_info->physical_width,
			&dp_private_info->physical_height);
	}
	return ret;
}

static struct drm_connector_funcs via_chrome9_dp_2_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_dp_2_connector_helper_funcs = {
	.get_modes = via_chrome9_dp_2_get_modes,
	.mode_valid = via_chrome9_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

void via_chrome9_set_dvi_xorg_options(void *options, int size,
		struct drm_connector *connector)
{

}

int via_dvi_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_dvi_connector_private_info *dvi_private_info =
		(struct via_dvi_connector_private_info *)
		via_conn->connector_info;
	struct via_dvi_options *via_dvi_options =
		(struct via_dvi_options *)via_conn->options;
	int ret = 0;

	if (via_dvi_options->no_ddc_value) {
		dvi_private_info->physical_width = 4096;
		dvi_private_info->physical_height = 2048;
	} else {
		ret = via_chrome9_ddc_get_modes(via_conn);
		via_chrome9_get_monitor_physical_size(connector,
			&dvi_private_info->physical_width,
			&dvi_private_info->physical_height);
	}
	return ret;
}

int via_chrome9_dvi_get_modes(struct drm_connector *connector)
{
	return via_dvi_get_modes(connector);
}

static enum drm_mode_status via_chrome9_dvi_connector_mode_valid(
		struct drm_connector *connector, struct drm_display_mode *mode)
{
	enum drm_mode_status status;
	status = via_chrome9_connector_mode_valid(connector, mode);
	/* mode with clock bigger than 165M is not support, so need be filtered. */
	if ((MODE_OK == status) && (mode->clock > 165000))
		status = MODE_CLOCK_HIGH;
	return status;
}

static struct drm_connector_funcs
	via_chrome9_dvi_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs
	via_chrome9_dvi_connector_helper_funcs = {
	.get_modes = via_chrome9_dvi_get_modes,
	.mode_valid = via_chrome9_dvi_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};


void via_chrome9_set_dvi_2_xorg_options(void *options, int size, 
	struct drm_connector *connector)
{

}

int via_dvi_2_get_modes(struct drm_connector *connector)
{
	struct via_chrome9_connector *via_conn =
		to_via_chrome9_connector(connector);
	struct via_dvi_connector_private_info *dvi_private_info =
		(struct via_dvi_connector_private_info *)via_conn->connector_info;
	struct via_dvi_options *via_dvi_options = 
		(struct via_dvi_options *)via_conn->options;
	int ret = 0;

	if (via_dvi_options->no_ddc_value) {
		dvi_private_info->physical_width = 4096;
		dvi_private_info->physical_height = 2048;
	} else {
		ret = via_chrome9_ddc_get_modes(via_conn);
		via_chrome9_get_monitor_physical_size(connector, 
					&dvi_private_info->physical_width,
					&dvi_private_info->physical_height);
	}
	return ret;
}

int via_chrome9_dvi_2_get_modes(struct drm_connector *connector)
{
	return via_dvi_2_get_modes(connector);
}

static struct drm_connector_funcs via_chrome9_dvi_2_connector_funcs = {
	.dpms = drm_helper_connector_dpms,
	.detect = via_chrome9_connector_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = via_chrome9_connector_destory,
	.set_property = via_chrome9_device_set_property,
};

static struct drm_connector_helper_funcs via_chrome9_dvi_2_connector_helper_funcs = {
	.get_modes = via_chrome9_dvi_2_get_modes,
	.mode_valid = via_chrome9_dvi_connector_mode_valid,
	.best_encoder = via_chrome9_best_single_encoder,
};

void via_chrome9_borders_property_attach(
		struct drm_connector *connector,
		struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	KMS_DEBUG("\n");
	drm_connector_attach_property( connector,
		p_priv->mode_info.left_border_property, 0);
	drm_connector_attach_property( connector,
		p_priv->mode_info.right_border_property, 0);
	drm_connector_attach_property( connector,
		p_priv->mode_info.top_border_property, 0);
	drm_connector_attach_property( connector,
		p_priv->mode_info.bottom_border_property, 0);
}

static bool via_chrome9_get_transmiter_type(int device)
{
	u8 tx_type = 0;
	ULONG encodertype = 0;

	if (ACTIVE_TYPE_DVI == device) {
		if (cbGetDITXtype(pcbe, &tx_type, S3_DVI) == FALSE) {
			KMS_DEBUG("get transmiter type failed!\n"); 
			return false;
		}
		KMS_DEBUG("tx_type is %x \n",tx_type); 
		if ( (tx_type == AD9389B) || (tx_type == INTERNAL_DP) ) {
			return true;			 
		}
	}
	else if(ACTIVE_TYPE_DVI2 == device){
		if (cbGetDITXtype(pcbe, &tx_type, S3_DVI2) == FALSE) {
			KMS_DEBUG("get transmiter type failed!\n"); 
			return false;
		}
		KMS_DEBUG("tx_type is %x \n",tx_type); 
		if ( tx_type == AD9389B) {
			return true;			 
		}
	}
	else if ( ACTIVE_TYPE_CRT2 == device) {
		if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE) {
			KMS_DEBUG("get transmiter type failed!\n"); 
			return false;
		}
		KMS_DEBUG("encodertype is %x \n",encodertype); 
		if ( encodertype == CH7301) {			
			return true;			 
		}
	}
		
	return false;
}

void via_chrome9_add_connector(struct drm_device *dev,
		int connector_id, enum via_chrome9_connector_type type)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_connector *connector;
	struct via_chrome9_connector *via_conn;
	struct via_vga_options *via_vga_options = NULL;
	struct via_vga_options *via_vga_2_options = NULL;
	struct via_lcd_options *via_lcd_options = NULL;
	struct via_dvi_options *via_dvi_options = NULL;
	struct via_hdmi_options *via_hdmi_options = NULL;
	struct via_hdmi_options *via_hdmi_2_options = NULL;
	struct via_dp_options *via_dp_options = NULL;
	struct via_dp_connector_private_info
		*via_dp_1_connector_private_info = NULL;
	struct via_dp_connector_private_info
		*via_dp_2_connector_private_info = NULL;
	struct via_hdmi_connector_private_info
		*via_hdmi_connector_private_info = NULL;
	struct via_dvi_connector_private_info
		*via_dvi_connector_private_info = NULL;
	struct via_dvi_connector_private_info 
		*via_dvi_2_connector_private_info = NULL;
	struct via_hdmi_connector_private_info
		*via_hdmi_2_connector_private_info = NULL;

	int connector_index;	

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		via_conn = to_via_chrome9_connector(connector);
		if ((via_conn->connector_id == connector_id) &&
			(via_conn->connector_type == type))
			return;
	}
	via_conn = kzalloc(sizeof(struct via_chrome9_connector), GFP_KERNEL);
	if (!via_conn) {
		DRM_INFO("allocate the connector error\n");
		return;
	}
	via_conn->connector_id = connector_id;
	via_conn->connector_type = type;
	connector = &via_conn->base;

	switch (connector_id) {
	case VIA_CHROME9_DEVICE_CONNECTOR_CRT:
		connector_index = VIA_CHROME9_CONNECTOR_CRT_INDEX;
		via_vga_options = kzalloc(sizeof(struct via_vga_options), GFP_KERNEL);
		if (!via_vga_options) {
			DRM_INFO("allocate the vga option error\n");
			return;
		}
		via_vga_options->no_ddc_value = false;
		via_conn->options = (void *)via_vga_options;
		via_conn->set_xorg_options =
			via_chrome9_set_vga_xorg_options;
		/* connector->polled = DRM_CONNECTOR_POLL_CONNECT; */
		connector->interlace_allowed = true;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_vga_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_vga_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_VGA); 
		drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_VGA);	
		
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_CRT_2:
		connector_index = VIA_CHROME9_CONNECTOR_CRT_2_INDEX;
		via_vga_2_options = kzalloc(sizeof(struct via_vga_options),GFP_KERNEL);
		if (!via_vga_2_options) {
			DRM_INFO("allocate the vga option error\n");
			return;
		}
		via_vga_2_options->no_ddc_value = false;
		via_conn->options = (void *)via_vga_2_options;
		via_conn->set_xorg_options = via_chrome9_set_vga_2_xorg_options;
		connector->interlace_allowed = true;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_vga_2_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_vga_2_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_VGA); 				
		 
		if(via_chrome9_get_transmiter_type(ACTIVE_TYPE_CRT2))
		{
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_DVI_I); 
		}
		else
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_VGA); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_LCD:
		connector_index = VIA_CHROME9_CONNECTOR_LCD_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_lcd_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_lcd_connector_helper_funcs);
		via_lcd_options = kzalloc(sizeof(struct via_lcd_options), GFP_KERNEL);
		if (!via_lcd_options) {
			DRM_INFO(
				"allocate the lcd xorg options structure error\n");
			return;
		}

		via_lcd_options->center = false;
		via_lcd_options->dual_channel = false;
		via_lcd_options->msb = false;
		via_lcd_options->no_dithering = false;
		via_lcd_options->fix_on_iga1 = false;
		via_lcd_options->physical_height = 0;
		via_lcd_options->physical_width = 0;
		via_conn->options = (void *)via_lcd_options;
		via_conn->set_xorg_options = via_chrome9_set_lcd_xorg_options;
		switch (connector->connector_type_id) {
		case 1:
			via_chrome9_fb_cmd_parse("LCD1", via_lcd_options);
			break;
		case 2:
			via_chrome9_fb_cmd_parse("LCD2", via_lcd_options);
			break;
		default:
			KMS_DEBUG( "get lcd%d option fail\n",connector->connector_type_id);
			break;

		}
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_LVDS); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_PANEL); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_HDMI:
		via_hdmi_connector_private_info =
			kzalloc(sizeof(struct via_hdmi_connector_private_info), GFP_KERNEL);
		if (!via_hdmi_connector_private_info) {
			DRM_INFO("allocate the hdmi connector private info error\n");
			return;
		}
		 
		via_conn->connector_info = (void *)via_hdmi_connector_private_info;
		via_hdmi_options = kzalloc(sizeof(struct via_hdmi_options),GFP_KERNEL);
		if (!via_hdmi_options) {
			DRM_INFO("allocate the hdmi option error\n");
			return;
		}
		via_hdmi_options->attach_all_modes = false;
		via_conn->options = (void *)via_hdmi_options;
		via_conn->set_xorg_options = via_chrome9_set_hdmi_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_HDMI_INDEX;
		connector->interlace_allowed = true;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_hdmi_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_hdmi_connector_helper_funcs);
		via_chrome9_borders_property_attach(connector, dev);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_TMDS); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_HDMI); 
		
		/* initial hdmi cts func variable.*/
		p_priv->hdmi_cts_renew = (struct hdmi_cts_renew *)kmalloc(
				sizeof(struct hdmi_cts_renew), GFP_KERNEL);
		p_priv->hdmi_cts_renew->cts = 0;
		p_priv->hdmi_cts_renew->interval = 0;
		p_priv->hdmi_cts_renew->feedback = 0;
		p_priv->hdmi_cts_renew->counter = 0;
		p_priv->hdmi_cts_renew->increaser = 0;
		p_priv->hdmi_cts_renew->is_hdmi_cts_timer_on = false;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2:
		via_hdmi_2_connector_private_info =
			kzalloc(sizeof(struct via_hdmi_connector_private_info),GFP_KERNEL);
		if (!via_hdmi_2_connector_private_info) {
			DRM_INFO("allocate the hdmi connector private info error\n");
			return;
		}
		 
		via_conn->connector_info =
			(void *)via_hdmi_2_connector_private_info;
		via_hdmi_2_options =
			kzalloc(sizeof(struct via_hdmi_options), GFP_KERNEL);
		if (!via_hdmi_2_options) {
			DRM_INFO("allocate the hdmi option error\n");
			return;
		}
		via_hdmi_2_options->attach_all_modes = false;
		via_conn->options = (void *)via_hdmi_2_options;
		via_conn->set_xorg_options = via_chrome9_set_hdmi_2_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_HDMI_2_INDEX;
		connector->interlace_allowed = true;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_hdmi_2_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_hdmi_2_connector_helper_funcs);
		via_chrome9_borders_property_attach(connector, dev);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_TMDS); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_HDMI); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DP_1:
		via_dp_1_connector_private_info =
			kzalloc(sizeof(struct via_dp_connector_private_info), GFP_KERNEL);
		if (!via_dp_1_connector_private_info) {
			DRM_INFO("allocate the dp1 private info error\n");
			return;
		}
		 
		via_conn->connector_private =
			(void *)via_dp_1_connector_private_info;
		via_dp_options = kzalloc(sizeof(struct via_dp_options), GFP_KERNEL);
		if (!via_dp_options) {
			DRM_INFO("allocate the dp1 option error\n");
			return;
		}
		via_conn->options = (void *)via_dp_options;
		via_conn->set_xorg_options = via_chrome9_set_dp_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_DP_1_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_dp_1_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_dp_1_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_DISPLAYPORT); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_DISPLAYPORT); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DP_2:
		via_dp_2_connector_private_info =
			kzalloc(sizeof(struct via_dp_connector_private_info), GFP_KERNEL);
		if (!via_dp_2_connector_private_info) {
			DRM_INFO("allocate the dp1 private info error\n");
			return;
		}
		 
		via_conn->connector_private =
			(void *)via_dp_2_connector_private_info;
		via_dp_options =
			kzalloc(sizeof(struct via_dp_options), GFP_KERNEL);
		if (!via_dp_options) {
			DRM_INFO("allocate the dp2 option error\n");
			return;
		}
		via_conn->options = (void *)via_dp_options;
		via_conn->set_xorg_options = via_chrome9_set_dp_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_DP_2_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_dp_2_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_dp_2_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_DISPLAYPORT); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_DISPLAYPORT);
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DVI_D:
		via_dvi_connector_private_info =
			kzalloc(sizeof(struct via_dvi_connector_private_info), GFP_KERNEL);
		if (!via_dvi_connector_private_info) {
			DRM_INFO("allocate the dvi connector private info error\n");
			return;
		}
		 
		via_conn->connector_info = (void *)via_dvi_connector_private_info;

		via_dvi_options =
			kzalloc(sizeof(struct via_dvi_options), GFP_KERNEL);
		if (!via_dvi_options) {
			DRM_INFO("allocate the dvi option error\n");
			return;
		}
		via_conn->options = (void *)via_dvi_options;
		via_conn->set_xorg_options = via_chrome9_set_dvi_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_DVI_D_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_dvi_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_dvi_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_TMDS); 		
		
		if(via_chrome9_get_transmiter_type(ACTIVE_TYPE_DVI))
		{ 
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_HDMI); 		  
		}
		else
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_DVI_D); 
			
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DVI_D_2:
		via_dvi_2_connector_private_info =
			kzalloc(sizeof(struct via_dvi_connector_private_info), GFP_KERNEL);
		if (!via_dvi_2_connector_private_info) {
			DRM_INFO("allocate the dvi2 connector private info error \n");
			return;
		}

		via_conn->connector_info= (void *)via_dvi_2_connector_private_info;
		
		via_dvi_options = kzalloc(sizeof(struct via_dvi_options), GFP_KERNEL);
		if (!via_dvi_options) {
			DRM_INFO("allocate the dvi option error \n");
			return;

		}		
		via_conn->options = (void *)via_dvi_options;
		via_conn->set_xorg_options = via_chrome9_set_dvi_2_xorg_options;
		connector_index = VIA_CHROME9_CONNECTOR_DVI_D_2_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_dvi_2_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_dvi_2_connector_helper_funcs);
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_TMDS); 		
		
		if(via_chrome9_get_transmiter_type(ACTIVE_TYPE_DVI2))
		{
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_HDMI); 
		}
		else
			drm_connector_attach_property( connector,
		               p_priv->mode_info.connector_type, CONNECTOR_TYPE_DVI_D); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_LCD_2:
		connector_index = VIA_CHROME9_CONNECTOR_LCD_2_INDEX;
		connector->interlace_allowed = false;
		connector->doublescan_allowed = false;
		drm_connector_init(dev, &via_conn->base,
			&via_chrome9_lcd_2_connector_funcs,
			via_chrome9_connector_convert[connector_index]);
		drm_connector_helper_add(&via_conn->base,
			&via_chrome9_lcd_2_connector_helper_funcs);
		via_lcd_options = kzalloc(sizeof(struct via_lcd_options), GFP_KERNEL);
		if (!via_lcd_options) {
			DRM_INFO("allocate the lcd xorg options structure error\n");
			return;
		}
		via_lcd_options->center = false;
		via_lcd_options->dual_channel = false;
		via_lcd_options->msb = false;
		via_lcd_options->no_dithering = false;
		via_lcd_options->fix_on_iga1 = false;
		via_lcd_options->physical_height = 0;
		via_lcd_options->physical_width = 0;
		via_conn->options = (void *)via_lcd_options;
		via_conn->set_xorg_options = via_chrome9_set_lcd_xorg_options;
		switch (connector->connector_type_id) {
		case 1:
			via_chrome9_fb_cmd_parse("LCD1", via_lcd_options);
			break;
		case 2:
			via_chrome9_fb_cmd_parse("LCD2", via_lcd_options);
			break;
		default:
			KMS_DEBUG("get lcd%d option fail\n", connector->connector_type_id);
			break;
		}
		drm_connector_attach_property( connector,
		          p_priv->mode_info.signal_format, SIGNAL_FORMAT_LVDS); 
		drm_connector_attach_property( connector,
		          p_priv->mode_info.connector_type, CONNECTOR_TYPE_PANEL); 
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_TV:
		break;
	default:
		DRM_INFO("invalid connector type\n");
		break;
	}
	drm_sysfs_connector_add(connector);
}

/*
 * travel the connector and encoder list, bind them together
 */
void via_chrome9_attach_encoder_connector(struct drm_device *dev)
{
	struct drm_connector *connector;
	struct drm_encoder *encoder;
	struct via_chrome9_connector *via_chrome9_connector;
	struct via_chrome9_encoder *via_chrome9_encoder;

	list_for_each_entry(connector, &dev->mode_config.connector_list, head) {
		via_chrome9_connector = to_via_chrome9_connector(connector);
		if (!via_chrome9_is_internal_connector(via_chrome9_connector))
			continue;
		list_for_each_entry(encoder, &dev->mode_config.encoder_list, head) {
			via_chrome9_encoder = to_via_chrome9_encoder(encoder);
			if ((via_chrome9_encoder->supported_connect_types &
				via_chrome9_connector->connector_id) &&
				((int)via_chrome9_encoder->encoder_type ==
				(int)via_chrome9_connector->connector_type)) {
				drm_mode_connector_attach_encoder(
					connector, encoder);
				KMS_DEBUG("attach  connector id =%x  encoder id =%x\n",
					via_chrome9_connector->connector_id,
					via_chrome9_encoder->encoder_id);
			}
		}
	}
}

int via_chrome9_detect_enc_conn(struct drm_device *dev)
{
	/* travel the internal encoder list and init */
	via_chrome9_internal_encoder_init(dev);
	/* bind the encoder and connector together */
	via_chrome9_attach_encoder_connector(dev);
	return 0;
}
