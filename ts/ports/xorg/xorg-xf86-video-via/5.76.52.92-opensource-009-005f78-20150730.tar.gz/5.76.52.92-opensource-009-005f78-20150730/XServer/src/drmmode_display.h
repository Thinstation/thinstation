/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_DRIVER_KMS_H_
#define _VIA_DRIVER_KMS_H_

#include "xf86.h"
#include "via_bo.h"

typedef enum {
    OPTION_NOACCEL,

#ifdef VIA_HAVE_EXA
    OPTION_ACCELMETHOD,
#endif
    OPTION_EXA_MEM4DDMPEG,
    OPTION_DRI,
    OPTION_SWCURSOR,
    OPTION_SHADOW_FB,
    OPTION_ROTATE,
    OPTION_ROTATE_TYPE,
    OPTION_VIDEORAM,
    OPTION_VIDEORAM1,
    OPTION_CRT_PORT,
    OPTION_ACTIVEDEVICE,
    OPTION_DVI_PORT,
    OPTION_LCD_PORT,
    OPTION_LCD_BUS_WIDTH,
    OPTION_CENTER,
    OPTION_TV_PORT,
    OPTION_TVDOTCRAWL,
    OPTION_TV2DOTCRAWL,
    OPTION_TVTYPE,
    OPTION_TV2TYPE,
    OPTION_TVOUTPUT,
    OPTION_TV2OUTPUT,
    OPTION_TVVSCAN,
#ifndef CS_FLAG_NO_TV_SCAL
    OPTION_TVHSCALE,
    OPTION_TVVSCALE,
    OPTION_TV2HSCALE,
    OPTION_TV2VSCALE,
#endif /* CS_FLAG_NO_TV_SCAL */
    OPTION_REFRESH,
    OPTION_DISABLEVQ,
    OPTION_NODDCVALUE,
    OPTION_DRIXINERAMA,
    /*to enable mergedfb,switch to virtualscreen*/
    OPTION_MERGEDFB,
    /*and set screen layout*/
    OPTION_NOVIAXINERAMA,
    OPTION_SCRN2POS,
    /*set video to work on which device for 3314,3204 etc.in duo view mode */
    OPTION_VideoOnDevice,
    /* to simply LCD panel option. */
    OPTION_LCD_PANEL_SIZE,
    OPTION_DPA_SETTING_DVP0,
    OPTION_DPA_SETTING_DVP1,
    OPTION_DPA_SETTING_DFPHIGH,
    OPTION_DPA_SETTING_DFPLOW,
    OPTION_DPA_SETTING_VT1636,
    OPTION_DPA_SETTING_VT1625,
#ifndef CS_FLAG_NO_TV_SCAL
    OPTION_TVDISP3DScaling,
#endif /* CS_FLAG_NO_TV_SCAL */
#ifndef CS_FLAG_NO_HDMI_SCAL
    OPTION_HDMIDISP3DScaling,
#endif /* CS_FLAG_NO_HDMI_SCAL */
#ifndef CS_FLAG_NO_LCD_SCAL
    OPTION_LCDDISP3DScaling,
#endif /* CS_FLAG_NO_LCD_SCAL */
    OPTION_VIDEO_COLOR_KEY,
    OPTION_GOOD_PERFORMANCE,
    OPTION_LCD_MSB_ENABLE,
    OPTION_LCD_NO_DITHERING,
    OPTION_LCD_DUAL_CHANNEL,
    OPTION_INTERLACE_MODE,
    OPTION_FN_HOTKEY,
    OPTION_TEXTUREVIDEOSUPPORT,
    OPTION_TEXTUREVIDEO3DPATH,
    OPTION_HDMI_PORT
} VIAOpts;

static OptionInfoRec VIAOptions[] = {
    {OPTION_NOACCEL,                 "NoAccel",             OPTV_BOOLEAN,
            {0}, FALSE},
#ifdef VIA_HAVE_EXA
    {OPTION_ACCELMETHOD,            "AccelMethod",          OPTV_STRING,
            {0}, FALSE},
    {OPTION_EXA_MEM4DDMPEG,         "Mem4Ddmpeg",           OPTV_INTEGER,
            {0}, FALSE},
#endif
    {OPTION_DRI,                    "DRI",                  OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_SWCURSOR,               "SWCursor",             OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_SHADOW_FB,              "ShadowFB",             OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_ROTATE,                 "Rotate",               OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_ROTATE_TYPE,            "RotateType",           OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_VIDEORAM,               "VideoRAM",             OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_VIDEORAM1,              "VideoRAM1",            OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_CRT_PORT,               "CRTPort",              OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DVI_PORT,               "DVIPort",              OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_LCD_PORT,               "LCDPort",              OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_LCD_BUS_WIDTH,          "LCDBusWidth",          OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_CENTER,                 "Center",               OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_LCD_PANEL_SIZE,         "PanelSize",            OPTV_STRING,
            {0}, FALSE},
    {OPTION_TV_PORT,                "TVPort",               OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_TVDOTCRAWL,             "TVDotCrawl",           OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_TV2DOTCRAWL,            "TV2DotCrawl",          OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_TVTYPE,                 "TVType",               OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_TV2TYPE,                "TV2Type",              OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_TVOUTPUT,               "TVOutput",             OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_TV2OUTPUT,              "TV2Output",            OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_TVVSCAN,                "TVVScan",              OPTV_ANYSTR,
            {0}, FALSE},
#ifndef CS_FLAG_NO_TV_SCAL                                  
    {OPTION_TVHSCALE,               "TVHScale",             OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_TVVSCALE,               "TVVScale",             OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_TV2HSCALE,              "TV2HScale",            OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_TV2VSCALE,              "TV2VScale",            OPTV_INTEGER,
            {0}, FALSE},
#endif /* CS_FLAG_NO_TV_SCAL */                             
    {OPTION_REFRESH,                "Refresh",              OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_DISABLEVQ,              "DisableVQ",            OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_NODDCVALUE,             "NoDDCValue",           OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_DRIXINERAMA,            "DRIXINERAMA",          OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_MERGEDFB,               "MergedFB",             OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_NOVIAXINERAMA,          "NoVIAXinerama",        OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_SCRN2POS,               "Scrn2Pos",             OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_VideoOnDevice,          "VideoOnDevice",        OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_DVP0,       "DPASetting_DVP0",      OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_DVP1,       "DPASetting_DVP1",      OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_DFPHIGH,    "DPASetting_DFPHIGH",   OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_DFPLOW,     "DPASetting_DFPLOW",    OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_VT1636,     "DPASetting_VT1636",    OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_DPA_SETTING_VT1625,     "DPASetting_VT1625",    OPTV_ANYSTR,
            {0}, FALSE},
#ifndef CS_FLAG_NO_TV_SCAL
    {OPTION_TVDISP3DScaling,        "DISPLAY_3DScaling_TV", OPTV_BOOLEAN,
            {0}, FALSE},
#endif /* CS_FLAG_NO_TV_SCAL */
#ifndef CS_FLAG_NO_HDMI_SCAL
    {OPTION_HDMIDISP3DScaling,      "DISPLAY_3DScaling_HDMI", OPTV_BOOLEAN,
            {0}, FALSE},
#endif /* CS_FLAG_NO_HDMI_SCAL */
#ifndef CS_FLAG_NO_LCD_SCAL
    {OPTION_LCDDISP3DScaling,       "DISPLAY_3DScaling_LCD", OPTV_BOOLEAN,
            {0}, FALSE},
#endif /* CS_FLAG_NO_LCD_SCAL */
    {OPTION_VIDEO_COLOR_KEY,        "VideoColorKey",        OPTV_INTEGER,
            {0}, FALSE},
    {OPTION_GOOD_PERFORMANCE,       "GoodPerformance",      OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_LCD_MSB_ENABLE,         "LCD_MSB_ENABLE",       OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_LCD_NO_DITHERING,       "NoDithering",          OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_LCD_DUAL_CHANNEL,       "DualChannel",          OPTV_STRING,
            {0}, FALSE},
    {OPTION_INTERLACE_MODE,         "Interlace",            OPTV_BOOLEAN,
            {0}, FALSE},
    {OPTION_FN_HOTKEY,              "FnHotkey",             OPTV_ANYSTR,
            {0}, FALSE},
    {OPTION_HDMI_PORT,              "HDMIPort",             OPTV_ANYSTR,
            {0}, FALSE},
    {-1,                             NULL,                  OPTV_NONE,
            {0}, FALSE}
};
typedef struct {
    /*Clock Polarity*/
    CARD8   clk_polarity;
    /*Clock Adjust*/
    CARD8   clk_adjust;
    /*DVP0 or DVP1 Clock Driving Selection*/
    CARD8   clk_driving_sel;
    /*DVP0 or DVP1 Data Driving Selection*/
    CARD8   data_driving_sel;
    CARD8   is_clk_polarity_used;
    CARD8       is_clk_adjust_used;
    CARD8       is_clk_driving_sel_used;
    CARD8       is_data_driving_sel_used;
} via_xorg_gfx_dpa, *via_xorg_gfx_dpa_ptr;

typedef struct {
    CARD8    vt1636_clk_sel_st1;
    CARD8    vt1636_clk_sel_st2;
    CARD8    is_vt_1636_clk_sel_st1_used;
    CARD8    is_vt_1636_clk_sel_st2_used;
} via_xorg_lvds_dpa, *via_xorg_lvds_dpa_ptr;

typedef struct {
    CARD8    no_ddc_value;
    /*Clock Polarity*/
    CARD8        clk_polarity;
    /*Clock Adjust*/
    CARD8        clk_adjust;
    /*DVP0 or DVP1 Clock Driving Selection*/
    CARD8        clk_driving_sel;    
    /*DVP0 or DVP1 Data Driving Selection*/
    CARD8        data_driving_sel;
    CARD8    is_clk_polarity_used;
    CARD8        is_clk_adjust_used;
    CARD8        is_clk_driving_sel_used;
    CARD8        is_data_driving_sel_used;
}via_crt_xorg_options, *via_crt_xorg_options_ptr;

typedef struct {
    CARD8     no_ddc_value;
    CARD8    clk_polarity;        /*Clock Polarity*/
    CARD8    clk_adjust;        /*Clock Adjust*/
    CARD8    clk_driving_sel;    /*DVP0 or DVP1 Clock Driving Selection*/
    CARD8    data_driving_sel;    /*DVP0 or DVP1 Data Driving Selection*/
    CARD8    ad9389_circuit_state_adjust;
    CARD8    is_clk_polarity_used;
    CARD8    is_clk_adjust_used;
    CARD8    is_clk_driving_sel_used;
    CARD8    is_data_driving_sel_used;
    CARD8    is_ad9389_circuit_state_adjust_used;
}via_dvi_xorg_options, *via_dvi_xorg_options_ptr;

typedef struct {
    CARD32  physical_width;
    CARD32  physical_height;
    CARD32  panel_index;
    CARD8    msb;
    CARD8        center;
    CARD8        fix_on_iga1;
    CARD8        dual_channel;
    CARD8        no_dithering;
    /*Clock Polarity*/
    CARD8        clk_polarity;
    /*Clock Adjust*/
    CARD8        clk_adjust;
    /*DVP0 or DVP1 Clock Driving Selection*/
    CARD8        clk_driving_sel;    
    /*DVP0 or DVP1 Data Driving Selection*/
    CARD8        data_driving_sel;
    CARD8        is_clk_polarity_used;
    CARD8    is_clk_adjust_used;
    CARD8    is_clk_driving_sel_used;
    CARD8        is_data_driving_sel_used;
    CARD8        vt1636_clk_sel_st1;
    CARD8        vt1636_clk_sel_st2;
    CARD8        is_vt_1636_clk_sel_st1_used;
    CARD8        is_vt_1636_clk_sel_st2_used;
}via_lcd_xorg_options, *via_lcd_xorg_options_ptr;

typedef struct {
    CARD8    attachAllModes;
    CARD8    clk_polarity;        /*Clock Polarity*/
    CARD8    clk_adjust;        /*Clock Adjust*/
    CARD8    clk_driving_sel;    /*DVP0 or DVP1 Clock Driving Selection*/
    CARD8    data_driving_sel;    /*DVP0 or DVP1 Data Driving Selection*/
    CARD8    ad9389_circuit_state_adjust;
    CARD8    is_clk_polarity_used;
    CARD8    is_clk_adjust_used;
    CARD8    is_clk_driving_sel_used;
    CARD8    is_data_driving_sel_used;
    CARD8    is_ad9389_circuit_state_adjust_used;

    CARD32    left_border;
    CARD32    right_border;
    CARD32    top_border;
    CARD32    bottom_border;

    CARD8    is_hdmi_audio_disable;
}via_hdmi_xorg_options, *via_hdmi_xorg_options_ptr;


typedef struct {
    CARD8    no_ddc_value;
    CARD8    sw_link_training;
} via_dp_xorg_options, *via_dp_xorg_options_ptr;

typedef struct {
	CARD32 mode_index;
	CARD32 standard;
	CARD32 signal;
	CARD32 scan;
	/* Clock Polarity */
	CARD8 clk_polarity;
	/* Clock Adjust */
	CARD8 clk_adjust;
	/* DVP0 or DVP1 Clock Driving Selection */
	CARD8 clk_driving_sel;
	/* DVP0 or DVP1 Data Driving Selection */
	CARD8 data_driving_sel;
	CARD8 vt1625_clk_adjust;
	CARD8 is_clk_polarity_used;
	CARD8 is_clk_adjust_used;
	CARD8 is_clk_driving_sel_used;
	CARD8 is_data_driving_sel_used;
	CARD8 is_vt1625_clk_adjust_used;
	CARD8 de_dot_crawl;
}via_tv_xorg_options, *via_tv_xorg_options_ptr;

struct drmmode_rec;
typedef struct drmmode_rec *drmmode_ptr;
extern Bool VIAPreInit_kms(ScrnInfoPtr pScrn, int flags);


#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0, 0))
extern Bool VIAEnterVT_kms(int scrnIndex, int flags);
extern void VIALeaveVT_kms(int scrnIndex, int flags);
extern void VIAAdjustFrame_kms(int scrnIndex, int x, int y, int flags);
extern Bool VIAScreenInit_kms(int scrnIndex, ScreenPtr pScreen, int argc,
                          char **argv);
extern Bool VIASwitchMode_kms(int scrnIndex, DisplayModePtr mode, int flags);
extern ModeStatus VIAValidMode_kms(int scrnIndex, DisplayModePtr mode,
                          Bool verbose, int flags);
extern Bool VIAPMEvent_kms(int scrnIndex, pmEvent event, Bool undo);
extern void VIAFreeScreen_kms(int scrnIndex, int flags);
#else
extern Bool VIAEnterVT_kms(ScrnInfoPtr pScrn);
extern void VIALeaveVT_kms(ScrnInfoPtr pScrn);
extern void VIAAdjustFrame_kms(ScrnInfoPtr pScrn, int x, int y);
extern Bool VIAScreenInit_kms(ScreenPtr pScreen, int argc,
                          char **argv);
extern Bool VIASwitchMode_kms(ScrnInfoPtr pScrn,DisplayModePtr mode);
extern ModeStatus VIAValidMode_kms(ScrnInfoPtr pScrn,DisplayModePtr mode,
                          Bool verbose, int flags);
extern Bool VIAPMEvent_kms(ScrnInfoPtr pScrn, pmEvent event, Bool undo);
extern void VIAFreeScreen_kms(ScrnInfoPtr pScrn);
#endif


extern Bool drmmode_pre_init(ScrnInfoPtr pScrn, int fd, int cpp);
extern void drmmode_set_cursor(ScrnInfoPtr scrn, int id, struct generic_bo *bo);
extern void drmmode_uevent_init(ScrnInfoPtr scrn, drmmode_ptr drmmode);
extern void drmmode_uevent_fini(ScrnInfoPtr scrn, drmmode_ptr drmmode);
extern void drm_get_lvds_physical_size(xf86OutputPtr output,
                          int *width, int *height);

#endif
