/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
 /*
  *EDID info by http://en.wikipedia.org/wiki/Extended_display_identification_data
  */
#include "via_driver.h"
#include "via_output.h"
#include "via_disphdmi.h"
#include "via_common.h"
#include "via_dp.h"

/*****************************************************/
/*           HDMI   Audio   CTS   Update              */
/*****************************************************/
CARD32 viaGetSampleRate(void);
Bool viaSetHDAudioCTSandN(CARD32 hdacSampleRate, CARD32 hdacPixelClock);
Bool viaSetHDAudioSampleRate(CARD32 hdacSampleRate, CARD32 hdacPixelClock);


#define VIAUPDATE_TIMER  20   // 20ms timer

/* HDMI CTS update variable */
typedef struct _HdmiUpdate {
    CARD32 CTS;
    CARD32 Interval;
    CARD32 Feedback;
    CARD32 Counter;
    CARD32 Increaser;

    CARD32 PixelClockSaved;
    CARD32 HdacSampleRateSaved;
    int isIga2Hdmi;

} HdmiUpdateRec, *HdmiUpdatePtr;

static HdmiUpdateRec hdacUpdateVar={0, 0, 0, 0, 0, 0, 0, 0};

CARD8
internalHdmiIgaPath(void)
{
#define HDTV0_ON_IGA2   0x02

    CARD8 regCRFF = viaReadVgaIo(REG_CRFF);

    if (HDTV0_ON_IGA2 & regCRFF) {
        return IGA2;
    } else {
        return IGA1;
    }
}

CARD8
isIgaDownScaleEnable(int igaPath)
{
    CARD8 regCR89;
    if (IGA1 == igaPath) {
        viaWriteVgaIoBits(REG_CRFD, BIT7, BIT7);
        regCR89 = viaReadVgaIo(REG_CR89);
        if (BIT0 & regCR89)
            return 1;
        else
            return 0;
    } else {
        viaWriteVgaIoBits(REG_CRFD, 0x00, BIT7);
        regCR89 = viaReadVgaIo(REG_CR89);
        if (BIT0 & regCR89)
            return 1;
        else
            return 0;
    }


}

/* This function transfer MRN register bytes to Clock Frequency(Hz) */
CARD32
calcClkFromReg(CARD8 regSR47, CARD8 regSR48, CARD8 regSR49, VIAPtr pVia)
{
#define UMA_CLK_Reference          14318180
    /**
     * Clcok Synthesizer Value 0 :      DM[9:0]
     * Clcok Synthesizer Value 1[4:2] : DR[2:0]
     * Clcok Synthesizer Value 2[6:0] : DN[6:0]
     */
    CARD32 PLLDM, PLLDN, PLLDR;
    CARD32 ret;

    PLLDM = (CARD32)(regSR48 & 0x03);
    PLLDM <<= 8 ;
    PLLDM |= (CARD32)regSR47;
    PLLDR = (CARD32)((regSR48 & 0x1C) >> 2);
    PLLDN = (CARD32)(regSR49 & 0x7F);   /* Remove DTZ bit */

    if (PLLDN == 0) {
        DEBUG(ErrorF("%s(): PLLDN = 0! \n", __FUNCTION__ ));
        return 0;
    }

    /* Notes: we only support for the chipset after VX800 */
    switch (pVia->Chipset) {
    case VIA_VX800 :
        /* VX800 need to add 2 before calculate them to pixelclock. */
        PLLDM += 2;
        PLLDN += 2;
        break;
    case VIA_VX855 :
    case VIA_VX900 :
    default              :
        break;
    }

    /* True Output Fout = Fref * (DM) / [(DN)(2^DR)] */
    ret = (UMA_CLK_Reference * (PLLDM) / ((PLLDN) * ((CARD32)1 << PLLDR)));

    return ret;
}


/* Get Pixel Clock from IGAn,  Frequency(Hz) */
CARD32
viaGetPixelClock(int igaPath, VIAPtr pVia)
{
    CARD8 regSR47, regSR48, regSR49;
    CARD32 ret = 0;

    if (IGA2 == igaPath) {

        regSR47 = viaReadVgaIo(REG_SR4A);
        regSR48 = viaReadVgaIo(REG_SR4B) ;
        regSR49= viaReadVgaIo(REG_SR4C) ;

    } else {

        regSR47 = viaReadVgaIo(REG_SR44);
        regSR48 = viaReadVgaIo(REG_SR45);
        regSR49 = viaReadVgaIo(REG_SR46);

    }

    ret = calcClkFromReg(regSR47, regSR48, regSR49, pVia);

    /* if do down scaling, the pixel clock should be divided by 2  */
    if (isIgaDownScaleEnable(igaPath)) {
        ret = ret >> 1;
        DEBUG(ErrorF("%s, IGA%d downscaling... \n", __FUNCTION__, igaPath));
    }

    return ret;

}

Bool
viaResetCtsUpdateVariable(CARD32 hdacSampleRate, CARD32 hdacPixelClock,
            HdmiUpdatePtr pHdacUpdate)
{
    unsigned long long N = 0, CTS = 0, CTSx1000 = 0;

    if (hdacPixelClock == 0 || hdacSampleRate== 0) {
        DEBUG(ErrorF("%s() : hdacPixelClock = 0x%lx, hdacSampleRate = 0x%lx\n",
            __FUNCTION__, hdacPixelClock, hdacSampleRate));
        return FALSE;
    }

    /* 
    * CTS and N value setting refer to 2.6.38 kernel
    * drivers/gpu/drm/radeon/r600_hdmi.c
    * r600_hdmi_calc_CTS funtion.
    * we fix N to 6144, and calculate CTS here.
    */
    
    N = 6144;
    CTS = (unsigned long long)(hdacPixelClock) * N;
    CTS /= (unsigned long long)(128 * hdacSampleRate);

    CTSx1000 = (unsigned long long)(hdacPixelClock) * N * 1000;
    CTSx1000 /= (unsigned long long)(128 * hdacSampleRate);

    pHdacUpdate->Interval = (CARD32)(CTSx1000 - (CTS * 1000));
    pHdacUpdate->CTS = (CARD32)CTS;
    pHdacUpdate->Feedback = 0;
    pHdacUpdate->Counter = 0;
    pHdacUpdate->Increaser = 0;

    return TRUE;

}

void
viaChangeHdmiAudioEnv(HdmiUpdatePtr pHdacUpdate)
{
    CARD32 mmC424/*, mmC4D4*/;
    CARD32 hdacSampleRate, hdacPixelClock = 0;

    hdacPixelClock = pHdacUpdate->PixelClockSaved;
    hdacSampleRate = pHdacUpdate->HdacSampleRateSaved;

    if ((!hdacPixelClock) || (!hdacSampleRate)) {
        DEBUG(ErrorF("%s(): hdacPixelClock = %ld, hdacSampleRate = %ld \n",
            __FUNCTION__, hdacPixelClock, hdacSampleRate));
        return;
    }

    mmC424 = MMIO_RD(0xC424) & 0xFFFF9FFF;
    //mmC424 |= (0 << 13);
    MMIO_WR(0xC424, mmC424);

    /*  set audio sample rate: register C400 and C410*/
    viaSetHDAudioSampleRate(hdacSampleRate, hdacPixelClock);
    /*  fill CTS & N according to Table7-1, 7-2, 7-3 of HDMI spec 1.3 */
    viaSetHDAudioCTSandN(hdacSampleRate, hdacPixelClock);
    /* reset the value of cts Update variables. */
    viaResetCtsUpdateVariable(hdacSampleRate, hdacPixelClock, pHdacUpdate);

}

CARD32
viaHdmiCtsUpdate(HdmiUpdatePtr pHdacUpdate)
{
    CARD32 CTSnow = 0, CTS = 0, mmC294 = 0, mmC298 = 0, mmC29C = 0;
    CARD32 hdacPixelClock, HorTotalxVerTotal;
    CARD32 Total = 1000 / VIAUPDATE_TIMER;

    /* get refresh rate from read registers. */
    hdacPixelClock = pHdacUpdate->PixelClockSaved;

    CTSnow = (MMIO_RD(0xC294) & 0x0FFFFF00) >> 8;
    CTS = CTSnow;

    if (CTSnow != pHdacUpdate->CTS
        && (pHdacUpdate->Counter * 1000) / Total >=
        (pHdacUpdate->Interval - pHdacUpdate->Feedback)) {
        pHdacUpdate->Increaser = ((pHdacUpdate->Counter * 1000) / Total) -
                                    pHdacUpdate->Interval +
                                    pHdacUpdate->Feedback;
        CTS = pHdacUpdate->CTS;
        DEBUG(ErrorF("%s, up: CTS = %ld, Update_freq = %ld\n",
            __FUNCTION__, CTS, Total ));
    }

    if (CTSnow != pHdacUpdate->CTS + 1
        && ((pHdacUpdate->Counter * 1000) / Total <
        (pHdacUpdate->Interval - pHdacUpdate->Feedback))) {
        CTS = pHdacUpdate->CTS + 1;
        DEBUG(ErrorF("%s, down: CTS = %ld, Update_freq = %ld\n",
            __FUNCTION__, CTS, Total));
    }

    pHdacUpdate->Counter = (pHdacUpdate->Counter + 1) % Total;

    if (pHdacUpdate->Counter == 0)
        pHdacUpdate->Feedback = pHdacUpdate->Increaser;

    if (CTS != CTSnow) {
        mmC294 = (MMIO_RD(0xC294) & 0x0000000F) | 0x100000C0;
        mmC294 |= (CTS << 8);
        MMIO_WR(0xC294, mmC294);

        mmC298 = MMIO_RD(0xC298) & 0x000FFFFF;
        mmC298 |= ((CTS & 0xFFF) << 20);
        MMIO_WR(0xC298, mmC298);

        mmC29C |= (CTS >> 12) & 0xFF;
        MMIO_WR(0xC29C, mmC29C);
    }

    return 0;
}

CARD32
isHdmiAudioEnvChanged(HdmiUpdatePtr pHdacUpdate, VIAPtr pVia)
{
    CARD32 hdacPixelClock, hdacSampleRate, horTotalxVerTotal;
    int isIga2HdmiTemp, ret = 0;

    isIga2HdmiTemp = internalHdmiIgaPath();
    if (pHdacUpdate->isIga2Hdmi != isIga2HdmiTemp) {
        pHdacUpdate->isIga2Hdmi = isIga2HdmiTemp;
        ret |= BIT0;
        DEBUG(ErrorF("%s, IGA changed to IGA%d : ret = 0x%x \n",
            __FUNCTION__, isIga2HdmiTemp,  ret));
    }

    hdacPixelClock = viaGetPixelClock(isIga2HdmiTemp, pVia);
    hdacSampleRate = viaGetSampleRate();
    if ((!hdacPixelClock) || (!hdacSampleRate)) {
        DEBUG(ErrorF("%s(): hdacPixelClock = %ld, hdacSampleRate = %ld \n",
            __FUNCTION__, hdacPixelClock, hdacSampleRate));
        return 0;
    }

    if (pHdacUpdate->PixelClockSaved != hdacPixelClock) {
        pHdacUpdate->PixelClockSaved = hdacPixelClock;
        ret |= BIT1;
        DEBUG(ErrorF("%s(): PixelClock changed to %ld, ret = 0x%x \n",
            __FUNCTION__, hdacPixelClock, ret));
    }

    if (pHdacUpdate->HdacSampleRateSaved != hdacSampleRate) {
        pHdacUpdate->HdacSampleRateSaved = hdacSampleRate;
        ret |= BIT2;
        DEBUG(ErrorF("%s(): HDA SampleRate changed to %ld, ret = 0x%x \n",
            __FUNCTION__, hdacSampleRate, ret));
    }

    if (ret) {
        viaChangeHdmiAudioEnv(pHdacUpdate);
        DEBUG(ErrorF("%s(): HDMI Audio Update environment has"
                     " been changed : ret = 0x%x \n",
                     __FUNCTION__, ret));
    }

    return ret;
}

static CARD32
viaHdmiCtsUpdateTimer(OsTimerPtr timer, CARD32 now, pointer arg)
{
#define PHY_FUNCTION_SELECT_HDMI    0x01
#define HDMI_MODE_ENBLE                    0x00000002
#define HDMI_MODE_ENBLE_MASK          0x00000042

    xf86OutputPtr output = (xf86OutputPtr) arg;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);

    CARD8 reg_3c4_save = STANDVGA_R8(REG_ZSR);  /* bak 0x3c4 (SR_REG index) */
    CARD8 reg_3d4_save = STANDVGA_R8(REG_ZCR);  /* bak 0x3d4 (CR_REG index) */

    CARD32 HdmiCtlFlag = MMIO_RD( 0xC280 );
    CARD8 regCRFF = viaReadVgaIo(REG_CRFF);

    if ((PHY_FUNCTION_SELECT_HDMI & regCRFF) &&
        (HDMI_MODE_ENBLE == (HdmiCtlFlag & HDMI_MODE_ENBLE_MASK))) {
            if (isHdmiAudioEnvChanged(&hdacUpdateVar, pVia)) {
                DEBUG(ErrorF("%s(): Something has been changed!!  \n",
                    __FUNCTION__));
            }
            viaHdmiCtsUpdate(&hdacUpdateVar);
    } else {
            DEBUG(ErrorF("%s(): 0xc280 = 0x%lx, CRFF = 0x%x\n",
                __FUNCTION__, HdmiCtlFlag, regCRFF));
            //xf86Msg(X_INFO, "viaHdmiCtsUpdateTimer(): 0xc280 = 0x%lx, CRFF = 0x%x\n", HdmiCtlFlag,regCRFF );
    }

    STANDVGA_W8(REG_ZSR, reg_3c4_save);  /* restore the SR_REG index */
    STANDVGA_W8(REG_ZCR, reg_3d4_save);  /* restore the CR_REG index */

    return VIAUPDATE_TIMER;
}


/*****************************************************/
/*                 HDMI                              */
/*****************************************************/
extern _X_EXPORT Bool ad9389_module_loaded;

Bool
viaGetStdEDIDBlock(CARD32 serialPort, CARD8 *pEDIDData)
{
    CARD8   EDIDHeader[3];
    int     i;

    /* First Read EDID Block 0 */
    for (i = 0; i < 3; i++) {
        viaSerialReadByte(serialPort, 0xA0, i, EDIDHeader + i);
    }

    
    /* EDID Header is 00 FF FF FF FF FF FF 00 */
    if ((EDIDHeader[0] == 0) && (EDIDHeader[1] == 0xFF) &&
        (EDIDHeader[2] == 0xFF)) {
        /* Read Block 0 Raw Data. */
        for (i = 0; i < 128; i++) {
            viaSerialReadByte(serialPort, 0xA0, i, pEDIDData + i);
        }
        return TRUE;
    } else {
        return FALSE;
    }
}

Bool
viaGetStdEDIDBlockByHDMI(CARD8 *pEDIDData)
{
    CARD8   EDIDHeader[3];
    int     i;

    /* First Read EDID Block 0 */
    for (i = 0; i < 3; i++) {
        viaSerialReadByteByHDMI(0xA0, i, EDIDHeader + i);
    }

    
    /* EDID Header is 00 FF FF FF FF FF FF 00 */
    if ((EDIDHeader[0] == 0) && (EDIDHeader[1] == 0xFF) &&
        (EDIDHeader[2] == 0xFF)) {
        /* Read Block 0 Raw Data. */
        viaSerialReadBytesByHDMI(0xA0, 0x0, pEDIDData, 128);

        return TRUE;
    } else {
        return FALSE;
    }
}

/* Return EDID Status*/
Bool
viaGetExtEDIDBlockByHDMI(CARD8 *pEDIDData, CARD8 extFlag)
{
    CARD8   ExtensionTag;   /* Extension Type */
    CARD8   RevisionNum;
    int     i;
    int     ret = FALSE;

    DEBUG(ErrorF("viaGetExtEDIDBlockByHDMI\n"));

    if (extFlag == 1) {
        DEBUG(ErrorF("Only one extension block\n"));

        viaSerialReadByteByHDMI(0xA0, 128, &ExtensionTag);

        
        /* 0x02 is timing extension block */
        if (ExtensionTag == 0x02) {
            viaSerialReadByteByHDMI(0xA0, 129, &RevisionNum);
            /* Currently, we only support rev.3 */
            if (RevisionNum == 0x03) {
                /* This have determined as HDMI EDID. */
                DEBUG(ErrorF("Found CEA EDID\n"));

                /* Read Block 2 Raw Data. */
                viaSerialReadBytesByHDMI(0xA0, 128, pEDIDData, 128);
                ret = TRUE;
            }
        }
    }

    return ret;
}


CARD32
viaDetectConnectType(CARD8 *extEdid)
{
    CARD8  VendorBlockIndex = 0;
    CARD8  tmp = 0;
    CARD32 ret = DISP_DEV_NONE;

    
    /* Check Data Block amount. If no data block exists, return DVI connect.
       Byte 2: byte number offset d where detail timing data begin. */
    /* if 0, No Data Block, No Detailed Timing Descriptor.*/
    /* if 4, No Data Block.*/
    if (!(extEdid[2] == 0 || extEdid[2] == 4)) {
        
        /* Byte 04 is where the Data Block Collection begins */
        VendorBlockIndex = 4;
        tmp = extEdid[VendorBlockIndex];

        
        /* Locate Vendor Description Block to identify if connect to HDMI.*/
        /* Bit[7:5]: Block Type Tag: value 3 is vendor specific*/
        while (((tmp & 0xE0) != 0x60)
             && (VendorBlockIndex < (extEdid[2]))) {
             
            /* Bit[4:0]: Total number of bytes in this block following
               this byte */
            tmp &= 0x1F;

            /* The next byte is assumed to be the beginning of the next
               data block. */
            VendorBlockIndex += (tmp + 1);

            /* Locate the next data block */
            tmp = extEdid[VendorBlockIndex];
        }

        if ((tmp & 0xE0) == 0x60) {
            
            /* Read 24-bit IEEE registration.*/
            /* HDMI identifier = 0x000C03.*/
            if ((extEdid[VendorBlockIndex + 1] == 0x03)
                && (extEdid[VendorBlockIndex + 2] == 0x0C)
                && (extEdid[VendorBlockIndex + 3] == 0x00)) {
                ret =  DISP_DEV_HDMI;
            } else {
                ret = DISP_DEV_DVI;
            }
        }
    } else {
        ret = DISP_DEV_DVI;
    }
    return ret;
}

void
viaFindMaxSupportMode(ScrnInfoPtr pScrn,
            CARD8 *stdEdid, CARD8 *extEDID,
            CARD32 *maxWidth, CARD32 *maxHeight)
{
    xf86MonPtr          edid_mon;

    int    TmpHSize = 0;
    int    TmpVSize = 0;
    int    MaxHSize = 0;
    int    MaxVSize = 0;
    int    i = 0;
    CARD8  tmp = 0;
    CARD8  VideoBlockIndex = 4;
    CARD32 DescriptorNum = 0;
    CARD8  HDMIModeIndex;

    if (stdEdid[0x7E] == 0) {
        /* Parse the EDID block */
        edid_mon = xf86InterpretEDID(pScrn->scrnIndex, stdEdid);
        if (edid_mon) {
            
            /*Find max resolution from Established timing*/
            VIAFindMaxResFromEstablishedTiming(edid_mon, &MaxHSize, &MaxVSize);

            
            /*Find max resolution from Standard timing*/
            for (i = 0; i < 8; i++) {
                if (edid_mon->timings2[i].hsize > MaxHSize) {
                    MaxHSize = edid_mon->timings2[i].hsize;
                    MaxVSize = edid_mon->timings2[i].vsize;
                }
            }
            
            /*Find max resolution from Detail timing*/
            for (i = 0; i < 4; i++) {
                if ((edid_mon->det_mon[i].type == DT) &&
                    (edid_mon->det_mon[i].section.d_timings.h_active > MaxHSize)) {

                    MaxHSize = edid_mon->det_mon[i].section.d_timings.h_active;
                    MaxVSize = edid_mon->det_mon[i].section.d_timings.v_active;

                    if (edid_mon->det_mon[i].section.d_timings.interlaced)
                        MaxVSize = MaxVSize * 2;
                }
            }

            /* To prevent to get a wrong EDID data. We should assign
                   a default value.*/
            if ((MaxHSize == 0) || (MaxVSize == 0)) {
                MaxHSize = 1280;
                MaxVSize = 720;
            }

            *maxHeight = MaxVSize;
            *maxWidth = MaxHSize;
        }
    } else if (stdEdid[0x7E] > 0) {
        
        /* Byte 04 is where the Data Block Collection begins */
        tmp = extEDID[4];

        
        /* Locate Video Block */
        /* Bit[7:5]: Block Type Tag: value 2 is video specific*/
        while (((tmp & 0xE0) != 0x40)
             && (VideoBlockIndex < (extEDID[2]))) {
             
            /* Bit[4:0]:
            Total number of bytes in this block following this byte */
            tmp &= 0x1F;

            /* The next byte is assumed to be the beginning of the
               next data block. */
            VideoBlockIndex += (tmp + 1);

            /* Locate the next data block */
            tmp = extEDID[VideoBlockIndex];
        }

        if ((tmp & 0xE0) == 0x40) {
            DescriptorNum = tmp & 0x1F;

            for (i = 0; i< DescriptorNum; i++) {

                tmp = extEDID[VideoBlockIndex + 1 + i];
                HDMIModeIndex = tmp & 0x7F;

                if (HDMIModeIndex <= 0)
                    HDMIModeIndex = 1;

                TmpHSize = CEATimingTable[HDMIModeIndex - 1].HorSize;
                TmpVSize = CEATimingTable[HDMIModeIndex - 1].VerSize;

                if (TmpHSize * TmpVSize > MaxHSize * MaxVSize) {
                    MaxHSize = TmpHSize;
                    MaxVSize = TmpVSize;
                }
            }

            *maxHeight = MaxVSize;
            *maxWidth = MaxHSize;

            DEBUG(ErrorF("HDMI Max Support HSize = %d\n", MaxHSize));
            DEBUG(ErrorF("HDMI Max Support VSize = %d\n", MaxVSize));
        }
    }
}

DisplayModePtr
viaAddExtDetailTiming(xf86OutputPtr output, DisplayModePtr modes,
            CARD8 *pEDIDData)
{
    int d = 0;
    int i = 0;
    unsigned int pixelClock;
    unsigned int hActive;
    unsigned int hBlanking;
    unsigned int horSyncOffset;
    unsigned int horSyncPluseWidth;
    unsigned int vActive;
    unsigned int vBlanking;
    unsigned int verSyncOffset;
    unsigned int verSyncPluseWidth;
    Bool         isInterlace;
    Bool         horSyncPolarity;
    Bool         verSyncPolarity;
    DisplayModePtr      newMode;

    unsigned char tmp, tmp1;
    d = pEDIDData[2];

    for (i = 0; (i + d) < pEDIDData[3]; i += 18) {

        newMode = xnfalloc(sizeof(DisplayModeRec));
        memset(newMode, 0, sizeof(DisplayModeRec));

         
        /* Pixel Clock */
        pixelClock = (((pEDIDData[1 + i + d]) << 8) + pEDIDData[i + d]) * 10000;

         
        /* H Active */
        tmp = pEDIDData[2 + i + d];
        tmp1 = pEDIDData[4 + i + d];
        hActive = ((tmp1 & 0xF0) << 4) + tmp;

         
        /* H Blanking */
        tmp= pEDIDData[3 + i + d];
        tmp1 = pEDIDData[4 + i + d];

        hBlanking = ((tmp1 & 0x0F) << 8) + tmp;

         
        /* H Sync Offset */
        tmp = pEDIDData[8 + i + d];
        tmp1 = pEDIDData[11 + i + d];
        horSyncOffset = ((tmp1 & 0xC0) << 2) + tmp;

         
        /* H Sync Pulse Width */
        tmp = pEDIDData[9 + i + d];
        tmp1 = pEDIDData[11 + i + d];
        horSyncPluseWidth = ((tmp1 & 0x30) << 4) + tmp;

         
        /* V Active */
        tmp = pEDIDData[5 + i + d];
        tmp1 = pEDIDData[7 + i + d];
        vActive = ((tmp1 & 0xF0) << 4) + tmp;

         
        /* V Blanking */
        tmp= pEDIDData[6 + i + d];
        tmp1 = pEDIDData[7 + i + d];
        vBlanking = ((tmp1 & 0x0F) << 8) + tmp;

         
        /* V Sync Offset */
        tmp = pEDIDData[10 + i + d];
        tmp1 = pEDIDData[11 + i + d];
        verSyncOffset = ((tmp1 & 0x0C) << 6) + ((tmp & 0xF0) >> 4);

         
        /* V Sync Pluse Width */
        tmp = pEDIDData[10 + i + d];
        tmp1 = pEDIDData[11 + i + d];
        verSyncPluseWidth = ((tmp1 & 0x03) << 8) + (tmp & 0x0F);

         
        /* Flag */
        tmp = pEDIDData[17 + i + d];
        if (tmp & 0x80)
            isInterlace = TRUE;
        else
            isInterlace = FALSE;

         
        /* horizontal polarity*/
        if (tmp & 0x1)
            horSyncPolarity = POSITIVE;
        else
            horSyncPolarity = NEGATIVE;

         
        /* verticle polarity*/
        if (tmp & 0x2)
            verSyncPolarity = POSITIVE;
        else
            verSyncPolarity = NEGATIVE;

        if (newMode) {
            newMode->type = M_T_DRIVER;
            newMode->Clock = pixelClock / 1000;
            newMode->HDisplay = hActive;
            newMode->HSyncStart = hActive + horSyncOffset;
            newMode->HSyncEnd = newMode->HSyncStart + horSyncPluseWidth;
            newMode->HTotal = hActive + hBlanking;
            newMode->VDisplay = vActive;
            newMode->VSyncStart = vActive + verSyncOffset;
            newMode->VSyncEnd = newMode->VSyncStart + verSyncPluseWidth;
            newMode->VTotal = vActive + vBlanking;

            if (isInterlace)
                newMode->Flags |= V_INTERLACE;

            if (horSyncPolarity == POSITIVE)
                newMode->Flags |= V_PHSYNC;
            else
                newMode->Flags |= V_NHSYNC;

            if (verSyncPolarity == POSITIVE)
                newMode->Flags |= V_PVSYNC;
            else
                newMode->Flags |= V_NVSYNC;

            if (newMode->HDisplay && newMode->VDisplay) {
                xf86SetModeDefaultName(newMode);
                modes = xf86ModesAdd(modes, newMode);
            }

            DEBUG(ErrorF("Add new mode %s from extend EDID\n", newMode->name));
        }
    }

    return modes;
}

static void
loadHdmiDefaultDPASetting(CARD32 chipset, CARD32 port)
{
    if (port == DISP_DI_DVP1) {
        switch (chipset) {
        case VIA_CX700:
            viaWriteVgaIoBits(REG_SR65, 0x0B, 0x0F);
            viaWriteVgaIoBits(REG_CR9B, 0x00, 0x0F);
            break;

        case VIA_VX800:
            viaWriteVgaIoBits(REG_SR65, 0x0B, 0x0F);
            viaWriteVgaIoBits(REG_CR9B, 0x0F, 0x0F);
            break;

        case VIA_VX855:
            viaWriteVgaIoBits(REG_SR65, 0x0B, 0x0F);
            viaWriteVgaIoBits(REG_CR9B, 0x0F, 0x0F);
            break;

        case VIA_VX900:
            /* Sync VBIOS DPA setting */
            viaWriteVgaIoBits(REG_SR65, 0x09, 0x0F);
            viaWriteVgaIoBits(REG_CR9B, 0x09, 0x0F);
            break;

        default:
            break;
        }
    }
}

static void
viaSetDotClock(xf86OutputPtr output, DisplayModePtr mode, int igaPath)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr  pVia = VIAPTR(pScrn);
    int i;
    CARD32  PLL= 0;

    switch (pVia->Chipset) {
    case VIA_VX855:
    case VIA_VX900:
        for (i = 0; ViaDotClocks[i].DotClock; i++) {
            if (ViaDotClocks[i].DotClock == mode->Clock) {
                PLL = ViaDotClocks[i].PLL3_409;
                break;
            }
        }
        break;

    default:
        for (i = 0; ViaDotClocks[i].DotClock; i++) {
            if (ViaDotClocks[i].DotClock == mode->Clock) {
                PLL = ViaDotClocks[i].PLL3;
                break;
            }
        }
        break;
    }

    viaSetVCLK(pVia, PLL, igaPath);
}

static void
viaPrintModeList(DisplayModePtr modeList)
{
    DEBUG(ErrorF("viaPrintModeList\n"));

    DisplayModePtr mode;

    for (mode = modeList; ; mode = mode->next) {
        DEBUG(ErrorF("mode name = %s\n", mode->name));
        DEBUG(ErrorF("mode HDisplay = %d\n", mode->HDisplay));
        DEBUG(ErrorF("mode VDisplay = %d\n", mode->VDisplay));
        DEBUG(ErrorF("mode CrtcHDisplay = %d\n", mode->CrtcHDisplay));
        DEBUG(ErrorF("mode CrtcVDisplay = %d\n", mode->CrtcVDisplay));
        if (mode->Flags & V_INTERLACE)
            DEBUG(ErrorF("interlace\n"));
        else
            DEBUG(ErrorF("non-interlace\n"));

        if (mode->Flags & V_DBLSCAN)
            DEBUG(ErrorF("double scan\n"));
        else
            DEBUG(ErrorF("non-double scan\n"));

        if ((mode->next == modeList) || (mode->next ==  NULL))
            break;  /* The end of mode list. */
    }
}

static DisplayModePtr
viaAddCEAModeLine(xf86OutputPtr output,
            CARD8 *extEDID, DisplayModePtr stCEAModes)
{
    int     i = 0, k = 0;
    Bool firstNativeMode = TRUE;
    CARD8   tmp = 0;
    CARD8   VideoBlockIndex = 0;
    CARD32  DescriptorNum = 0;
    CARD8   HDMIModeIndex;
    DisplayModePtr  newMode = NULL;
    DisplayModePtr  modeList = NULL;
    ViaHdmiPrivateInfoPtr viaHdmiInfo = output->driver_private;

    if (viaHdmiInfo->attachAllModes) {
        while (ViaCEAModes[k].name) {
            if (CEATimingTable[k].IsBuilt) {
                newMode = xnfalloc(sizeof(DisplayModeRec));
                if (newMode) {
                    memcpy(newMode, &ViaCEAModes[k], sizeof(DisplayModeRec));
                    newMode->name = xnfstrdup(ViaCEAModes[k].name);
                    modeList = xf86ModesAdd(modeList, newMode);
                    DEBUG(ErrorF("Just add CEA mode ID:%d %dx%d@%d I:%d\n",
                          k,
                          CEATimingTable[k].HorSize,
                          CEATimingTable[k].VerSize,
                          CEATimingTable[k].RefreshRate,
                          CEATimingTable[k].ScanType));
                }
            }
            k++;
        }
        return modeList;
    }

     
    /* Byte 04 is where the Data Block Collection begins */
    VideoBlockIndex = 4;
    tmp = extEDID[4];
     
    /* Locate Video Block */
    /* Bit[7:5]: Block Type Tag: value 2 is video specific*/
    while (((tmp & 0xE0) != 0x40)
         && (VideoBlockIndex < (extEDID[2]))) {
          
        /* Bit[4:0]:
        Total number of bytes in this block following this byte */
        tmp &= 0x1F;

        /* The next byte is assumed to be the beginning of the
           next data block. */
        VideoBlockIndex += (tmp + 1);

        /* Locate the next data block */
        tmp = extEDID[VideoBlockIndex];
    }
    if ((tmp & 0xE0) == 0x40) {
        DescriptorNum = tmp & 0x1F;

        for (i = 0; i< DescriptorNum; i++) {
            tmp = extEDID[VideoBlockIndex + 1 + i];
            HDMIModeIndex = tmp & 0x7F;

            DEBUG(ErrorF("Monitor support CEA mode ID:%d %dx%d@%d I:%d\n",
                  HDMIModeIndex,
                  CEATimingTable[HDMIModeIndex-1].HorSize,
                  CEATimingTable[HDMIModeIndex-1].VerSize,
                  CEATimingTable[HDMIModeIndex-1].RefreshRate,
                  CEATimingTable[HDMIModeIndex-1].ScanType));

            if (CEATimingTable[HDMIModeIndex-1].IsBuilt &&
                ViaCEAModes[HDMIModeIndex-1].name != NULL) {

                newMode = xnfalloc(sizeof(DisplayModeRec));
                if (newMode) {
                    memcpy(newMode, &ViaCEAModes[HDMIModeIndex - 1],
                            sizeof(DisplayModeRec));
                    newMode->name =
                            xnfstrdup(ViaCEAModes[HDMIModeIndex - 1].name);
                    if ((tmp & 0x80) && firstNativeMode) {
                        newMode->type |= M_T_PREFERRED;
                        firstNativeMode = FALSE;
                    }
                    modeList = xf86ModesAdd(modeList, newMode);
                    DEBUG(ErrorF("Driver add CEA mode ID:%d %dx%d@%d I:%d\n",
                          HDMIModeIndex,
                          CEATimingTable[HDMIModeIndex - 1].HorSize,
                          CEATimingTable[HDMIModeIndex - 1].VerSize,
                          CEATimingTable[HDMIModeIndex - 1].RefreshRate,
                          CEATimingTable[HDMIModeIndex - 1].ScanType));
                }
            }
        }
    }

    if (firstNativeMode)
        xf86ModesAdd (modeList, stCEAModes);

    return modeList;
}

static CARD32
viaHotplugTimer(OsTimerPtr timer, CARD32 now, pointer arg)
{
    xf86OutputPtr output = (xf86OutputPtr) arg;
    ViaOutputInfo commonInfo = ((ViaHdmiPrivateInfoPtr)(output->driver_private))->commonInfo;
    CARD32 serialPort = commonInfo.serialPort;
    CARD8 state;
    CARD8 state2;

    if (SUBCHIP_AD9389 == commonInfo.subChipName) {
        state = via_ad9389_power_state(serialPort);
        state2 = via_ad9389_hot_plug_state(serialPort);

        /* if connected but disable */
        if ((state == 0x50) && (state2 & 0x40))
            viaInitializeAD9389(output);
    }

    /* 3 sec */
    return 3000;
}

/* calcute the BCH code and output 1 byte BCH code */
CARD8
viaInsertBCHCode(CARD8 *input, CARD32 length)
{
    CARD32   i, n;
    CARD32   reg[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    CARD32   matrix[56];
    CARD8   output = 0;

    // initialize matrix
    for (i = 0; i < length; i++) {
        matrix[0 + i * 8] = (input[i] >> 0) & BIT0;
        matrix[1 + i * 8] = (input[i] >> 1) & BIT0;
        matrix[2 + i * 8] = (input[i] >> 2) & BIT0;
        matrix[3 + i * 8] = (input[i] >> 3) & BIT0;
        matrix[4 + i * 8] = (input[i] >> 4) & BIT0;
        matrix[5 + i * 8] = (input[i] >> 5) & BIT0;
        matrix[6 + i * 8] = (input[i] >> 6) & BIT0;
        matrix[7 + i * 8] = (input[i] >> 7) & BIT0;
    }

    for (i = 0; i < length * 8; i++) {
        reg[0] = reg[8] ^ matrix[i];
        reg[8] = reg[7] ^ reg[0];
        reg[7] = reg[6] ^ reg[0];

        reg[6] = reg[5];
        reg[5] = reg[4];
        reg[4] = reg[3];
        reg[3] = reg[2];
        reg[2] = reg[1];
        reg[1] = reg[0];
    }

    n = 0;
    for (i = 1; i <= 4; i++) {
        if (reg[i] == 1)
            n = 2 * n + 1;
        else
            n = 2 * n;
    }

    output |= n << 4;

    n = 0;
    for (i = 5; i <= 8; i++) {
        if (reg[i] == 1)
            n = 2 * n + 1;
        else
            n = 2 * n;
    }

    output |= n;

    return output;
}

void
viaSetAVIInfoFrame(DisplayModePtr mode)
{
    viaHDMI_InfoFrameRec  InfoFramePacket;
    CARD32   i = 0;
    CARD8   checksum = 0;
    CARD32   mmC204, mmC208, mmC20C, mmC210;
    CARD32   mmC214, mmC218, mmC21C, mmC220, mmC224;
    CEATimingInfoPtr ceaTimingInfoPtr = &CEATimingTable[mode->HSkew - 1];

    InfoFramePacket.PacketHeader[0] = 0x82;
    InfoFramePacket.PacketHeader[1] = 0x02;
    InfoFramePacket.PacketHeader[2] = 0x0D;
    InfoFramePacket.ECCCode = viaInsertBCHCode(InfoFramePacket.PacketHeader, 3);

    // set Packet Bytes
    for (i = 0; i < 28; i++)
        InfoFramePacket.PacketByte[i] = 0;

    InfoFramePacket.PacketByte[1] |= 0x2;

    InfoFramePacket.PacketByte[2] |= 0x08;

    switch (ceaTimingInfoPtr->Ratio) {
    case RATIO_4_3:
        InfoFramePacket.PacketByte[2] |= 0x10;
        break;
    case RATIO_16_9:
        InfoFramePacket.PacketByte[2] |= 0x20;
        break;
    default:
        break;
    }

    InfoFramePacket.PacketByte[3] |= 0x80;

    InfoFramePacket.PacketByte[4] = ceaTimingInfoPtr->ID;

    for (i = 1; i < 28; i++)
        checksum += InfoFramePacket.PacketByte[i];
    checksum += (0x82 + 0x02 + 0x0D);

    checksum = 0x100 - checksum;
    InfoFramePacket.PacketByte[0] = checksum;

    for (i = 0; i < 4; i++) {
        InfoFramePacket.BCHCode[i] =
                viaInsertBCHCode(&(InfoFramePacket.PacketByte[i * 7]), 7);
    }

    mmC204 = (InfoFramePacket.ECCCode << 24 ) |
             (InfoFramePacket.PacketHeader[2] << 16) |
             (InfoFramePacket.PacketHeader[1] << 8) |
             InfoFramePacket.PacketHeader[0];
    mmC208 = (InfoFramePacket.PacketByte[3] << 24) |
             (InfoFramePacket.PacketByte[2] << 16) |
             (InfoFramePacket.PacketByte[1] << 8) |
             InfoFramePacket.PacketByte[0];
    mmC20C = (InfoFramePacket.BCHCode[0] << 24) |
             (InfoFramePacket.PacketByte[6] << 16) |
             (InfoFramePacket.PacketByte[5] << 8) |
             InfoFramePacket.PacketByte[4];
    mmC210 = (InfoFramePacket.PacketByte[10] << 24) |
             (InfoFramePacket.PacketByte[9] << 16) |
             (InfoFramePacket.PacketByte[8] << 8) |
             InfoFramePacket.PacketByte[7];
    mmC214 = (InfoFramePacket.BCHCode[1] << 24) |
             (InfoFramePacket.PacketByte[13] << 16) |
             (InfoFramePacket.PacketByte[12] << 8) |
             InfoFramePacket.PacketByte[11];
    mmC218 = (InfoFramePacket.PacketByte[17] << 24) |
             (InfoFramePacket.PacketByte[16] << 16) |
             (InfoFramePacket.PacketByte[15] << 8) |
             InfoFramePacket.PacketByte[14];
    mmC21C = (InfoFramePacket.BCHCode[2] << 24) |
             (InfoFramePacket.PacketByte[20] << 16) |
             (InfoFramePacket.PacketByte[19] << 8) |
             InfoFramePacket.PacketByte[18];
    mmC220 = (InfoFramePacket.PacketByte[24] << 24) |
             (InfoFramePacket.PacketByte[23] << 16) |
             (InfoFramePacket.PacketByte[22] << 8) |
             InfoFramePacket.PacketByte[21];
    mmC224 = (InfoFramePacket.BCHCode[3] << 24) |
             (InfoFramePacket.PacketByte[27] << 16) |
             (InfoFramePacket.PacketByte[26] << 8) |
             InfoFramePacket.PacketByte[25];

    MMIO_WR(0xC204, mmC204);
    MMIO_WR(0xC208, mmC208);
    MMIO_WR(0xC20C, mmC20C);
    MMIO_WR(0xC210, mmC210);
    MMIO_WR(0xC214, mmC214);
    MMIO_WR(0xC218, mmC218);
    MMIO_WR(0xC21C, mmC21C);
    MMIO_WR(0xC220, mmC220);
    MMIO_WR(0xC224, mmC224);

    MMIO_WR(0xC200, 0x80);

}

void
viaSetAudioInfoFrame()
{
    viaHDMI_InfoFrameRec  InfoFramePacket;
    CARD32   i = 0;
    CARD8   checksum = 0;
    CARD32   mmC204, mmC208, mmC20C, mmC210;
    CARD32   mmC214, mmC218, mmC21C, mmC220, mmC224;

    InfoFramePacket.PacketHeader[0] = 0x84;
    InfoFramePacket.PacketHeader[1] = 0x01;
    InfoFramePacket.PacketHeader[2] = 0x0A;
    InfoFramePacket.ECCCode = viaInsertBCHCode(InfoFramePacket.PacketHeader, 3);

    // set Packet Bytes
    for (i = 0; i < 28; i++)
        InfoFramePacket.PacketByte[i] = 0;

    InfoFramePacket.PacketByte[1] |= 0x0;

    InfoFramePacket.PacketByte[1] |= 0x00;

    InfoFramePacket.PacketByte[2] |= 0x00;

    InfoFramePacket.PacketByte[2] |= 0x00;

    for (i = 1; i < 28; i++)
        checksum += InfoFramePacket.PacketByte[i];
    checksum += ( 0x84 + 0x01 + 0x0A );

    checksum = 0x100 - checksum;
    InfoFramePacket.PacketByte[0] = checksum;

    for (i = 0; i < 4; i++) {
        InfoFramePacket.BCHCode[i] =
                viaInsertBCHCode( &(InfoFramePacket.PacketByte[i * 7]), 7);
    }

    mmC204 = (InfoFramePacket.ECCCode << 24 ) |
             (InfoFramePacket.PacketHeader[2] << 16) |
             (InfoFramePacket.PacketHeader[1] << 8) |
             InfoFramePacket.PacketHeader[0];
    mmC208 = (InfoFramePacket.PacketByte[3] << 24) |
             (InfoFramePacket.PacketByte[2] << 16) |
             (InfoFramePacket.PacketByte[1] << 8) |
             InfoFramePacket.PacketByte[0];
    mmC20C = (InfoFramePacket.BCHCode[0] << 24) |
             (InfoFramePacket.PacketByte[6] << 16) |
             (InfoFramePacket.PacketByte[5] << 8) |
             InfoFramePacket.PacketByte[4];
    mmC210 = (InfoFramePacket.PacketByte[10] << 24) |
             (InfoFramePacket.PacketByte[9] << 16) |
             (InfoFramePacket.PacketByte[8] << 8) |
             InfoFramePacket.PacketByte[7];
    mmC214 = (InfoFramePacket.BCHCode[1] << 24) |
             (InfoFramePacket.PacketByte[13] << 16) |
             (InfoFramePacket.PacketByte[12] << 8) |
             InfoFramePacket.PacketByte[11];
    mmC218 = (InfoFramePacket.PacketByte[17] << 24) |
             (InfoFramePacket.PacketByte[16] << 16) |
             (InfoFramePacket.PacketByte[15] << 8) |
             InfoFramePacket.PacketByte[14];
    mmC21C = (InfoFramePacket.BCHCode[2] << 24) |
             (InfoFramePacket.PacketByte[20] << 16) |
             (InfoFramePacket.PacketByte[19] << 8) |
             InfoFramePacket.PacketByte[18];
    mmC220 = (InfoFramePacket.PacketByte[24] << 24) |
             (InfoFramePacket.PacketByte[23] << 16) |
             (InfoFramePacket.PacketByte[22] << 8) |
             InfoFramePacket.PacketByte[21];
    mmC224 = (InfoFramePacket.BCHCode[3] << 24) |
             (InfoFramePacket.PacketByte[27] << 16) |
             (InfoFramePacket.PacketByte[26] << 8) |
             InfoFramePacket.PacketByte[25];

    MMIO_WR(0xC204, mmC204);
    MMIO_WR(0xC208, mmC208);
    MMIO_WR(0xC20C, mmC20C);
    MMIO_WR(0xC210, mmC210);
    MMIO_WR(0xC214, mmC214);
    MMIO_WR(0xC218, mmC218);
    MMIO_WR(0xC21C, mmC21C);
    MMIO_WR(0xC220, mmC220);
    MMIO_WR(0xC224, mmC224);

    MMIO_WR(0xC200, 0x81);

}

CARD32
viaGetSampleRate(void)
{
    CARD32 mmC4D4, mmC4D8, hdacSampleRate = 0;


    /* step 1. read out C4D8 */
    mmC4D4 = MMIO_RD(0xC4D4) & 0x00FFFFFF;
    mmC4D4 |=  0x01000000;      /* stream format */
    MMIO_WR(0xC4D4, mmC4D4);

    mmC4D8 = MMIO_RD(0xC4D8); /* [15:0] */

    /*
     * step 2. decode C4D8 by definition of C45C
     * C45C [14] Converter_Format_Base
     * BASE. Converter Format Sample Base Rate. (PCM Format structure bit 14)
     *              0: 48kHz
     *              1: 44.1kHz
     * C45C [13:11] Converter_Format_Mult
     * MULT. Converter Format Sample Base Rate Multiple. (PCM Format structure bits 13:11)
     *              000: 48kHz/ 44.1 kHz or lesss
     *              001: x2 (96kHz, 88.2kHz, 32kHz)
     *              010: x3 (144kHz)
     *              011: x4 (192kHz, 176.4kHz)
     *              100-111: Reserved
     * C45C [10:8] Converter_Format_Div
     * DIV. Converter Format Sample Base Rate Divisor. (PCM Format structure bits 10:8)
     *              000: Divide by 1 (48kHz, 44.1 kHz)
     *              001: Divide by 2 (24kHz, 22.05kHz)
     *              010: Divide by 3 (16kHz, 32kHz)
     *              011: Divide by 4 (11.025kHz)
     *              100: Divide by 5 (9.6kHz)
     *              101: Divide by 6 (8kHz)
     *              110: Divide by 7
     *              111: Divide by 8 (6kHz)
     */
    if (mmC4D8 & 0x4000)
        hdacSampleRate = 44100;
    else
        hdacSampleRate = 48000;

    switch ((mmC4D8 & 0x3800) >> 11) {
    case 1:
        hdacSampleRate *= 2;
        break;
    case 2:
        hdacSampleRate *= 3;
        break;
    case 3:
        hdacSampleRate *= 4;
        break;
    default:
        break;
    }

    switch ((mmC4D8 & 0x700) >> 8) {
    case 1:
        hdacSampleRate /= 2;
        break;
    case 2:
        hdacSampleRate /= 3;
        break;
    case 3:
        hdacSampleRate /= 4;
        break;
    case 4:
        hdacSampleRate /= 5;
        break;
    case 5:
        hdacSampleRate /= 6;
        break;
    case 6:
        hdacSampleRate /= 7;
        break;
    case 7:
        hdacSampleRate /= 8;
        break;
    default:
        break;
    }

    return hdacSampleRate;
}

Bool
viaSetHDAudioSampleRate(CARD32 hdacSampleRate, CARD32 hdacPixelClock)
{
    CARD32  mmC400 = 0, mmC404 = 0, mmC410 = 0, mmC414 = 0;
    unsigned long long hdacWallClock = 0, hdacPacketClock = 0;
    unsigned long long two2fourty = 1099511627776LL;  /* 2^40 */

    if (hdacPixelClock == 0 || hdacSampleRate == 0)  {
        DEBUG(ErrorF("viaSetHDAudioSampleRate : divide by zero error!\n"));
        return FALSE;
    }

    mmC404 = MMIO_RD(0xC404) & 0xFFFFFF00;
    mmC414 = MMIO_RD(0xC414) & 0xFFFFFF00;

    hdacWallClock = two2fourty / hdacPixelClock;
    hdacWallClock *= 24000000;
    mmC400 = (CARD32)(hdacWallClock & 0xFFFFFFFF);
    mmC404 |= (CARD32)(hdacWallClock >> 32);

    MMIO_WR(0xC404, mmC404);
    MMIO_WR(0xC400, mmC400);

    hdacPacketClock = hdacSampleRate * two2fourty;
    hdacPacketClock /= hdacPixelClock;
    mmC410 = (CARD32)(hdacPacketClock & 0xFFFFFFFF);
    mmC414 |= (CARD32)(hdacPacketClock >> 32);

    MMIO_WR(0xC414, mmC414);
    MMIO_WR(0xC410, mmC410);

    return TRUE;
}

Bool
viaSetHDAudioCTSandN(CARD32 hdacSampleRate, CARD32 hdacPixelClock)
{
    CARD32  mmC294 = 0, mmC298 = 0, mmC29C = 0;
    unsigned long long int  CTS = 0, N = 0;

    if (hdacPixelClock == 0 || hdacSampleRate == 0) {
        DEBUG(ErrorF("viaSetHDAudioCTSandN : divide by zero error!\n"));
        return FALSE;
    }


    /* 
    * CTS and N value setting refer to 2.6.38 kernel
    * drivers/gpu/drm/radeon/r600_hdmi.c
    * r600_hdmi_calc_CTS funtion.
    * we fix N to 6144, and calculate CTS here.
    */
    N = 6144;
    CTS = (unsigned long long)(hdacPixelClock) * N;
    CTS /= (unsigned long long)(128 * hdacSampleRate);

    mmC294 = (MMIO_RD(0xc294) & 0x0000000F) | 0x100000C0;
    /* notes: C294[27:8] shoule be the same value as cts */
    mmC294 |= ((CARD32)(CTS) << 8);
    MMIO_WR(0xC294, mmC294);

    mmC298 = (CARD32)(N) | (((CARD32)(CTS) & 0xFFF ) << 20);
    MMIO_WR(0xC298, mmC298);

    mmC29C = MMIO_RD(0xC29C) & 0xFFFFFF00;
    mmC29C |= (((CARD32)(CTS) >> 12) & 0xFF);
    MMIO_WR(0xC29C, mmC29C);

    return TRUE;
}

void
viaSetHDAudioParameter(DisplayModePtr mode)
{
    CARD32   mmC4D4, mmC4D8, mmC424, hdacSampleRate, hdacPixelClock;

    hdacPixelClock = mode->Clock * 1000;

    hdacSampleRate = viaGetSampleRate();

    /* C424[14:13] codec type. related with mm c618, mm c698 */
    mmC424 = MMIO_RD(0xC424) & 0xFFFF9FFF;

    MMIO_WR(0xC424, mmC424);

    /* calculate C400, C404, C410 and C414 */
    viaSetHDAudioSampleRate(hdacSampleRate, hdacPixelClock);

    /* fill CTS & N according to Table7-1, 7-2, 7-3 of HDMI spec 1.3 */
    viaSetHDAudioCTSandN(hdacSampleRate, hdacPixelClock);

}

void
viaSetInfoFrameData(DisplayModePtr mode)
{
    viaSetAVIInfoFrame(mode);
    viaSetAudioInfoFrame();
}

void
viaSetIntegratedHDMIMode(VIAPtr pVia, DisplayModePtr mode, int igaPath)
{
    /* Infoframe setting */
    viaSetInfoFrameData(mode);
    viaSetHDAudioParameter(mode);

    /* 135MHz ~ 270MHz */
    if (mode->Clock >= 135000)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x00000000, 0xC0000000);
    /* 67.5MHz ~ <135MHz */
    else if (mode->Clock >= 67500)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x40000000, 0xC0000000);
    /* 33.75MHz ~ <67.5MHz */
    else if (mode->Clock >= 33750)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x80000000, 0xC0000000);
    /* 25MHz ~ <33.75MHz */
    else
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0xC0000000, 0xC0000000);

    /* touch C282 when init HDMI by mode 720x576, 720x480, or other modes */
    if ((mode->HDisplay == 720) && (mode->VDisplay == 576))
        MMIO_WR(0xC280, 0x18232402);
    else if ((mode->HDisplay == 720) && (mode->VDisplay == 480))
        MMIO_WR(0xC280, 0x181f2402);
    else
        MMIO_WR(0xC280, 0x18330002);

    /* power down to reset */
    MMIO_WR_MASK(0xC740, 0x00000000, 0x06000000);
    /*make sure Tpll/Tpll reg are off*/
    viaDelay_Nmsec(pVia, 375);
    // enable
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x00000001, 0x00000001);
    /* select HDMI mode */
    MMIO_WR_MASK(0xC748, 0, BIT0);
    /* enable HDMI with HDMI mode */
    MMIO_WR_MASK(0xC280, 0x0, 0x40);
    /* select AC mode */
    MMIO_WR_MASK(0xC74C, 0x40, 0x40);
    /* enable InfoFrame */
    MMIO_WR(0xC284, 0x20000102);
    /* set status of Lane0~3 */
    MMIO_WR_MASK(0xC744, 0x00FFFF82, 0x00FFFF82);
    MMIO_WR(0xC0B4, 0x92000000);
    /* enable audio packet */
    MMIO_WR_MASK(0xC294, 0x10000000, 0x10000000);
    /* enable InfoFrame */
    MMIO_WR(0xC284, 0x20000102);
    MMIO_WR_MASK(0xC740, 0x1E4CBE7F, 0x3FFFFFFF);
    MMIO_WR_MASK(0xC748, 0x84509180, 0x001FFFFF);
    /* Select PHY Function as HDMI */
    /* Select HDTV0 source */
    if (IGA1 == igaPath)
        write_reg_mask(CRFF, VIACR, BIT0, BIT1 + BIT0);
    else
        write_reg_mask(CRFF, VIACR, BIT1 + BIT0, BIT1 + BIT0);

}

// Save for BIOS current setting
static void
via_hdmi_save(xf86OutputPtr output)
{
    ViaOutputInfo commonInfo = ((ViaHdmiPrivateInfoPtr)
            (output->driver_private))->commonInfo;
    CARD32 subChipName = commonInfo.subChipName;

    switch (subChipName) {
    case SUBCHIP_AD9389:
        viaSaveAD9389Regs(output);
        break;
    case SUBCHIP_INTEGRATED_HDMI:
        viaSaveInternalHdmiRegs(output);
        break;
    default:
        break;
    }
}

static void
via_hdmi_restore(xf86OutputPtr output)
{
    ViaOutputInfo commonInfo = ((ViaHdmiPrivateInfoPtr)
            (output->driver_private))->commonInfo;
    CARD32 subChipName = commonInfo.subChipName;

    switch (subChipName) {
    case SUBCHIP_AD9389:
        viaRestoreAD9389Regs(output);
        break;
    case SUBCHIP_INTEGRATED_HDMI:
        viaRestoreInternalHdmiRegs(output);
        break;
    default:
        break;
    }
}

static void
via_hdmi_dpms(xf86OutputPtr output, int mode)
{
     DEBUG(ErrorF("via_hdmi_dpms, mode = %d\n", mode));

     ScrnInfoPtr    pScrn = output->scrn;
     VIAPtr         pVia = VIAPTR(pScrn);
     ViaOutputInfo  commonInfo = ((ViaHdmiPrivateInfoPtr)
                                    (output->driver_private))->commonInfo;
     ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;
     CARD32         subChipName = commonInfo.subChipName;
     CARD32         serialPort = hdmiInfo->commonInfo.serialPort;
     CARD32         diPort = commonInfo.diPort;
     int            usedIga;

    switch (mode) {
    case DPMSModeOn: /* 0 */
        usedIga = ((VIACrtcPrivatePtr)(output->crtc->driver_private))->iga;
        if (NONE_SUBCHIP == subChipName)
            return;

        /*1. Turn on DI port clock, set Iga source for DI port*/
        viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga, pVia->Chipset);

        if (SUBCHIP_AD9389 == subChipName) {
            /*2. Enable HDMI transmitter*/
            DEBUG(ErrorF("Initial AD9389\n"));
            viaInitializeAD9389(output);
        } else if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            // enable video
            MMIO_WR_MASK(0xC640, 0x8, 0x8);
            // enable HDMI
            MMIO_WR_MASK(0xC280, 0x2, 0x2);
        }

        /*3. Insert a hotplug timer */
        if ((commonInfo.hasHotplug) && (!hdmiInfo->hotplugTimer))
            hdmiInfo->hotplugTimer = TimerSet(NULL, 0, 3000,
                                        viaHotplugTimer, output);

        /* HDMI CTS Update timer */
        if (!hdmiInfo->ctsUpdateTimer) {
            hdmiInfo->ctsUpdateTimer = TimerSet(NULL, 0, VIAUPDATE_TIMER,
                                viaHdmiCtsUpdateTimer, output);
        }

        break;

    case DPMSModeStandby:   /* 1 */
    case DPMSModeSuspend:   /* 2 */
    case DPMSModeOff:       /* 3 */

        if (NONE_SUBCHIP == subChipName)
            return;

        /* unload hotplug Timer */
        if (hdmiInfo->hotplugTimer) {
            TimerCancel(hdmiInfo->hotplugTimer);
            hdmiInfo->hotplugTimer=NULL;
        }

        /* unload cts Update timer */
        if (hdmiInfo->ctsUpdateTimer) {
            TimerCancel(hdmiInfo->ctsUpdateTimer);
            hdmiInfo->ctsUpdateTimer=NULL;
            /* Clear the cts Update variables, ready for re-enable cts Update timer. */
            hdacUpdateVar.PixelClockSaved = 0;
            hdacUpdateVar.HdacSampleRateSaved = 0;
            hdacUpdateVar.isIga2Hdmi =0;
            hdacUpdateVar.CTS = 0;
            hdacUpdateVar.Interval =0;
            hdacUpdateVar.Feedback =0;
            hdacUpdateVar.Counter =0;
            hdacUpdateVar.Increaser =0;
        }

        if (SUBCHIP_AD9389 == subChipName)
            via_dpms_off_ad9389(serialPort);
        else if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            // disable video
            MMIO_WR_MASK(0xC640, 0x0, 0x8);
            // disable HDMI
            MMIO_WR_MASK(0xC280, 0x0, 0x2);
        }

        viaDIPortPadOff(pScrn->scrnIndex, diPort);
        break;

    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

/*
* Saves the crtc's state for restoration on VT switch.

static void
via_hdmi_save (xf86OutputPtr output)
{
}
*/
/*
* Restore's the crtc's state at VT switch.

static void
via_hdmi_restore (xf86OutputPtr output)
{
}
*/
/*
 * Callback for testing a video mode for a given output.
 *
 * This function should only check for cases where a mode can't be supported
 * on the pipe specifically, and not represent generic CRTC limitations.
 *
 * return MODE_OK if the mode is valid, or another MODE_* otherwise.
 */
static int
via_hdmi_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr    pScrn = output->scrn;
    VIAPtr         pVia = VIAPTR(pScrn);

    /* Currently, only VX855 can support CEA interlace mode. */
    if ((pVia->Chipset < VIA_VX855) && (mode->Flags & V_INTERLACE))
        return MODE_NOMODE;

    if (mode->type & M_T_DRIVER)
        return MODE_OK;
    else
        return MODE_NOMODE;
}

static Bool
via_hdmi_mode_fixup(xf86OutputPtr output,
                         DisplayModePtr mode,
                         DisplayModePtr adjusted_mode)
{
    return TRUE;
}

static void
via_hdmi_mode_set(xf86OutputPtr output,
                       DisplayModePtr mode,
                       DisplayModePtr adjusted_mode)
{
    DEBUG(ErrorF("via_hdmi_mode_set\n"));
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr      pVia = VIAPTR(pScrn);
    CARD8       reg0x17;
    CARD8       reg0x46;
    ViaHdmiPrivateInfoPtr viaHdmiInfo = output->driver_private;
    CARD32      serialPort = viaHdmiInfo->commonInfo.serialPort;
    CARD32      diPort = viaHdmiInfo->commonInfo.diPort;
    CARD32      subChipName = viaHdmiInfo->commonInfo.subChipName;
    VIACrtcPrivatePtr   viaCrtc = VIACrtcPrivate(output->crtc);
    int usedIga = viaCrtc->iga;

    /* update sync polarity */
    setDiportSyncPolarity(pScrn->scrnIndex,
        viaHdmiInfo->commonInfo.diPort, adjusted_mode);

    /* Important: Use HSkew to indicate CEA mode ID. Because the others
       parameters will be clear by Xorg. I have no choice, there is only this
       parameter can be used. This should be fixed when we found a better
       solution.
    */
    CEATimingInfoPtr ceaTimingInfoPtr =
        &CEATimingTable[adjusted_mode->HSkew - 1];

    /* Set aspect ratio */
    if (SUBCHIP_AD9389 == subChipName)
        via_ad9389_set_video_aspect_ratio(serialPort, adjusted_mode);
    else if (SUBCHIP_INTEGRATED_HDMI == subChipName)
        viaSetIntegratedHDMIMode(pVia, adjusted_mode, usedIga);

    /* Set Pixel Timing register */
    if (usedIga == IGA1)
        viaLoadCrtcPixelTiming(adjusted_mode);

    /* Set Hsync Offset, delay one clock */
    viaWriteVgaIoBits(REG_CR8A, 0x01, 0x7);

    /* If CR8A +1, HSyc must -1 */
    viaWriteVgaIo(REG_CR56, viaReadVgaIo(REG_CR56) - 1);
    viaWriteVgaIo(REG_CR57, viaReadVgaIo(REG_CR57) - 1);

    if (adjusted_mode->Flags & V_INTERLACE) {
       if (viaCrtc->iga == IGA2) {
            switch (pVia->Chipset) {
            case VIA_VX855:
                viaWriteVgaIoBits(REG_CRFB,
                    ceaTimingInfoPtr->VSyncOffset & 0xFF, 0xFF);
                viaWriteVgaIoBits(REG_CRFC,
                    (ceaTimingInfoPtr->VSyncOffset & 0x700) >> 8, 0x07);
                break;

            case VIA_VX900:
                viaWriteVgaIoBits(REG_CRAB,
                    ceaTimingInfoPtr->VSyncOffset & 0xFF, 0xFF);
                viaWriteVgaIoBits(REG_CRAC,
                    (ceaTimingInfoPtr->VSyncOffset & 0x700) >> 8, 0x07);

                /* If CRFC/FB is 0, the counter for HW DVP half-line */
                /* function will underflow and cause it fail */
                /* HW suggestion: set CRFB to 0x02 to bypass DVP half-line */
                /* function and avoid underflow.*/
                viaWriteVgaIoBits(REG_CRFB, 0x02, 0xFF);
                viaWriteVgaIoBits(REG_CRFC, 0x00, 0x07);

                /**
                 * According to information from HW team,
                 * we need to set 0xC280[1] = 1 (HDMI function enable)
                 * or 0xC640[0] = 1 (DP1 enable) to let the half line function work.
                 * Otherwise, the clock for interlace mode will not correct.
                 * This is a special setting for 410.
                 */
                MMIO_WR_MASK(0xC280, BIT1, BIT1);

                break;

            default:
                viaWriteVgaIoBits(REG_CRFB,
                    ceaTimingInfoPtr->VSyncOffset & 0xFF, 0xFF);
                viaWriteVgaIoBits(REG_CRFC,
                    (ceaTimingInfoPtr->VSyncOffset & 0x700) >> 8, 0x07);
                break;
            }
        }
    } else { /* non-interlace, clear interlace setting. */
        if (viaCrtc->iga == IGA2) {
            viaWriteVgaIoBits(REG_CRFB, 0, 0xFF);
            viaWriteVgaIoBits(REG_CRFC, 0, 0x07);
        }
    }

    /*Update for clock skew*/
    loadHdmiDefaultDPASetting(pVia->Chipset, diPort);
    LoadUserGfxDPASetting(diPort, &viaHdmiInfo->userGfxDPA);

}


/* Need TODO to meet hot-plug's behavior */
static xf86OutputStatus
via_hdmi_detect(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_hdmi_detect\n"));

    unsigned char           inputType;
    unsigned char           edidHeader[2];
    ScrnInfoPtr               pScrn = output->scrn;
    VIAPtr                      pVia = VIAPTR(pScrn);
    xf86OutputStatus       status = XF86OutputStatusDisconnected;
    ViaHdmiPrivateInfoPtr viaHdmiInfo = output->driver_private;
    CARD32  subChipName = viaHdmiInfo->commonInfo.subChipName;

    /*if set AttachAllModes ,return XF86OutputStatusConnected .*/
    if (viaHdmiInfo->attachAllModes) {
        status = XF86OutputStatusConnected;
    } else {
        switch (subChipName) {
        case SUBCHIP_INTEGRATED_HDMI:
            /* Internal HDMI read EDID */
            viaSerialReadBytesByHDMI(0xA0, 0, edidHeader, 2);
            if ((edidHeader[0] == 0x00) && (edidHeader[1] == 0xFF)) {
                 
                /* Check input type of EDID. EDID byte 20 bit 7 is input type:
                   0:analog, 1:digital
                   VGA: analog input
                   LCD/DVI/HDMI: digital input */
                viaSerialReadByteByHDMI(0xA0, 20, &inputType);
                inputType =  (inputType & 0x80) >> 7;
                if (inputType == 1) {
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                            "== Detect monitor %s ==\n", output->name);
                    status = XF86OutputStatusConnected;
                }
            }
        break;

        case SUBCHIP_AD9389:
            /*The EDID of the Monitor buffered on AD9389*/
            /*Read HDMI EDID from AD9389 can not check the true connection status.*/
            status = viaDetectAD9389(viaHdmiInfo->commonInfo.serialPort);
        break;

        default:
            status = XF86OutputStatusConnected;
        break;
        }
    }
    return status;
}

static void
via_hdmi_destroy (xf86OutputPtr output)
{
    ViaHdmiPrivateInfoPtr viaHdmiInfo = output->driver_private;

    if (viaHdmiInfo->commonInfo.rawEDID)
        free(viaHdmiInfo->commonInfo.rawEDID);

    if (viaHdmiInfo->savedRegs) {
        free(viaHdmiInfo->savedRegs);
        viaHdmiInfo->savedRegs = NULL;
    }

    if (viaHdmiInfo)
        free(viaHdmiInfo);
}


void
via_hdmi_prepare(xf86OutputPtr output)
{
    output->funcs->dpms (output, DPMSModeOff);
}

void
via_hdmi_commit (xf86OutputPtr output)
{
    DEBUG(ErrorF("via_hdmi_commit\n"));

    output->funcs->dpms (output, DPMSModeOn);
}

/* not care for HSkew */
Bool
viaModesEqual(const DisplayModeRec *pMode1, const DisplayModeRec *pMode2)
{
    if (pMode1->Clock == pMode2->Clock &&
        pMode1->HDisplay == pMode2->HDisplay &&
        pMode1->HSyncStart == pMode2->HSyncStart &&
        pMode1->HSyncEnd == pMode2->HSyncEnd &&
        pMode1->HTotal == pMode2->HTotal &&
        pMode1->VDisplay == pMode2->VDisplay &&
        pMode1->VSyncStart == pMode2->VSyncStart &&
        pMode1->VSyncEnd == pMode2->VSyncEnd &&
        pMode1->VTotal == pMode2->VTotal &&
        pMode1->VScan == pMode2->VScan &&
        pMode1->Flags == pMode2->Flags) {
        return TRUE;
    } else {
        return FALSE;
    }
}


void
viaPruneUnPreferredModes(DisplayModePtr *modeList)
{
    DisplayModePtr m;
    for (m = *modeList; m != NULL; ) {
        DisplayModePtr next = m->next;
        if (m->type & M_T_PREFERRED) {

        } else {
            xf86DeleteMode(modeList, m);
        }
        m = next;
    }
}

//0124
void
viaPruneUnCEAModes(DisplayModePtr *modeList)
{
    DisplayModePtr m;
    int i = 0;

    for (m = *modeList; m != NULL; ) {
        DisplayModePtr next = m->next;

        for (i = 0; i < VIA_CEA_VIDEO_MODES_NUM; i++) {
            if (viaModesEqual((DisplayModeRec *)m, &ViaCEAModes[i]))
                break;
        }
        if (VIA_CEA_VIDEO_MODES_NUM == i)
            xf86DeleteMode(modeList, m);

        m = next;
    }

}

DisplayModePtr
via_hdmi_get_modes (xf86OutputPtr output)
{
    DEBUG(ErrorF("via_hdmi_get_modes\n"));
    ScrnInfoPtr pScrn = output->scrn;
    xf86MonPtr          edid_mon;
    DisplayModePtr      modes = NULL;
    ViaHdmiPrivateInfoPtr viaHdmiInfo = output->driver_private;
    CARD32      subChipName = viaHdmiInfo->commonInfo.subChipName;
    unsigned char *rawEDID = viaHdmiInfo->commonInfo.rawEDID;

    /* Xorg's EDID parser is incorrect to process interlace mode's modeline.
    *  So we don't get modeline from detail timing. we use the EDID's
    *  video block to get the monitor's support capabilities. And we use this
    *  capabilities to map to our builit-in CEA mode table.
    */

    if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
        /* Read Std and Ext EDID block */
        if (viaGetStdEDIDBlockByHDMI(rawEDID)) {
            DEBUG(ErrorF("Read Std EDID Success\n"));
            if (rawEDID[0x7E]) {
                if (viaGetExtEDIDBlockByHDMI(rawEDID + 128, rawEDID[0x7E])) {
                    DEBUG(ErrorF("Read Ext EDID Success\n"));
                    viaHdmiInfo->hasExtEDID = TRUE;
                } else {
                    DEBUG(ErrorF("Read Ext EDID Fail\n"));
                    viaHdmiInfo->hasExtEDID = FALSE;
                }
            } else {
                DEBUG(ErrorF("No extension block\n"));
                viaHdmiInfo->hasExtEDID = FALSE;
            }
        } else {
            DEBUG(ErrorF("Read Std EDID Fail\n"));
        }
        /* Detect the max support mode size */
        viaFindMaxSupportMode(pScrn, rawEDID, rawEDID + 128,
                              &viaHdmiInfo->commonInfo.physicalWidth,
                              &viaHdmiInfo->commonInfo.physicalHeight);
    }

    if ((0x00 == rawEDID[0]) && (0xFF == rawEDID[1])) {
            edid_mon = xf86InterpretEDID(pScrn->scrnIndex, rawEDID);
            if (edid_mon) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                        "== EDID of monitor %s ==\n", output->name);
                xf86PrintEDID(edid_mon);
                xf86OutputSetEDID(output, edid_mon);
                modes = xf86OutputGetEDIDModes(output);
            }
    }
    viaPruneUnPreferredModes(&modes);
    viaPruneUnCEAModes(&modes);
    return viaAddCEAModeLine(output, rawEDID + 128, modes);

#if 0    /* Reservered. (see the above description).*/
    ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;
    ScrnInfoPtr         pScrn = output->scrn;
    DisplayModePtr      stdModes = NULL;
    DisplayModePtr      newModes = NULL;
    DisplayModePtr      builtInMode = NULL;
    xf86MonPtr          monitorInfo = NULL;

    /* Parse the EDID block */
    monitorInfo = xf86InterpretEDID(pScrn->scrnIndex, g_StdEdid);
    if (monitorInfo)
        xf86OutputSetEDID(output, monitorInfo);

    stdModes = xf86OutputGetEDIDModes(output);
    viaPrintModeList(stdModes);

    /* Add mode according to extension EDID. */
    if (hdmiInfo->hasExtEDID)
        newModes = viaAddExtDetailTiming(output, stdModes, g_ExtEdid);
    else
        DEBUG(ErrorF("Extension EDID doesn't exists\n"));

    return newModes;
#endif
}


static const xf86OutputFuncsRec via_hdmi_output_funcs = {
    .dpms = via_hdmi_dpms,
    .save = via_hdmi_save,
    .restore = via_hdmi_restore,
    .mode_valid = via_hdmi_mode_valid,
    .mode_fixup = via_hdmi_mode_fixup,
    .prepare = via_hdmi_prepare,
    .mode_set = via_hdmi_mode_set,
    .commit = via_hdmi_commit,
    .detect = via_hdmi_detect,
    .get_modes = via_hdmi_get_modes,
    .destroy = via_hdmi_destroy,
};

/*
Function Name:  checkHdmiSupport
Description:    Check if HDMI supported by platform
*/
static Bool
checkHdmiSupport(VIAPtr pVia, xf86OutputPtr output)
{
    Bool retVal = FALSE;
    ScrnInfoPtr pScrn = output->scrn;
    ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;

    /* default HDMI type is internal */
    if (hdmiInfo->commonInfo.type == DISP_DEFAULT_SETTING) {

        if (pVia->GfxDispCaps & INTERNAL_HDMI)
            hdmiInfo->commonInfo.type = DISP_TYPE_INTERNAL;
        else
            hdmiInfo->commonInfo.type = DISP_TYPE_EXTERNAL;
    }

    /* default HDMI DI port*/
    if (hdmiInfo->commonInfo.diPort == DISP_DEFAULT_SETTING) {
        if (hdmiInfo->commonInfo.type == DISP_TYPE_INTERNAL)
            /* 410 integrated HDMI doesn't have DI port */
            hdmiInfo->commonInfo.diPort = DISP_DI_NONE;
        else
            hdmiInfo->commonInfo.diPort = DISP_DI_DVP1;
    }

    /*if HDMI DI port is free*/
    if (checkDiPortUsage(pVia, hdmiInfo->commonInfo.diPort)) {

        /* external HDMI */
        if (hdmiInfo->commonInfo.type == DISP_TYPE_EXTERNAL) {
            /* Sense AD9389 */
            // viaDIPortPadOn(pScrn->scrnIndex, hdmiInfo->commonInfo.diPort);
            if (ad9389_module_loaded && senseSubChip(&hdmiInfo->commonInfo,
                                SUBCHIP_AD9389)) {
                hdmiInfo->commonInfo.subChipName = SUBCHIP_AD9389;
                hdmiInfo->commonInfo.slaveAddress = SUBCHIP_AD9389_SLAVE_ADDR;

                if (hdmiInfo->commonInfo.ddcPort == DISP_DEFAULT_SETTING)
                    hdmiInfo->commonInfo.ddcPort =
                            hdmiInfo->commonInfo.serialPort;

                pVia->MbDiPortUsedInfo |= hdmiInfo->commonInfo.diPort;
                retVal = TRUE;

                /* Save registers of AD9389 for BIOS */
                if (output->funcs->save)
                    output->funcs->save(output);

                /* AD9389 doesn't have to be re-initialized when HDMI was ignored */
                if (!hdmiInfo->commonInfo.isOuputIgnored) {
                    /* Init AD9389 at here to avoid enable/disable frequently. */
                    viaInitializeAD9389(output);
                }
            } else {
                if (!ad9389_module_loaded) {
                    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                    "Failed to load AD9389 module, "
                    "so we don't creat hdmi output "
                    "if you need hdmi output, please load the submodule.\n"));
                }
            }
            /*Turn off relevant di port clk set on previously to keep things consistent */
            // viaDIPortPadOff(pScrn->scrnIndex, hdmiInfo->commonInfo.diPort);

        }
   } else {
        /* internal HDMI */
        if (hdmiInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
            if (pVia->GfxDispCaps & INTERNAL_HDMI) {
                hdmiInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_HDMI;
                hdmiInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;

                /* Save registers of Internal HDMI for BIOS */
                if (output->funcs->save)
                    output->funcs->save(output);

                /* HDMI ignored by xorg.conf doesn't occupy HW circuits actually */
                if (!hdmiInfo->commonInfo.isOuputIgnored) {
                    pVia->GfxDispCaps &= ~INTERNAL_HDMI;
                    // enable bangap
                    MMIO_WR_MASK(0xC740,  0x1, 0x1);
                }

                retVal = TRUE;
            }
        }
   }

   return retVal;
}

static void
parseHdmiOption(xf86OutputPtr output)
{
    char *s = NULL;
    int value = 0;
    int sPort = DISP_SERIALP_NONE;
    int dPort = DISP_SERIALP_NONE;
    ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;

    hdmiInfo->userGfxDPA.isClkPolarityUsed = FALSE;
    hdmiInfo->userGfxDPA.isClkAdjustUsed = FALSE;
    hdmiInfo->userGfxDPA.isClkDrivingSelUsed = FALSE;
    hdmiInfo->userGfxDPA.isDataDrivingSelUsed = FALSE;

    /* Default value */
    hdmiInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
    hdmiInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    hdmiInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
    hdmiInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;
    hdmiInfo->commonInfo.hasHotplug = FALSE;
    hdmiInfo->attachAllModes = FALSE;
    hdmiInfo->AD9389CircuitStateAdjust = 0x04;
    hdmiInfo->isAD9389CircuitStateAdjustUsed = FALSE;
    hdmiInfo->fixOnIGA1 = FALSE;

    /* if no "HDMI" monitor section, all use default setting */
    if (output->conf_monitor)
        xf86ProcessOptions (output->scrn->scrnIndex,
                    output->conf_monitor->mon_option_lst,
                    ViaHdmiOptions);


    /* parse option "DIPort" */
    if ((s = xf86GetOptValString(ViaHdmiOptions, OPTION_HDMI_DIPORT)))
        hdmiInfo->commonInfo.diPort = transformDiPort(s);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(ViaHdmiOptions, OPTION_HDMI_TYPE)))
        hdmiInfo->commonInfo.type = transformOutputType(s);

    /* parse option "SerialPort" */
    if (xf86GetOptValInteger(ViaHdmiOptions, OPTION_HDMI_SERIALPORT, &sPort))
        hdmiInfo->commonInfo.serialPort = transformPort(sPort);

    /* parse option "DDCPort" */
    if (xf86GetOptValInteger(ViaHdmiOptions, OPTION_HDMI_DDCPORT, &dPort))
        hdmiInfo->commonInfo.ddcPort = transformPort(dPort);

    /* parse option  "HotPlug" */
    if (xf86ReturnOptValBool(ViaHdmiOptions, OPTION_HDMI_Hotplug, FALSE))
        hdmiInfo->commonInfo.hasHotplug = TRUE;

    /* parse option  "DiscardEDID" */
    if (xf86ReturnOptValBool(ViaHdmiOptions, OPTION_HDMI_ATTACH_ALL_MODES,
        FALSE))
        hdmiInfo->attachAllModes = TRUE;

    /* parse user clock skew setting*/
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(ViaHdmiOptions, OPTION_HDMI_CLOCK_POLARITY,
        &value)) {
        hdmiInfo->userGfxDPA.clkPolarity = value & BIT0;
        hdmiInfo->userGfxDPA.isClkPolarityUsed = TRUE;
    }

    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(ViaHdmiOptions, OPTION_HDMI_CLOCK_ADJUST,
        &value)) {
        hdmiInfo->userGfxDPA.clkAdjust = value;
        hdmiInfo->userGfxDPA.isClkAdjustUsed = TRUE;
    }

    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(ViaHdmiOptions,
        OPTION_HDMI_CLOCK_DRIVING_SELECTION, &value)) {
        hdmiInfo->userGfxDPA.clkDrivingSel = value;
        hdmiInfo->userGfxDPA.isClkDrivingSelUsed = TRUE;
    }

    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(ViaHdmiOptions,
        OPTION_HDMI_DATA_DRIVING_SELECTION, &value)) {
        hdmiInfo->userGfxDPA.dataDrivingSel = value;
        hdmiInfo->userGfxDPA.isDataDrivingSelUsed = TRUE;
    }

    /* parse option  "AD9389CircuitStateAdjust" */
    if (xf86GetOptValInteger(ViaHdmiOptions,
        OPTION_HDMI_AD9389_CIRCUIT_STATE_ADJUST, &value)) {
        hdmiInfo->AD9389CircuitStateAdjust= value;
        hdmiInfo->isAD9389CircuitStateAdjustUsed= TRUE;
    }

    /* parse option  "fixOnIGA1" */
    if (xf86ReturnOptValBool(ViaHdmiOptions, OPTION_HDMI_FIX_ON_IGA1, FALSE))
        hdmiInfo->fixOnIGA1 = TRUE;

}

void
via_hdmi_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr                  pVia = VIAPTR(pScrn);
    xf86OutputPtr           outputHdmi;
    ViaHdmiPrivateInfoPtr   hdmiInfo;
    Bool isHdmiIgnored = FALSE;

    outputHdmi = xf86OutputCreate (pScrn, &via_hdmi_output_funcs, name);

    if (!outputHdmi) {
        /* When BIOS light the output and XF86ConfigFile ignore it,
            this output may be lit by default value.
            So we create IgnoredOutput to do something to avoid this problem */
        outputHdmi = viaOutputCreate(pScrn, &via_hdmi_output_funcs, name);
        if (outputHdmi) {
            isHdmiIgnored = TRUE;
        } else {
            DEBUG(ErrorF("viaOutputCreate %s Fail.\n", name));
            return;
        }
    }

    /* allocate HDMI private info structure */
    hdmiInfo = xnfcalloc (sizeof (ViaHdmiPrivateInfo), 1);
    if (!hdmiInfo) {
        xf86OutputDestroy(outputHdmi);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }

    hdmiInfo->commonInfo.isOuputIgnored = isHdmiIgnored;
    outputHdmi->driver_private = hdmiInfo;

    /* allocate memory to store EDID info */
    hdmiInfo->commonInfo.rawEDID = calloc(1, sizeof(unsigned char) * (256));
    if (!hdmiInfo->commonInfo.rawEDID) {
        xf86OutputDestroy(outputHdmi);
        DEBUG(ErrorF("Allocate %s EDID space Fail.\n", name));
        return;
    }

    /* Read HDMI options in HDMI monitor section */
    parseHdmiOption(outputHdmi);

    if (!hdmiInfo->commonInfo.isOuputIgnored) {
        if (checkHdmiSupport(pVia, outputHdmi)) {
            if (hdmiInfo->fixOnIGA1)
                outputHdmi->possible_crtcs = 0x1;
            else
                outputHdmi->possible_crtcs = 0x2;
            outputHdmi->possible_clones = 0;
            outputHdmi->interlaceAllowed = TRUE;
            outputHdmi->doubleScanAllowed = FALSE;

            if (!xf86NameCmp(name, OUTPUT_HDMI_NAME))
                pVia->hdmi1Created = TRUE;

        } else {
            /* also free HDMI private date */
            xf86OutputDestroy(outputHdmi);
        }
    } else {
        /* Default setting can only be used to check support status of default
           HDMI. Default HDMI is different for various chipsets. This is just
           a temporary solution. */
        hdmiInfo->commonInfo.type = DISP_DEFAULT_SETTING;
        hdmiInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
        hdmiInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
        hdmiInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;

        if (!checkHdmiSupport(pVia, outputHdmi)) {
           xf86OutputDestroy(outputHdmi);
           pVia->numIgnoredOutput--;
        }

    }
}

void
viaSaveInternalHdmiRegs(xf86OutputPtr output)
{
    DEBUG(ErrorF("viaSaveInternalHdmiRegs\n"));

    ViaOutputInfo   commonInfo = ((ViaHdmiPrivateInfoPtr)
            (output->driver_private))->commonInfo;
    ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;
    ViaInternalHdmiReg *SavedRegs;
    CARD32 tmp;

    if (hdmiInfo->savedRegs) {
        free(hdmiInfo->savedRegs);
        hdmiInfo->savedRegs = NULL;
    }

    hdmiInfo->savedRegs = (void *)calloc(sizeof(ViaInternalHdmiReg), 1);;
    SavedRegs = (ViaInternalHdmiReg *)hdmiInfo->savedRegs;

    if (!hdmiInfo->savedRegs)
        return;

    /* Save AVI infoFrame */
    MMIO_WR(0xC200, 0x8000);
    SavedRegs->AVI_C204 = MMIO_RD(0xC204);
    SavedRegs->AVI_C208 = MMIO_RD(0xC208);
    SavedRegs->AVI_C20C = MMIO_RD(0xC20C);
    SavedRegs->AVI_C210 = MMIO_RD(0xC210);
    SavedRegs->AVI_C214 = MMIO_RD(0xC214);
    SavedRegs->AVI_C218 = MMIO_RD(0xC218);
    SavedRegs->AVI_C21C = MMIO_RD(0xC21C);
    SavedRegs->AVI_C220 = MMIO_RD(0xC220);
    SavedRegs->AVI_C224 = MMIO_RD(0xC224);

    /* Save Audio InfoFrame */
    MMIO_WR(0xC200, 0x8100);
    SavedRegs->Audio_C204 = MMIO_RD(0xC204);
    SavedRegs->Audio_C208 = MMIO_RD(0xC208);
    SavedRegs->Audio_C20C = MMIO_RD(0xC20C);
    SavedRegs->Audio_C210 = MMIO_RD(0xC210);
    SavedRegs->Audio_C214 = MMIO_RD(0xC214);
    SavedRegs->Audio_C218 = MMIO_RD(0xC218);
    SavedRegs->Audio_C21C = MMIO_RD(0xC21C);
    SavedRegs->Audio_C220 = MMIO_RD(0xC220);
    SavedRegs->Audio_C224 = MMIO_RD(0xC224);

    /* Save HD Audio Para */
    /* Driver use C4D4 and C4D8 to calculate some value used in C404, C400, ...
    We already have these values. Hence C4D4 and C4D4 are not necessary. */
    SavedRegs->C424 = MMIO_RD(0xC424);
    SavedRegs->C400 = MMIO_RD(0xC400);
    SavedRegs->C404 = MMIO_RD(0xC404);
    SavedRegs->C414 = MMIO_RD(0xC414);
    SavedRegs->C410 = MMIO_RD(0xC410);

    SavedRegs->C000 = MMIO_RD(0xC000);
    SavedRegs->C0B4 = MMIO_RD(0xC0B4);

    SavedRegs->C280 = MMIO_RD(0xC280);
    SavedRegs->C284 = MMIO_RD(0xC284);
    SavedRegs->C294 = MMIO_RD(0xC294);
    SavedRegs->C298 = MMIO_RD(0xC298);
    SavedRegs->C29C = MMIO_RD(0xC29C);

    SavedRegs->C640 = MMIO_RD(0xC640);

    SavedRegs->C740 = MMIO_RD(0xC740);
    SavedRegs->C744 = MMIO_RD(0xC744);
    SavedRegs->C748 = MMIO_RD(0xC748);
    SavedRegs->C74C = MMIO_RD(0xC74C);

}


void
viaRestoreInternalHdmiRegs(xf86OutputPtr output)
{
    DEBUG(ErrorF("viaRestoreInternalHdmiRegs\n"));

    ViaOutputInfo   commonInfo = ((ViaHdmiPrivateInfoPtr)
            (output->driver_private))->commonInfo;
    ViaHdmiPrivateInfoPtr hdmiInfo = output->driver_private;
    ViaInternalHdmiReg *restoreRegs = (ViaInternalHdmiReg *)hdmiInfo->savedRegs;

    if (!restoreRegs)
        return;

    /* TODO: The following process of registers setting is reference to
        viaSetIntegratedHDMI. I am not sure if it is correct. */

    /* Set AVI infoFrame*/
    MMIO_WR(0xC204, restoreRegs->AVI_C204);
    MMIO_WR(0xC208, restoreRegs->AVI_C208);
    MMIO_WR(0xC20C, restoreRegs->AVI_C20C);
    MMIO_WR(0xC210, restoreRegs->AVI_C210);
    MMIO_WR(0xC214, restoreRegs->AVI_C214);
    MMIO_WR(0xC218, restoreRegs->AVI_C218);
    MMIO_WR(0xC21C, restoreRegs->AVI_C21C);
    MMIO_WR(0xC220, restoreRegs->AVI_C220);
    MMIO_WR(0xC224, restoreRegs->AVI_C224);
    MMIO_WR(0xC200, 0x80); // write AVI

    /* Set Audio InfoFrame */
    MMIO_WR(0xC204, restoreRegs->Audio_C204);
    MMIO_WR(0xC208, restoreRegs->Audio_C208);
    MMIO_WR(0xC20C, restoreRegs->Audio_C20C);
    MMIO_WR(0xC210, restoreRegs->Audio_C210);
    MMIO_WR(0xC214, restoreRegs->Audio_C214);
    MMIO_WR(0xC218, restoreRegs->Audio_C218);
    MMIO_WR(0xC21C, restoreRegs->Audio_C21C);
    MMIO_WR(0xC220, restoreRegs->Audio_C220);
    MMIO_WR(0xC224, restoreRegs->Audio_C224);
    MMIO_WR(0xC200, 0x81); //Write Audio

    /* Set HDAduio Para */
    MMIO_WR(0xC424, restoreRegs->C424); // HDAudio Codec
    MMIO_WR(0xC404, restoreRegs->C404); // HDAudio Wall Clock
    MMIO_WR(0xC400, restoreRegs->C400); // HDAudio Wall Clock
    MMIO_WR(0xC414, restoreRegs->C414); // HDAudio Sample Rate
    MMIO_WR(0xC410, restoreRegs->C410); // HDAudio Sample Rate
    /* SetHDAudioCTSandN */
    MMIO_WR(0xC294, restoreRegs->C294);
    MMIO_WR(0xC298, restoreRegs->C298);
    MMIO_WR(0xC29C, restoreRegs->C29C);

    /* TPLL N2,N3 and N4 setting */
    MMIO_WR_MASK(DP_EPHY_PLL_REG, restoreRegs->C740, 0xC0000000);
    /* power down to reset */
    MMIO_WR_MASK(0xC740, 0x00000000, 0x06000000);
    // enable
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x00000001, 0x00000001);
    /* select HDMI or DP mode */
    MMIO_WR_MASK(0xC748, restoreRegs->C748, BIT0);
    /* enable HDMI with HDMI or DVI mode */
    MMIO_WR_MASK(0xC280, restoreRegs->C280, 0x40);
    /* select AC mode */
    MMIO_WR_MASK(0xC74C, restoreRegs->C74C, 0x40);
    /* enable InfoFrame or not */
    MMIO_WR(0xC284, restoreRegs->C284);
    /* set status of Lane0~3 */
    MMIO_WR_MASK(0xC744, restoreRegs->C744, 0x00FFFF82);
    MMIO_WR(0xC0B4, restoreRegs->C0B4);
#if 0  // these had set above.
    /* enable audio packet */
    MMIO_WR_MASK(0xC294, restoreRegs->C294, 0x10000000);
    /* enable InfoFrame */
    MMIO_WR(0xC284, restoreRegs->C284);
#endif
    MMIO_WR_MASK(0xC740, restoreRegs->C740, 0x3FFFFFFF);

    MMIO_WR(0xC280, restoreRegs->C280);
    MMIO_WR(0xC640, restoreRegs->C640);

}
