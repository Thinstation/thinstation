/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef _VIA_CHROME9_DRM_H_
#define _VIA_CHROME9_DRM_H_



/* Driver specific ioctl number */
#define DRM_VIA_CHROME9_ALLOCMEM                    0x00
#define DRM_VIA_CHROME9_FREEMEM                     0x01
#define DRM_VIA_CHROME9_FREE                        0x02
#define DRM_VIA_CHROME9_ALLOCATE_EVENT_TAG          0x03
#define DRM_VIA_CHROME9_FREE_EVENT_TAG              0x04
#define DRM_VIA_CHROME9_ALLOCATE_APERTURE           0x05
#define DRM_VIA_CHROME9_FREE_APERTURE               0x06
#define DRM_VIA_CHROME9_ALLOCATE_VIDEO_MEM          0x07
#define DRM_VIA_CHROME9_FREE_VIDEO_MEM              0x08
#define DRM_VIA_CHROME9_WAIT_CHIP_IDLE              0x09
#define DRM_VIA_CHROME9_PROCESS_EXIT                0x0A
#define DRM_VIA_CHROME9_RESTORE_PRIMARY             0x0B
#define DRM_VIA_CHROME9_FLUSH_CACHE                 0x0C
#define DRM_VIA_CHROME9_INIT                        0x0D
#define DRM_VIA_CHROME9_FLUSH                       0x0E
#define DRM_VIA_CHROME9_CHECKVIDMEMSIZE             0x0F
#define DRM_VIA_CHROME9_PCIEMEMCTRL                 0x10
#define DRM_VIA_CHROME9_AUTH_MAGIC                  0x11
#define DRM_VIA_CHROME9_GET_PCI_ID                  0x12
#define DRM_VIA_CHROME9_INIT_JUDGE                  0x16
#define DRM_VIA_CHROME9_DMA                         0x17
#define DRM_VIA_CHROME9_QUERY_BRANCH                0x18
#define DRM_VIA_CHROME9_REQUEST_BRANCH_BUF          0x19
#define DRM_VIA_CHROME9_BRANCH_BUF_FLUSH            0x1A
/* GEM-interfaced TTM core parts */
#define DRM_VIA_CHROME9_GEM_CREATE                  0x20
#define DRM_VIA_CHROME9_GEM_MMAP                    0x21
#define DRM_VIA_CHROME9_GEM_PREAD                   0x22
#define DRM_VIA_CHROME9_GEM_PWRITE                  0x23
#define DRM_VIA_CHROME9_GEM_SET_DOMAIN              0x24
#define DRM_VIA_CHROME9_GEM_FLUSH                   0x25
#define DRM_VIA_CHROME9_GEM_WAIT                    0x26
#define DRM_VIA_CHROME9_SHADOW_INIT                 0x27
#define DRM_VIA_CHROME9_GEM_CPU_GRAB                0x28
#define DRM_VIA_CHROME9_GEM_CPU_RELEASE             0x29
#define DRM_VIA_CHROME9_GEM_LEAVE                   0x2A
#define DRM_VIA_CHROME9_GEM_ENTER                   0x2B
#define DRM_VIA_CHROME9_GEM_PIN                     0x30
#define DRM_VIA_CHROME9_GEM_UNPIN                   0x31
#define DRM_VIA_CHROME9_GEM_CHIPINFO                0x32
#define DRM_VIA_CHROME9_XORG_OPTIONS                0x33
#define DRM_VIA_CHROME9_GET_CRTC_ID                 0x34
#define DRM_VIA_CHROME9_OUTPUT_MODE_VALID           0x37
#define DRM_VIA_CHROME9_CRTC_DPMS                   0x38
#define DRM_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO    0x39
#define DRM_VIA_CHROME9_PASS_MODE_LINE              0x40
#define DRM_VIA_CHROME9_HELPER_SET_MODE             0x41
#define DRM_VIA_CHROME9_GET_CLOCKS                  0x42
#define DRM_VIA_CHROME9_GET_TV_CONFIGURE                  0x43

/* The memory type for ttm */
#define VIA_CHROME9_GEM_DOMAIN_CPU                  0x1
#define VIA_CHROME9_GEM_DOMAIN_GTT                  0x2
#define VIA_CHROME9_GEM_DOMAIN_VRAM                 0x4
/* The memory flag for ttm */
#define VIA_CHROME9_GEM_FLAG_NO_EVICT    (1 << 21)

/* via engine type */
#define VIA_CHROME9_CMD_2D 0x10
#define VIA_CHROME9_CMD_3D 0x20
#define VIA_CHROME9_CMD_VD 0x40
#define VIA_CHROME9_CMD_HQV0 0x80
#define VIA_CHROME9_CMD_HQV1 0x100
#define VIA_CHROME9_CMD_VIDEO 0x200
#define VIA_CHROME9_CMD_DMA0 0x1000
#define VIA_CHROME9_CMD_DMA1 0x2000
#define VIA_CHROME9_CMD_DMA2 0x4000
#define VIA_CHROME9_CMD_DMA3 0x8000
#define VIA_CHROME9_CMD_GFX  (VIA_CHROME9_CMD_2D | VIA_CHROME9_CMD_3D)

#define VIA_CHROME9_CMD_MASK 0xFFF0

/*
 * VIA Chrome9 BO read/write domain
 */
/* read/write by CPU */
#define VIA_CHROME9_OBJ_DOMAIN_CPU              0x10
/* read/write by 2D engine */
#define VIA_CHROME9_OBJ_DOMAIN_2D               0x20
/* read/write by 3D engine */
#define VIA_CHROME9_OBJ_DOMAIN_3D               0x40
#define VIA_CHROME9_OBJ_DOMAIN_HQV0             0x80
#define VIA_CHROME9_OBJ_DOMAIN_HQV1             0x100
#define VIA_CHROME9_OBJ_DOMAIN_VD               0x200
#define VIA_CHROME9_OBJ_DOMAIN_VIDEO            0x400
#define VIA_CHROME9_OBJ_DOMAIN_HQV  \
            (VIA_CHROME9_OBJ_DOMAIN_HQV0 | VIA_CHROME9_OBJ_DOMAIN_HQV1)

/* read/write by GFX engine */
#define VIA_CHROME9_OBJ_DOMAIN_GFX \
            (VIA_CHROME9_OBJ_DOMAIN_2D | VIA_CHROME9_OBJ_DOMAIN_3D)
/* read/write by GPU */
#define VIA_CHROME9_OBJ_DOMAIN_GPU \
            (VIA_CHROME9_OBJ_DOMAIN_2D|VIA_CHROME9_OBJ_DOMAIN_3D | \
            VIA_CHROME9_OBJ_DOMAIN_VD | VIA_CHROME9_OBJ_DOMAIN_HQV)
#define VIA_CHROME9_OBJ_DOMAIN_MASK             0x00000FF0

/* VIA Chrome9 FLUSH flag*/
#define VIA_CHROME9_FLUSH_RING_BUFFER	0x1
#define VIA_CHROME9_FLUSH_BRANCH_BUFFER	0x2

/* Define the R/W mode of each ioctl */
#define DRM_IOCTL_VIA_CHROME9_GEM_CREATE    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CREATE, \
    struct drm_via_chrome9_gem_create)
#define DRM_IOCTL_VIA_CHROME9_GEM_MMAP    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_MMAP, \
    struct drm_via_chrome9_gem_mmap)
#define DRM_IOCTL_VIA_CHROME9_GEM_PREAD    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PREAD, \
    struct drm_via_chrome9_gem_pread)
#define DRM_IOCTL_VIA_CHROME9_GEM_PWRITE    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PWRITE, \
    struct drm_via_chrome9_gem_pwrite)
#define DRM_IOCTL_VIA_CHROME9_GEM_SET_DOMAIN    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_SET_DOMAIN, \
    struct drm_via_chrome9_gem_set_domain)
#define DRM_IOCTL_VIA_CHROME9_GEM_FLUSH    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_FLUSH, \
    struct drm_via_chrome9_gem_flush)
#define DRM_IOCTL_VIA_CHROME9_GEM_WAIT    \
    DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_WAIT, \
    struct drm_via_chrome9_gem_wait)
#define DRM_IOCTL_VIA_CHROME9_GEM_CPU_GRAB \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CPU_GRAB,\
        struct drm_via_chrome9_cpu_grab)
#define DRM_IOCTL_VIA_CHROME9_GEM_CPU_RELEASE \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_CPU_RELEASE,\
        struct drm_via_chrome9_cpu_release)
#define DRM_IOCTL_VIA_CHROME9_GEM_PIN \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_PIN, \
        struct drm_via_chrome9_gem_pin)
#define DRM_IOCTL_VIA_CHROME9_GEM_UNPIN \
        DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GEM_UNPIN, \
        struct drm_via_chrome9_gem_unpin)
#define DRM_IOCTL_VIA_CHROME9_XORG_OPTIONS\
        DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_XORG_OPTIONS, \
        struct drm_via_chrome9_xorg_options)
#define DRM_IOCTL_VIA_CHROME9_GET_CRTC_ID \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CRTC_ID, \
        struct drm_get_crtc_id_info)
#define DRM_IOCTL_VIA_CHROME9_OUTPUT_MODE_VALID\
        DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_OUTPUT_MODE_VALID, \
        struct drm_via_chrome9_output_kmode)
#define DRM_IOCTL_VIA_CHROME9_CRTC_DPMS \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_CRTC_DPMS, \
        struct drm_crtc_dpms_info)
#define DRM_IOCTL_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO  \
	DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO, \
	struct drm_get_customize_timing_info)
#define DRM_IOCTL_VIA_CHROME9_PASS_MODE_LINE  \
        DRM_IOWR(DRM_COMMAND_BASE + DRM_VIA_CHROME9_PASS_MODE_LINE, \
        struct drm_pass_customize_timing)
#define DRM_IOCTL_VIA_CHROME9_HELPER_SET_MODE \
        DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_HELPER_SET_MODE, \
        struct drm_via_chrome9_mode_set_par)
#define DRM_IOCTL_VIA_CHROME9_GET_CLOCKS \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_CLOCKS, \
	struct drm_via_chrome9_clocks)
#define DRM_IOCTL_VIA_CHROME9_GET_TV_CONFIGURE \
	DRM_IOW(DRM_COMMAND_BASE + DRM_VIA_CHROME9_GET_TV_CONFIGURE, \
	struct drm_via_chrome9_tv_type)	

/* The data structure of each ioctl, which is used to
 * communicate between user mode and kernel mode
 */
struct drm_via_chrome9_gem_create {
    uint64_t    size;
    uint64_t    alignment;
    uint32_t    handle;
    uint32_t    initial_domain;
    uint32_t    flags;
    uint32_t    offset;
};

struct drm_via_chrome9_gem_mmap {
    uint32_t    handle;
    uint32_t    pad;
    uint64_t    offset;
    uint64_t    size;
    uint64_t    addr_ptr;
    void    *virtual;
};

struct drm_via_chrome9_gem_pread {
    /** Handle for the object being read. */
    uint32_t handle;
    uint32_t pad;
    /** Offset into the object to read from */
    uint64_t offset;
    /** Length of data to read */
    uint64_t size;
    /** Pointer to write the data into. */
    /* void *, but pointers are not 32/64 compatible */
    uint64_t data_ptr;
};

struct drm_via_chrome9_gem_pwrite {
    /** Handle for the object being written to. */
    uint32_t handle;
    uint32_t pad;
    /** Offset into the object to write to */
    uint64_t offset;
    /** Length of data to write */
    uint64_t size;
    /** Pointer to read the data from. */
    /* void *, but pointers are not 32/64 compatible */
    uint64_t data_ptr;
};

struct drm_via_chrome9_gem_set_domain {
    uint32_t    handle;
    uint32_t    read_domains;
    uint32_t    write_domain;
};

struct drm_via_chrome9_gem_flush {
    /* the pointer to this exec buffer */
    uint64_t buffer_ptr;
    uint32_t num_cliprects;
    /* This is a struct drm_clip_rect *cliprects */
    uint64_t cliprects_ptr;
    uint32_t flag;
};

enum drm_via_chrome9_reloc_type {
    /* the reloc type for 2D command */
    VIA_RELOC_2D,
    /* the reloc type for 3D command */
    VIA_RELOC_3D,
    /* the reloc type for video*/
    VIA_RELOC_HQV0,
    VIA_RELOC_HQV1,
    VIA_RELOC_VIDEO,
    VIA_RELOC_VERTEX_STREAM_L,
    VIA_RELOC_VERTEX_STREAM_H,
    VIA_RELOC_VD
};

struct drm_via_chrome9_gem_relocation_entry {
    /* the target bo handle which add at the reloc list */
    uint32_t target_handle;
    /* the additional offset to this bo */
    uint32_t delta;
    /* this offset to command buffer */
    uint64_t offset;
    /* the target bo offset */
    uint64_t presumed_offset;
    /* the mask indicate this bo location */
    uint32_t location_mask;
    /* the command type for this target bo*/
    enum drm_via_chrome9_reloc_type type;
    /* read write domain by this operation*/
    uint32_t    read_domains;
    uint32_t    write_domain;
    /* for multi-level branch buffer */
    uint32_t    access_engine_type;
};

struct drm_via_chrome9_gem_exec_object {
    /* the command buffer pointer */
    union {
        uint64_t buffer_ptr;
        uint32_t cmd_bo_handle;
    };
    /* the reloc list pointer */
    uint64_t relocs_ptr;
    /* the buffer length we want to exec (dword) */
    uint32_t buffer_length;
    /* the bo count for reloc list */
    uint32_t relocation_count;
};

struct drm_via_chrome9_gem_wait {
    /* the buffer object handle */
    uint32_t handle;
    uint32_t no_wait;
};

struct drm_via_chrome9_shadow_init{
    /*for event tag*/
    unsigned int   shadow_size;
    unsigned long   shadow_handle;
};

struct drm_via_chrome9_cpu_release {
    uint32_t   handle;
};

struct drm_via_chrome9_cpu_grab {
    uint32_t handle;
    uint32_t flags;
};

/* @handle: bo handle
 * @location_mask: to which location bo pinned
 * @offset: the updated offset deliver to user
 * After pin, user mode process should fetch the updated
 * vram address from @offset
 */
struct drm_via_chrome9_gem_pin {
    uint32_t handle;
    uint32_t location_mask;
    uint64_t offset;
};

struct drm_via_chrome9_gem_unpin {
    uint32_t handle;
};

struct drm_via_chrome9_xorg_options {
    uint32_t connector_id;
    void *xorg_options;
    uint32_t options_size;
};

struct drm_via_chrome9_output_kmode {
	uint32_t connector_id;
	uint32_t mode_status;
	void *output_kmode;
};

struct drm_via_chrome9_mode_set_par {
	uint32_t connector_id;
};

// define a structure for Clocks
struct drm_via_chrome9_clocks{
    unsigned int  eng_clock;
    unsigned int  gpu_clock;
    unsigned int  mem_clock;
};

// define a structure for TV
struct drm_via_chrome9_tv_type{
    unsigned int  hdtv_enabled;
};

/*branch buffer object
 */
struct via_cmd_buffer_obj {
    struct generic_bo *bo;
    int num;
    int type;
};

struct drm_get_crtc_id_info {
    int crtc_id;
    int crtc_hw_id;
};

struct drm_crtc_dpms_info {
    int crtc_id;
    uint32_t status;
};

struct drm_get_customize_timing_info {
    int crtc_id;
    uint32_t connector_id;
    uint32_t pixel_clock;

    uint32_t dispDev;
    uint32_t colorDepth;
    uint32_t vPLL;
};

struct drm_pass_customize_timing {
    void *ml_pkg;
    uint32_t pkg_size;

    void *cust_tm_aux_info_ptr;
    uint32_t  cust_tm_aux_info_len;
};

#endif      /* _VIA_CHROME9_DRM_H_ */
