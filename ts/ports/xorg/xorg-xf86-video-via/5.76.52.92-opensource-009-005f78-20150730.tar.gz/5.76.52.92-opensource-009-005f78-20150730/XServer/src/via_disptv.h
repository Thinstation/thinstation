/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef __VIA_DISPTV_H__
#define __VIA_DISPTV_H__

#include "xf86Crtc.h"
#include "via_output.h"
#include "via_driver.h"

#define NUM_OF_FUNC               6
#define NUM_OF_CRTC_TIMING     12

typedef struct _Vt1625FuncTable
{
    unsigned short *normal[NUM_OF_FUNC];
    unsigned short *fit[NUM_OF_FUNC];
    unsigned short *over[NUM_OF_FUNC];
} Vt1625FuncTable, *Vt1625FuncTablePtr;

typedef struct _Vt1625Table
{
    int modeIndex;
    Vt1625FuncTablePtr stdNtsc;
    Vt1625FuncTablePtr stdPal;
    Vt1625FuncTablePtr std720p;
    Vt1625FuncTablePtr std1080i;
} Vt1625Table, *Vt1625TablePtr;

/*For dynamic change property*/
/*TV Brightness */
static Atom tv_brightness_atom;

#define TV_BRIGHTNESS_NAME  "Brightness"

/*TV Contrast*/
static Atom tv_contrast_atom;

#define TV_CONTRAST_NAME  "Contrast"

/*TV Saturation*/
static Atom tv_saturation_atom;

#define TV_SATURATION_NAME  "Saturation"

/*TV Hue*/
static Atom tv_hue_atom;

#define TV_HUE_NAME  "Hue"

/*TV Horizontal Scale*/
static Atom tv_hor_scale_atom;

#define TV_HOR_SCALE_NAME   "ScaleH"

/*TV Vertical Scale*/
static Atom tv_ver_scale_atom;

#define TV_VER_SCALE_NAME   "ScaleV"

/*TV flicker affliter*/
static Atom tv_affliterValue_atom;

#define TV_AFFliter_Value "AFFilterValue"

/*TV flicker fliter*/
static Atom tv_ffliter_atom;
static Atom tv_ffliter_name_atoms[3];

static char *tv_ffliter_names[] = {
    "FFON",
    "AFFON",
    "ALLOFF"
};

#define TV_FFliter_NAME  "FFilter"

static Atom tv_ffliterValue_atom;

#define TV_FFliter_Value "FFilterValue"

/*TV Dot Crawl*/
static Atom tv_dotcrawl_atom;
static Atom tv_dotcrawl_name_atoms[2];

static char *tv_dotcrawl_names[] = {
    "Off",
    "On"
};

#define TV_DOTCRAWL_NUM   2
#define TV_DOTCRAWL_NAME  "DotCrawl"

/* TV Type */
static Atom tv_type_atom;
static Atom tv_type_name_atoms[6];

static char *tv_type_names_6x4_8x6_10x7[] = {
    "NTSC",
    "PAL",
    "480P",
    "576P",
    "720P",
    "1080I"
};

static char *tv_type_names_720x480[] = {
    "NTSC",
    "480P",
    "720P",
    "1080I"
};

static char *tv_type_names_720x576[] = {
    "PAL",
    "576P",
    "720P",
    "1080I"
};

static char *tv_type_names_1280x720[] = {
    "720P"
};

static char *tv_type_names_1920x1080[] = {
    "1080I"
};

#define TV_TYPE_NUM   6
#define TV_TYPE_NAME  "Type"

/*TV PosH*/
static Atom tv_posh_atom;

#define TV_POSH_NAME    "PosH"

/*TV PosV*/
static Atom tv_posv_atom;

#define TV_POSV_NAME    "PosV"

/* TV Signal */
static Atom tv_signal_atom;
static Atom tv_signal_name_atoms[4];

static char *tv_signal_names_NTSC_PAL[] = {
    "Composite",
    "SVideo",
    "RGB",
    "YCbCr"
};

static char *tv_signal_names_480P_720P_576P_1080I[] = {
    "RGB",
    "YCbCr"
};

#define TV_SIGNAL_NUM   4
#define TV_SIGNAL_NAME  "Signal"

/* TV Scan Type */
static Atom tv_scan_type_atom;
static Atom tv_scan_type_name_atoms[3];

static char *tv_scan_type_names[] = {
    "Normal",
    "Fit",
    "Over"
};

#define TV_SCAN_TYPE_NUM   3
#define TV_SCAN_TYPE_NAME  "Scan"

/*Creat a parse TV property structure*/
typedef struct _TVParseStruct
{
    int propertyID;
    char name[20];
} TVParseStruct, *TVParseStructPtr;

typedef struct _TVParseCombineStruct
{
    CARD32 propertyID;
    int tvSignalNum;
    char **pTvSignalNames;
    TVParseStructPtr pTvParseStruct;
} TVParseCombineStruct, *TVParseCombineStructPtr;

static TVParseStruct tv_dotcrawl_struct[] = {
    {FALSE, "Off"},
    {TRUE, "On"},
    {-1, ""}
};

/*TV type structure*/
static TVParseStruct tv_type_struct_6x4_8x6_10x7[] = {
    {TV_STANDARD_NTSC, "NTSC"}, {TV_STANDARD_PAL, "PAL"},
    {TV_STANDARD_480P, "480P"}, {TV_STANDARD_576P, "576P"},
    {TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
    {-1, ""}
};

static TVParseStruct tv_type_struct_720x480[] = {
    {TV_STANDARD_NTSC, "NTSC"}, {TV_STANDARD_480P, "480P"},
    {TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
    {-1, ""}
};

static TVParseStruct tv_type_struct720x576[] = {
    {TV_STANDARD_PAL, "PAL"}, {TV_STANDARD_576P, "576P"},
    {TV_STANDARD_720P, "720P"}, {TV_STANDARD_1080I, "1080I"},
    {-1, ""}
};

static TVParseStruct tv_type_struct_1280x720[] = {
    {TV_STANDARD_720P, "720P"},
    {-1, ""}
};

static TVParseStruct tv_type_struct_1920x1080[] = {
    {TV_STANDARD_1080I, "1080I"},
    {-1, ""}
};

static TVParseCombineStruct tv_type_struct[] = {
    {TV_STANDARD_ALL, 6, tv_type_names_6x4_8x6_10x7,
	    tv_type_struct_6x4_8x6_10x7},
    {(TV_STANDARD_NTSC | TV_STANDARD_480P | TV_STANDARD_720P |
		TV_STANDARD_1080I), 4, tv_type_names_720x480,
	    tv_type_struct_720x480},
    {(TV_STANDARD_PAL | TV_STANDARD_576P | TV_STANDARD_720P |
		TV_STANDARD_1080I), 4, tv_type_names_720x576,
	    tv_type_struct720x576},
    {TV_STANDARD_720P, 1, tv_type_names_1280x720, tv_type_struct_1280x720},
    {TV_STANDARD_1080I, 1, tv_type_names_1920x1080, tv_type_struct_1920x1080},
    {-1, -1, NULL, NULL}
};

/*TV signal structure*/
static TVParseStruct tv_signal_struct_480P_720P_576P_1080I[] = {
    {TV_SIGNAL_RGB, "RGB"},
    {TV_SIGNAL_YCBCR, "YCbCr"},
    {-1, ""}
};

static TVParseStruct tv_signal_struct_NTSC_PAL[] = {
    {TV_SIGNAL_COMPOSITE, "Composite"},
    {TV_SIGNAL_SVIDEO, "SVideo"},
    {TV_SIGNAL_RGB, "RGB"},
    {TV_SIGNAL_YCBCR, "YCbCr"},
    {-1, ""}
};

static TVParseCombineStruct tv_signal_struct[] = {
    {TV_SIGNAL_ALL, 4, tv_signal_names_NTSC_PAL, tv_signal_struct_NTSC_PAL},
    {TV_SIGNAL_RGB | TV_SIGNAL_YCBCR, 2, tv_signal_names_480P_720P_576P_1080I,
	    tv_signal_struct_480P_720P_576P_1080I},
    {-1, -1, NULL, NULL}
};

static TVParseStruct tv_scan_struct[] = {
    {TV_SCAN_NORMAL, "Normal"},
    {TV_SCAN_FIT, "Fit"},
    {TV_SCAN_OVER, "Over"},
    {-1, ""}
};

#define     VT1625_DAC_A                BIT5
#define     VT1625_DAC_B                BIT4
#define     VT1625_DAC_C                BIT3
#define     VT1625_DAC_D                BIT2
#define     VT1625_DAC_E                BIT1
#define     VT1625_DAC_F                BIT0

#define GET_HIGH_BYTE(x)    (unsigned char)((x) >> 8)
#define GET_LOW_BYTE(x)     (unsigned char)((x) & 0x00FF)

#define EMBTV_DAC_PRIMARY               1

/* TV Support Mode */
static struct _VIASUPPORTMODE TvSupportMode[] = {
    /*  Index,         HActive,     VActive */
    {"640x480", M640x480, 640, 480},
    {"720x480", M720x480, 720, 480},
    {"720x576", M720x576, 720, 576},
    {"800x600", M800x600, 800, 600},
    {"1024x768", M1024x768, 1024, 768},
    {"1280x720", M1280x720, 1280, 720},
    {"1920x1080", M1920x1080, 1920, 1080},
    {"", -1, 0, 0}
};

typedef enum
{
    OPTION_TV_TYPE,
    OPTION_TV_DIPORT,
    OPTION_TV_SERIALPORT,
    OPTION_TV_STANDARD,
    OPTION_TV_SIGNAL,
    OPTION_TV_SCAN,
    OPTION_TV_DEDOTCRAWL,
    OPTION_TV_CLOCK_POLARITY,
    OPTION_TV_CLOCK_ADJUST,
    OPTION_TV_CLOCK_DRIVING_SELECTION,
    OPTION_TV_DATA_DRIVING_SELECTION,
    OPTION_TV_VT162X_DPA
} ViaTvOpts;

static OptionInfoRec ViaTvOptions[] = {
    {OPTION_TV_TYPE,                    "Type",                  OPTV_STRING,
        {0}, FALSE},
    {OPTION_TV_DIPORT,                  "DIPort",                OPTV_STRING,
        {0}, FALSE},
    {OPTION_TV_SERIALPORT,              "SerialPort",            OPTV_INTEGER,
        {0}, FALSE},
    {OPTION_TV_STANDARD,                "Standard",              OPTV_STRING,
        {0}, FALSE},
    {OPTION_TV_SIGNAL,                  "Signal",                OPTV_STRING,
        {0}, FALSE},
    {OPTION_TV_SCAN,                    "Scan",                  OPTV_STRING,
        {0}, FALSE},
    {OPTION_TV_DEDOTCRAWL,              "DeDotCrawl",            OPTV_BOOLEAN,
        {0}, FALSE},
    {OPTION_TV_CLOCK_POLARITY,          "ClockPolarity",         OPTV_INTEGER,
        {0}, FALSE},
    {OPTION_TV_CLOCK_ADJUST,            "ClockAdjust",           OPTV_INTEGER,
        {0}, FALSE},
    {OPTION_TV_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection", OPTV_INTEGER,
	    {0}, FALSE},
    {OPTION_TV_DATA_DRIVING_SELECTION, "DataDrivingSelection",   OPTV_INTEGER,
	    {0}, FALSE},
    {OPTION_TV_VT162X_DPA,              "TvEncoderDPA",          OPTV_INTEGER,
        {0}, FALSE},
    {-1,                                NULL,                    OPTV_NONE,
        {0}, FALSE}
};

typedef struct _TVFeature
{
    CARD32 defaultBrightness;
    CARD32 currentBrightness;
    CARD32 brightnessLevel;

    CARD32 defaultContrast;
    CARD32 currentContrast;
    CARD32 contrastLevel;

    CARD32 defaultSaturation;
    CARD32 currentSaturation;
    CARD32 saturationLevel;

    CARD32 defaultHue;
    CARD32 currentHue;
    CARD32 hueLevel;

    /* Scale Level (only useful for integrated TV) */
    /* Horizontal */
    CARD32 defaultHorScale;
    CARD32 currentHorScale;
    CARD32 horScaleInterval;
    /* Vertical */
    CARD32 defaultVerScale;
    CARD32 currentVerScale;
    CARD32 verScaleInterval;

    CARD32 DefaultPositionH;
    CARD32 CurrentPositionH;
    CARD32 PositionHLevel;
    CARD32 DefaultPositionV;
    CARD32 CurrentPositionV;
    CARD32 PositionVLevel;

    CARD32 DefaultAFFilter;
    CARD32 CurrentAFFilter;
    CARD32 AFFilterLevel;
    CARD32 AdaptiveFFilterOn;

    CARD32 DefaultFFilter;
    CARD32 CurrentFFilter;
    CARD32 FFilterLevel;
    CARD32 FFilterOn;
} TVFeature, *TVFeaturePtr;

typedef struct _ViaTvEncoderDPAValue
{
    CARD8 DPA;			       /*for Vt1625 */
    Bool isDPAUsed;
} ViaTvEncoderDPA, *ViaTvEncoderDPAPtr;

typedef struct _ViaTvPrivateInfo
{
    ViaOutputInfo commonInfo;
    ViaGfxDPA userGfxDPA;
    ViaTvEncoderDPA userTvEncoderDPA;
    CARD32 standard;
    CARD32 signal;
    CARD32 scan;
    Bool deDotCrawl;
    Bool isAutoDetect;		  /* use auto or normal sense to detect monitor */
    CARD32 tvSupportedCaps;
    TVFeaturePtr tvFeatureInfoPtr;
} ViaTvPrivateInfo, *ViaTvPrivateInfoPtr;

extern Bool viaDelay_Nmsec(VIAPtr pVia, CARD32 dwCounter);
Bool viaGetTvCapsSupported(xf86OutputPtr output, CARD32 hDisplay,
    CARD32 vDisplay);
void via_tv_init(ScrnInfoPtr pScrn, const char *name);
#endif
