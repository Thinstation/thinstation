/*
 * Copyright 2009-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2009-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_DP2_H_
#define _VIA_DP2_H_ 1
#include "via_common.h"

#define DP_DATA_PASS_ENABLE_REG           0xC000

/************************************************************************
*     DisplayPort Register
*************************************************************************/
#define DP_ATTR_DATA_REG        0xC610
#define DP_LINK_TRAINING_REG    0xC614
#define DP_VIDEO_CTRL_REG       0xC618
#define DP_VER_EXT_PKT_HEAD_REG 0xC61C

//DP Display Port Enable and InfoFrame Control
#define DP_ENABLE_IF_REG        0xC640
#define DP_HWIDTH_TUSIZE_REG    0xC644
#define DP_HLINE_DUR_REG        0xC648
#define DP_MVID_MISC0_REG       0xC64C

#define DP_H_ATTR_REG           0xC650
#define DP_HV_START_REG         0xC654
#define DP_POLARITY_WIDTH_REG   0xC658
#define DP_ACITVE_WH_REG        0xC65C

#define AUX_W_DATA0_REG         0xC710
#define AUX_W_DATA1_REG         0xC714
#define AUX_W_DATA2_REG         0xC718
#define AUX_W_DATA3_REG         0xC71C

#define AUX_R_DATA0_REG         0xC720
#define AUX_R_DATA1_REG         0xC724
#define AUX_R_DATA2_REG         0xC728
#define AUX_R_DATA3_REG         0xC72C

#define AUX_TIMER_REG           0xC730
#define AUX_CMD_REG             0xC734
#define DP_NAUD_MUTE_REG        0xC738

#define DP_EPHY_PLL_REG         0xC740
#define DP_EPHY_TX_PWR_REG      0xC744
#define DP_EPHY_MISC_PWR_REG    0xC748

/*****************************************************
*     DisplayPort2 Register
******************************************************/
#define DP2_NVID_MISC0_REG        0xC690
#define DP2_LINK_TRAINING_REG     0xC694
#define DP2_VIDEO_CTRL_REG        0xC698
#define DP2_EXT_REG               0xC69C
#define DP2_VER_EXT_PKT_HEAD_REG  0xC61C

//DP2 Display Port Enable and InfoFrame Control
#define DP2_ENABLE_IF_REG         0xC6C0
#define DP2_HWIDTH_TUSIZE_REG     0xC6C4
#define DP2_HLINE_DUR_REG         0xC6C8
#define DP2_MVID_MISC0_REG        0xC6CC

#define DP2_H_ATTR_REG            0xC6D0
#define DP2_HV_START_REG          0xC6D4
#define DP2_POLARITY_WIDTH_REG    0xC6D8
#define DP2_ACITVE_WH_REG         0xC6DC

#define DP2_EPHY_SSC_REG          0xC740	// the same with DP1
#define DP2_EPHY_RT_REG           0xC744	// the same with DP1

#define DP2_AUX_W_DATA0_REG       0xC790
#define DP2_AUX_W_DATA1_REG       0xC794
#define DP2_AUX_W_DATA2_REG       0xC798
#define DP2_AUX_W_DATA3_REG       0xC79C

#define DP2_AUX_R_DATA0_REG       0xC7A0
#define DP2_AUX_R_DATA1_REG       0xC7A4
#define DP2_AUX_R_DATA2_REG       0xC7A8
#define DP2_AUX_R_DATA3_REG       0xC7AC

#define DP2_AUX_TIMER_REG         0xC7B0
#define DP2_AUX_CMD_REG           0xC7B4
#define DP2_NAUD_MUTE_REG         0xC7B8

#define DP2_EPHY_TX_PWR_REG2      0xC7C0
#define DP2_EPHY_TX_IDLE_REG      0xC7C4
#define DP2_EPHY_TX_PWR_REG       0xC7C8
#define DP2_EPHY_PLL_REG          0xC7CC

#define Speed_NONE 0
#define Speed_162MHz 1
#define Speed_270MHz 2

#define NUM_RE_ISSUE_COMMAND 3
#define NUM_RECHECK          20

#define ACK_OK 0x00000005
#define RE_ISSUE_CMD 0x0005

#define NONEVERSION 0
#define DPCD_VER_1   0x100
#define DPCD_REV_0   0x001
#define DPCD_REV_1   0x002

#define AUX_CMD_I2C_WRITE 0x00
#define AUX_CMD_I2C_READ  0x01

#define AUX_CMD_WRITE 0x08
#define AUX_CMD_READ  0x09

#define LANE 4
#define TU_SIZE 47

extern _X_EXPORT void MMIO_WR(DWORD addr, DWORD data);
extern _X_EXPORT DWORD MMIO_RD(DWORD addr);
extern _X_EXPORT void MMIO_WR_MASK(DWORD addr, DWORD data, DWORD mask);

#endif /* _VIA_DP2_H_ */
