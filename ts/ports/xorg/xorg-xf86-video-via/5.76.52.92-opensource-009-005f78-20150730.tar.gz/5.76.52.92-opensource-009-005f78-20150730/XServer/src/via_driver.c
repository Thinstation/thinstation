/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*************************************************************************
 *
 *  File:       via_driver.c
 *  Content:    XFree86 4.0 for VIA/S3G UniChrome
 *
 ************************************************************************/
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <linux/version.h>

#include "via_driver.h"
#ifndef XSERVER_LIBPCIACCESS
#include "xf86RAC.h"
#endif
#include "xf86Priv.h"
#include "shadowfb.h"
#include "mipointer.h"
#include "mipointrst.h"
#include "inputstr.h"

#include "globals.h"

#define DPMS_SERVER

#include "via_video.h"
#include "hw.h"
#include "via_serial.h"
#include "debug.h"               /* for DBG_DD */
#include "via_eng_regs.h"

#ifdef XF86DRI
#include "dri.h"
#endif
#include "via_mergedfb.h"           /*for mergedfb */

#include "via_rotate.h"               /* for rotate feature. */
#include "via_dmabuffer.h"
#include "via_exa_common.h"

#include "via_lcd.h"
#include "via_dp.h"

#ifdef VIA_RANDR12_SUPPORT
#include "xf86Crtc.h"
#include "xf86RandR12.h"
#include "via_common.h"
#include "via_modedata.h"
#include "via_display.h"
#include "via_output.h"
#include "via_displcd.h"
#include "via_swov.h"
#endif
/* add for ttm support */
#include "via_bo_gem.h"
#include "drmmode_display.h"

#include "via_dri2.h"

/*
  *   fix the "Undefined Symbol:vgaHWddc1SetSpeed" problem on FC5(32/64)
  *   when starting X,
  *   replace the function vgaHWddc1SetSpeed as VIAvgaHWddc1SetSpeed.
 */
#ifdef XORG_VERSION_CURRENT
 /*
  *   fix the "Undefined Symbol:vgaHWddc1SetSpeed" problem on FC7(32/64) when
  *   starting X,
  *   assign the function Xorg 1.3.0 to Xorg 7.2.0.
  */

extern Bool VIAnoPanoramiXExtension;

#define DRM_DRIVER_NAME "via_chrome9"

#ifdef DRM_SAMM_VIA
extern drm_context_t samm_ctx_hdl;
#endif

/*
 * prototypes
 */

static void VIAIdentify(int flags);

#if XSERVER_LIBPCIACCESS
static Bool VIAPciProbe(DriverPtr drv, int entity_num, struct pci_device *dev,
    intptr_t data);
#else
static Bool VIAProbe(DriverPtr drv, int flags);
#endif
static Bool VIAPreInit(ScrnInfoPtr pScrn, int flags);
static Bool VIAEnterVT(int scrnIndex, int flags);
static void VIALeaveVT(int scrnIndex, int flags);
static void VIASave(ScrnInfoPtr pScrn);
static void VIARestore(ScrnInfoPtr, vgaRegPtr, VIARegPtr, int flags);
static void VIALoadScaleInfo(ScrnInfoPtr pScrn, ScalingRegs ScaleRegs,
    CARD32 * ScaleType);
static Bool VIAModeInit(ScrnInfoPtr pScrn, DisplayModePtr mode);
static Bool VIACloseScreen(int scrnIndex, ScreenPtr pScreen);
static Bool VIASaveScreen(ScreenPtr pScreen, int mode);
static Bool VIAPMEvent(int scrnIndex, pmEvent event, Bool undo);
static Bool VIAScreenInit(int scrnIndex, ScreenPtr pScreen, int argc,
    char **argv);
static void VIAFreeScreen(int scrnIndex, int flags);
static ModeStatus VIAValidMode(int index, DisplayModePtr mode,
    Bool verbose, int flags);
static const OptionInfoRec *VIAAvailableOptions(int chipid, int busid);
static Bool VIAFilterMode(ScrnInfoPtr pScrn);
static Bool VIACollectBIOSInfo(ScrnInfoPtr pScrn);

static void VIAEnableMMIO(ScrnInfoPtr pScrn);
static Bool VIAMapMMIO(ScrnInfoPtr pScrn);
Bool VIASetDisplayPath_SAMM(ScrnInfoPtr pScrn);
Bool VIASetDisplayPath(ScrnInfoPtr pScrn);
void VIAFindMaxResFromEstablishedTiming(xf86MonPtr MonitorConf, int *MaxH,
    int *MaxV);

#ifdef VIA_RANDR12_SUPPORT
void viaInitDispEngine(VIAPtr pVia);
void viaInitOutputRegSet(ScrnInfoPtr pScrn);
Bool viaInitHwInfo(VIAPtr pVia);
extern Bool viaGetTvCapsSupported(xf86OutputPtr output, CARD32 hDisplay,
    CARD32 vDisplay);
extern void viaSetEmbTvBufferAddress(unsigned int MMIOBase, int mapBase);
#endif

Bool volatile b3DRegsInitialized = 0;
CARD32 g_ChipsetRevisionID = 0;
CARD32 g_ChipCaps = 0;               /* chipset caps */

/* E X T E R N   F U N C T I O N S -----------------------------------------*/
/*fix video can't get enough space from Xserver fb manager*/
extern Bool VIADRIFBInit(ScreenPtr pScreen, VIAPtr pVia);
extern void VIADRIRingBufferCleanup(ScrnInfoPtr pScrn);
extern Bool VIACheckDrmAlreadyInit(ScrnInfoPtr pScrn);
extern void VIAEnableVQ(ScrnInfoPtr pScrn);
extern void VIADisableVQ(ScrnInfoPtr pScrn);
extern void viaFinishInitAccel(ScreenPtr pScreen);

BOOL IsNeedReserve3DScalingMem(VIAPtr pVia);

/* Define one global NEWVIAGRAPHICINFO structure for ddmpeg*/
/* Only used in three files:via_driver.c,via_display.c,via_utility.c*/
NEWVIAGRAPHICINFO NEWVIAGraphicInfo;

/* Only for noRandR rotate for CW and CCW, neet to swap "pScrn->virtualX/virtualY"
 * And "currentMode->HDisplay/VDisplay" for XServer to set correct XV Rotate+panning
 *   clipping windows
 * */
int
swap_height_width_for_CWorCCW(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 tmp = 0;

    if ((pVia->RotateDegree == VIA_ROTATE_DEGREE_90) ||
        (pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
        tmp = pScrn->currentMode->HDisplay;
        pScrn->currentMode->HDisplay = pScrn->currentMode->VDisplay;
        pScrn->currentMode->VDisplay = tmp;

        tmp = pScrn->virtualX;
        pScrn->virtualX = pScrn->virtualY;
        pScrn->virtualY = tmp;
    }

    return 0;
}

/*---------------------------------------------------------------------------*/

#if XSERVER_LIBPCIACCESS
static const struct pci_id_match VIAPciIdMatch[] = {
    {0x1106, PCI_CHIP_VT3314, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3324, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3336, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3327, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3364, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3353, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3409, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
    {0x1106, PCI_CHIP_VT3410, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
#ifdef VIA_VT3293_SUPPORT
    {0x1106, PCI_CHIP_VT3293, PCI_MATCH_ANY, PCI_MATCH_ANY, 0, 0, 0},
#endif
    {0, 0, 0}
};
#endif

DriverRec VIA = {
    VIA_VERSION,
    DRIVER_NAME,
    VIAIdentify,
#if XSERVER_LIBPCIACCESS
    NULL,
#else
    VIAProbe,
#endif
    VIAAvailableOptions,
    NULL,
    0,
    NULL,
#if XSERVER_LIBPCIACCESS
    VIAPciIdMatch,
    VIAPciProbe
#endif
};

/* Supported chipsets */

static SymTabRec VIAChipsets[] = {
    {VIA_P4M800PRO, "P4M800PRO"},
    {VIA_CX700,     "CX700"},
    {VIA_K8M890,    "K8M890"},
    {VIA_P4M890,    "P4M890"},
    {VIA_P4M900,    "P4M900"},
    {VIA_VX800,     "VX800"},
    {VIA_VX855,     "VX855"},
    {VIA_VX900,     "VX900"},
#ifdef VIA_VT3293_SUPPORT
    {VIA_CN750,    "CN750"},
#endif
    {-1, NULL}
};

/* This table maps a PCI device ID to a chipset family identifier. */

static PciChipsets VIAPciChipsets[] = {
    {VIA_P4M800PRO, PCI_CHIP_VT3314,    RES_SHARED_VGA},
    {VIA_CX700,     PCI_CHIP_VT3324,    RES_SHARED_VGA},
    {VIA_K8M890,    PCI_CHIP_VT3336,    RES_SHARED_VGA},
    {VIA_P4M890,    PCI_CHIP_VT3327,    RES_SHARED_VGA},
    {VIA_P4M900,    PCI_CHIP_VT3364,    RES_SHARED_VGA},
    {VIA_VX800,     PCI_CHIP_VT3353,    RES_SHARED_VGA},
    {VIA_VX855,     PCI_CHIP_VT3409,    RES_SHARED_VGA},
    {VIA_VX900,     PCI_CHIP_VT3410,    RES_SHARED_VGA},
#ifdef VIA_VT3293_SUPPORT
    {VIA_CN750,     PCI_CHIP_VT3293,    RES_SHARED_VGA},
#endif
    {-1, -1, RES_UNDEFINED}
};

int gVIAEntityIndex = -1;

Bool via_module_loaded = FALSE;
Bool vt1625_module_loaded = FALSE;
Bool integratedtv_module_loaded = FALSE;
Bool ad9389_module_loaded = FALSE;
Bool sil164_module_loaded = FALSE;
Bool ch7301_module_loaded = FALSE;

#ifndef XSERVER_LIBPCIACCESS

static int via_mem_en = FALSE;
static int via_io_en = FALSE;
static int via_io_mem_en = FALSE;
static xf86SetAccessFuncRec viaAccessFunctionSaved;

static void
via_mem_enable(void *arg)
{
    if (!via_mem_en) {
        (viaAccessFunctionSaved.mem->AccessEnable) (viaAccessFunctionSaved.
            mem->arg);
        via_mem_en = TRUE;
    }
}

static void
via_mem_disable(void *arg)
{
    if (via_mem_en) {
        (viaAccessFunctionSaved.mem->AccessDisable) (viaAccessFunctionSaved.
            mem->arg);
        via_mem_en = FALSE;
    }
}

static void
via_io_enable(void *arg)
{
    if (!via_io_en) {
        (viaAccessFunctionSaved.io->AccessEnable) (viaAccessFunctionSaved.io->
            arg);
        via_io_en = TRUE;
    }
}

static void
via_io_disable(void *arg)
{
    if (via_io_en) {
        (viaAccessFunctionSaved.io->AccessDisable) (viaAccessFunctionSaved.
            io->arg);
        via_io_en = FALSE;
    }
}

static void
via_io_mem_enable(void *arg)
{
    if (!via_io_mem_en) {
        (viaAccessFunctionSaved.io_mem->AccessEnable) (viaAccessFunctionSaved.
            io_mem->arg);
        via_io_mem_en = TRUE;
    }
}

static void
via_io_mem_disable(void *arg)
{
    if (via_io_mem_en) {
        (viaAccessFunctionSaved.io_mem->
            AccessDisable) (viaAccessFunctionSaved.io_mem->arg);
        via_io_mem_en = FALSE;
    }
}

static xf86AccessRec via_mem = {
    &via_mem_disable,
    &via_mem_enable,
    (void *)0
};

static xf86AccessRec via_io = {
    &via_io_disable,
    &via_io_enable,
    (void *)0
};

static xf86AccessRec via_io_mem = {
    &via_io_mem_disable,
    &via_io_mem_enable,
    (void *)0
};

static xf86SetAccessFuncRec via_rac_function = {
    &via_mem,
    &via_io,
    &via_io_mem
};
#endif

/* for Via DVD and Video support */
/*
 * No use now, for old Xserver module code use
 */

#ifdef XFree86LOADER

static MODULESETUPPROTO(VIASetup);

static XF86ModuleVersionInfo VIAVersRec = {
    "via",
    MODULEVENDORSTRING,
    MODINFOSTRING1,
    MODINFOSTRING2,
    XF86_VERSION_CURRENT,
    PACKAGE_VERSION_MAJOR, PACKAGE_VERSION_MINOR, PACKAGE_VERSION_PATCHLEVEL,
    ABI_CLASS_NONE,
    ABI_VIDEODRV_VERSION,
    MOD_CLASS_VIDEODRV,
    {0, 0, 0, 0}
};

_X_EXPORT XF86ModuleData viaModuleData = { &VIAVersRec, VIASetup, NULL };

unsigned int via_xf86_version_current;

#ifdef VIA_RANDR12_SUPPORT
static Bool
via_xf86crtc_resize(ScrnInfoPtr pScrn, int width, int height)
{
    DEBUG(ErrorF("via_xf86crtc_resize, width=%d, height=%d\n", width,
        height));

    pScrn->virtualX = width;
    pScrn->virtualY = height;

    pScrn->frameX1 = pScrn->virtualX;
    pScrn->frameY1 = pScrn->virtualY;

    return TRUE;
}

static const xf86CrtcConfigFuncsRec via_xf86crtc_config_funcs = {
    via_xf86crtc_resize
};
#endif

void
fill3DScalingInfo(VIAPtr pVia, IGASETTINGINFO *pIGASettingInfo,
    HW3D_Scaling_INFO *pgfx3DScal_info)
{
    VIA3DSclSCNParasPtr pDISP3DScalScreenInfo = NULL;
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    VIADISP3DSCALCTRLPtr p3DSCALCTRLInfo =
        &(pIGASettingInfo->DISP3DSCALCTRLInfo);

    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "fill 3D Scaling info, device is %x\n",
        pIGASettingInfo->deviceActived);
    switch (pIGASettingInfo->deviceActived) {
    case VIA_DEVICE_TV:
        pDISP3DScalScreenInfo = &(pBIOSInfo->TVSettingInfo.TV3DScalInfo);
        break;
    case VIA_DEVICE_DFP:
        pDISP3DScalScreenInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        break;
    case VIA_DEVICE_HDMI:
        pDISP3DScalScreenInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        break;
    case VIA_DEVICE_LCD:
        pDISP3DScalScreenInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        break;
    }
    pgfx3DScal_info->gfx3DScalingEnable = TRUE;
    pgfx3DScal_info->OrigHActive = p3DSCALCTRLInfo->OrigHActive;
    pgfx3DScal_info->OrigVActive = p3DSCALCTRLInfo->OrigVActive;
    pgfx3DScal_info->RealHActive = p3DSCALCTRLInfo->RealHActive;
    pgfx3DScal_info->RealVActive = p3DSCALCTRLInfo->RealVActive;
    pgfx3DScal_info->DISP3DScalIGAPath = p3DSCALCTRLInfo->DISP3DScalIGAPath;
    pgfx3DScal_info->XSIZEOffset = pDISP3DScalScreenInfo->XSIZEOffset;
    pgfx3DScal_info->YSIZEOffset = pDISP3DScalScreenInfo->YSIZEOffset;
    pgfx3DScal_info->XPOSITIONOffset = pDISP3DScalScreenInfo->XPOSITIONOffset;
    pgfx3DScal_info->YPOSITIONOffset = pDISP3DScalScreenInfo->YPOSITIONOffset;

    viaGfxInfo->igaInfo[pgfx3DScal_info->DISP3DScalIGAPath -
        1].desired_width = pBIOSInfo->CrtcHDisplay;
    viaGfxInfo->igaInfo[pgfx3DScal_info->DISP3DScalIGAPath -
        1].desired_height = pBIOSInfo->CrtcVDisplay;
}

void
Translate_FillGFXMemInfo(ScrnInfoPtr pScrn, viaGfxInfoPtr viaGfxInfo,
    LPNEWVIAGRAPHICINFO lpNEWVIAGraphicInfo)
{
    VIAPtr pVia = VIAPTR(pScrn);

    if (viaGfxInfo->fbPhybase != 0) {
        lpNEWVIAGraphicInfo->ScreenPhysAddr = viaGfxInfo->fbPhybase;
    }

    if (viaGfxInfo->vramsize != 0) {
        lpNEWVIAGraphicInfo->Screen[0].TotalVRAM = viaGfxInfo->vramsize;
        lpNEWVIAGraphicInfo->Screen[1].TotalVRAM = viaGfxInfo->vramsize;
    }
    if (viaGfxInfo->vheapbase != 0) {
        lpNEWVIAGraphicInfo->Screen[0].VideoHeapBase = viaGfxInfo->vheapbase;
        lpNEWVIAGraphicInfo->Screen[1].VideoHeapBase = viaGfxInfo->vheapbase;
    }
    if (viaGfxInfo->vheapend != 0) {
        lpNEWVIAGraphicInfo->Screen[0].VideoHeapEnd = viaGfxInfo->vheapend;
        lpNEWVIAGraphicInfo->Screen[1].VideoHeapEnd = viaGfxInfo->vheapend;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "[Memory_layout] FB reported to ddmpeg= %ldk \n",
        (viaGfxInfo->vheapend - viaGfxInfo->vheapbase) / 1024);
}

/* Translate the new GfxInfo to the DDMPEG NEWVIAGRAPHICINFO.
*/
void
TranslateGFXInfo(ScrnInfoPtr pScrn, viaGfxInfoPtr viaGfxInfo,
    LPNEWVIAGRAPHICINFO lpNEWVIAGraphicInfo)
{
    int idx;
    int scrnIndex;
    VIAPtr pVia = VIAPTR(pScrn);

    DBG_DD(
        ("  TranslateGFXInfo called: Translate the new GfxInfo"
        " to the DDMPEG NEWVIAGRAPHICINFO.\n"));

    if (viaGfxInfo->chipId != 0) {
        lpNEWVIAGraphicInfo->dwDeviceID = viaGfxInfo->chipId;
    }

    if (viaGfxInfo->fbhandle != 0) {
        lpNEWVIAGraphicInfo->FBhandle = viaGfxInfo->fbhandle;
    }
    if (viaGfxInfo->mmiohandle != 0) {
        lpNEWVIAGraphicInfo->MMIOhandle = viaGfxInfo->mmiohandle;
    }

    if (viaGfxInfo->drmEnabled) {
        lpNEWVIAGraphicInfo->DRMEnabled = TRUE;
    } else {
        lpNEWVIAGraphicInfo->DRMEnabled = FALSE;
    }

    lpNEWVIAGraphicInfo->xrandrEnabled = viaGfxInfo->xrandrEnabled;

    lpNEWVIAGraphicInfo->dwXServerEnabled = TRUE;

    lpNEWVIAGraphicInfo->IsHWCursorEnabled = viaGfxInfo->hwIconEnalbed;

    if (viaGfxInfo->screenAttr.m1.singleview) {
        lpNEWVIAGraphicInfo->duoview = 0;
        lpNEWVIAGraphicInfo->SAMM = FALSE;
        lpNEWVIAGraphicInfo->IsExtend = FALSE;
    } else if (viaGfxInfo->screenAttr.m1.duoview) {
        lpNEWVIAGraphicInfo->duoview = DUOVIEW_ENABLED;
        lpNEWVIAGraphicInfo->SAMM = FALSE;
        lpNEWVIAGraphicInfo->IsExtend = FALSE;
    } else if (viaGfxInfo->screenAttr.m1.samm) {
        lpNEWVIAGraphicInfo->duoview = 0;
        lpNEWVIAGraphicInfo->SAMM =
            (viaGfxInfo->xrandrEnabled) ? FALSE : TRUE;
        lpNEWVIAGraphicInfo->IsExtend =
            (viaGfxInfo->xrandrEnabled) ? TRUE : FALSE;
        lpNEWVIAGraphicInfo->ExtendStatus = RELATION_NONE;
        lpNEWVIAGraphicInfo->Screen1IsAbove = 0;
        lpNEWVIAGraphicInfo->Screen1IsLeft = 0;
    }

    if (viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m2.extend) {
        if (viaGfxInfo->igaAttr.iga2_left)
            lpNEWVIAGraphicInfo->ExtendStatus |= RELATION_LEFT_OF;
        if (viaGfxInfo->igaAttr.iga2_above)
            lpNEWVIAGraphicInfo->ExtendStatus |= RELATION_ABOVE_OF;
        if (viaGfxInfo->igaAttr.iga2_right)
            lpNEWVIAGraphicInfo->ExtendStatus |= RELATION_RIGHT_OF;
        if (viaGfxInfo->igaAttr.iga2_below)
            lpNEWVIAGraphicInfo->ExtendStatus |= RELATION_BELOW_OF;
    } else {
        lpNEWVIAGraphicInfo->Screen1IsLeft = viaGfxInfo->igaAttr.iga2_left;
        lpNEWVIAGraphicInfo->Screen1IsAbove = viaGfxInfo->igaAttr.iga2_above;
    }

    lpNEWVIAGraphicInfo->Screen_IGA_Map[2] = -1;
    /*
     * 1. Non_RandR
     * a. Single:    Screen0 - Screen_IGA_Map[0]
     * b. DuoView:   Screen0 - IGA1
     * Screen1 - IGA2
     * c. SAMM       Screen0 - Screen_IGA_Map[0]
     * Screen1 - Screen_IGA_Map[1]
     * 2. RandR
     * a. Single:    Screen0 - Screen_IGA_Map[0]
     * b. Clone:     Screen0 - IGA1
     * Screen1 - IGA2
     * c. Extend:    Screen0 - IGA1
     * Screen1 - IGA2
     */
    for (idx = 0; idx < 2; idx++) {
        if (viaGfxInfo->igaInfo[idx].actived) {
            /* look for screen index according to IGA */
            for (scrnIndex = 0; scrnIndex < 2; scrnIndex++) {
                if (viaGfxInfo->screenInfo[scrnIndex].igaInuse ==
                    (IGA1 | IGA2)) {
                    lpNEWVIAGraphicInfo->Screen_IGA_Map[0] = IGA1;
                    lpNEWVIAGraphicInfo->Screen_IGA_Map[1] = IGA2;
                    scrnIndex = idx;
                    break;
                } else if (viaGfxInfo->screenInfo[scrnIndex].igaInuse ==
                    idx + 1) {
                    lpNEWVIAGraphicInfo->Screen_IGA_Map[scrnIndex] = idx + 1;
                    break;
                }
            }

            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwSaveWidth =
            viaGfxInfo->igaInfo[idx].visible_width;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwSaveHeight =
            viaGfxInfo->igaInfo[idx].visible_height;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwBPP =
            viaGfxInfo->screenInfo[scrnIndex].bpp;

            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwWidth =
                viaGfxInfo->igaInfo[idx].desired_width;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwHeight =
                viaGfxInfo->igaInfo[idx].desired_height;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwCurWidth =
                viaGfxInfo->igaInfo[idx].crtc_width;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwCurHeight =
                viaGfxInfo->igaInfo[idx].crtc_height;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwPanelWidth =
                viaGfxInfo->igaInfo[idx].crtc_width;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwPanelHeight =
                viaGfxInfo->igaInfo[idx].crtc_height;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwRefreshRate =
                viaGfxInfo->igaInfo[idx].refreshrate;
            lpNEWVIAGraphicInfo->Screen[scrnIndex].dwPitch =
                pScrn->displayWidth *
                (viaGfxInfo->screenInfo[scrnIndex].bpp >> 3);
            lpNEWVIAGraphicInfo->offset_x[idx] =
                viaGfxInfo->igaInfo[idx].start_x;
            lpNEWVIAGraphicInfo->offset_y[idx] =
                viaGfxInfo->igaInfo[idx].start_y;

            if (viaGfxInfo->igaInfo[idx].activeDevice.unit) {
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwActiveDevice =
                    viaGfxInfo->igaInfo[idx].activeDevice.unit;
            } else {
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwActiveDevice = 0;
            }

            if (viaGfxInfo->igaInfo[idx].igaStatus.unit) {
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwPanning =
                    viaGfxInfo->igaInfo[idx].igaStatus.panning;
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwExpand =
                    viaGfxInfo->igaInfo[idx].igaStatus.expanded;
                lpNEWVIAGraphicInfo->Screen[scrnIndex].IsDownScaling =
                    viaGfxInfo->igaInfo[idx].igaStatus.scaling_hw;

                if (viaGfxInfo->igaInfo[idx].igaStatus.panning)
                    lpNEWVIAGraphicInfo->IGAPanningStatus |=
                        (!idx) ? IGA1 : IGA2;

                if (viaGfxInfo->igaInfo[idx].igaStatus.scaling_3d) {
                    memcpy(((!idx) ? &lpNEWVIAGraphicInfo->
                        iga1gfx3DScal_info : &lpNEWVIAGraphicInfo->
                        iga2gfx3DScal_info),
                        &viaGfxInfo->igaInfo[idx].igagfx3DScaling_info,
                        sizeof(HW3D_Scaling_INFO));
                } else {
                    memset(((!idx) ? &lpNEWVIAGraphicInfo->
                        iga1gfx3DScal_info : &lpNEWVIAGraphicInfo->
                        iga2gfx3DScal_info), 0x00,
                        sizeof(HW3D_Scaling_INFO));
                }
            } else {
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwPanning = 0;
                lpNEWVIAGraphicInfo->Screen[scrnIndex].dwExpand = 0;
                lpNEWVIAGraphicInfo->Screen[scrnIndex].IsDownScaling = 0;
                memset(((!idx) ? &lpNEWVIAGraphicInfo->
                    iga1gfx3DScal_info : &lpNEWVIAGraphicInfo->
                    iga2gfx3DScal_info), 0x00, sizeof(HW3D_Scaling_INFO));
            }
            if (viaGfxInfo->igaInfo[idx].igaRRStatus.unit) {
                lpNEWVIAGraphicInfo->IsRotationEnabled = TRUE;
                lpNEWVIAGraphicInfo->rotate =
                    viaGfxInfo->igaInfo[idx].igaRRStatus.unit;
                lpNEWVIAGraphicInfo->samm_rotate[idx + 1] =
                    viaGfxInfo->igaInfo[idx].igaRRStatus.unit;
            } else {
                lpNEWVIAGraphicInfo->IsRotationEnabled = FALSE;
                lpNEWVIAGraphicInfo->rotate = 0;
                lpNEWVIAGraphicInfo->samm_rotate[idx + 1] = 0;
            }
        }
    }

    return;
}

void
FillGraphicInfo_New(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    viaGfxInfo->xrandrEnabled = TRUE;
    /* Added to pass DRM info to V4L */
#ifdef XF86DRI
    viaGfxInfo->drmEnabled = (unsigned long)(pVia->driType != DRI_DISABLED);
#else
    viaGfxInfo->drmEnabled = 0;
#endif

    return;
}

void
FillGraphicMemInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    /*fill generally info, just do once in ScreenInit, because won't changed */
    if (!pVia->IsSecondary) {
        viaGfxInfo->vheapbase = (unsigned long)pVia->FBFreeStart;
        viaGfxInfo->vheapend = (unsigned long)pVia->FBFreeEnd;
        pVia->FBFreeStart = pVia->FBFreeEnd;

        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "[Memory_layout] video managed Fb size = %ld k\n",
            (viaGfxInfo->vheapend - viaGfxInfo->vheapbase) / 1024);

        viaGfxInfo->vramsize = pVia->videoRambytes;
        viaGfxInfo->revisionId = pVia->ChipRev;
        viaGfxInfo->chipId = pVia->ChipId;
        viaGfxInfo->fbPhybase = pVia->FrameBufferBase;
        viaGfxInfo->mmioPhybase = pVia->MmioBase;
        viaGfxInfo->mmioSize = VIA_MMIO_REGSIZE;
        viaGfxInfo->fbSize = pVia->videoRambytes;
    }
}

static pointer
VIASetup(pointer module, pointer opts, int *errmaj, int *errmin)
{
    static Bool setupDone = FALSE;

    /*Only be loaded once */
    if (!setupDone) {
        /*print addtional build string */
        char *subversion = VIA_SUBVERSION;

        if (subversion)
            xf86Msg(X_INFO, "via driver subversion: %s\n", subversion);
        setupDone = TRUE;
        xf86AddDriver(&VIA, module,
#if XSERVER_LIBPCIACCESS
        HaveDriverFuncs
#else
        0
#endif
        );

        return (pointer) 1;
    } else {
        if (errmaj)
            *errmaj = LDR_ONCEONLY;

        return NULL;
    }
}                       /* VIASetup */

#endif /* XFree86LOADER */

int
WaitIdle_H2Chips(VIAPtr pVia)
{
    int loop = 0;

    mem_barrier();

    while (!(VIAGETREG(VIA_REG_STATUS) & VIA_VR_QUEUE_EMPTY)
        && (loop++ < MAXLOOP)) ;

    while ((VIAGETREG(VIA_REG_STATUS) &
        (VIA_CMD_RGTR_BUSY | VIA_2D_ENG_BUSY | VIA_3D_ENG_BUSY)) &&
        (loop++ < MAXLOOP)) ;

    return loop >= MAXLOOP;
}

int
WaitIdle_H5Chips(VIAPtr pVia)
{
    int loop = 0;

    mem_barrier();

    while ((VIAGETREG(VIA_REG_STATUS) &
        (VIA_CMD_RGTR_BUSY_H5 | VIA_2D_ENG_BUSY_H5 | VIA_3D_ENG_BUSY_H5))
        && (loop++ < MAXLOOP)) ;

    return loop >= MAXLOOP;
}

int
WaitIdle_H6Chips(VIAPtr pVia)
{
    int loop = 0;

    mem_barrier();

    while ((VIAGETREG(VIA_REG_STATUS) &
        (VIA_CMD_RGTR_BUSY_M1 | VIA_2D_ENG_BUSY_M1 | VIA_3D_ENG_BUSY_M1))
        && (loop++ < MAXLOOP)) ;

    return loop >= MAXLOOP;
}

Bool
VIAGetRec(ScrnInfoPtr pScrn)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAGetRec\n"));

    if (pScrn->driverPrivate)
        return TRUE;

    /* allocate VIARec */
    pScrn->driverPrivate = xnfcalloc(sizeof(VIARec), 1);

    ((VIARec *) (pScrn->driverPrivate))->pBIOSInfo =
        xnfcalloc(sizeof(VIABIOSInfoRec), 1);

    ((VIARec *) (pScrn->driverPrivate))->pChipInfo =
        xnfcalloc(sizeof(VIAChipInfoRec), 1);

    /* initial value in VIARec */
    ((VIARec *) (pScrn->driverPrivate))->SavedReg.mode = 0xFF;
    ((VIARec *) (pScrn->driverPrivate))->pBIOSInfo->FirstInit = TRUE;
    ((VIARec *) (pScrn->driverPrivate))->HwCursorImage = NULL;
    ((VIARec *) (pScrn->driverPrivate))->HwIconImage = NULL;
    ((VIARec *) (pScrn->driverPrivate))->HIScalingPrimImage = NULL;
    ((VIARec *) (pScrn->driverPrivate))->HIScalingSecImage = NULL;

    return TRUE;

}                       /* VIAGetRec */

void
VIAFreeRec(ScrnInfoPtr pScrn)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAFreeRec\n"));
    if (!pScrn->driverPrivate)
        return;

    free(((VIARec *) (pScrn->driverPrivate))->pBIOSInfo);
    free(((VIARec *) (pScrn->driverPrivate))->pChipInfo);

    free(pScrn->driverPrivate);
    pScrn->driverPrivate = NULL;

}                       /* VIAFreeRec */

static const OptionInfoRec *
VIAAvailableOptions(int chipid, int busid)
{

    return VIAOptions;

}                       /* VIAAvailableOptions */

static void
VIAIdentify(int flags)
{
    xf86PrintChipsets(DRIVER_NAME, "driver for VIA chipsets", VIAChipsets);
    xf86LoadKernelModule("via_chrome9");
}                       /* VIAIdentify */

#if XSERVER_LIBPCIACCESS
struct pci_device *
VIAGetHostBridge(uint32_t Bus, uint32_t Device, uint32_t Function)
{
    struct pci_device_iterator *SlotIterator = NULL;
    struct pci_device *MatchBridge = NULL;

    struct pci_slot_match slot_match = {
        .domain = 0,
        .bus = Bus,
        .dev = Device,
        .func = Function,
        .match_data = 0
    };

    SlotIterator = pci_slot_match_iterator_create(&slot_match);
    MatchBridge = pci_device_next(SlotIterator);
    pci_iterator_destroy(SlotIterator);
    return MatchBridge;
}

static Bool
VIAPciProbe(DriverPtr drv, int entity_num, struct pci_device *dev,
    intptr_t data)
{
    ScrnInfoPtr pScrn = NULL;
    EntityInfoPtr pEnt;
    DevUnion *pPriv;
    static int instance = 0;
    VIAEntPtr pVIAEnt;
    Bool kms_enable = FALSE;

    pScrn = xf86ConfigPciEntity(pScrn, 0, entity_num, VIAPciChipsets,
        NULL, NULL, NULL, NULL, NULL);

    if (!pScrn)
        return FALSE;

    kms_enable = via_kernel_mode_enabled(pScrn);
    pScrn->driverVersion = VIA_VERSION;
    pScrn->driverName = DRIVER_NAME;
    pScrn->name = "VIA";
    pScrn->Probe = NULL;

    if (kms_enable) {
        pScrn->PreInit = VIAPreInit_kms;
        pScrn->ScreenInit = VIAScreenInit_kms;
        pScrn->SwitchMode = VIASwitchMode_kms;
        pScrn->AdjustFrame = VIAAdjustFrame_kms;
        pScrn->EnterVT = VIAEnterVT_kms;
        pScrn->LeaveVT = VIALeaveVT_kms;
        pScrn->FreeScreen = VIAFreeScreen_kms;
        pScrn->ValidMode = VIAValidMode;
        pScrn->PMEvent = VIAPMEvent_kms;
    } else {
        pScrn->PreInit = VIAPreInit;
        pScrn->ScreenInit = VIAScreenInit;
        pScrn->SwitchMode = VIASwitchMode;
        pScrn->AdjustFrame = VIAAdjustFrame;
        pScrn->EnterVT = VIAEnterVT;
        pScrn->LeaveVT = VIALeaveVT;
        pScrn->FreeScreen = VIAFreeScreen;
        pScrn->ValidMode = VIAValidMode;
        pScrn->PMEvent = VIAPMEvent;
    }
    pEnt = xf86GetEntityInfo(entity_num);

    xf86SetEntitySharable(entity_num);
    xf86SetEntityInstanceForScreen(pScrn, pScrn->entityList[0], instance);

    if (gVIAEntityIndex < 0) {
        gVIAEntityIndex = xf86AllocateEntityPrivateIndex();
        pPriv = xf86GetEntityPrivate(pScrn->entityList[0], gVIAEntityIndex);

        if (!pPriv->ptr) {
            pPriv->ptr = xnfcalloc(sizeof(VIAEntRec), 1);
            pVIAEnt = pPriv->ptr;
            pVIAEnt->HasSecondary = FALSE;
            pVIAEnt->pPrimaryScrn = NULL;
            pVIAEnt->pSecondaryScrn = NULL;
            pVIAEnt->pScreensPublicInfo =
            xnfcalloc(sizeof(VIAScreensPublicInfo), 1);
            pVIAEnt->pVidData = (PVIDDATA) malloc(sizeof(VIDDATA));
            memset(pVIAEnt->pVidData, 0, sizeof(VIDDATA));

            pVIAEnt->pVidData->viaGfxInfo =
            (viaGfxInfoPtr) malloc(sizeof(viaGfxInfoRec));
            memset(pVIAEnt->pVidData->viaGfxInfo, 0, sizeof(viaGfxInfoRec));
        }
    }
    instance++;

    if (instance > 1) {
        pPriv = xf86GetEntityPrivate(pScrn->entityList[0], gVIAEntityIndex);

        if (pPriv->ptr) {
            pVIAEnt = pPriv->ptr;
            pVIAEnt->HasSecondary = TRUE;
        }
    }

    return TRUE;
}
#else /* XSERVER_LIBPCIACCESS */

static Bool
VIAProbe(DriverPtr drv, int flags)
{
    GDevPtr *devSections;
    int *usedChips;
    int numDevSections;
    int numUsed;
    Bool foundScreen = FALSE;
    int i;
    Bool kms_enable = FALSE;

    /* sanity checks */
    if ((numDevSections = xf86MatchDevice(DRIVER_NAME, &devSections)) <= 0)
        return FALSE;

    if (xf86GetPciVideoInfo() == NULL)
        return FALSE;

    numUsed = xf86MatchPciInstances(DRIVER_NAME,
    PCI_VIA_VENDOR_ID,
    VIAChipsets,
    VIAPciChipsets, devSections, numDevSections, drv, &usedChips);
    free(devSections);

    if (numUsed <= 0)
        return FALSE;

    if (flags & PROBE_DETECT) {
        foundScreen = TRUE;
    } else {
        /* SAMM on Xorg 1.4.x series, Xorg treats the two screens independent
         * of each other and do lots of screen dependent resources(io*mem)
         * enable*disable when XServer states(SETUP*OPERATING) change, it
         * was this too-frequent-change that cause the GFX won't response to
         * cycle from io or mem range.
         * SO: hook our own enable*disable function, our own enable*disable
         * function will call the xorg's original enable*disable function
         * when it is really needs.
         */
        if (numUsed > 1) {
            EntityInfoRec via_entityinfo;

            via_entityinfo.index = usedChips[0];
            xf86SetAccessFuncs(&via_entityinfo,
                &via_rac_function, &viaAccessFunctionSaved);
        }
        for (i = 0; i < numUsed; i++) {
            ScrnInfoPtr pScrn = NULL;
            static int instance = 0;
            DevUnion *pPriv;
            VIAEntPtr pVIAEnt;

            if ((pScrn = xf86ConfigPciEntity(pScrn, 0, usedChips[i],
                VIAPciChipsets, 0, 0, 0, 0, 0))) {
                kms_enable = via_kernel_mode_enabled(pScrn);
                pScrn->driverVersion = VIA_VERSION;
                pScrn->driverName = DRIVER_NAME;
                pScrn->name = "VIA";
                pScrn->Probe = VIAProbe;
                if (kms_enable) {
                    pScrn->PreInit = VIAPreInit_kms;
                    pScrn->ScreenInit = VIAScreenInit_kms;
                    pScrn->SwitchMode = VIASwitchMode_kms;
                    pScrn->AdjustFrame = VIAAdjustFrame_kms;
                    pScrn->EnterVT = VIAEnterVT_kms;
                    pScrn->LeaveVT = VIALeaveVT_kms;
                    pScrn->FreeScreen = VIAFreeScreen_kms;
                    pScrn->ValidMode = VIAValidMode_kms;
                    pScrn->PMEvent = VIAPMEvent_kms;
                } else {
                    pScrn->PreInit = VIAPreInit;
                    pScrn->ScreenInit = VIAScreenInit;
                    pScrn->SwitchMode = VIASwitchMode;
                    pScrn->AdjustFrame = VIAAdjustFrame;
                    pScrn->EnterVT = VIAEnterVT;
                    pScrn->LeaveVT = VIALeaveVT;
                    pScrn->FreeScreen = VIAFreeScreen;
                    pScrn->ValidMode = VIAValidMode;
                    pScrn->PMEvent = VIAPMEvent;
                }
                foundScreen = TRUE;

                xf86SetEntitySharable(usedChips[i]);
                xf86SetEntityInstanceForScreen(pScrn,
                    pScrn->entityList[0], instance);

                if (gVIAEntityIndex < 0) {
                    gVIAEntityIndex = xf86AllocateEntityPrivateIndex();
                    pPriv = xf86GetEntityPrivate(pScrn->entityList[0],
                        gVIAEntityIndex);

                    if (!pPriv->ptr) {
                        pPriv->ptr = xnfcalloc(sizeof(VIAEntRec), 1);
                        pVIAEnt = pPriv->ptr;
                        pVIAEnt->HasSecondary = FALSE;
                        pVIAEnt->pPrimaryScrn = NULL;
                        pVIAEnt->pSecondaryScrn = NULL;
                        pVIAEnt->pScreensPublicInfo =
                            xnfcalloc(sizeof(VIAScreensPublicInfo), 1);
                        pVIAEnt->pVidData =
                            (PVIDDATA) malloc(sizeof(VIDDATA));
                        memset(pVIAEnt->pVidData, 0, sizeof(VIDDATA));

                        pVIAEnt->pVidData->viaGfxInfo =
                            (viaGfxInfoPtr) malloc(sizeof(viaGfxInfoRec));
                        memset(pVIAEnt->pVidData->viaGfxInfo, 0,
                            sizeof(viaGfxInfoRec));
                    }
                }
                instance++;
                if (instance > 1) {
                    pPriv = xf86GetEntityPrivate(pScrn->entityList[0],
                    gVIAEntityIndex);

                    if (pPriv->ptr) {
                        pVIAEnt = pPriv->ptr;
                        pVIAEnt->HasSecondary = TRUE;
                    }
                }
            }
        }
    }

    free(usedChips);

    return foundScreen;

}                       /* VIAProbe */
#endif /* XSERVER_LIBPCIACCESS */

static int
LookupChipID(PciChipsets * pset, int ChipID)
{
    /* Is there a function to do this for me? */
    while (pset->numChipset >= 0) {
        if (pset->PCIid == ChipID)
            return pset->numChipset;

        pset++;
    }

    return -1;

}                       /* LookupChipID */

static unsigned int
VIAddc1Read(ScrnInfoPtr pScrn)
{
    register vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    register CARD8 tmp;

    while (hwp->readST01(hwp) & 0x8) {
    };
    while (!(hwp->readST01(hwp) & 0x8)) {
    };

    VGAOUT8(0x3c4, 0x26);
    tmp = VGAIN8(0x3c5);
    return ((unsigned int)((tmp & 0x08) >> 3));
}

void
VIAvgaHWddc1SetSpeed(ScrnInfoPtr pScrn, xf86ddcSpeed speed)
{
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    unsigned char tmp;
    struct _vgaDdcSave *save;

    switch (speed) {
        case DDC_FAST:

            if (hwp->ddc != NULL)
                break;
            hwp->ddc = xnfcalloc(sizeof(struct _vgaDdcSave), 1);
            save = (struct _vgaDdcSave *)hwp->ddc;
            /* Lightpen register disable - allow access to cr10 & 11; just in case */
            save->cr03 = hwp->readCrtc(hwp, 0x03);
            hwp->writeCrtc(hwp, 0x03, (save->cr03 | 0x80));
            save->cr12 = hwp->readCrtc(hwp, 0x12);
            hwp->writeCrtc(hwp, 0x12, DISPLAY_END);
            save->cr15 = hwp->readCrtc(hwp, 0x15);
            hwp->writeCrtc(hwp, 0x15, BLANK_START);
            save->cr10 = hwp->readCrtc(hwp, 0x10);
            hwp->writeCrtc(hwp, 0x10, SYNC_START);
            save->cr11 = hwp->readCrtc(hwp, 0x11);
            /* unprotect group 1 registers; just in case ... */
            hwp->writeCrtc(hwp, 0x11, ((save->cr11 & 0x70) | SYNC_END));
            save->cr16 = hwp->readCrtc(hwp, 0x16);
            hwp->writeCrtc(hwp, 0x16, BLANK_END);
            save->cr06 = hwp->readCrtc(hwp, 0x06);
            hwp->writeCrtc(hwp, 0x06, V_TOTAL);
            /* all values have less than 8 bit - mask out 9th and 10th bits */
            save->cr09 = hwp->readCrtc(hwp, 0x09);
            hwp->writeCrtc(hwp, 0x09, (save->cr09 & 0xDF));
            save->cr07 = hwp->readCrtc(hwp, 0x07);
            hwp->writeCrtc(hwp, 0x07, (save->cr07 & 0x10));
            /* vsync polarity negativ & ensure a 25MHz clock */
            save->msr = hwp->readMiscOut(hwp);
            hwp->writeMiscOut(hwp, ((save->msr & 0xF3) | 0x80));
            break;
        case DDC_SLOW:
            if (hwp->ddc == NULL)
                break;
            save = (struct _vgaDdcSave *)hwp->ddc;
            hwp->writeMiscOut(hwp, save->msr);
            hwp->writeCrtc(hwp, 0x07, save->cr07);
            tmp = hwp->readCrtc(hwp, 0x09);
            hwp->writeCrtc(hwp, 0x09, ((save->cr09 & 0x20) | (tmp & 0xDF)));
            hwp->writeCrtc(hwp, 0x06, save->cr06);
            hwp->writeCrtc(hwp, 0x16, save->cr16);
            hwp->writeCrtc(hwp, 0x11, save->cr11);
            hwp->writeCrtc(hwp, 0x10, save->cr10);
            hwp->writeCrtc(hwp, 0x15, save->cr15);
            hwp->writeCrtc(hwp, 0x12, save->cr12);
            hwp->writeCrtc(hwp, 0x03, save->cr03);
            free(save);
            hwp->ddc = NULL;
            break;
        default:
            break;
    }
}

#else
#define VIAvgaHWddc1SetSpeed vgaHWddc1SetSpeed
#endif

static Bool
VIAddc1(int scrnIndex)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    xf86MonPtr pMon;
    CARD8 tmp;
    Bool success = FALSE;

    /* initialize chipset */
    VGAOUT8(0x3c4, 0x26);
    tmp = VGAIN8(0x3c5);
    VGAOUT8(0x3c4, 0x26);
    VGAOUT8(0x3c5, (tmp | 0x11));

    if ((pMon =
        xf86PrintEDID(xf86DoEDID_DDC1(scrnIndex, VIAvgaHWddc1SetSpeed,
        VIAddc1Read))) != NULL)
    success = TRUE;
    xf86SetDDCproperties(pScrn, pMon);

    /* undo initialization */
    VGAOUT8(0x3c4, 0x26);
    VGAOUT8(0x3c5, tmp);
    return success;
}

static Bool
VIAddc2(int scrnIndex)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    xf86MonPtr pMon;
    CARD8 tmp;
    Bool success = FALSE;

    VGAOUT8(0x3c4, 0x26);
    tmp = VGAIN8(0x3c5);
    pMon = xf86DoEDID_DDC2(pScrn->scrnIndex, pVia->I2C_Port1);
    if (pMon)
        success = TRUE;
    pVia->DDC1 = pMon;
    xf86PrintEDID(pMon);
    xf86SetDDCproperties(pScrn, pMon);
    VGAOUT8(0x3c4, 0x26);
    VGAOUT8(0x3c5, tmp);

    return success;
}

void
VIACheckIfUseDuoView(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIACheckIfUseDuoView\n"));

    pBIOSInfo->DuoView = TRUE;


    if (pVia->pVIAEnt->HasSecondary) {
        pBIOSInfo->DuoView = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Not support DuoView because SAMM is on.\n"));
    }
}

void
VIACheckCursorTypeToUse(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    if ((pVia->ForceSWCursor) || (pBIOSInfo->MergedFB)) {
        /* Use SW Cursor */
        pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor = FALSE;
    } else {
        if (pBIOSInfo->DuoView) {
            switch (pBIOSInfo->Chipset) {
            case VIA_CX700:
            case VIA_P4M890:
            case VIA_P4M900:
            case VIA_VX800:
            case VIA_VX855:
            case VIA_VX900:
                pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor = TRUE;
                break;
            default:
                pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor = FALSE;
            }
        } else {
            /* Use HW Cursor */
            pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor = TRUE;
        }
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Using %s cursor\n",
        pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor ? "HW" : "SW"));
}

/* For Hotkey Timer Use. */
CARD32
VIACheckHotkeyStatus(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    CARD16 deviceCount = 0;
    CARD16 i;
    CARD16 deviceSeq[4];

    /* Check the change of register CR3C[0]. */
    if (read_reg(VIACR, CR3C) & BIT0) {
	/* Clear */
	write_reg_mask(CR3C, VIACR, 0x00, BIT0);

	VIASwitchMode(pScrn->scrnIndex, pScrn->currentMode, 0);
    }

    return 1000;
}

CARD32
VIASyncTimer(OsTimerPtr timer, CARD32 now, pointer arg)
{
    ScrnInfoPtr pScrn = (ScrnInfoPtr) arg;
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->IsHotkeyTimerEnabled) {
        VIACheckHotkeyStatus(pScrn);
    }

    return 30;
}

static int
VIATranslateTVOutputNameToID(char *pName)
{
    if (!xf86NameCmp(pName, "S-Video")) {
        return TV_OUTPUT_SVIDEO;
    } else if (!xf86NameCmp(pName, "Composite")) {
        return TV_OUTPUT_COMPOSITE;
    } else if (!xf86NameCmp(pName, "SC")) {
        return TV_OUTPUT_COMPOSITE_SVIDEO;
    } else if (!xf86NameCmp(pName, "RGB")) {
        return TV_OUTPUT_RGB;
    } else if (!xf86NameCmp(pName, "YCbCr") || !xf86NameCmp(pName, "YPbPr")) {
        return TV_OUTPUT_YPBPR;
    } else if (!xf86NameCmp(pName, "RGBSC")) {
        return TV_OUTPUT_RGB_COMPOSITE_SVIDEO;
    } else if (!xf86NameCmp(pName, "YCbCrSC")
        || !xf86NameCmp(pName, "YPbPrSC")) {
        return TV_OUTPUT_YPBPR_COMPOSITE_SVIDEO;
    } else {
        ErrorF("Invalid TV Output.\n");
        return TV_OUTPUT_NONE;
    }
}

static void
VIAGetOptions_MergedFB(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    char *strptr;
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    /* collect MergedFB options */
    pBIOSInfo->MergedFB = FALSE;
    pBIOSInfo->UseVIAXinerama = TRUE;
    pBIOSInfo->Scrn2Position = viaRightOf;

    if (xf86ReturnOptValBool(VIAOptions, OPTION_MERGEDFB, FALSE)) {
        pBIOSInfo->MergedFB = TRUE;
        pBIOSInfo->DuoView = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MergedFB mode forced on.\n");
    } else {
        pBIOSInfo->MergedFB = FALSE;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MergedFB mode forced off.\n");
    }

    /* Do some MergedFB mode initialisation */
    if (pBIOSInfo->MergedFB) {
        strptr = (char *)xf86GetOptValString(VIAOptions, OPTION_SCRN2POS);
        if (strptr) {
            if ((!xf86NameCmp(strptr, "LeftOf"))) {
                pBIOSInfo->Scrn2Position = viaLeftOf;
            } else if ((!xf86NameCmp(strptr, "RightOf"))) {
                pBIOSInfo->Scrn2Position = viaRightOf;
            } else if ((!xf86NameCmp(strptr, "Above"))) {
                pBIOSInfo->Scrn2Position = viaAbove;
            } else if ((!xf86NameCmp(strptr, "Below"))) {
                pBIOSInfo->Scrn2Position = viaBelow;
            } else {
                xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                    "\"%s\" is not a valid parameter for"
                    " Option \"Scrn2Position\"\n",
                    strptr);
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "Valid parameters are \"RightOf\", \"LeftOf\","
                    " \"Above\", or\"Below\"\n");
            }
        }

        /*don't use pseudo xinerama,but virtual screen */
        if (xf86ReturnOptValBool(VIAOptions, OPTION_NOVIAXINERAMA, FALSE))
            pBIOSInfo->UseVIAXinerama = FALSE;
    }
}

static void
VIAGetOptions_Cursor(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    /*
     * The default if neither is specified is HW.
     */
    pVia->ForceSWCursor = FALSE;

    if (xf86ReturnOptValBool(VIAOptions, OPTION_SWCURSOR, FALSE)) {
        pVia->ForceSWCursor = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Option SWCursor enabled.\n");
    }
}

static void
VIAGetOptions_Mem4DDmpeg(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    int mem4ddmpeg;

    if (xf86GetOptValInteger(VIAOptions, OPTION_EXA_MEM4DDMPEG, &mem4ddmpeg)) {
        pVia->mem4ddmpeg = mem4ddmpeg;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option mem4ddmpeg  size =%d k \n", mem4ddmpeg / 1024);
    }
}

int
TranslateDIPortNameToID(char *pStr)
{
    if (!xf86NameCmp(pStr, "DFP_HIGH"))
        return VIA_DI_DFPHIGH;
    else if (!xf86NameCmp(pStr, "DFP_LOW"))
        return VIA_DI_DFPLOW;
    else if (!xf86NameCmp(pStr, "DFP_HIGHLOW"))
        return VIA_DI_DFPHIGHLOW;
    else if (!xf86NameCmp(pStr, "DVP0"))
        return VIA_DI_DVP0;
    else if (!xf86NameCmp(pStr, "DVP1"))
        return VIA_DI_DVP1;
    else if (!xf86NameCmp(pStr, "LVDS0"))
        return VIA_DI_LVDS0;
    else if (!xf86NameCmp(pStr, "LVDS1"))
        return VIA_DI_LVDS1;
    else if (!xf86NameCmp(pStr, "LVDS0LVDS1"))
        return VIA_DI_LVDS0LVDS1;
    else if (!xf86NameCmp(pStr, "TMDS"))
        return VIA_DI_TMDS;
    else if (!xf86NameCmp(pStr, "TTL"))
        return VIA_DI_TTL;
    else if (!xf86NameCmp(pStr, "LVDS1DVP1"))
        return VIA_DI_LVDS1DVP1;
    else
        return VIA_DI_NONE;           /* Invalid port. */
}

static void
viaSetDefaultLCDPanelChannelInfo(VIABIOSInfoPtr pBIOSInfo)
{
    switch (pBIOSInfo->LVDSSettingInfo.PanelSizeID) {
    case VIA_1280X1024:
    case VIA_1400X1050:
    case VIA_1440X900:
    case VIA_1600X1200:
        pBIOSInfo->LVDSSettingInfo.IsDualEdge = TRUE;
        pBIOSInfo->LVDSSettingInfo2.IsDualEdge = TRUE;
        break;
    default:
        pBIOSInfo->LVDSSettingInfo.IsDualEdge = FALSE;
        pBIOSInfo->LVDSSettingInfo2.IsDualEdge = FALSE;
        break;
    }
}

static void
VIAGetOptions_LCDInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;

    /* Initialize LCD panel size: */
    pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_INVALID;

    switch (pVia->Chipset) {
    case VIA_CX700:
    case VIA_VX800:
    case VIA_VX855:
    case VIA_VX900:
        pBIOSInfo->LVDSSettingInfo.ChipID = VIA_INTEGRATED_LVDS;
        break;
    default:
        pBIOSInfo->LVDSSettingInfo.ChipID = VIA_Hardwired;
        break;
    }

    /* LCD MSB/LSB Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_LCD_MSB_ENABLE, FALSE)) {
        pBIOSInfo->LVDSSettingInfo.MsbEnable = TRUE;
        pBIOSInfo->LVDSSettingInfo2.MsbEnable = TRUE;
    } else {
        pBIOSInfo->LVDSSettingInfo.MsbEnable = FALSE;
        pBIOSInfo->LVDSSettingInfo2.MsbEnable = FALSE;
    }

    /* Set LCD Panel Info. */
    if (pStr = xf86GetOptValString(VIAOptions, OPTION_LCD_PANEL_SIZE)) {
        char *b = strdup(pStr);

        pStr = strtok(b, "x");
        CARD32 panelWidth = (CARD32) atoi(pStr);

        pStr = strtok(NULL, "x");
        CARD32 panelHeight = (CARD32) atoi(pStr);

        /*Check if the panel size is valid */
        if (VIAIsPanelSizeValid(panelWidth, panelHeight)) {
            pBIOSInfo->LVDSSettingInfo.PanelSizeID =
                VIA_MAKE_ID(panelWidth, panelHeight);

            viaSetDefaultLCDPanelChannelInfo(pBIOSInfo);

            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "LCD Panel Size is %lux%lu.\n", panelWidth, panelHeight);
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "LCD Panel size %lux%lu is invalid!\n", panelWidth,
                panelHeight);
        }
    }

    /* LCD Dithering Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_LCD_NO_DITHERING, FALSE)) {
        pBIOSInfo->LVDSSettingInfo.IsDithering = FALSE;
        pBIOSInfo->LVDSSettingInfo2.IsDithering = FALSE;
    } else {
        pBIOSInfo->LVDSSettingInfo.IsDithering = TRUE;
        pBIOSInfo->LVDSSettingInfo2.IsDithering = TRUE;
    }

    /* LCD DualChannel Option */
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_LCD_DUAL_CHANNEL))) {
        if ((*pStr == '\0') ||
            !xf86NameCmp(pStr, "TRUE") ||
            !xf86NameCmp(pStr, "True") || !xf86NameCmp(pStr, "true")) {
            pBIOSInfo->LVDSSettingInfo.IsDualEdge = TRUE;
            pBIOSInfo->LVDSSettingInfo2.IsDualEdge = TRUE;
        } else if (!xf86NameCmp(pStr, "FALSE") ||
            !xf86NameCmp(pStr, "False") || !xf86NameCmp(pStr, "false")) {
            pBIOSInfo->LVDSSettingInfo.IsDualEdge = FALSE;
            pBIOSInfo->LVDSSettingInfo2.IsDualEdge = FALSE;
        }
    }

    /* LCD Center/Expand Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_CENTER, FALSE)) {
        pBIOSInfo->LVDSSettingInfo.Center = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "(OPTION) LCD Center is On\n");
    } else {
        pBIOSInfo->LVDSSettingInfo.Center = FALSE;
    }

    /* Bus Width Option */
    pBIOSInfo->LVDSSettingInfo.BusWidth = VIA_DI_12BIT;

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_LCD_BUS_WIDTH))) {
        if (!xf86NameCmp(pStr, "12BIT")) {
            pBIOSInfo->LVDSSettingInfo.BusWidth = VIA_DI_12BIT;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "LCD Bus Width is 12BIT\n");
        } else if (!xf86NameCmp(pStr, "24BIT")) {
            pBIOSInfo->LVDSSettingInfo.BusWidth = VIA_DI_24BIT;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "LCD Bus Width is 24BIT\n");
        }
    }

    /* Support LCD port selection */
    pBIOSInfo->LVDSSettingInfo.DIPort = VIA_DI_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_LCD_PORT))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "LCD port set to %s.\n",
            pStr));
        pBIOSInfo->LVDSSettingInfo.DIPort = TranslateDIPortNameToID(pStr);

        if (pBIOSInfo->LVDSSettingInfo.DIPort == VIA_DI_TTL) {
            if (pBIOSInfo->Chipset == VIA_VX855)
                pBIOSInfo->LVDSSettingInfo.DIPort =
                    (VIA_DI_LVDS0LVDS1DVP1 | VIA_DI_TTL);
            else
                pBIOSInfo->LVDSSettingInfo.DIPort =
                    (VIA_DI_LVDS0DVP1 | VIA_DI_TTL);
        }
    }
}

static void
VIAGetOptions_TVInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;

    /* TV DotCrawl Enable Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_TVDOTCRAWL, FALSE)) {
        pBIOSInfo->TVSettingInfo.TVDotCrawl = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "DotCrawl is Enable\n");
    } else {
        pBIOSInfo->TVSettingInfo.TVDotCrawl = FALSE;
    }

    /* TV Type: */
    pBIOSInfo->TVSettingInfo.TVType = TVTYPE_NONE;
    pBIOSInfo->TVSettingInfo.TVTypeIsNTSCJ = FALSE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TVTYPE))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "TV Type is %s.\n",
            pStr));

    if (!xf86NameCmp(pStr, "NTSC"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_NTSC;
    else if (!xf86NameCmp(pStr, "NTSC_J")) {
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_NTSC;
        pBIOSInfo->TVSettingInfo.TVTypeIsNTSCJ = TRUE;
    } else if (!xf86NameCmp(pStr, "PAL"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_PAL;
    else if (!xf86NameCmp(pStr, "480P"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_480P;
    else if (!xf86NameCmp(pStr, "576P"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_576P;
    else if (!xf86NameCmp(pStr, "720P"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_720P;
    else if (!xf86NameCmp(pStr, "1080I"))
        pBIOSInfo->TVSettingInfo.TVType = TVTYPE_1080I;
    }

    /* TV out put signal Option */
    pBIOSInfo->TVSettingInfo.TVOutput = TV_OUTPUT_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TVOUTPUT))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "TV Output Signal is %s\n", pStr));
        pBIOSInfo->TVSettingInfo.TVOutput =
            VIATranslateTVOutputNameToID(pStr);
    }

    if (pVia->DISP3DScalingCaps & VIA_DEVICE_TV) {
        /* TV Shrink Option */
        if ((TVTYPE_1080I == pBIOSInfo->TVSettingInfo.TVType) ||
            (TVTYPE_720P == pBIOSInfo->TVSettingInfo.TVType))
            pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVNORMAL;
        else {
            pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVOVER;
            if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TVVSCAN))) {
                if (!xf86NameCmp(pStr, "under")
                    || !xf86NameCmp(pStr, "normal"))
                    pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVNORMAL;
                else if (!xf86NameCmp(pStr, "fit"))
                    pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVFIT;
                else if (!xf86NameCmp(pStr, "over"))
                    pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVOVER;
            }
        }
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "TV Shrink scan mode is %d\n",
            pBIOSInfo->TVSettingInfo.TVVScan));
    } else {
        /* TV Standard Option */
        pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVNORMAL;
        if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TVVSCAN))) {
            if (!xf86NameCmp(pStr, "under") || !xf86NameCmp(pStr, "normal"))
                pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVNORMAL;
            else if (!xf86NameCmp(pStr, "fit"))
                pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVFIT;
            else if (!xf86NameCmp(pStr, "over"))
                pBIOSInfo->TVSettingInfo.TVVScan = VIA_TVOVER;
        }
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "TV scan mode is %d\n",
            pBIOSInfo->TVSettingInfo.TVVScan));
    }

#ifndef CS_FLAG_NO_TV_SCAL
    /* For H-Scaling adjustment: */
    /* We can use this option to specify the number of pixels to adjust
       each time. */
    pBIOSInfo->TVSettingInfo.TVHScale = VIA_TVSCALE5;
    if (xf86GetOptValInteger(VIAOptions, OPTION_TVHSCALE,
        &(pBIOSInfo->TVSettingInfo.TVHScale))) {
        if ((pBIOSInfo->TVSettingInfo.TVHScale < VIA_TVSCALE1) ||
            (pBIOSInfo->TVSettingInfo.TVHScale > VIA_TVSCALE5))
            pBIOSInfo->TVSettingInfo.TVHScale = VIA_TVSCALE5;
    }

    /* For V-Scaling adjustment: */
    /* We can use this option to specify the number of lines to adjust
       each time. */
    pBIOSInfo->TVSettingInfo.TVVScale = VIA_TVSCALE5;
    if (xf86GetOptValInteger(VIAOptions, OPTION_TVVSCALE,
        &(pBIOSInfo->TVSettingInfo.TVVScale))) {
        if ((pBIOSInfo->TVSettingInfo.TVVScale < VIA_TVSCALE1) ||
            (pBIOSInfo->TVSettingInfo.TVVScale > VIA_TVSCALE5))
            pBIOSInfo->TVSettingInfo.TVVScale = VIA_TVSCALE5;
    }
#endif /* CS_FLAG_NO_TV_SCAL */

    pBIOSInfo->TVDIPort = VIA_DI_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TV_PORT))) {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "TV port set to %s.\n", pStr);
        pBIOSInfo->TVDIPort = TranslateDIPortNameToID(pStr);
    }
}

static void
VIAGetOptions_TV2Info(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;

    /* TV2 DotCrawl Enable Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_TV2DOTCRAWL, FALSE)) {
        pBIOSInfo->TVSettingInfo2.TVDotCrawl = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: TV2 DotCrawl Enable\n");
    } else {
        pBIOSInfo->TVSettingInfo2.TVDotCrawl = FALSE;
    }

    /* TV2 Type: */
    pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TV2TYPE))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: TV2 Type is %s.\n", pStr));

        if (!xf86NameCmp(pStr, "NTSC"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_NTSC;
        else if (!xf86NameCmp(pStr, "PAL"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_PAL;
        else if (!xf86NameCmp(pStr, "480P"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_480P;
        else if (!xf86NameCmp(pStr, "576P"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_576P;
        else if (!xf86NameCmp(pStr, "720P"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_720P;
        else if (!xf86NameCmp(pStr, "1080I"))
            pBIOSInfo->TVSettingInfo2.TVType = TVTYPE_1080I;
    }

    /* TV2 out put signal Option */
    pBIOSInfo->TVSettingInfo2.TVOutput = TV_OUTPUT_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_TV2OUTPUT))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: TV2 Output Signal is %s\n", pStr));
        pBIOSInfo->TVSettingInfo2.TVOutput =
            VIATranslateTVOutputNameToID(pStr);
    }

    /* TV2 Standard Option: TV2 only could be internal TV, so it only use
       normal scan. */
    pBIOSInfo->TVSettingInfo2.TVVScan = VIA_TVNORMAL;

#ifndef CS_FLAG_NO_TV_SCAL
    /* For TV2 H-Scaling adjustment: */
    /* We can use this option to specify the number of pixels to adjust
       each time. */
    pBIOSInfo->TVSettingInfo2.TVHScale = VIA_TVSCALE5;
    if (xf86GetOptValInteger(VIAOptions, OPTION_TV2HSCALE,
        &(pBIOSInfo->TVSettingInfo2.TVHScale))) {
        if ((pBIOSInfo->TVSettingInfo2.TVHScale < VIA_TVSCALE1) ||
            (pBIOSInfo->TVSettingInfo2.TVHScale > VIA_TVSCALE5)) {
            pBIOSInfo->TVSettingInfo2.TVHScale = VIA_TVSCALE5;
        }
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: TV2 HScale is %d\n",
            pBIOSInfo->TVSettingInfo2.TVHScale));
    }

    /* For TV2 V-Scaling adjustment: */
    /* We can use this option to specify the number of lines to adjust
       each time. */
    pBIOSInfo->TVSettingInfo2.TVVScale = VIA_TVSCALE5;
    if (xf86GetOptValInteger(VIAOptions, OPTION_TV2VSCALE,
        &(pBIOSInfo->TVSettingInfo2.TVVScale))) {
        if ((pBIOSInfo->TVSettingInfo2.TVVScale < VIA_TVSCALE1) ||
            (pBIOSInfo->TVSettingInfo2.TVVScale > VIA_TVSCALE5)) {
            pBIOSInfo->TVSettingInfo2.TVVScale = VIA_TVSCALE5;
        }
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: TV2 VScale is %d\n",
            pBIOSInfo->TVSettingInfo2.TVVScale));
    }
#endif /* CS_FLAG_NO_TV_SCAL */

}

static void
VIAGetOptions_DVIInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;

    /* Initialize DVI panel size: */
    pBIOSInfo->TMDSSettingInfo.DFPSize = M_INVALID;
    pBIOSInfo->TMDSSettingInfo2.DFPSize = M_INVALID;

    /* Support DVI port selection */
    pBIOSInfo->TMDSSettingInfo.DFPDIPort = VIA_DI_NONE;
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DVI_PORT))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "DVI port set to %s.\n",
            pStr));

        if (!xf86NameCmp(pStr, "DFP_HIGH")) {
            pBIOSInfo->TMDSSettingInfo.DFPDIPort = VIA_DI_DFPHIGH;
        } else if (!xf86NameCmp(pStr, "DFP_LOW"))
            pBIOSInfo->TMDSSettingInfo.DFPDIPort = VIA_DI_DFPLOW;
        else if (!xf86NameCmp(pStr, "DVP0"))
            pBIOSInfo->TMDSSettingInfo.DFPDIPort = VIA_DI_DVP0;
        else if (!xf86NameCmp(pStr, "DVP1"))
            pBIOSInfo->TMDSSettingInfo.DFPDIPort = VIA_DI_DVP1;
    }
}

static void
VIAParseDPAValues(char *pStr, int *pReturnedBuffer, int BufSize)
{
    char *pToken;
    int i = 0;

    pToken = strtok(pStr, ",");

    if (pToken) {
        *pReturnedBuffer = atoi(pToken);
        pReturnedBuffer++;
        i++;
    }

    for (; i < BufSize; i++) {
        pToken = strtok('\0', ",");

        if (pToken) {
            *pReturnedBuffer = atoi(pToken);
            pReturnedBuffer++;
        }
    }
}

static void
VIAGetOptions_DPASettingInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;
    int TmpBuffer[3];

    pBIOSInfo->UserDPASettingInfo.HasUserSetting_Gfx = FALSE;

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_DVP0))) {
        /* The data we get should be "v1,v2,v3", they are for */
        /* "Clock Polarity/Adjust,Data Driving,Clock Driving". */
        VIAParseDPAValues(pStr, TmpBuffer, 3);
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "DVP0 DPA=%d, DataDriving=%d, ClockDriving=%d.\n",
            TmpBuffer[0], TmpBuffer[1], TmpBuffer[2]));

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_Gfx = TRUE;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP0 = TmpBuffer[0] & 0x0F;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP0DataDri_S =
            (TmpBuffer[1] & BIT0) << 1;    /* for SR1B[1] */
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP0DataDri_S1 =
            (TmpBuffer[1] & BIT1) << 4;    /* for SR2A[5] */
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP0ClockDri_S =
            (TmpBuffer[2] & BIT0) << 2;    /* for SR1E[2] */
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP0ClockDri_S1 =
            (TmpBuffer[2] & BIT1) << 3;    /* for SR2A[4] */
    }

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_DVP1))) {
        /* The data we get should be "v1,v2,v3", they are for */
        /* "Clock Polarity/Adjust,Data Driving,Clock Driving". */
        VIAParseDPAValues(pStr, TmpBuffer, 3);
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "DVP1 DPA=%d, DataDriving=%d, ClockDriving=%d.\n",
            TmpBuffer[0], TmpBuffer[1], TmpBuffer[2]));

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_Gfx = TRUE;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP1 = TmpBuffer[0] & 0x0F;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DVP1Driving =
            ((TmpBuffer[2] & 0x03) << 2) | (TmpBuffer[1] & 0x03);
    }

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_DFPHIGH))) {
        /* The data we get is for "Clock Polarity/Adjust" */
        VIAParseDPAValues(pStr, TmpBuffer, 1);

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_Gfx = TRUE;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DFPHigh = TmpBuffer[0] & 0x0F;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "DFPHIGH DPA = %d.\n",
            pBIOSInfo->UserDPASettingInfo.GfxDPA.DFPHigh));
    }

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_DFPLOW))) {
        /* The data we get is for "Clock Polarity/Adjust" */
        VIAParseDPAValues(pStr, TmpBuffer, 1);

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_Gfx = TRUE;
        pBIOSInfo->UserDPASettingInfo.GfxDPA.DFPLow = TmpBuffer[0] & 0x0F;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "DFPLOW DPA = %d.\n",
            pBIOSInfo->UserDPASettingInfo.GfxDPA.DFPLow));
    }

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_VT1636))) {
        /* The data we get should be "v1,v2", they are for
           "CLK_SEL_ST1, CLK_SEL_ST2" */
        VIAParseDPAValues(pStr, TmpBuffer, 2);

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_VT1636 = TRUE;
        pBIOSInfo->UserDPASettingInfo.VT1636DPA.CLK_SEL_ST1 =
            TmpBuffer[0] & 0x1F;
        pBIOSInfo->UserDPASettingInfo.VT1636DPA.CLK_SEL_ST2 =
            TmpBuffer[1] & 0x0F;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "VT1636 DPA: CLK_SEL_ST1=%d, CLK_SEL_ST2=%d.\n",
            pBIOSInfo->UserDPASettingInfo.VT1636DPA.CLK_SEL_ST1,
            pBIOSInfo->UserDPASettingInfo.VT1636DPA.CLK_SEL_ST2));
    } else {
        pBIOSInfo->UserDPASettingInfo.HasUserSetting_VT1636 = FALSE;
    }

    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_DPA_SETTING_VT1625))) {
        /* The data we get is for VT1625 DPA. */
        VIAParseDPAValues(pStr, TmpBuffer, 1);

        pBIOSInfo->UserDPASettingInfo.HasUserSetting_VT1625 = TRUE;
        pBIOSInfo->UserDPASettingInfo.VT1625DPA = TmpBuffer[0] & 0x1F;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "VT1625 DPA = %d.\n",
            pBIOSInfo->UserDPASettingInfo.VT1625DPA));
    } else {
        pBIOSInfo->UserDPASettingInfo.HasUserSetting_VT1625 = FALSE;
    }
}

static void
VIAGetOptions_RotateInfo(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;
    CARD32 RotateType = VIA_ROTATE_TYPE_HW;
    char *s = NULL;

    viaGfxInfo->hwIconEnalbed = FALSE;

    /* Initilize */
    pVia->RotateDegree = VIA_ROTATE_DEGREE_0;
    pVia->IsHWRotateEnabled = FALSE;

    if ((s = xf86GetOptValString(VIAOptions, OPTION_ROTATE))) {
        if (!xf86NameCmp(s, "CW")) {
            pVia->RotateDegree = VIA_ROTATE_DEGREE_90;
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Rotating screen clockwise.\n"));
        } else if (!xf86NameCmp(s, "CCW")) {
            pVia->RotateDegree = VIA_ROTATE_DEGREE_270;
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Rotating screen counter-clockwise. \n"));
        } else if (!xf86NameCmp(s, "UD")) {
            pVia->RotateDegree = VIA_ROTATE_DEGREE_180;
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Rotating screen upside-down. \n"));
        } else {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "\"%s\" is not a valid" "value for Option \"Rotate\"\n",
                s));
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Valid options are \"CW\" or \"CCW\" or \"UD\" \n"));
        }
    }

    if ((s = xf86GetOptValString(VIAOptions, OPTION_ROTATE_TYPE))) {
        if (!xf86NameCmp(s, "SW")) {
            RotateType = VIA_ROTATE_TYPE_SW;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Use Software Rotation - Acceleration disabled\n");
        } else if (!xf86NameCmp(s, "HW")) {
            RotateType = VIA_ROTATE_TYPE_HW;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Use Hardware Rotation.\n");
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "\"%s\" is not a valid"
                "value for Option \"RotateType\"\n", s);
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Valid options are \"SW\" or \"HW\"  \n");
        }
    }
#if 0
    if (pVia->IsSecondary)
        viaGfxInfo->screenInfo[1].rotatetype = RotateType;
    else
        viaGfxInfo->screenInfo[0].rotatetype = RotateType;
#endif
    pVia->rotateType = RotateType;

    if (pVia->RotateDegree != VIA_ROTATE_DEGREE_0) {
        switch (RotateType) {
            /* accel is disabled below for shadowFB */
        case VIA_ROTATE_TYPE_SW:
            pVia->shadowFB = TRUE;
            break;

        case VIA_ROTATE_TYPE_HW:
            pVia->IsHWRotateEnabled = TRUE;
            break;
        }

        viaGfxInfo->hwIconEnalbed = TRUE;
    }
}

static void
VIAGetOptions_Video(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    int VideoColorKey;

    if (xf86GetOptValInteger(VIAOptions, OPTION_VIDEO_COLOR_KEY,
        &VideoColorKey)) {
        pVia->xvColorKey = VideoColorKey;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "video color key set to 0x%lx\n", pVia->xvColorKey);
    } else {
        pVia->xvColorKey = (1 << pScrn->offset.red) |
            (1 << pScrn->offset.green) | (1 << pScrn->offset.blue);
    }
}

static void
VIAGetOptions_general(ScrnInfoPtr pScrn)
{
    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;
    MessageType from = X_DEFAULT;
    char *s = NULL;

    pVia = VIAPTR(pScrn);
    pBIOSInfo = pVia->pBIOSInfo;

#ifdef XF86DRI
    pVia->drixinerama = FALSE;
    if (xf86IsOptionSet(VIAOptions, OPTION_DRIXINERAMA))
        pVia->drixinerama = TRUE;
#else
    if (xf86IsOptionSet(VIAOptions, OPTION_DRIXINERAMA))
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: drixinerama ignored, no DRI support compiled"
            " into driver.\n");
#endif

    if (xf86IsOptionSet(VIAOptions, OPTION_SHADOW_FB)) {
        pVia->shadowFB = TRUE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Option: ShadowFB %s.\n",
            pVia->shadowFB ? "enabled" : "disabled");
    } else {
        pVia->shadowFB = FALSE;
    }

    if (!xf86ReturnOptValBool(VIAOptions, OPTION_DRI, TRUE)) {
        pVia->directRenderingEnabled = FALSE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Option: DRI is disabled\n");
    } else {
        pVia->directRenderingEnabled = TRUE;
    }

#ifndef CS_FLAG_NO_TV_SCAL
    /* Initialize the DISPLAY 3D scaling CAP */
    /*modified the variable type,and change the function of this variable */
    pVia->DISP3DScalingCaps = FALSE;
    /* the max number should be 2, so when you add more device need
     * this function, please check the number */
    pVia->NumOfDevNeed3dScl = 0;
    if (xf86IsOptionSet(VIAOptions, OPTION_TVDISP3DScaling)) {
        pVia->DISP3DScalingCaps |= DISPLAY_3D_SCALING_SUPPORT + VIA_DEVICE_TV;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: Display SW scaling %s.\n",
            (pVia->DISP3DScalingCaps & VIA_DEVICE_TV) ?
            "enabled" : "disabled");
    }
#endif /* CS_FLAG_NO_TV_SCAL */

#ifndef CS_FLAG_NO_HDMI_SCAL
    if (xf86IsOptionSet(VIAOptions, OPTION_HDMIDISP3DScaling)) {
        pVia->DISP3DScalingCaps |=
            DISPLAY_3D_SCALING_SUPPORT + VIA_DEVICE_HDMI;

        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: HDMI Display SW scaling %s.\n",
            (pVia->DISP3DScalingCaps & VIA_DEVICE_HDMI) ? "enabled" :
            "disabled");
    }
#endif /* CS_FLAG_NO_HDMI_SCAL */

#ifndef CS_FLAG_NO_LCD_SCAL
    if (xf86IsOptionSet(VIAOptions, OPTION_LCDDISP3DScaling)) {
        pVia->DISP3DScalingCaps |=
            DISPLAY_3D_SCALING_SUPPORT + VIA_DEVICE_LCD;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: LCD Display SW scaling %s.\n",
            (pVia-> DISP3DScalingCaps & VIA_DEVICE_LCD) ?
            "enabled" : "disabled");
    }
#endif /* CS_FLAG_NO_LCD_SCAL */

    if (xf86IsOptionSet(VIAOptions, OPTION_GOOD_PERFORMANCE)) {
        pVia->GoodPerformance = DISPLAY_3D_SCALING_GOOD_PERFORMANCE;
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: 3D scaling use good performance mode.\n");
    }
    /*if chip is not CX700 or CN700 , need not do 3d scaling twice. */
    /*set "good performance" force */
    if (!pVia->GoodPerformance) {
        if ((PCI_CHIP_VT3324 != pVia->ChipId)
            && (PCI_CHIP_VT3314 != pVia->ChipId)) {
            pVia->GoodPerformance = DISPLAY_3D_SCALING_GOOD_PERFORMANCE;
        }
    }

    from = X_DEFAULT;

    pScrn->videoRam = 0;
    if (xf86GetOptValInteger(VIAOptions, OPTION_VIDEORAM, &pScrn->videoRam)) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: VideoRAM %dkB\n", pScrn->videoRam));
    }

    if (xf86ReturnOptValBool(VIAOptions, OPTION_DISABLEVQ, FALSE)) {
        pVia->VQEnable = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: DisableVQ -VQ Disabled\n"));
    } else {
        pVia->VQEnable = TRUE;
    }

    /* Get rotate option. */
    VIAGetOptions_RotateInfo(pScrn);

    if (xf86ReturnOptValBool(VIAOptions, OPTION_NOACCEL, FALSE)) {
        pVia->NoAccel = TRUE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: NoAccel -Acceleration Disabled\n"));
    } else {
        pVia->NoAccel = FALSE;
    }

    /* NoDDCValue Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_NODDCVALUE, FALSE)) {
        pBIOSInfo->NoDDCValue = TRUE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: Not using DDC probed value to set HorizSync"
            " & VertRefresh\n"));
    } else {
        pBIOSInfo->NoDDCValue = FALSE;
    }

    /* Interlace Mode Option */
    if (xf86ReturnOptValBool(VIAOptions, OPTION_INTERLACE_MODE, FALSE)) {
        pBIOSInfo->IsEnableInterlaceMode = TRUE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: Enable Interlace Mode. \n"));
    } else {
        pBIOSInfo->IsEnableInterlaceMode = FALSE;
    }

    pBIOSInfo->HDMISettingInfo.HDMIDIPort = VIA_DI_NONE;
    if ((s = xf86GetOptValString(VIAOptions, OPTION_HDMI_PORT))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "HDMI port set to %s.\n",
            s));

        if (!xf86NameCmp(s, "DFP_HIGH"))
            pBIOSInfo->HDMISettingInfo.HDMIDIPort = VIA_DI_DFPHIGH;
        else if (!xf86NameCmp(s, "DFP_LOW"))
            pBIOSInfo->HDMISettingInfo.HDMIDIPort = VIA_DI_DFPLOW;
        else if (!xf86NameCmp(s, "DVP0"))
            pBIOSInfo->HDMISettingInfo.HDMIDIPort = VIA_DI_DVP0;
        else if (!xf86NameCmp(s, "DVP1"))
            pBIOSInfo->HDMISettingInfo.HDMIDIPort = VIA_DI_DVP1;
    }
#ifdef VIA_HAVE_EXA
    if (!pVia->NoAccel) {
        from = X_DEFAULT;
        /*Set NonRandR default is XAA, RandR default is EXA */
        if (pVia->useRandR) {
            pVia->useEXA = TRUE;
            pVia->useUXA = TRUE;
        }
        if ((s = (char *)xf86GetOptValString(VIAOptions, OPTION_ACCELMETHOD))) {
            if (!xf86NameCmp(s, "XAA")) {
                from = X_CONFIG;
                pVia->useUXA = FALSE;
                pVia->useEXA = FALSE;
            } else if (!xf86NameCmp(s, "EXA")) {
                from = X_CONFIG;
                pVia->useEXA = TRUE;
                pVia->useUXA = TRUE;
            }
        }
        xf86DrvMsg(pScrn->scrnIndex, from,
            "Using %s acceleration architecture.\n",
            pVia->useEXA ? "EXA" : "XAA");
    }
#endif /* VIA_HAVE_EXA */

    if (pVia->shadowFB && !pVia->NoAccel) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
            "HW acceleration not supported with \"shadowFB\".\n"));
        pVia->NoAccel = TRUE;
    }

    return;
}

static void
VIAGetOptions_Hotkey(ScrnInfoPtr pScrn)
{
    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;

    pVia = VIAPTR(pScrn);
    pBIOSInfo = pVia->pBIOSInfo;
    char *pStr = NULL;
    char *pTmpStr = NULL;
    CARD32 i = 0;

    pVia->IsForceHotkeySwitch = FALSE;
    /* Hotkey triggered by a timer. */
    if ((pStr = xf86GetOptValString(VIAOptions, OPTION_FN_HOTKEY))) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "Option: Enable a timer to active hotkey.\n"));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Device Sequence = %s\n",
            pStr));

        pTmpStr = strtok(pStr, ",");
        while (pTmpStr != NULL) {
            if (!xf86NameCmp(pTmpStr, "CRT"))
                pVia->deviceSequence[i] = VIA_DEVICE_CRT1;
            else if (!xf86NameCmp(pTmpStr, "LCD"))
                pVia->deviceSequence[i] = VIA_DEVICE_LCD;
            else if (!xf86NameCmp(pTmpStr, "DVI"))
                pVia->deviceSequence[i] = VIA_DEVICE_DFP;
            else if (!xf86NameCmp(pTmpStr, "TV"))
                pVia->deviceSequence[i] = VIA_DEVICE_TV;
            else if (!xf86NameCmp(pTmpStr, "FORCE"))
                pVia->IsForceHotkeySwitch = TRUE;
            else
                ErrorF("Unknow Option %s for hotkey used. \n", pTmpStr);

            pTmpStr = strtok(NULL, ",");
            i++;
        }

        /* It should has more than one prefered device at least. */
        if (i > 1)
            pVia->IsHotkeyTimerEnabled = TRUE;
        else
            pVia->IsHotkeyTimerEnabled = FALSE;
    }
}

void
VIAProcessCfgOptions(ScrnInfoPtr pScrn)
{
    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;

    pVia = VIAPTR(pScrn);
    pBIOSInfo = pVia->pBIOSInfo;

    xf86CollectOptions(pScrn, NULL);
    xf86ProcessOptions(pScrn->scrnIndex, pScrn->options, VIAOptions);

    VIAGetOptions_general(pScrn);

    VIAGetOptions_Hotkey(pScrn);

    /*get mergedfb options */
    if (!pVia->IsSecondary)
        VIAGetOptions_MergedFB(pScrn);

    /* Probe the capabilities about rotation. */
    ProbeRotateCaps(pScrn);

    VIAGetOptions_LCDInfo(pScrn);
    VIAGetOptions_TVInfo(pScrn);
    VIAGetOptions_DVIInfo(pScrn);
    VIAGetOptions_DPASettingInfo(pScrn);

    /*here add this function because  chipset id is identified just above */
    VIAGetOptions_Cursor(pScrn);
    VIAGetOptions_Video(pScrn);
    VIAGetOptions_Mem4DDmpeg(pScrn);

    return;
}

void
VIAProbeChipset(ScrnInfoPtr pScrn, EntityInfoPtr pEnt)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAProbeChipSet!\n"));

    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;
    MessageType from = X_DEFAULT;

    pVia = VIAPTR(pScrn);
    pBIOSInfo = pVia->pBIOSInfo;

    if (pEnt->device->chipset && *pEnt->device->chipset) {
        pScrn->chipset = pEnt->device->chipset;
        pVia->ChipId = pEnt->device->chipID;
        pVia->Chipset = xf86StringToToken(VIAChipsets, pScrn->chipset);
        from = X_CONFIG;
    } else if (pEnt->device->chipID >= 0) {
        pVia->ChipId = pEnt->device->chipID;
        pVia->Chipset = LookupChipID(VIAPciChipsets, pVia->ChipId);
        pScrn->chipset = (char *)xf86TokenToString(VIAChipsets,
            pVia->Chipset);
        from = X_CONFIG;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "ChipID override: 0x%04X\n", pEnt->device->chipID));
    } else {
        from = X_PROBED;
        pVia->ChipId = DEVICE_ID(pVia->PciInfo);
        pVia->Chipset = LookupChipID(VIAPciChipsets, pVia->ChipId);
        pScrn->chipset = (char *)xf86TokenToString(VIAChipsets,
            pVia->Chipset);
    }

    if (pEnt->device->chipRev >= 0) {
        pVia->ChipRev = pEnt->device->chipRev;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "ChipRev override: %d\n",
            pVia->ChipRev));
    } else {
        /* Read PCI bus 0, dev 0, function 0, index 0xF6 to get chip rev. */
        uint8_t ChipRev;

#if XSERVER_LIBPCIACCESS
        pci_device_cfg_read_u8(VIAGetHostBridge(0, 0, 0), &ChipRev, 0xF6);
#else
        ChipRev = pciReadByte(pciTag(0, 0, 0), 0xF6);
#endif
        pVia->ChipRev = ChipRev;
    }

    xf86DrvMsg(pScrn->scrnIndex, from, "Chipset: \"%s\"\n", pScrn->chipset);
    xf86DrvMsg(pScrn->scrnIndex, from, "Chipset Rev.: %d\n", pVia->ChipRev);

    pBIOSInfo->Chipset = pVia->Chipset;
    pBIOSInfo->ChipRev = pVia->ChipRev;
}

void
VIAFindMaxResFromEstablishedTiming(xf86MonPtr MonitorConf, int *MaxH,
    int *MaxV)
{
    if (MonitorConf->timings1.t1 & 0xD0) {
        *MaxH = 720;
        *MaxV = 400;
    }

    if (MonitorConf->timings1.t1 & 0x3D) {
        *MaxH = 640;
        *MaxV = 480;
    }

    if (MonitorConf->timings1.t1 & 0x03) {
        *MaxH = 800;
        *MaxV = 600;
    }

    if (MonitorConf->timings1.t2 & 0xD0) {
        *MaxH = 800;
        *MaxV = 600;
    }

    if (MonitorConf->timings1.t2 & 0x20) {
        *MaxH = 832;
        *MaxV = 624;
    }

    if (MonitorConf->timings1.t2 & 0x1E) {
        *MaxH = 1024;
        *MaxV = 768;
    }

    if (MonitorConf->timings1.t2 & 0x01) {
        *MaxH = 1280;
        *MaxV = 1024;
    }
}

static Bool
VIACollectBIOSInfo(ScrnInfoPtr pScrn)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIACollectBIOSInfo!\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int tmp;

    /* Read PCI configuration space to get frame buffer size. */
    VIAGetFBSize(pScrn);

    /* Check if spread spectrum is enable */
    VGAOUT8(0x3c4, SR1E);
    if (VGAIN8(0x3c5) & BIT3) {
        pVia->pChipInfo->biosIsSpreadSpectrum = TRUE;
    } else {
        pVia->pChipInfo->biosIsSpreadSpectrum = FALSE;
    }

    if (!pVia->IsMAMMEnable) {

        /* get default TV standard from scratch pad */
        if (pBIOSInfo->TVSettingInfo.TVType == TVTYPE_NONE) {
            VGAOUT8(0x3D4, 0x4E);
            tmp = VGAIN8(0x3D5) & 0x0F;

            if (tmp) {
                pVia->pChipInfo->biosTVType = TVTYPE_PAL;
                pBIOSInfo->TVSettingInfo.TVType = TVTYPE_PAL;
            } else {
                pVia->pChipInfo->biosTVType = TVTYPE_NTSC;
                pBIOSInfo->TVSettingInfo.TVType = TVTYPE_NTSC;
            }
        }

        /* get default LCD panel ID from scratch pad. */
        if (pBIOSInfo->LVDSSettingInfo.PanelSizeID == VIA_INVALID) {
            VGAOUT8(0x3D4, 0x3F);
            tmp = VGAIN8(0x3D5) & 0x0F;

            pVia->pChipInfo->biosPanelID = tmp;
            if (VIASetLCDPanelInfo(pBIOSInfo, tmp)) {
                DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
                    "Get PanelID From Scratch Pad is 0x%x\n",
                    pVia->pChipInfo->biosPanelID));
            } else {
                DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_ERROR,
                    "No Panel ID\n"));
            }
        }
    }

    /* For hardward or register variation! Record chipset and PCI revision ID. */
    VIASetChipsetRevisionID(pVia);
    DEBUG(ErrorF("ChipsetRevisionID=0x%x \n", g_ChipsetRevisionID));

    return TRUE;

}

Bool
VIAIsMAMM(ScrnInfoPtr pScrn)
{
    char *viaDriverName;
    Bool retValue;

    viaDriverName = pScrn->confScreen->device->driver;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "the driver module for this screen 0 is \"%s\" driver.\n",
        viaDriverName);
    if (!memcmp(viaDriverName, "VIA", 3))
        retValue = TRUE;
    else
        retValue = FALSE;
    return retValue;
}

/* Get the CRTC timing from xorg.conf */
void
VIAGetModeLineTiming(ScrnInfoPtr pScrn, DisplayModePtr mode)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    /*
     * case 1: user specified timing in xorg.conf, we'll use it,
     * and the option "Refresh" doesn't take effect
     */
    if (mode->type == M_T_USERDEF) {
        pBIOSInfo->ModeLineStatus = MODE_LINE_TYPE_USER;
        /*
         * case 2: monitor preferred timing, we'll use it,
         * and the option "Refresh" doesn't take effect
         */
    } else if (mode->type & M_T_PREFERRED)
        pBIOSInfo->ModeLineStatus = MODE_LINE_TYPE_EDID;
    /*
     * other case: we'll use hard code timing,
     * and the option "Refresh" take effect
     */
    else
        pBIOSInfo->ModeLineStatus = 0;

    if (pBIOSInfo->ModeLineStatus &
        (MODE_LINE_TYPE_USER | MODE_LINE_TYPE_EDID)) {
        pBIOSInfo->UserSpecifiedMode.clk = mode->Clock * 1000;
        if (mode->Flags & V_PHSYNC)
            pBIOSInfo->UserSpecifiedMode.h_sync_polarity = POSITIVE;
        if (mode->Flags & V_NHSYNC)
            pBIOSInfo->UserSpecifiedMode.h_sync_polarity = NEGATIVE;
        if (mode->Flags & V_PVSYNC)
            pBIOSInfo->UserSpecifiedMode.v_sync_polarity = POSITIVE;
        if (mode->Flags & V_NVSYNC)
            pBIOSInfo->UserSpecifiedMode.v_sync_polarity = NEGATIVE;

        pBIOSInfo->UserSpecifiedMode.crtc.hor_total = mode->CrtcHTotal;
        pBIOSInfo->UserSpecifiedMode.crtc.hor_addr = mode->CrtcHDisplay;
        /* mode->CrtcHBlankStart is incorrect! */
        pBIOSInfo->UserSpecifiedMode.crtc.hor_blank_start = mode->CrtcHDisplay;
        pBIOSInfo->UserSpecifiedMode.crtc.hor_blank_end =
            mode->CrtcHBlankEnd - mode->CrtcHDisplay;
        pBIOSInfo->UserSpecifiedMode.crtc.hor_sync_start =
            mode->CrtcHSyncStart;
        pBIOSInfo->UserSpecifiedMode.crtc.hor_sync_end =
            mode->CrtcHSyncEnd - mode->CrtcHSyncStart;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_total = mode->CrtcVTotal;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_addr = mode->CrtcVDisplay;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_blank_start =
            mode->CrtcVBlankStart;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_blank_end =
            mode->CrtcVBlankEnd - mode->CrtcVBlankStart;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_sync_start =
            mode->CrtcVSyncStart;
        pBIOSInfo->UserSpecifiedMode.crtc.ver_sync_end =
            mode->CrtcVSyncEnd - mode->CrtcVSyncStart;
    }

}

/* for CLE AX/CX differential behavior.                         *
 * Define UniChrome Family Project ID/Revision, for simplify    *
 * Device ID + Revision combination.                            *
 * TODO: Use uni-variable capability flag to replace this.      */
void
VIAGetdwProjectIDRevision(ScrnInfoPtr pScrn)
{
    CARD8 BondingOption;
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    switch (pVia->Chipset) {
    case VIA_P4M800PRO:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3314;
        break;
    case VIA_CX700:
        /*add for get 3324A3 revision */
        VGAOUT8(VIASR, SR43);
        BondingOption = VGAIN8(VIASR + 1);

        if (BondingOption & 0x02)
            pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3324M2;
        else if (BondingOption & 0x40)
            pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3324M;
        else
            pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3324;
        break;
    case VIA_K8M890:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3336;
        break;
    case VIA_P4M890:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3327;
        break;
    case VIA_P4M900:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3364;
        break;
    case VIA_VX800:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3353;
        break;
    case VIA_VX855:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3409;
        break;
    case VIA_VX900:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3410;
        break;
#ifdef VIA_VT3293_SUPPORT
    case VIA_CN750:
        pBIOSInfo->dwProjectIDRevision = UNICHROME_VT3293;
        break;
#endif
    default:
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "VIABIOSInit: Unknown Device ID\n"));
        break;
    }
}

void
VIAARGBCursorInit(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr  pBIOSInfo = pVia->pBIOSInfo;
    CARD32 dwHiControl;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAARGBCursorInit\n"));

    switch (pBIOSInfo->Chipset ) {
    case VIA_CX700:
    case VIA_P4M890:
    case VIA_P4M900:
    case VIA_VX800:
    case VIA_VX855:
    case VIA_VX900:
#ifdef VIA_VT3293_SUPPORT
    case VIA_CN750:
#endif
        /* set 0 as transparent color key */
        VIASETREG(PRIM_HI_TRANSCOLOR, 0);
        VIASETREG(PRIM_HI_FIFO, 0x0D000D0F);
        VIASETREG(PRIM_HI_INVTCOLOR, 0X00FFFFFF);
        VIASETREG(V327_HI_INVTCOLOR, 0X00FFFFFF);
        dwHiControl = VIAGETREG(PRIM_HI_CTRL);

        /* Turn cursor off. */
        VIASETREG(PRIM_HI_CTRL, dwHiControl & 0xFFFFFFFA);

        if (pVia->useRandR) {
            VIASETREG(PRIM_HI_FBOFFSET, pVia->HiBuf_bo[0]->offset);
            VIASETREG(HI_FBOFFSET, pVia->HiBuf_bo[1]->offset);
        } 
		
        /* set 0 as transparent color key */
        VIASETREG(HI_TRANSPARENT_COLOR, 0);
        VIASETREG(HI_INVTCOLOR, 0X00FFFFFF);
        VIASETREG(ALPHA_V3_PREFIFO_CONTROL, 0xE0000);
        VIASETREG(ALPHA_V3_FIFO_CONTROL, 0xE0F0000);
        dwHiControl = VIAGETREG(HI_CONTROL);

        /* Turn cursor off. */
        VIASETREG(HI_CONTROL, dwHiControl & 0xFFFFFFFA);
        break;

    default:
        if (pVia->useRandR)
            VIASETREG(HI_FBOFFSET, pVia->HiBuf_bo[0]->offset);
		
        VIASETREG(HI_TRANSPARENT_COLOR, 0);
        VIASETREG(HI_INVTCOLOR, 0X00FFFFFF);
        VIASETREG(ALPHA_V3_PREFIFO_CONTROL, 0xE0000);
        VIASETREG(ALPHA_V3_FIFO_CONTROL, 0xE0F0000);
        dwHiControl = VIAGETREG(HI_CONTROL);

        /* Turn cursor off. */
        VIASETREG(HI_CONTROL, dwHiControl & 0xFFFFFFFA);
    }
}

static void
via_xf86_crtc_notify(ScreenPtr pScreen)
{
    VIAPtr pVia;
    int num = pScreen->myNum;
    ScrnInfoPtr pScrn = xf86Screens[num];

    pVia = VIAPTR(pScrn);
    pVia->crtc_info_changed = TRUE;
    DBG_DD((" enter %s \n", __func__));
}

static Bool
VIAPreInit(ScrnInfoPtr pScrn, int flags)
{
    EntityInfoPtr pEnt;
    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;
    char *busId, *drmDriverName;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAPreInit\n"));
    DEBUG(ErrorF("XORG_VERSION_CURRENT = %d\n", XORG_VERSION_CURRENT));
#if XORG_VERSION_CURRENT < XF86_VERSION_NUMERIC(1,5,99,0,0) || \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(7,0,0,0,0)
    via_xf86_version_current = xf86GetVersion();
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XF86_VER=%d\n,Driver Not depending on this anymore\n",
        via_xf86_version_current));
#endif

    if (pScrn->numEntities > 1)
        return FALSE;

    if (flags & PROBE_DETECT)
        return FALSE;

    if (!xf86LoadSubModule(pScrn, "vgahw"))
        return FALSE;

    if (!vgaHWGetHWRec(pScrn))
        return FALSE;

    if (!VIAGetRec(pScrn))
        return FALSE;

    if (!LoadSubModule(pScrn->module, "viavideo", NULL, NULL, NULL, NULL,
        NULL, NULL)) {
        via_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            " Couldn't open viavideo\n"));
    } else
        via_module_loaded = TRUE;

    pVia = VIAPTR(pScrn);

    DevUnion *pPriv;

    pPriv = xf86GetEntityPrivate(pScrn->entityList[0], gVIAEntityIndex);
    pVia->pVIAEnt = pPriv->ptr;

    pVia->IsSuspending = FALSE;
    pVia->IsVIAModeInitRunOnceDone = FALSE;

    pBIOSInfo = pVia->pBIOSInfo;
    pBIOSInfo->s3utility = FALSE;
    pBIOSInfo->FirstTimeToSenseIntegratedTV = TRUE;
    pBIOSInfo->scrnIndex = pScrn->scrnIndex;

    if (VIAIsMAMM(pScrn)) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MAMM mode enable\n");
        pVia->IsMAMMEnable = TRUE;
    } else {
        pVia->IsMAMMEnable = FALSE;
    }

    pVia->IsSecondary = FALSE;
    pEnt = xf86GetEntityInfo(pScrn->entityList[0]);
#ifndef XSERVER_LIBPCIACCESS
    if (pEnt->resources) {
        free(pEnt);
        VIAFreeRec(pScrn);
        return FALSE;
    }
#endif

    pVia->PciInfo = xf86GetPciInfoForEntity(pEnt->index);

#ifndef XSERVER_LIBPCIACCESS
    pVia->PciTag = pciTag(pVia->PciInfo->bus, pVia->PciInfo->device,
    pVia->PciInfo->func);

    if (xf86RegisterResources(pEnt->index, NULL, ResNone)) {
        free(pEnt);
        VIAFreeRec(pScrn);
        return FALSE;
    }
#endif

    if (xf86IsEntityShared(pScrn->entityList[0])) {
        if (xf86IsPrimInitDone(pScrn->entityList[0])) {

            pVia->pVIAEnt->pSecondaryScrn = pScrn;
            pVia->IsSecondary = TRUE;

            /* If SAMM, Hot key zoom locked
             * pScrn->zoomLocked = TRUE;*/
            pVia->pVIAEnt->pSecondaryScrn->zoomLocked = TRUE;
            pVia->pVIAEnt->pPrimaryScrn->zoomLocked = TRUE;
        } else {
            xf86SetPrimInitDone(pScrn->entityList[0]);
            pVia->pVIAEnt->pPrimaryScrn = pScrn;
            if (pVia->pVIAEnt->HasSecondary)
                pVia->IsSecondary = FALSE;
        }
    }

    /* Detect which chipset we used. */
    VIAProbeChipset(pScrn, pEnt);

    pScrn->monitor = pScrn->confScreen->monitor;

    /*
     * We support depths of 8, 16 and 24.
     * We support bpp of 8, 16, and 32.
     */

    if (!xf86SetDepthBpp(pScrn, 0, 0, 0, Support32bppFb)) {
        free(pEnt);
        VIAFreeRec(pScrn);
        return FALSE;
    } else {
        switch (pScrn->depth) {
        case 8:
        case 16:
        case 24:
        case 32:
            /* OK */
            break;
        default:
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Given depth (%d) is not supported by this driver\n",
                pScrn->depth);
            free(pEnt);
            VIAFreeRec(pScrn);
            return FALSE;
        }
    }

    xf86PrintDepthBpp(pScrn);

    if (pScrn->depth == 32)
        pScrn->depth = 24;

    if (pScrn->depth > 8) {
        rgb zeros = { 0, 0, 0 };

        if (!xf86SetWeight(pScrn, zeros, zeros)) {
            free(pEnt);
            VIAFreeRec(pScrn);
            return FALSE;
        } else {
            /* TODO check weight returned is supported */
            ;
        }
    }

    if (!xf86SetDefaultVisual(pScrn, -1)) {
        return FALSE;
    } else {
        /* We don't currently support DirectColor at > 8bpp */
        if (pScrn->depth > 8 && pScrn->defaultVisual != TrueColor) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Given default visual"
                " (%s) is not supported at depth %d\n",
                xf86GetVisualName(pScrn->defaultVisual), pScrn->depth);
            free(pEnt);
            VIAFreeRec(pScrn);
            return FALSE;
        }
    }

    /* Set the bits per RGB for 8bpp mode */
    if (pScrn->depth == 8)
        pScrn->rgbBits = 8;

    /* We use a programmable clock */
    pScrn->progClock = TRUE;

    /* If MAMM mode, we can't use int10,vbe */
    if (!pVia->IsMAMMEnable) {
        if (xf86LoadSubModule(pScrn, "int10")) {
            pVia->pInt10 = xf86InitInt10(pEnt->index);
        }

        if (pVia->pInt10 && xf86LoadSubModule(pScrn, "vbe")) {
            pVia->pVbe = VBEExtendedInit(pVia->pInt10, pEnt->index, 0);
        }
    }

    /* Set status word positions based on chip type. */
    switch (pVia->Chipset) {
    case VIA_K8M890:
    case VIA_P4M900:
#ifdef VIA_VT3293_SUPPORT
    case VIA_CN750:
#endif
        pVia->myWaitIdle = WaitIdle_H5Chips;
        break;
    case VIA_VX800:
    case VIA_VX855:
    case VIA_VX900:
        pVia->myWaitIdle = WaitIdle_H6Chips;
        break;
    default:
        pVia->myWaitIdle = WaitIdle_H2Chips;
        break;
    }

    /* Because xf86Info.disableRandR is changeful, but it match the option
     * "RandR" in ServerLayout section, so we store it to pVia->useRandR */
#ifdef VIA_RANDR12_SUPPORT
    pVia->useRandR = !xf86Info.disableRandR;
    /* if xorg doesn't support RandR1.2, we can only support old architecture */
#else
    pVia->useRandR = FALSE;
#endif

    /* *_* We process all config file's options in one function *_* */
    VIAProcessCfgOptions(pScrn);

    if (pEnt->device->videoRam != 0) {
        if (!pScrn->videoRam)
            pScrn->videoRam = pEnt->device->videoRam;
        else
            xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                "Video Memory Size in Option is %d KB, Detect is %d KB!",
                pScrn->videoRam, pEnt->device->videoRam);
    }

    free(pEnt);

    /* FrameBufferBase always represets physical start address for the
     * whole video memory. */
    if (pVia->pBIOSInfo->Chipset == VIA_VX900) {
        pVia->FrameBufferBase = MEMBASE(pVia->PciInfo, 2);
    } else {
        pVia->FrameBufferBase = MEMBASE(pVia->PciInfo, 0);
    }

    /* ScreenBase represents physical start address for each screen */
    if (pVia->pBIOSInfo->Chipset == VIA_VX900) {
        pVia->ScreenBase = MEMBASE(pVia->PciInfo, 2);
    } else {
        pVia->ScreenBase = MEMBASE(pVia->PciInfo, 0);
    }

    if (!VIAMapMMIO(pScrn)) {
        if (pVia->pVbe != NULL)
            vbeFree(pVia->pVbe);
        return FALSE;
    }

    /*Get dwProjectIDRevision for capture and TV
     * This function must call after VIAMapMMIO */
    VIAGetdwProjectIDRevision(pScrn);

    /* load vt1625 sub module */
    /* using LoadSubModule instead of xf86LoadSubModule
     * for if module does not exsit don't print error */
    if (!LoadSubModule(pScrn->module, "vt1625", NULL, NULL, NULL, NULL, NULL,
        NULL)) {
        vt1625_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            " Couldn't load vt1625 submodule\n"));
    } else
        vt1625_module_loaded = TRUE;

    /* load integratedtv sub module */
    if (!LoadSubModule(pScrn->module, "ViaIntegratedTV", NULL, NULL, NULL,
        NULL, NULL, NULL)) {
        integratedtv_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            " Couldn't load ViaIntegratedTV submodule\n"));
    } else
        integratedtv_module_loaded = TRUE;

    /* load ad9389 sub module */
    if (!LoadSubModule(pScrn->module, "ad9389", NULL, NULL, NULL, NULL, NULL,
        NULL)) {
        ad9389_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Failed to load AD9389 module\n"));
    } else
        ad9389_module_loaded = TRUE;

    if (!LoadSubModule(pScrn->module, "sil164", NULL, NULL, NULL, NULL, NULL,
        NULL)) {
        sil164_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Failed to load sil164 module\n"));
    } else {
        sil164_module_loaded = TRUE;
    }

    if (!LoadSubModule(pScrn->module, "ch7301", NULL, NULL, NULL, NULL, NULL,
        NULL)) {
        ch7301_module_loaded = FALSE;
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Failed to load ch7301 module\n"));
    } else {
        ch7301_module_loaded = TRUE;
    }

    /* Collect some information about Chip or CMOS setting */
    if (!VIACollectBIOSInfo(pScrn)) {
        VIAFreeRec(pScrn);
        return FALSE;
    }

    /* Initialize the colormap and this step must be done before calling
       xf86HandleColormaps. */
    Gamma zeros = { 0.0, 0.0, 0.0 };
    if (!xf86SetGamma(pScrn, zeros)) {
        VIAFreeRec(pScrn);
        vbeFree(pVia->pVbe);
        return FALSE;
    }

    /* Split FB for SAMM */
    /* TODO: For now, split FB into two equal sections. This should
     *        be able to be adjusted by user with a config option. */
    if (pVia->IsSecondary) {
        VIAPtr pVia0;
        int videoram1 = 0;

        if (xf86GetOptValInteger(VIAOptions, OPTION_VIDEORAM1, &videoram1))
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "Option: VideoRAM1 %dkB\n", videoram1);

        if (videoram1 > 0)
            videoram1 = (videoram1 >> 10) << 10;

        if (videoram1 >= pScrn->videoRam - 16384)
            videoram1 = pScrn->videoRam - 16384;

        if ((videoram1 <= 16384) && (videoram1 > 0))
            videoram1 = 16384;

        if (videoram1)
            pScrn->videoRam = videoram1;
        else
            /* Reserve 11M for second scrn, because 1920x1440x4/2^20 = 10.5M  */
            pScrn->videoRam = 11 * 1024;

        pVia->pVIAEnt->pPrimaryScrn->videoRam -= pScrn->videoRam;
        pVia0 = VIAPTR(pVia->pVIAEnt->pPrimaryScrn);
        /*Rewrite pVia0->videoRambytes here */
        pVia0->videoRambytes = pVia->pVIAEnt->pPrimaryScrn->videoRam << 10;
        pVia->ScreenBase += (pVia->pVIAEnt->pPrimaryScrn->videoRam << 10);

    }

    if (!pVia->IsSecondary) {
        pVia->pVIAEnt->pScreensPublicInfo->VRamSize = pScrn->videoRam << 10;
    }

    /* Init videoRambytes to All Video Memory Size, pVia->videoRambytes may
       rewrite in SAMM mode */
    pVia->videoRambytes = pScrn->videoRam << 10;

    xf86DrvMsg(pScrn->scrnIndex, X_PROBED, "videoram =  %dk\n",
        pScrn->videoRam);

    /* here load any modules that we need */
    /* Before using DDC, we must initialize the I2C. */
    if (!xf86LoadSubModule(pScrn, "i2c")) {
        VIAFreeRec(pScrn);
        return FALSE;
    } else {
        VIAI2CInit(pScrn);
    }

    if (xf86LoadSubModule(pScrn, "fb") == NULL) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Failed to load fb module");
        VIAFreeRec(pScrn);
        return FALSE;
    }

    if (!pVia->NoAccel) {
#ifdef VIA_HAVE_EXA
        if (pVia->useEXA) {
#if (EXA_VERSION_MAJOR >= 2)
            XF86ModReqInfo req;
            int errmaj, errmin;

            memset(&req, 0, sizeof(req));
            req.majorversion = 2;
            req.minorversion = 0;
            if (!LoadSubModule(pScrn->module, "exa", NULL, NULL, NULL, &req,
                &errmaj, &errmin)) {
                LoaderErrorMsg(NULL, "exa", errmaj, errmin);
                VIAFreeRec(pScrn);
                return FALSE;
            }
#else
            if (!xf86LoadSubModule(pScrn, "exa")) {
                VIAFreeRec(pScrn);
                return FALSE;
            }
#endif /* EXA_VERSION */
#endif /* VIA_HAVE_EXA */
        } else {
            if (!xf86LoadSubModule(pScrn, "xaa")) {
                VIAFreeRec(pScrn);
                return FALSE;
            }
        }
    }

    if (!pVia->ForceSWCursor) {
        if (!xf86LoadSubModule(pScrn, "ramdac")) {
            VIAFreeRec(pScrn);
            return FALSE;
        }
    }

    if (pVia->shadowFB) {
        if (!xf86LoadSubModule(pScrn, "shadowfb")) {
            VIAFreeRec(pScrn);
            return FALSE;
        }
    }
#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /*Check MB and get information of what device we can support */
        viaInitHwInfo(pVia);
    }
#endif

    /* Check Spread Spectrum. Or it will cause garbage when we sense the
     * external encoder.
     */
    if (pVia->pChipInfo->biosIsSpreadSpectrum) {
        /* Disable spread spectrum temporarily, we will turn it on when set mode. */
        if ((pVia->Chipset == VIA_CX700) ||
            (pVia->Chipset == VIA_VX800) || (pVia->Chipset == VIA_VX855)) {
            VGAOUT8(0x3c4, SR3D);
            VGAOUT8(0x3c5, VGAIN8(0x3c5) & 0xFE);
        } else {
            VGAOUT8(0x3c4, SR2C);
            VGAOUT8(0x3c5, VGAIN8(0x3c5) & 0xFE);
        }

        VGAOUT8(0x3c4, SR1E);
        VGAOUT8(0x3c5, VGAIN8(0x3c5) & 0xF7);
    }
#ifdef VIA_RANDR12_SUPPORT
    /*============= For RandR v1.2 =======================*/
    if (pVia->useRandR) {
        xf86CrtcConfigPtr config;
        int i;
        int pitch;

        /* Load DDC module for EDID. */
        xf86LoadSubModule(pScrn, "ddc");

        xf86SetDpi(pScrn, 0, 0);

        xf86CrtcConfigInit(pScrn, &via_xf86crtc_config_funcs);
        config = XF86_CRTC_CONFIG_PTR(pScrn);
        config->xf86_crtc_notify = via_xf86_crtc_notify;
        xf86CrtcSetSizeRange(pScrn, 320, 200, 8192, 8192);

        via_crtc_init(pScrn, 2);
        via_output_init(pScrn);

        if (!xf86InitialConfiguration(pScrn, FALSE)) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "No valid initial configuration found\n");
            return FALSE;
        }

        pitch =
            CMDISP_ALIGN_TO(pScrn->virtualX * (pScrn->bitsPerPixel >> 3), 32);
        pScrn->displayWidth = pitch / (pScrn->bitsPerPixel >> 3);

        xf86CrtcConfigPtr via_crtc_config = XF86_CRTC_CONFIG_PTR(pScrn);

        /* If TV output create,get the TV Caps */
        for (i = 0; i < via_crtc_config->num_output; i++) {
            if ((!xf86NameCmp(via_crtc_config->output[i]->name, "TV")) ||
            (!xf86NameCmp(via_crtc_config->output[i]->name, "TV-2"))) {
                int HDisplay = 1024;
                int VDisplay = 768;

                if (via_crtc_config->output[i]->crtc) {
                    HDisplay =
                    via_crtc_config->output[i]->crtc->desiredMode.
                    HDisplay;
                    VDisplay =
                    via_crtc_config->output[i]->crtc->desiredMode.
                    VDisplay;
                }
                viaGetTvCapsSupported(via_crtc_config->output[i], HDisplay,
                    VDisplay);
            }
        }
    }
    /*============= End RandR v1.2 =======================*/
#endif

    /* After calling xf86ValidateModes(), pScrn->virtualX(Y) will get the
       final value of virtual size. */
    /* At RandR v1.2, pScrn->virtualX,Y will get value after
       xf86InitialConfiguration */

/*  Refined Rotate process code, pBIOSInfo's item:VirtualX, VirtualY only get
 *  the original value of pScrn->virtualX/virtualY
 *  And NEVER change it's value in our code. It needs because the XV panning
    support for setting correct Clipping Windows.
 */
    pBIOSInfo->VirtualX = pScrn->virtualX;
    pBIOSInfo->VirtualY = pScrn->virtualY;

    /* Set up screen parameters. */
    pVia->Bpp = pScrn->bitsPerPixel >> 3;
    pVia->Bpl = pScrn->displayWidth * pVia->Bpp;

    if (pBIOSInfo->MergedFB) {
        /*to set virtul X,Y value while mergedfb */
        if ((pBIOSInfo->Scrn2Position == viaRightOf) ||
            (pBIOSInfo->Scrn2Position == viaLeftOf))
            pScrn->virtualX += pScrn->virtualX;

        if ((pBIOSInfo->Scrn2Position == viaAbove) ||
            (pBIOSInfo->Scrn2Position == viaBelow))
            pScrn->virtualY += pScrn->virtualY;

        pScrn->displayWidth = pScrn->virtualX;
    }

    /* Check what type of cursor (SW/HW) to use. */
    VIACheckCursorTypeToUse(pScrn);

    VIAUnmapMem(pScrn);

    if (!via_open_drm_master(pScrn)) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "[drm]  failed to open the DRM\n");
        return FALSE;
    }

    return TRUE;
}

Bool
via_open_drm_master(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    drmSetVersion sv;
    char *busId, *drmDriverName;

    busId = (char *)malloc(64);
    /*XXX older PCI formats here */
    sprintf(busId, "PCI:%d:%d:%d",
#if XSERVER_LIBPCIACCESS
        ((pVia->PciInfo->domain << 8) | pVia->PciInfo->bus),
        pVia->PciInfo->dev, pVia->PciInfo->func
#else
        ((pciConfigPtr) pVia->PciInfo->thisCard)->busnum,
        ((pciConfigPtr) pVia->PciInfo->thisCard)->devnum,
        ((pciConfigPtr) pVia->PciInfo->thisCard)->funcnum
#endif
        );
    drmDriverName = DRM_DRIVER_NAME;

    if (!DRIOpenDRMMaster(pScrn, 16 * 1024, busId, drmDriverName)) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "[drm]  failed to open the DRM\n");
        return FALSE;
    }
    pVia->drmFD = DRIMasterFD(pScrn);

    return TRUE;
}

void
VIAGEMLeaveVT(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    drmCommandNone(pVia->drmFD, DRM_VIA_CHROME9_GEM_LEAVE);
    return;
}

void
VIAGEMEnterVT(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    drmCommandNone(pVia->drmFD, DRM_VIA_CHROME9_GEM_ENTER);
    return;
}

static Bool
VIAEnterVT(int scrnIndex, int flags)
{
    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIAEnterVT\n"));

    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    vgaRegPtr vgaSavePtr = &hwp->SavedReg;
    VIARegPtr viaSavePtr = &pVia->SavedReg;
    Bool ret;
    int i;
    miPointerScreenPtr PointPriv;
    int x, y;

    drmSetMaster(pVia->bufmgr->drmfd);

    /* 410 chipset some register setting are lost when suspend from
     * S3, the extended memory access enable/disable bit is the one
     * so enable the bit for we need to access the extended MMIO space
     */
    if (pVia->Chipset == VIA_VX900 && !pVia->IsSecondary) {
        VIAEnableMMIO(pScrn);
    }

    if (pVia->VQEnable && pVia->VQStart)
        VIAEnableVQ(pScrn);

    /* TODO: Rebind AGP memory here */
    /* TODO: Unlock DRI here */

    vgaHWUnlock(hwp);

    /* If the screen is under the rotated situation, the OS consider that
     * current mode is a rotated size. For example: 768x1024. So when the OS
     * want to set mode, it will transfer a rotated size to request the driver
     * to set this mode(768x1024). But we should set display timing according
     * to non-rotated size.(e.g. 1024x768).
     * So we have to convert the rotated size to the normal size.
     */
    /* If we just do SW/HW noRandR rotation 90/270 degree for 2D ONLY, we
     * don't need to do this. While, if we need XV support for Rotation, we
     * need to swap pScrn->virtualX/pScrn->virtualY,
     * for XV path cliping window detect.
     */
    swap_height_width_for_CWorCCW(pScrn);

#if XORG_VERSION_CURRENT < XF86_VERSION_NUMERIC(1,5,99,0,0) || \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(7,0,0,0,0)
    /* This is really a patch. patch for ubuntu8.04 os has garbage when resume
     * from S3 it seems the ubuntu os's own behavior. When os behavior right,
     * the patch can be removed. And this patch take no effect on other OS
     * like FCX whose xorg version is > 7.0.
     * but this patch has side effect to xorg<7.0,like suse10.1 suse10.2, when
     * switch console, the cursor disppear.
     * so we take the condision into consideration */
    if (pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor) {
#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0) && \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,4,99,0,0)
        PointPriv =
            (miPointerScreenPtr)dixLookupPrivate(&pScrn->pScreen->devPrivates,
            miPointerScreenKey);
#else
        extern int miPointerScreenIndex;

        PointPriv = pScrn->pScreen->devPrivates[miPointerScreenIndex].ptr;
#endif

#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0) && \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,4,0,0,0)
        miPointerGetPosition(inputInfo.pointer, &x, &y);
#else
        miPointerPosition(&x, &y);
#endif
        PointPriv->spriteFuncs->SetCursor(pScrn->pScreen, 0, x, y);
    }
#endif

    /* PCIE series new Registers */
    if (pVia->Chipset == VIA_VX800 || pVia->Chipset == VIA_VX855 ||
        pVia->Chipset == VIA_VX900) {
        for (i = 0; i < 10; i++) {
            VGAOUT8(0x3c4, 0x66 + i);
            VGAOUT8(0x3c5, viaSavePtr->SRRegs[0x66 + i]);
        }

        for (i = 0; i < 3; i++) {
            VGAOUT8(0x3c4, 0x79 + i);
            VGAOUT8(0x3c5, viaSavePtr->SRRegs[0x79 + i]);
        }

        for (i = 0; i < 6; i++) {
            VGAOUT8(0x3c4, 0x70 + i);
            VGAOUT8(0x3c5, viaSavePtr->SRRegs[0x70 + i]);
        }
    }

    if (!pVia->IsSecondary) {
        /* 1. Restore first or some of BIOS settings will lose. */
        /* 2. Flags=TRUE implies decrease flick. When the system resume from
         * suspend mode. LCD is switch too many times, so it cause eyes
         * feel flick. But We don't need to enable LCD so many times.
         * LCD panel will be enabled at the following setmode function.
         */
        VIARestore(pScrn, vgaSavePtr, viaSavePtr, TRUE);

        /* For ACPI S3/S4, EPHY setting won't be reserved after suspend. */
        /* Need to initial EPHY and do link-training again. */
        if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
            xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

            for (i = 0; i < xf86_config->num_output; i++) {
                xf86OutputPtr output = xf86_config->output[i];

                if (!xf86NameCmp(output->name, "DP")) {
                    viaDPInitEPHY(output);
                    viaDPLinkTraining(output);
                }
                if (!xf86NameCmp(output->name, "DP-2")) {
                    viaDP2InitEPHY(output);
                    viaDP2LinkTraining(output);
                }
            }
#endif
            /* Disable ignored output devices to avoid that they have display output. */
            for (i = 0; i < pVia->numIgnoredOutput; i++) {
                xf86OutputPtr output = pVia->ignoredOutput[i];

                output->funcs->dpms(output, DPMSModeOff);
            }
        }

        /*Clear FB with black color to avoid garbage caused by VIARestore */
        memset(pVia->FBBase, 0x00,
            ((pScrn->displayWidth * pScrn->bitsPerPixel >> 3) *
            pScrn->virtualY));

        /*Clear 3Dscaling buffer to avoid garbage */
        if (pVia->DISP3DScalingBufferStart)
            memset(pVia->FBBase + pVia->DISP3DScalingBufferStart, 0x00,
            DISP_3D_SCALING_BUFFER_SIZE * DISP_3D_SCALING_BUFNUM_ONESET *
            pVia->NumOfDevNeed3dScl);
    } else {
        /*Clear FB with black color to avoid garbage caused by VIARestore */
        memset(pVia->FBBase, 0x00,
            ((pScrn->displayWidth * pScrn->bitsPerPixel >> 3) *
            pScrn->virtualY));
    }

#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /* Initialize display engine */
        viaInitDispEngine(pVia);
        viaInitOutputRegSet(pScrn);
        ret = xf86SetDesiredModes(pScrn);
    }
#endif

    ret = VIAModeInit(pScrn, pScrn->currentMode);

    /*
     * TODO, Must call VIAGEMEnterVT because some console driver
     * (vesa fb driver) do not alloc VRAM through GEM
     * No needs when using KMS
     */
    VIAGEMEnterVT(pScrn);

    /* We need to initialize related registers about hardware icon again */
    /* when system resumes, or the cursor will become garbage. */
    VIAARGBCursorInit(pScrn);

    /* retore video status */
    if (!pVia->IsSecondary) {
        viaRestoreHqv(pScrn);
        viaRestoreVideo(pScrn);
    }

    VIAAdjustFrame(scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);

    /* Insert a timer */
    if ((pVia->IsHotkeyTimerEnabled) && (!pVia->pVIAEnt->HasSecondary)) {
        if (!pVia->devicesTimer) {
            pVia->devicesTimer = TimerSet(NULL, 0, 30, VIASyncTimer, pScrn);
        }
    } else {
        if (pVia->devicesTimer) {
            TimerCancel(pVia->devicesTimer);
            pVia->devicesTimer = NULL;
        }
    }

    pVia->IsSuspending = FALSE;           /* System has resumed. */

    /* Revert to the rotated size.(e.g. 1024x768 -> 768x1024) */
    swap_height_width_for_CWorCCW(pScrn);

    /* Release the DRM lock, or the DRI APs will be pending forever. */
#ifdef XF86DRI
    if (pVia->driType == DRI_1) {
        DRIUnlock(pScrn->pScreen);
    }
#endif

    return ret;
}

static void
VIALeaveVT(int scrnIndex, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    vgaRegPtr vgaSavePtr = &hwp->SavedReg;
    VIARegPtr viaSavePtr = &pVia->SavedReg;
    int i, rotate_degree;

    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIALeaveVT\n"));

    drmDropMaster(pVia->bufmgr->drmfd);

    /* TODO: take the DRI lock here to avoid accidents */
    /* TODO: unbind the AGP memory ? */
    /* Get DRM Lock to avoid DRI APs run unexpected under non-X situation */
#ifdef XF86DRI
    if (pVia->driType == DRI_1) {
        DRILock(pScrn->pScreen, 0);
    }
#endif

    /* Unload Timer */
    if (pVia->devicesTimer)
        TimerCancel(pVia->devicesTimer);

    pVia->devicesTimer = NULL;

    /* Wait Hardware Engine idle to exit graphicd mode */
    WaitIdle();

    if (pVia->VQEnable) {
        /* if we use VQ, disable it before we exit */
        switch (pVia->Chipset) {
        case VIA_P4M890:
        case VIA_K8M890:
            VIASETREG(0x41c, 0x00100000);
            VIASETREG(0x420, 0x74301000);
            break;
        default:
            VIASETREG(0x43c, 0x00fe0000);
            VIASETREG(0x440, 0x00000004);
            VIASETREG(0x440, 0x40008c0f);
            VIASETREG(0x440, 0x44000000);
            VIASETREG(0x440, 0x45080c04);
            VIASETREG(0x440, 0x46800408);
            break;
        }
    }

    /* Save video status and turn off all video activities */
    if (!pVia->IsSecondary) {
        viaSaveHqv(pScrn);
        viaSaveVideo(pScrn);
    }

    if (pVia->IsHWRotateEnabled) {
        DisableCBUrotate(pScrn);

        /* Disable CBU HW Rotate.
         * VX855 and VX900 rotation 90 and 270 degree probably has issue
         * but 180 degree doesn't have.
         * So here mimic the behavior of CBU 180
         * The root cause is still unknown.
         */
        if ((pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) &&
            (pVia->RotateDegree == VIA_ROTATE_DEGREE_90 ||
            pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
            /* Mimic the behavior of rotate 180 */
            rotate_degree = pVia->RotateDegree;
            pVia->RotateDegree = VIA_ROTATE_DEGREE_180;
            EnableCBUrotate(pScrn);
            pVia->RotateDegree = rotate_degree;
            /* Let CBU 180 rotate take effect */
            memset(pVia->FBBase, 0x00,
            (pScrn->displayWidth * pScrn->bitsPerPixel >> 3));

            DisableCBUrotate(pScrn);
        }
    }

    if (pVia->RotateDegree == VIA_ROTATE_DEGREE_90
        || pVia->RotateDegree == VIA_ROTATE_DEGREE_270) {
        memset(pVia->FBBase, 0x00,
            ((pScrn->displayWidth * pScrn->bitsPerPixel >> 3) *
            pScrn->virtualX));
    } else {
        memset(pVia->FBBase, 0x00,
            ((pScrn->displayWidth * pScrn->bitsPerPixel >> 3) *
            pScrn->virtualY));
    }

    /* TODO: For vt3353, some registers can't be restore in DRM module, it
     * seems that these registers be modified between DRM resume function and
     * VIAEnterVT function when using "suspend" button shipped with ubuntu 8.04.
     * So we save these registers here and restore them in VIAEnterVT.
     * These registers including: SR66~SR6F, SR70~SR75, SR79~SR7B.
     */
    if (pVia->Chipset == VIA_VX800 || pVia->Chipset == VIA_VX855 ||
        pVia->Chipset == VIA_VX900) {
        for (i = 0; i < 10; i++) {
            VGAOUT8(0x3c4, 0x66 + i);
            viaSavePtr->SRRegs[0x66 + i] = VGAIN8(0x3c5);
        }

        for (i = 0; i < 6; i++) {
            VGAOUT8(0x3c4, 0x70 + i);
            viaSavePtr->SRRegs[0x70 + i] = VGAIN8(0x3c5);
        }

        for (i = 0; i < 3; i++) {
            VGAOUT8(0x3c4, 0x79 + i);
            viaSavePtr->SRRegs[0x79 + i] = VGAIN8(0x3c5);
        }
    }
    /*
     * TODO, Must call VIAGEMLeaveVT because some console driver
     * (vesa fb driver) do not alloc VRAM through GEM
     * No needs when using KMS
     */
    VIAGEMLeaveVT(pScrn);

    VIARestore(pScrn, vgaSavePtr, viaSavePtr, FALSE);
    /* disable all IGA scaling and clear factors. */
    // viaSetIgaScaleFunction(IGA1+IGA2, VIA_SCALING_HW+VIA_EXPAND, FALSE);

    pVia->IsSuspending = TRUE;           /* System will suspend. */
    pVia->IsVIAModeInitRunOnceDone = FALSE;

    /*To fix hang issue when switch VT using 3D desktop */
    VGAOUT8(0x3c4, 0x32);
    VGAOUT8(0x3c5, 0x00);

    vgaHWLock(hwp);
}

static void
VIASave(ScrnInfoPtr pScrn)
{
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    vgaRegPtr vgaSavePtr = &hwp->SavedReg;
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    VIARegPtr save = &pVia->SavedReg;
    int vgaCRIndex, vgaCRReg, vgaIOBase;
    int i;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIASave\n"));

    if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
        vgaHWProtect(pScrn, TRUE);

        if (!pVia->IsMAMMEnable) {
            vgaHWSave(pScrn, vgaSavePtr, VGA_SR_ALL);
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Primary Adapter! saving VGA_SR_ALL !!\n"));
        } else {
            vgaHWSave(pScrn, vgaSavePtr, VGA_SR_MODE);
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Non-Primary Adapter! saving VGA_SR_MODE only !!\n"));
        }

        /* Unlock Extended Regs */
        viaWriteVgaIoBits(REG_SR10, 0x01, BIT0);
        /* Unlock CRTC register protect */
        if (VIAGetChipsetRevisionID() >= REVISION_VX855_A1) {
            viaWriteVgaIoBits(REG_CR47, 0, BIT4);
        } else {
            viaWriteVgaIoBits(REG_CR47, 0, BIT0);
        }

        /* Save Sequencer regs: from SR00 to SRFF */
        i = 0;
        while (1) {
            /* We have saved SR1A in VIAPreInit(). */
            if (i != 0x1A)
                save->SRRegs[i] = viaReadVgaIo(i + REG_SR00);

            if (i == 0xFF)
                break;
            else
                i++;
        }

        /* Save CRTC regs: from CR00 to CRFF */
        i = 0;
        while (1) {
            /* We have saved CR08 and CR09 in VIAPreInit(). */
            if ((i != 0x08) && (i != 0x09))
                save->CRTCRegs[i] = viaReadVgaIo(i + REG_CR00);

            if (i == 0xFF)
                break;
            else
                i++;
        }

        /* save IGA1 scale regs first */
        viaWriteVgaIoBits(REG_CRFD, 0x80, BIT0 + BIT7);
        for (i = 0; i <= 0xff; i++) {
            if (SearchScaleIndex(i) != 36)
                save->IGAScalingRegs[0].CR_Regs[SearchScaleIndex(i)] =
                    viaReadVgaIo(i);

        }

        /* save IGA2 scale regs */
        viaWriteVgaIoBits(REG_CRFD, 0x01, BIT0 + BIT7);
        for (i = 0; i <= 0xff; i++) {
            if (SearchScaleIndex(i) != 36) {
                save->IGAScalingRegs[1].CR_Regs[SearchScaleIndex(i)] =
                    viaReadVgaIo(i);
            }
        }

        /* Saving HW Cursor state */
        save->dwCursorMode = VIAGETREG(VIA_REG_CURSOR_MODE);
        save->dwCursorPOS = VIAGETREG(VIA_REG_CURSOR_POS);
        save->dwCursorORG = VIAGETREG(VIA_REG_CURSOR_ORG);
        save->dwCursorBG = VIAGETREG(VIA_REG_CURSOR_BG);
        save->dwCursorFG = VIAGETREG(VIA_REG_CURSOR_FG);

        vgaHWProtect(pScrn, FALSE);
		
#endif
    } 
	
    return;
}

unsigned char
SearchScaleIndex(unsigned char index)
{
    if (0x50 <= index && index <= 0x5f) {
        /* 0x50~0x5f is index 0~15 */
        return index - 0x50;
    } else if (0x77 <= index && index <= 0x87) {
        /* 0x77~0x87 is index 16~32 */
        return index - 0x67;
    } else if (index == 0x9f) {
        /* 0x9f is index 33 */
        return 33;
    } else if (index == 0xa2) {
        /* 0xa2 is index 34 */
        return 34;
    } else if (index == 0xd1) {
        /* 0xd1 is index 35 */
        return 35;
    } else {
        /* garbage index */
        return 36;
    }
}

static void
VIALoadScaleInfo(ScrnInfoPtr pScrn, ScalingRegs ScaleRegs, CARD32 * ScaleType)
{
    unsigned char *CR = ScaleRegs.CR_Regs;

    // disable scaling
    if ((CR[SearchScaleIndex(0xA2)] & (BIT3 | BIT7)) == 0) {
        *ScaleType = VIA_NONE_SCALING;
        return;
    }

    if ((CR[SearchScaleIndex(0x79)] & BIT0 == 0)
        && (CR[SearchScaleIndex(0x89)] & BIT0 == 1)) {
        *ScaleType = VIA_SCALING_HW;
    } else if (((CR[SearchScaleIndex(0x79)] & BIT0) == 1)
        && ((CR[SearchScaleIndex(0x89)] & BIT0) == 0)) {
        *ScaleType = VIA_EXPAND;
    } else {
        *ScaleType = VIA_NONE_SCALING;
    }

}

static void
VIARestore(ScrnInfoPtr pScrn, vgaRegPtr vgaSavePtr, VIARegPtr restore,
    int flags)
{
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int vgaCRIndex, vgaCRReg, vgaIOBase;
    int i;
    Bool deFlick = flags;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIARestore\n"));
    vgaIOBase = hwp->IOBase;
    vgaCRIndex = vgaIOBase + 4;
    vgaCRReg = vgaIOBase + 5;

    if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
        xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

        /* Disable outputs */
        for (i = 0; i < xf86_config->num_output; i++) {
            xf86OutputPtr output = xf86_config->output[i];

            output->funcs->dpms(output, DPMSModeOff);
        }

        /* Disable ignore outputs */
        for (i = 0; i < pVia->numIgnoredOutput; i++) {
            xf86OutputPtr output = pVia->ignoredOutput[i];

            output->funcs->dpms(output, DPMSModeOff);
        }

        /* Disable crtc */
        for (i = 0; i < xf86_config->num_crtc; i++) {
            xf86CrtcPtr crtc = xf86_config->crtc[i];

            crtc->funcs->dpms(crtc, DPMSModeOff);
        }

        vgaHWProtect(pScrn, TRUE);

        /* Unlock Extended Regs */
        viaWriteVgaIoBits(REG_SR10, 0x01, BIT0);
        /* Unlock CRTC register protect */
        if (VIAGetChipsetRevisionID() >= REVISION_VX855_A1) {
            viaWriteVgaIoBits(REG_CR47, 0, BIT4);
        } else {
            viaWriteVgaIoBits(REG_CR47, 0, BIT0);
        }

        /*=* CR6A, CR6B, CR6C must be reset before restore
            standard vga regs, or system will be hang. *=*/
        /*=* Reset IGA2 channel before disable IGA2 channel
            or it may cause some line garbage. *=*/
        /* Modify for the sequence issue of enable and disable */
        /* second display channel. */
        viaWriteVgaIoBits(REG_CR6A, 0x00, BIT6);    /* Set CR6A[6] to 0. */
        viaWriteVgaIoBits(REG_CR6A, 0x00, BIT7);    /* Set CR6A[7] to 0. */
        viaWriteVgaIoBits(REG_CR6A, 0x40, BIT6);    /* Set CR6A[6] to 1. */
        viaWriteVgaIoBits(REG_CR6A, 0x00, 0x3F);    /* Set CR6A[5:0] to 0. */

        viaWriteVgaIoBits(REG_CR6B, 0x00, 0xFF);    /* Set CR6B[7:0] to 0. */
        viaWriteVgaIoBits(REG_CR6C, 0x00, 0xFF);    /* Set CR6C[7:0] to 0. */

        /* Gamma must disable before restore pallette */
        viaWriteVgaIoBits(REG_CR33, 0x00, BIT7);    /* Set CR33[7] to 0. */

        /* restore the standard vga regs */
        if (!pVia->IsMAMMEnable)
            vgaHWRestore(pScrn, vgaSavePtr, VGA_SR_ALL);
        else
            vgaHWRestore(pScrn, vgaSavePtr, VGA_SR_MODE);

        /* restore Sequencer regs: From SR14 to SR3F  */
        for (i = 0x14; i < 0x40; i++) {
            viaWriteVgaIoBits(i + REG_SR00, restore->SRRegs[i], 0xFF);
        }

        viaWriteVgaIoBits(REG_SR42, restore->SRRegs[0x42], 0xFF);
        viaWriteVgaIoBits(REG_SR4F, restore->SRRegs[0x4F], 0xFF);
        viaWriteVgaIoBits(REG_SR50, restore->SRRegs[0x50], 0xFF);
        viaWriteVgaIoBits(REG_SR57, restore->SRRegs[0x57], 0xFF);
        viaWriteVgaIoBits(REG_SR5D, restore->SRRegs[0x5D], 0xFF);

        /* DVP1 Clock and Data Pads Driving: */
        viaWriteVgaIoBits(REG_SR65, restore->SRRegs[0x65], 0xFF);

            /*=* restore VCK, LCDCK and ECK *=*/
        /* VCK: */
        viaWriteVgaIoBits(REG_SR44, restore->SRRegs[0x44], 0xFF);
        viaWriteVgaIoBits(REG_SR45, restore->SRRegs[0x45], 0xFF);
        viaWriteVgaIoBits(REG_SR46, restore->SRRegs[0x46], 0xFF);
        /* Reset VCK PLL */
        viaWriteVgaIoBits(REG_SR40, 0x02, BIT1);    /* Set SR40[1] to 1 */
        viaWriteVgaIoBits(REG_SR40, 0x00, BIT1);    /* Set SR40[1] to 0 */

        /* LCK: */
        viaWriteVgaIoBits(REG_SR4A, restore->SRRegs[0x4A], 0xFF);
        viaWriteVgaIoBits(REG_SR4B, restore->SRRegs[0x4B], 0xFF);
        viaWriteVgaIoBits(REG_SR4C, restore->SRRegs[0x4C], 0xFF);
        /* Reset LCK PLL */
        viaWriteVgaIoBits(REG_SR40, 0x04, BIT2);    /* Set SR40[2] to 1 */
        viaWriteVgaIoBits(REG_SR40, 0x00, BIT2);    /* Set SR40[2] to 0 */

        /* ECK: */
        viaWriteVgaIoBits(REG_SR47, restore->SRRegs[0x47], 0xFF);
        viaWriteVgaIoBits(REG_SR48, restore->SRRegs[0x48], 0xFF);
        viaWriteVgaIoBits(REG_SR49, restore->SRRegs[0x49], 0xFF);
        /* Reset ECK PLL */
        viaWriteVgaIoBits(REG_SR40, 0x01, BIT0);    /* Set SR40[0] to 1 */
        viaWriteVgaIoBits(REG_SR40, 0x00, BIT0);    /* Set SR40[0] to 0 */

        /* Restore Preemptive Arbiter Control Register */
        if (pVia->Chipset == VIA_VX900) {
            viaWriteVgaIoBits(REG_SR4D, restore->SRRegs[0x4D], 0xFF);
        }

        /* Restore CRTC controller extended regs: */
        viaWriteVgaIoBits(REG_CR08, restore->CRTCRegs[0x08], 0xFF);
        viaWriteVgaIoBits(REG_CR09, restore->CRTCRegs[0x09], 0xFF);

        viaWriteVgaIoBits(REG_CR13, restore->CRTCRegs[0x13], 0xFF);
        viaWriteVgaIoBits(REG_CR30, restore->CRTCRegs[0x30], 0xFF);
        viaWriteVgaIoBits(REG_CR31, restore->CRTCRegs[0x31], 0xFF);
        viaWriteVgaIoBits(REG_CR32, restore->CRTCRegs[0x32], 0xFF);
        viaWriteVgaIoBits(REG_CR33, restore->CRTCRegs[0x33], 0xFF);

        /* From CR35 to CR47 */
        i = 0x35;
        while (1) {
            viaWriteVgaIoBits(i + REG_CR00, restore->CRTCRegs[i], 0xFF);
            if (i == 0x47)
                break;
            else
                i++;
        }

        /* Starting Address: */
        viaWriteVgaIoBits(REG_CR0C, restore->CRTCRegs[0x0C], 0xFF);
        viaWriteVgaIoBits(REG_CR0D, restore->CRTCRegs[0x0D], 0xFF);
        viaWriteVgaIoBits(REG_CR48, restore->CRTCRegs[0x48], 0xFF);
        viaWriteVgaIoBits(REG_CR34, restore->CRTCRegs[0x34], 0xFF);

        /* Before restore scaling setting, disable scaling first. */
        viaSetIgaScaleFunction(IGA1 + IGA2, VIA_SCALING_HW + VIA_EXPAND,
            FALSE);
        viaWriteVgaIoBits(REG_CRFD, restore->CRTCRegs[0xfd], 0xFF);

        /* From CR49 to CRFF */
        for (i = 0x49; i < 0x100; i++) {
            if (i == 0x91) {
                /*
                 * LCD Panel could use software power sequence, so we should resotore it
                 * individually to avoid incorrect enable LCD.
                 */
            } else if (i == 0xfd) {
                /*
                 * CR_FD will affect some scaling registers.
                 * Ex: It makes CR_89[0] to become 1 from 0
                 * then make some bugs in DuoView.
                 * Hence It should be writen before these registers.
                 */
            } else {
                viaWriteVgaIoBits(i + REG_CR00, restore->CRTCRegs[i], 0xFF);
            }
        }

        /* restore bios scaling registers */
        CARD32 ScaleType = VIA_NONE_SCALING;
        unsigned char *IGAScalingReg;

        /* IGA1 */
        IGAScalingReg = restore->IGAScalingRegs[0].CR_Regs;
        VIALoadScaleInfo(pScrn, restore->IGAScalingRegs[0], &ScaleType);

        if (ScaleType & VIA_EXPAND) {
            if (g_ChipCaps & CAPS_IGA1_EXPAND) {
                DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "Restore IGA1 Expand\n"));

                viaSetIgaScaleFunction(IGA1, VIA_EXPAND, TRUE);
                // Load Scaling factor
                viaWriteVgaIoBits(REG_CR77,
                    IGAScalingReg[SearchScaleIndex(0x77)], 0xFF);
                viaWriteVgaIoBits(REG_CR78,
                    IGAScalingReg[SearchScaleIndex(0x78)], 0xFF);
                viaWriteVgaIoBits(REG_CR79,
                    IGAScalingReg[SearchScaleIndex(0x79)], 0xF8);
                viaWriteVgaIoBits(REG_CR9F,
                    IGAScalingReg[SearchScaleIndex(0x9F)], BIT1 + BIT0);
            }
        } else if (ScaleType & VIA_SCALING_HW) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Restore IGA1 DownScaling\n"));
            // TODO: IGA1 downScaling
        }

        /* IGA2 */
        ScaleType = VIA_NONE_SCALING;
        IGAScalingReg = restore->IGAScalingRegs[1].CR_Regs;
        VIALoadScaleInfo(pScrn, restore->IGAScalingRegs[1], &ScaleType);

        if (ScaleType & VIA_EXPAND) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Restore IGA2 Expand\n"));
            viaSetIgaScaleFunction(IGA2, VIA_EXPAND, TRUE);
            // Load Scaling factor
            viaWriteVgaIoBits(REG_CR77, IGAScalingReg[SearchScaleIndex(0x77)],
                0xFF);
            viaWriteVgaIoBits(REG_CR78, IGAScalingReg[SearchScaleIndex(0x78)],
                0xFF);
            viaWriteVgaIoBits(REG_CR79, IGAScalingReg[SearchScaleIndex(0x79)],
                0xFF);
            viaWriteVgaIoBits(REG_CR9F, IGAScalingReg[SearchScaleIndex(0x9F)],
                BIT1 + BIT0);
        } else if (ScaleType & VIA_SCALING_HW) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Restore IGA2 DownScaling\n"));
            // TODO: IGA2 downScaling
        }

        /* Restore enable outputs */
        for (i = 0; i < xf86_config->num_output; i++) {
            xf86OutputPtr output = xf86_config->output[i];

            if (output->funcs->restore)
                output->funcs->restore(output);
        }

        /*  Restore ignore outputs */
        for (i = 0; i < pVia->numIgnoredOutput; i++) {
            xf86OutputPtr output = pVia->ignoredOutput[i];

            if (output->funcs->restore)
                output->funcs->restore(output);
        }

        /* Restore CR91 after lvds restore */
        viaWriteVgaIoBits(REG_CR91, restore->CRTCRegs[0x91], 0xFF);

        /* Reset clock */
        viaWriteMiscIo(viaReadMiscIo());

        /* Restore HW Cursor state */
        VIASETREG(VIA_REG_CURSOR_MODE, restore->dwCursorMode);
        VIASETREG(VIA_REG_CURSOR_POS, restore->dwCursorPOS);
        VIASETREG(VIA_REG_CURSOR_ORG, restore->dwCursorORG);
        VIASETREG(VIA_REG_CURSOR_BG, restore->dwCursorBG);
        VIASETREG(VIA_REG_CURSOR_FG, restore->dwCursorFG);

        vgaHWProtect(pScrn, FALSE);
        return;

#endif
    } 
}

static Bool
VIAMapMMIO(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    vgaHWPtr hwp;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAMapMMIO\n"));

    pVia->MmioBase = MEMBASE(pVia->PciInfo, 1);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_PROBED,
        "mapping MMIO @ 0x%lx with size 0x%x\n",
        pVia->MmioBase, VIA_MMIO_REGSIZE));

    /*Notice: pci_device_map_range will return error if there is already a map
     * region which base and size are the same as what you want to map. So in
     * SAMM case, just map these regions only once. */
    /*Map MMIO */
#if XSERVER_LIBPCIACCESS
    pci_device_map_range(pVia->PciInfo,
        pVia->MmioBase,
        VIA_MMIO_REGSIZE, PCI_DEV_MAP_FLAG_WRITABLE, (void **)&pVia->MapBase);
#else
    pVia->MapBase = xf86MapPciMem(pScrn->scrnIndex,
    VIDMEM_MMIO, pVia->PciTag, pVia->MmioBase, VIA_MMIO_REGSIZE);
#endif
    pBIOSInfo->MapBase = pVia->MapBase;

    MMIO_MB1 = pVia->MapBase;

    /*Map Blit space */
    MMIOMapBase = pVia->MapBase + 0x8000;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_PROBED,
        "mapping BitBlt MMIO @ 0x%lx with size 0x%x\n",
        pVia->MmioBase + VIA_MMIO_BLTBASE, VIA_MMIO_BLTSIZE));

#if XSERVER_LIBPCIACCESS
    pci_device_map_range(pVia->PciInfo,
        pVia->MmioBase + VIA_MMIO_BLTBASE,
        VIA_MMIO_BLTSIZE, PCI_DEV_MAP_FLAG_WRITABLE, (void **)&pVia->BltBase);
#else
    pVia->BltBase = xf86MapPciMem(pScrn->scrnIndex, VIDMEM_MMIO, pVia->PciTag,
    pVia->MmioBase + VIA_MMIO_BLTBASE, VIA_MMIO_BLTSIZE);
#endif

    if (!pVia->MapBase || !pVia->BltBase) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Internal error: cound not map registers\n");
        return FALSE;
    }

    /* Memory mapped IO for Video Engine */
    pVia->VidMapBase = pVia->MapBase + 0x200;

    /* Memory mapped IO for Integrated TV. */
#ifdef VIA_VT3293_SUPPORT
    if ((pVia->pBIOSInfo->Chipset == VIA_CX700) ||
        (pVia->pBIOSInfo->Chipset == VIA_CN750)) {
#else
    if (pVia->pBIOSInfo->Chipset == VIA_CX700) {
#endif
        xf86DrvMsg(pScrn->scrnIndex, X_PROBED,
            "mapping Integrated TV MMIO @ 0x%lx with size 0x%x\n",
            pVia->MmioBase + VIA_MMIO_INTEGRATED_TV_BASE,
            VIA_MMIO_INTEGRATED_TV_SIZE);

#if XSERVER_LIBPCIACCESS
        pci_device_map_range(pVia->PciInfo,
            pVia->MmioBase + VIA_MMIO_INTEGRATED_TV_BASE,
            VIA_MMIO_INTEGRATED_TV_SIZE,
            PCI_DEV_MAP_FLAG_WRITABLE, (void **)&pVia->IntegratedTVMapBase);
#else
        pVia->IntegratedTVMapBase =
            xf86MapPciMem(pScrn->scrnIndex, VIDMEM_MMIO, pVia->PciTag,
            pVia->MmioBase + VIA_MMIO_INTEGRATED_TV_BASE,
            VIA_MMIO_INTEGRATED_TV_SIZE);
#endif

        if (!pVia->IntegratedTVMapBase) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "Internal error: cound not map integrated TV registers\n");
            return FALSE;
        }

        pBIOSInfo->IntegratedTVMapBase = pVia->IntegratedTVMapBase;
    }

    VIAEnableMMIO(pScrn);
    hwp = VGAHWPTR(pScrn);
    vgaHWGetIOBase(hwp);

    if (!vgaHWMapMem(pScrn))
        return FALSE;

    return TRUE;
}

Bool
VIAMapFB(ScrnInfoPtr pScrn)
{

    VIAPtr pVia;

    pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    unsigned int frontSize;

    /* with UXA, front_bo only needs onscreen size buffer */
#ifdef VIA_HAVE_UXA
    frontSize =
        CMDISP_ALIGN_TO((pScrn->displayWidth * pScrn->bitsPerPixel >> 3),
        32) * pScrn->virtualY;
#else
    /* 90 Mega, temp solution, it will be fixed radically by UXA */
    unsigned int frontSize_limit = 90 << 20;

    frontSize =
        3 * (pScrn->displayWidth * pScrn->bitsPerPixel >> 3) *
        pScrn->virtualY;

    frontSize = frontSize > frontSize_limit ? frontSize_limit : frontSize;
#endif

    /* front bo is fix to (displayWidth*displayWidth*BPP) in case of dri */
#if DRI2INFOREC_VERSION < 4
    if ((pScrn->virtualX > VIA_DRI_MIN_WIDTH)
        && (pScrn->virtualY > VIA_DRI_MIN_WIDTH)) {
        frontSize =
            CMDISP_ALIGN_TO((pScrn->virtualX * (pScrn->bitsPerPixel >> 3)),
            32) * pScrn->virtualY;
    } else if (pScrn->virtualX > VIA_DRI_MIN_WIDTH) {
        frontSize = 
            CMDISP_ALIGN_TO((pScrn->virtualX * (pScrn->bitsPerPixel >> 3)),
            32) * VIA_DRI_MIN_WIDTH;			
    } else if (pScrn->virtualY > VIA_DRI_MIN_WIDTH) {
        frontSize = 
            CMDISP_ALIGN_TO((VIA_DRI_MIN_WIDTH * (pScrn->bitsPerPixel >> 3)),
            32) * pScrn->virtualY;			
	} else {
        frontSize =
            CMDISP_ALIGN_TO((VIA_DRI_MIN_WIDTH * (pScrn->bitsPerPixel >> 3)),
            32) * VIA_DRI_MIN_WIDTH;
	}
#endif
    if (!pVia->useEXA) {
        if ((pScrn->virtualX > VIA_DRI_MIN_WIDTH)
            && (pScrn->virtualY > VIA_DRI_MIN_WIDTH))
            frontSize =
            CMDISP_ALIGN_TO((pScrn->virtualX *
                (pScrn->bitsPerPixel >> 3)), 32) * pScrn->virtualY;
        else
            frontSize =
            CMDISP_ALIGN_TO((VIA_DRI_MIN_WIDTH *
                (pScrn->bitsPerPixel >> 3)), 32) * VIA_DRI_MIN_WIDTH;
    }

    if (pVia->useEXA)
        pVia->front_bo = dri_bo_alloc(pVia->bufmgr, "front_bo", frontSize,
            0, VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);
    else
        pVia->front_bo =
            dri_bo_alloc(pVia->bufmgr, "front_bo",
            frontSize + VIA_PIXMAP_CACHE_SIZE, 0,
            VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);

    if (dri_bo_map(pVia->front_bo, 0)) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "can not mmap the front bo \n");
        return FALSE;
    }
    /*init frameX/Y*/
	pScrn->frameX1 = pScrn->virtualX;
	pScrn->frameY1 = pScrn->virtualY;
	
    pVia->FBBase = (unsigned char *)pVia->front_bo->virtual;

    pBIOSInfo->FBBase = pVia->FBBase;
    pBIOSInfo->videoRambytes = pVia->videoRambytes;
    pVia->FBFreeStart = pVia->FBFreeEnd = pVia->videoRambytes;

    pScrn->fbOffset = pVia->front_bo->offset;

    /*Clear FB with black color to avoid garbage */
    memset(pVia->FBBase, 0x00, frontSize);

    return TRUE;
}

void
VIAUnmapMem(ScrnInfoPtr pScrn)
{
    VIAPtr pVia;

    pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAUnmapMem\n"));

    /*XXX free front bo in CloseScreen stage */
    if (pVia->front_bo)
        dri_bo_unreference(pVia->front_bo);

    return;
}

int
VIAHWCursorSpaceAllocate(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int addr = 0;

    if (!pVia->IsSecondary) {
        if (pVia->useRandR) {
            if (!pVia->ForceSWCursor) {
#ifdef VIA_RANDR12_SUPPORT
                int i;

                for (i = 0; i < 2; i++) {
                    pVia->HiBuf_bo[i] =
                    dri_bo_alloc(pVia->bufmgr, "hibuf_bo",
                        VIA_CURSOR_SIZE, 16,
                        VIA_CHROME9_GEM_DOMAIN_VRAM |
                        VIA_CHROME9_GEM_FLAG_NO_EVICT);
                    if (dri_bo_map(pVia->HiBuf_bo[i], 0)) {
                        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                            "Cursor Buffer map failed\n");
                        return -1;
                    }
                }
#endif
            }
        } else if (pVia->pVIAEnt->pScreensPublicInfo->UseHwCursor
            || pVia->pVIAEnt->HasSecondary) {
            /*Note:
             * We must allocate the address in 64M,so we can't allocate the address from FBFreeEnd
             * Graphic Hardware Cursor Mode Control 0x2D0 use bits [25:8] define 32x32x2 pattern base address,
             * use bits [25:10] define 64x64x2 pattern base address, so we make pVia->FBFreeStart align base
             * address with bit10. */
            addr =
                viaFBAlloctor(pScrn, VIA_CURSOR_SIZE, SEQUENCE,
                "noRandR HW Icon Buf");
            if (addr) {
                pVia->pVIAEnt->pScreensPublicInfo->CursorInfo.HIBufStart =
                    addr;
            } else {
                return -1;
            }

            addr =
                viaFBAlloctor(pScrn, VIA_CURSOR_SIZE, SEQUENCE,
                "noRandR HW Primary Scaling Buf");
            if (addr) {
                pVia->pVIAEnt->pScreensPublicInfo->CursorInfo.
                    HIPrimScalingBufStart = addr;
            } else {
                return -1;
            }

            addr =
                viaFBAlloctor(pScrn, VIA_CURSOR_SIZE, SEQUENCE,
                "noRandR HW Second Scaling Buf");
            if (addr) {
                pVia->pVIAEnt->pScreensPublicInfo->CursorInfo.
                    HISecScalingBufStart = addr;
            } else {
                return -1;
            }
        }
    }
    return 0;
}

#ifdef DRM_SAMM_VIA

void
VIADrmUnlock(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    VIAPtr pVia0 = VIAPTR(pVia->pVIAEnt->pPrimaryScrn);

    if (pVia0->LockRefCount > 0) {
        pVia0->LockRefCount--;
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "In SAMM+DRM case, driver unlock too many times.\n");
    }

    if (!pVia0->LockRefCount) {
        drmUnlock(pVia0->drmFD, samm_ctx_hdl);
    }
}

void
VIADrmLock(ScreenPtr pScreen, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    VIAPtr pVia0 = VIAPTR(pVia->pVIAEnt->pPrimaryScrn);

    if (!pVia0->LockRefCount) {
        drmGetLock(pVia0->drmFD, samm_ctx_hdl, 0);
    }
    pVia0->LockRefCount++;
}

/* These functions will be called When X reponse to something */
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
void
VIABlockHandler(int screenNum, pointer blockData,
    pointer pTimeout, pointer pReadmask)
#else
void
VIABlockHandler(ScreenPtr pScreen,
    pointer pTimeout, pointer pReadmask)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScreenPtr pScreen = screenInfo.screens[screenNum]; 
    ScrnInfoPtr pScrn = xf86Screens[screenNum];
#else
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
#endif
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "enter VIABlockHandler function\n"));

    pScreen->BlockHandler = pVia->viaBlockHandlerback;
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    (*pScreen->BlockHandler) (screenNum, blockData, pTimeout, pReadmask);
#else
	(*pScreen->BlockHandler) (pScreen,pTimeout,pReadmask);
#endif
    pVia->viaBlockHandlerback = pScreen->BlockHandler;
    pScreen->BlockHandler = VIABlockHandler;

    /* do usefull work here */
    /* We can take it for granted that
     * the DRM has been initialized properly
     */
     
    VIADrmUnlock(pScreen);
}

#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
void
VIAWakeupHandler(int screenNum, pointer wakeupData,
    unsigned long result, pointer pReadmask)
#else
void
VIAWakeupHandler(ScreenPtr pScreen,
    unsigned long result, pointer pReadmask)
#endif
{
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    ScreenPtr pScreen = screenInfo.screens[screenNum];
    ScrnInfoPtr pScrn = xf86Screens[screenNum];
#else
	ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
	int screenNum = pScreen->myNum;
#endif
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "enter VIAWakeupHandler function\n"));

    pScreen->WakeupHandler = pVia->viaWakeupHandlerback;
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    (*pScreen->WakeupHandler) (screenNum, wakeupData, result, pReadmask);
#else
	(*pScreen->WakeupHandler) (pScreen, result, pReadmask);
#endif
    pVia->viaWakeupHandlerback = pScreen->WakeupHandler;
    pScreen->WakeupHandler = VIAWakeupHandler;

    /* do usefull work here */
    /* We can take it for granted that
     * the DRM has been initialized properly
     */
    VIADrmLock(pScreen, 0);
}
#endif

#ifdef VIA_HAVE_UXA
Bool
VIACreateScreenResources(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    PixmapPtr ppix;
    struct via_pixmap *vpix;

    pScreen->CreateScreenResources = pVia->CreateScreenResources;

    if (!(*pScreen->CreateScreenResources) (pScreen))
        return FALSE;

    if (pVia->useUXA && !uxa_resources_init(pScreen))
        return FALSE;

    pScreen->CreateScreenResources = VIACreateScreenResources;

    if (!pVia->NoAccel && (pVia->useEXA || pVia->useUXA)) {
        ppix = pScreen->GetScreenPixmap(pScreen);
    if (pVia->useUXA) {
        vpix = calloc(1, sizeof(*vpix));
    } else
        vpix = (struct via_pixmap *)exaGetPixmapDriverPrivate(ppix);
    vpix->pbo = pVia->front_bo;
    vpix->location = VIA_CHROME9_GEM_DOMAIN_VRAM;
    vpix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;

    if (pVia->useUXA)
        via_uxa_set_pixmap_private(ppix, vpix);
    }
    return TRUE;
}
#endif

static Bool
VIAScreenInit(int scrnIndex, ScreenPtr pScreen, int argc, char **argv)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    int ret;
    unsigned int TmpSwapValue;
    unsigned int addr;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAScreenInit\n"));
/*version usingdef */
#ifdef XORG_VERSION_CURRENT
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XF86_VER=%d\n, Not using in driver Now.\n",
        via_xf86_version_current));
#if XORG_VERSION_CURRENT <= XF86_VERSION_NUMERIC(2,0,0,0,0) && \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(1,0,0,0,0)
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "XORG_VER=%d\n, Now driver depending only on this.\n",
        XORG_VERSION_CURRENT));
#else
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "WARNING!!XORG_VER Out of (2,0,0,0,0)and(1,0,0,0,0),if =7.0~2,"
        "will ok,or Old version driver no surpport.\n"));
#endif
#else
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "WARNING!!XORG_VER=%d\n,Not Exist,flow may wrong  Now.\n",
        XORG_VERSION_CURRENT));
#endif
/*version using define*/

    /* Initialize TTM buffer manager for device driver */
    if (!pVia->bufmgr) {
        pVia->bufmgr = via_bo_bufmgr_con(pVia->drmFD);
    }
    if (!pVia->bufmgr) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "failed to initialize TTM buffer manager\n"));
        return FALSE;
    }
    /* TODO
     * when switch user, console driver(e.x vesa fb driver) may over write
     * gart-table in VRAM, patch this by try to restore gart-table
     * No needs when using KMS
     * */
    VIAGEMEnterVT(pScrn);
    /* For MAMM */
    if (!pVia->IsMAMMEnable)
        vgaHWUnlock(hwp);

    if (!VIAMapFB(pScrn))
        return FALSE;

    if (pVia->useRandR) {
        if (pVia->numOfEmbTv) {
            if (integratedtv_module_loaded) {
                addr =
                    viaFBAlloctor(pScrn, INTEGRATED_TV_BUFFER_SIZE,
                    INVERT_SEQ, "Integrated TV buf");
                if (addr) {
                    pVia->IntegratedTVBufferStart = addr;
                } else {
                    return FALSE;
                }
                viaSetEmbTvBufferAddress((unsigned int)pVia->
                    IntegratedTVMapBase, pVia->IntegratedTVBufferStart);
            }
        }
    } else {
        /* We should arrange the base address of source and */
        /* destination buffers by frame buffer size, for integrated TV only. */
        /* Only need to do once, so secondary driver doesn't need to do. */
#ifdef VIA_VT3293_SUPPORT
        if (((pVia->Chipset == VIA_CX700) || (pVia->Chipset == VIA_CN750))
            && (!pVia->IsSecondary)) {
#else
        if ((pVia->Chipset == VIA_CX700) && (!pVia->IsSecondary)) {
#endif
            if (integratedtv_module_loaded) {
                addr =
                    viaFBAlloctor(pScrn, INTEGRATED_TV_BUFFER_SIZE,
                    INVERT_SEQ, "Integrated TV buf");
                if (addr) {
                    pVia->IntegratedTVBufferStart = addr;
                } else {
                    return FALSE;
                }
                SetIntegratedTVBufferAddress(pScrn);
            }
        }
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Mem Mapped\n"));

    /* Try to enable DRI2 as default */
    if (pVia->directRenderingEnabled == TRUE) {
        pVia->driType = DRI_2;
        if (!VIADRI2ScreenInit(pScreen)) {
            /* DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIA DRI2 \n")); */
            pVia->driType = DRI_1;
        }
    } else
        pVia->driType = DRI_DISABLED;

#ifdef XF86DRI
    if (pVia->driType == DRI_1) {
        if (!VIADRIScreenInit(pScreen))
            pVia->driType = DRI_DISABLED;
    }
#endif

    VIASave(pScrn);

#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /* Initialize display engine, must after VIASave() and before
           VIAModeInit() */
        viaInitDispEngine(pVia);
        viaInitOutputRegSet(pScrn);

        /* Disable ignored output */
        /* We might modify SR and CR when disable output devices.
         * Therefore, disable ignored output devices after VIASave(). */
        int i;

        for (i = 0; i < pVia->numIgnoredOutput; i++) {
            xf86OutputPtr output = pVia->ignoredOutput[i];

            output->funcs->dpms(output, DPMSModeOff);
        }
    }
#endif

    /* Even we had disable the spread spectrum at PreInit.
     * But we still disable it again for safty.
     */
    if (pVia->pChipInfo->biosIsSpreadSpectrum) {
        /* Disable spread spectrum temporarily, we will turn it on when set mode. */
        VGAOUT8(0x3c4, SR3D);
        VGAOUT8(0x3c5, VGAIN8(0x3c5) & 0xFE);

        VGAOUT8(0x3c4, SR1E);
        VGAOUT8(0x3c5, VGAIN8(0x3c5) & 0xF7);
    }

    vgaHWBlankScreen(pScrn, FALSE);

    if (!VIAModeInit(pScrn, pScrn->currentMode))
        return FALSE;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- State saved\n"));

    /* Darken the screen for aesthetic reasons and set the viewport */
    VIASaveScreen(pScreen, SCREEN_SAVER_ON);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    pScrn->AdjustFrame(scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);
#else
	pScrn->AdjustFrame(pScrn, pScrn->frameX0, pScrn->frameY0);
#endif
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Blanked\n"));

    miClearVisualTypes();

    if (pScrn->bitsPerPixel > 8 && !pVia->IsSecondary) {
        if (!miSetVisualTypes(pScrn->depth, TrueColorMask,
            pScrn->rgbBits, pScrn->defaultVisual))
            return FALSE;
        if (!miSetPixmapDepths())
            return FALSE;
    } else {
        if (!miSetVisualTypes(pScrn->depth,
            miGetDefaultVisualMask(pScrn->depth), pScrn->rgbBits,
            pScrn->defaultVisual))
            return FALSE;
        if (!miSetPixmapDepths())
            return FALSE;
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Visuals set up\n"));

    ret = VIAInternalScreenInit(scrnIndex, pScreen);

    if (!ret)
        return FALSE;

    xf86SetBlackWhitePixels(pScreen);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- B & W\n"));

    if (pScrn->bitsPerPixel > 8) {
        VisualPtr visual;

        visual = pScreen->visuals + pScreen->numVisuals;
        while (--visual >= pScreen->visuals) {
            if ((visual->class | DynamicClass) == DirectColor) {
                visual->offsetRed = pScrn->offset.red;
                visual->offsetGreen = pScrn->offset.green;
                visual->offsetBlue = pScrn->offset.blue;
                visual->redMask = pScrn->mask.red;
                visual->greenMask = pScrn->mask.green;
                visual->blueMask = pScrn->mask.blue;
            }
        }
    }

    /* must be after RGB ordering fixed */
    fbPictureInit(pScreen, 0, 0);

    /*for 2D accel fail */
    if (!pVia->NoAccel) {
        if (FALSE == VIAInitAccel(pScreen))
            return FALSE;
    } else {
        /* No Accel path :
         * Sync marker space.
         */
        /* No Accel path :
         * Init the 3D pipeline API for the uniform 3D texture blting interface */
        viaExa3DInit(pScreen);
        viaExa2DInit(pScreen);
        pVia->exa_sync_bo =
            dri_bo_alloc(pVia->bufmgr, "EXA Sync Marker", 32, 0,
            VIA_CHROME9_GEM_DOMAIN_VRAM | VIA_CHROME9_GEM_FLAG_NO_EVICT);
        if (dri_bo_map(pVia->exa_sync_bo, 0)) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "can not map the exa sync bo \n"));
            return FALSE;
        }
        pVia->markerOffset = pVia->exa_sync_bo->offset;
        pVia->markerOffset = (pVia->markerOffset + 31) & ~31;
        pVia->markerBuf =
            (volatile CARD32 *)(pVia->exa_sync_bo->virtual +
            (pVia->exa_sync_bo->offset - pVia->markerOffset));
        *pVia->markerBuf = 0;
    }

    ret = VIAHWCursorSpaceAllocate(pScreen);
    if (ret != 0) {
        return FALSE;
    }
#ifdef XF86DRI
    /*for VIDEO play memory overlap PIXEL_MAP_CACHE */
    if (pVia->driType == DRI_1
#ifdef DRM_SAMM_VIA
        || pVia->drmSammEnabled
#endif
    ) {
        if (!(VIADRIFBInit(pScreen, pVia))) {
            VIADRICloseScreen(pScreen);
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "[dri] frame buffer initialize failed .\n");
            pVia->driType = DRI_DISABLED;
        }
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "[dri] frame buffer initialized done.\n");
    }
#endif

    xf86SetBackingStore(pScreen);
    xf86SetSilkenMouse(pScreen);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Backing store set up\n"));

    if (pVia->useRandR)
        xf86DiDGAInit(pScreen, pVia->FrameBufferBase + pScrn->fbOffset);

    miDCInitialize(pScreen, xf86GetPointerScreenFuncs());
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- SW cursor set up\n"));

#ifdef VIA_RANDR12_SUPPORT
    if (!pVia->ForceSWCursor) {
        /*Disable HW cursor 0x2D0[0] */
        CARD32 regCursorMode = VIAGETREG(VIA_REG_CURSOR_MODE);

        VIASETREG(VIA_REG_CURSOR_MODE, regCursorMode & 0xFFFFFFFE);
        /*Init HW Icon */
        VIAARGBCursorInit(pScrn);
        if (!xf86_cursors_init(pScreen, MAX_CURS, MAX_CURS,
            (HARDWARE_CURSOR_SOURCE_MASK_INTERLEAVE_64 |
            HARDWARE_CURSOR_AND_SOURCE_WITH_MASK |
            HARDWARE_CURSOR_TRUECOLOR_AT_8BPP |
            HARDWARE_CURSOR_INVERT_MASK |
            HARDWARE_CURSOR_BIT_ORDER_MSBFIRST |
            HARDWARE_CURSOR_ARGB | 0)))
        DEBUG(ErrorF("Fail to initial xf86_cursors_init()\n"));
    }
#endif

    if (pVia->shadowFB) {
        RefreshAreaFuncPtr refreshArea = VIARefreshArea;

        if (pVia->RotateDegree) {
            switch (pScrn->bitsPerPixel) {
            case 8:
                refreshArea = VIARefreshArea8;
                break;
            case 16:
                refreshArea = VIARefreshArea16;
                break;
            case 32:
                refreshArea = VIARefreshArea32;
                break;
            }
        }
        ShadowFBInit(pScreen, refreshArea);
    }
#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /* For RandR v1.2 */
        if (!xf86CrtcScreenInit(pScreen)) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "xf86CrtcScreenInit Fail\n"));
            return FALSE;
        }
    }
#endif

    if (!miCreateDefColormap(pScreen))
        return FALSE;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Def Color map set up\n"));

    /* only 3123Ax IGA2 use 6-Bit LUT, others chipset IGA2 use 8-Bit LUT */
    /* So, except 3123Ax, we use 8-Bit LUT as default. */
    pScrn->rgbBits = 8;
    VGAOUT8(0x3C4, SR15);
    VGAOUT8(0x3C5, VGAIN8(0x3C5) | 0x80);
    if (!xf86HandleColormaps(pScreen, 256, 8, VIALoadPalette, NULL,
        CMAP_RELOAD_ON_MODE_SWITCH | CMAP_PALETTED_TRUECOLOR))
    return FALSE;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Palette loaded\n"));

    /* Remove restart flag file for utility */
    UTRemoveRestartFlag(pBIOSInfo);

    vgaHWBlankScreen(pScrn, TRUE);

    pVia->CloseScreen = pScreen->CloseScreen;
    pScreen->CloseScreen = VIACloseScreen;

    if (pVia->useRandR) {
        xf86DPMSInit(pScreen, xf86DPMSSet, 0);
        pScreen->SaveScreen = xf86SaveScreen;
    } 
	
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- DPMS set up\n"));

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Color maps etc. set up\n"));

#ifdef XF86DRI
    if (pVia->driType == DRI_1
#ifdef DRM_SAMM_VIA
        || pVia->drmSammEnabled
#endif
        )
        if (!VIADRIFinishScreenInit(pScreen))
            pVia->driType = DRI_DISABLED;

    if (pVia->driType != DRI_DISABLED) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "direct rendering enabled(%s)\n",
            pVia->driType == DRI_1 ? "DRI" : "DRI2");
        VIASet3DSyncInfoParas(pScreen);
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "direct rendering disabled\n");
    }
#endif

    if (!pVia->NoAccel) {
        viaFinishInitAccel(pScreen);
    } else {
        /* Init Command Buffer for the uniform 3D texture blting interface */
        viaSetupCBuffer(pScrn, &pVia->cb, 0);
    }

    /* Initial VIA Video Driver */
    FillGraphicMemInfo(pScrn);
    if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
        FillGraphicInfo_New(pScrn);
#endif
    } 
	
#ifdef VIA_RANDR12_SUPPORT
    if (pVia->useRandR) {
        /*added for RANDR12 static rotate , because of the xorg's randr12 has
         * issue, at which point pScrn->pScreen is not set but the
         * xf86SetDesiredModes will use it, so we just manually assign it before
         * the function, we only need to do this manually in xorg-1.4.0.90,
         * in xorg-1.4.99.905 is fix, we do not need to assign it manully */
        ScrnInfoPtr pTemp = pScrn;

        pScrn->pScreen = screenInfo.screens[pScrn->scrnIndex];

        if (!xf86SetDesiredModes(pScrn))
            return FALSE;

        pScrn->pScreen = pTemp->pScreen;
    }
#endif

    /* Mark we have already use all memory */
    /* pVia->FBFreeStart = pVia->FBFreeEnd; */
    if (via_module_loaded) {
        /*When the first time we use the structure, we initialize it */
        if (!(pVia->IsSecondary)) {
            memset((void *)&NEWVIAGraphicInfo, 0x0,
            sizeof(NEWVIAGRAPHICINFO));
        }
        Translate_FillGFXMemInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
        TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
        vvaInitVideo(pVia->FBBase, pVia->MapBase, &NEWVIAGraphicInfo);

        if (FALSE == vvaSyncInfo(NULL, VIA_XSERVERON))
            return FALSE;
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "libddmpeg: Heap Begin 0x%lx,End 0x%lx\n", viaGfxInfo->vheapbase,
        viaGfxInfo->vheapend));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "DRMEnabled: 0x%x\n",
        viaGfxInfo->drmEnabled));
    if (viaGfxInfo->igaInfo[IGA1 - 1].actived) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].desired_width));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwHeight: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].desired_height));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwRefreshRate: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].refreshrate));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA1 dwExpand: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA1 - 1].igaStatus.expanded));
    }
    if (viaGfxInfo->igaInfo[IGA2 - 1].actived) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].desired_width));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwSaveWidth: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].desired_height));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwBPP: 0x%lx\n",
            viaGfxInfo->screenInfo[IGA2 - 1].bpp));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwRefreshRate: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].refreshrate));
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "using IGA2 dwExpand: 0x%lx\n",
            viaGfxInfo->igaInfo[IGA2 - 1].igaStatus.expanded));
    }

    /*  Init video structure, video flags & HW difference flags */
    vidInitVideoInfo(pVidData);

    viaInitVideo(pScreen);

    if (pBIOSInfo->MergedFB) {
        /* Psuedo xinerama */
        if (pBIOSInfo->UseVIAXinerama) {
            VIAnoPanoramiXExtension = FALSE;
            VIAXineramaExtensionInit(pScrn);
        }
    }

    /* Create a extension handler to receive the request of s3utility. */
    /* XV path and Xext path is co-exists now. */
    //VIADisplayExtensionInit(pScrn);

    /* For XV Rotate+panning support, set the correct Clipping window.
     *
     * In NoRandR rotate for 2D, we don't need to swap virtualX/Y,
     * while XV Rotate+panning in noRandR need it.
     * */
    if ((pVia->RotateDegree == VIA_ROTATE_DEGREE_90) ||
        (pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
        TmpSwapValue = pScrn->currentMode->HDisplay;
        pScrn->currentMode->HDisplay = pScrn->currentMode->VDisplay;
        pScrn->currentMode->VDisplay = TmpSwapValue;
    }

    if (serverGeneration == 1)
        xf86ShowUnusedOptions(pScrn->scrnIndex, pScrn->options);

/* Only hook this two function when SAMM + DRM enabled.
 * for dealing with DRM lock.
 * Maybe we can do other usefull things in this function.
 */
#ifdef DRM_SAMM_VIA
    if (pVia->drmSammEnabled) {
        pVia->viaBlockHandlerback = pScreen->BlockHandler;
        pScreen->BlockHandler = VIABlockHandler;
        pVia->viaWakeupHandlerback = pScreen->WakeupHandler;
        pScreen->WakeupHandler = VIAWakeupHandler;
    }
#endif

#ifdef VIA_HAVE_UXA
    pVia->CreateScreenResources = pScreen->CreateScreenResources;
    pScreen->CreateScreenResources = VIACreateScreenResources;
#endif
//  uxa_resources_init(pScreen);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "- Done\n"));
    return TRUE;
}

int
VIAInternalScreenInit(int scrnIndex, ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn;
    VIAPtr pVia;
    VIABIOSInfoPtr pBIOSInfo;
    int width, height, displayWidth, shadowHeight;
    unsigned char *FBStart;
    int ret = TRUE;

    xf86DrvMsg(scrnIndex, X_INFO, "VIAInternalScreenInit\n");

    pScrn = xf86Screens[pScreen->myNum];
    pVia = VIAPTR(pScrn);
    pBIOSInfo = pVia->pBIOSInfo;

    displayWidth = pScrn->displayWidth;

    if ((pVia->RotateDegree == VIA_ROTATE_DEGREE_90) ||
        (pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
        height = pScrn->virtualX;
        width = pScrn->virtualY;

        /* For XV Rotate+panning support, set the correct Clipping window.
         *
         * In NoRandR rotate for 2D, we don't need to swap virtualX/Y,
         * while XV Rotate+panning in noRandR need it.
         * */
        pScrn->virtualX = width;
        pScrn->virtualY = height;
    } else {
        width = pScrn->virtualX;
        height = pScrn->virtualY;
    }

    shadowHeight = height;

    if (pVia->shadowFB) {
        pVia->ShadowPitch = BitmapBytePad(pScrn->bitsPerPixel * width);
        pVia->ShadowPtr =
            (unsigned char *)malloc(pVia->ShadowPitch * shadowHeight);
        displayWidth = pVia->ShadowPitch / (pScrn->bitsPerPixel >> 3);
        FBStart = pVia->ShadowPtr;
    } else {
        pVia->ShadowPtr = NULL;

        FBStart = pVia->FBBase;
    }

    /*
     *   Use Direct Access Window Rotate.
     *   When screen will be rotated, we must report a rotated size to OS
     *   to generate a rotated screen data.
     */
    if (pVia->IsHWRotateEnabled) {
        switch (pVia->RotateDegree) {
        case VIA_ROTATE_DEGREE_90:
        case VIA_ROTATE_DEGREE_270:
            displayWidth = width;
            break;
        }
    }

    ret = fbScreenInit(pScreen, FBStart, width, height,
    pScrn->xDpi, pScrn->yDpi, displayWidth, pScrn->bitsPerPixel);

    return ret;
}

static ModeStatus
VIAValidMode(int scrnIndex, DisplayModePtr mode, Bool verbose, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int ModeIndex;
    CARD32 DesiredModePixelClock;

    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIAValidMode\n"));

    if (!memcmp(mode->name, "PanelMode", 9)) {
        mode->type = M_T_USERDEF;
        VIAGetModeLineTiming(pScrn, mode);
        pBIOSInfo->EDIDType = VIA_DEVICE_LCD;
        pBIOSInfo->LVDSSettingInfo.PanelSizeID =
            VIA_MAKE_ID(mode->HDisplay, mode->VDisplay);
        pBIOSInfo->isPanelModeLine = TRUE;
        return MODE_OK;
    }

    if (!pBIOSInfo->NoDDCValue) {
        /* 1.if user don't set modes in config file, we want to use PreferMode,
           so we use PreferModeH  PreferModeV to valid modes.
         * 2.if user set modes in config file, we use EDID can support maxH,
           maxV to valid modes */
        if (pBIOSInfo->IsAutoDectectEnable == TRUE) {
            if ((mode->CrtcHDisplay > pBIOSInfo->CRTSettingInfo.PreferModeH)
                || (mode->CrtcVDisplay >
                    pBIOSInfo->CRTSettingInfo.PreferModeV))
                return MODE_BAD_VVALUE;
        } else {
            if ((mode->CrtcHDisplay > pBIOSInfo->CRTSettingInfo.MonitorSizeH)
                || (mode->CrtcVDisplay >
                    pBIOSInfo->CRTSettingInfo.MonitorSizeV))
                return MODE_BAD_VVALUE;
        }
    }

    /* If the modeline is added by user, pass it. */
    if ((mode->type == M_T_USERDEF) || (mode->type == 0))
        return MODE_OK;

    /* If the modeline is added by monitor, pass it. */
    switch (mode->type) {
    /* Monitor EDID */
    case M_T_DRIVER:
    /* Monitor EDID + Auto-detection */
    case M_T_DRIVER | M_T_USERDEF:
    /* Monitor EDID + Monitor Preferred Mode */
    case M_T_DRIVER | M_T_PREFERRED:
    /* Monitor EDID + Auto-detection + Monitor Preferred Mode */
    case M_T_DRIVER | M_T_USERDEF | M_T_PREFERRED:
        return MODE_OK;
        break;
    }

    /* check modes */
    if (IsValidMode(mode->CrtcHDisplay, mode->CrtcVDisplay) == 0) {
        return MODE_BAD;
    } else {
        return MODE_OK;
    }
}

static void
VIABIOSInit(VIAPtr pVia, ScrnInfoPtr pScrn, DisplayModePtr pMode)
{
    int i;
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIABIOSInit begin\n"));

    pBIOSInfo->bitsPerPixel = pScrn->bitsPerPixel;
    pBIOSInfo->displayWidth = pScrn->displayWidth;
    pBIOSInfo->IGA1SettingInfo.IsActive = FALSE;
    pBIOSInfo->IGA2SettingInfo.IsActive = FALSE;

    pBIOSInfo->Clock = pMode->Clock;
    pBIOSInfo->HTotal = pMode->HTotal;
    pBIOSInfo->VTotal = pMode->VTotal;
    pBIOSInfo->HDisplay = pMode->HDisplay;
    pBIOSInfo->VDisplay = pMode->VDisplay;
    pBIOSInfo->CrtcHDisplay = pMode->CrtcHDisplay;
    pBIOSInfo->CrtcVDisplay = pMode->CrtcVDisplay;

    if (pBIOSInfo->FirstInit) {
        pBIOSInfo->SaveHDisplay = pMode->HDisplay;
        pBIOSInfo->SaveVDisplay = pMode->VDisplay;
        pBIOSInfo->SaveVirtualX = pScrn->virtualX;
        pBIOSInfo->SaveVirtualY = pScrn->virtualY;
    }

    for (i = 0; i < 0xFF; i++) {
        pBIOSInfo->TVRegs[i] = pVia->SavedReg.TVRegs[i];
    }
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pBIOSInfo:bitsPerPixel=%d,displayWidth=%d,frameX1=%d,frameY1=%d\n",
        pBIOSInfo->bitsPerPixel, pBIOSInfo->displayWidth,
        pBIOSInfo->frameX1, pBIOSInfo->frameY1));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pMode:HTotal=%d,VTotal=%d,HDisplay=%d,VDisplay=%d\n",
        pMode->HTotal, pMode->VTotal, pMode->HDisplay, pMode->VDisplay));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pMode:,CrtcHDisplay=%d,CrtcVDisplay=%d\n", pMode->CrtcHDisplay,
        pMode->CrtcVDisplay));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIABIOSInit exit\n"));
}

static void
VIAPostFindMode(VIAPtr pVia, ScrnInfoPtr pScrn, DisplayModePtr pMode)
{
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int tmp = 0;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAPostFindMode begin\n"));
    /* For LCD panning Case */
    pScrn->frameX1 = pBIOSInfo->frameX1;
    pScrn->frameY1 = pBIOSInfo->frameY1;

    /* FAKE as RanR12 for XV noRandR rotation, exchange frameX1 and frameY1 */
    if ((pVia->RotateDegree == VIA_ROTATE_DEGREE_90) ||
        (pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
        tmp = pScrn->frameX1;
        pScrn->frameX1 = pScrn->frameY1;
        pScrn->frameY1 = tmp;
    }

    if (pBIOSInfo->ActualDesktopSizeX > pBIOSInfo->HDisplay)
        pMode->HDisplay = pBIOSInfo->HDisplay;
    else
        pMode->HDisplay = pBIOSInfo->ActualDesktopSizeX;

    if (pBIOSInfo->ActualDesktopSizeY > pBIOSInfo->VDisplay)
        pMode->VDisplay = pBIOSInfo->VDisplay;
    else
        pMode->VDisplay = pBIOSInfo->ActualDesktopSizeY;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pBIOSInfo: offsetWidthByQWord=%d,countWidthByQWord=%d\n",
        pBIOSInfo->offsetWidthByQWord, pBIOSInfo->countWidthByQWord));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pBIOSInfo:,frameX1=%d,frameY1=%d,HDisplay=%d,VDisplay=%d\n",
        pBIOSInfo->frameX1, pBIOSInfo->frameY1, pBIOSInfo->HDisplay,
        pBIOSInfo->VDisplay));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "pBIOSInfo:,ActualDesktopSizeX=%d,ActualDesktopSizeY=%d\n",
        pBIOSInfo->ActualDesktopSizeX, pBIOSInfo->ActualDesktopSizeY));

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAPostFindMode exit\n"));
}

void
VIACorrectModeList(ScrnInfoPtr pScrn)
{
    DisplayModePtr mode;

    for (mode = pScrn->modes;; mode = mode->next) {
        VIAGetModeSizeByName(mode->name, &mode->HDisplay, &mode->VDisplay);

        if (mode->next == pScrn->modes)
            break;               /* The end of mode list. */
    }
}

static Bool
VIAModeInit(ScrnInfoPtr pScrn, DisplayModePtr mode)
{
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    vgaRegPtr vganew = &hwp->ModeReg;
    Bool bRet;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAModeInit\n");

    /* Because we may update HDisplay/VDisplay of some mode for */
    /* panning issue in the previous mode setting, so we'd better restore them to fit */
    /* the real mode size first, or it may cause problems when that mode is not in use, */
    /* especially when the mode setting is called by RandR. */
    /* For example, CRT+DVI (panel size is 1280x1024), when we set to 1920x1080, this mode */
    /* will be dropped from RandR's mode list until we re-login X. */
    if (!pBIOSInfo->ModeLineStatus)
        VIACorrectModeList(pScrn);

    if (!vgaHWInit(pScrn, mode)) {
        vgaHWBlankScreen(pScrn, TRUE);
        return FALSE;
    }

    pScrn->vtSema = TRUE;

    if (!pVia->IsVIAModeInitRunOnceDone) {
        /* Just run once. */
        pVia->IsVIAModeInitRunOnceDone = TRUE;
    }

    VIABIOSInit(pVia, pScrn, mode);

    /* load utility user active device setting */
    /* We also need to load user settings in SAMM case, */
    /* so I move this call to here. */
    //VIALoadUserSetting(pBIOSInfo);

    if (!pVia->pVIAEnt->HasSecondary) {
        VIASetDisplayPath(pScrn);

    /* Check what type of cursor (SW/HW) to use. */
    VIACheckCursorTypeToUse(pScrn);
    }

    /* Set DuoView Video Output Device of S3Utility setting */
    VIALoadUserDuoViewVideoOutputDeviceSetting(pScrn);
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIALoadUserDuoViewVideoOutputDeviceSetting exit:TVtype=%d, TVScan=%d\n",
        pBIOSInfo->TVSettingInfo.TVType,
        pBIOSInfo->TVSettingInfo.TVVScan));

    if (!VIAFindModeUseBIOSTable(pScrn)) {
        vgaHWBlankScreen(pScrn, TRUE);
        return FALSE;
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIAFindModeUseBIOSTable exit:TVtype=%d, TVScan=%d\n",
        pBIOSInfo->TVSettingInfo.TVType,
        pBIOSInfo->TVSettingInfo.TVVScan));

    /* The post find mode information only tell the xorg core to do something
     * like panning and HW rotation, it is not necessary for RANDR architecture
     * moreover, this routine set the wrong scrn's viewport in randr case
     * which has already been correctly set by via_crtc_resize function.
     * The wrong viewport will cause wrong behavior of Xv/texture video
     * or anything else related to viewport
     */
#ifdef VIA_RANDR12_SUPPORT
    VIAPostFindMode(pVia, pScrn, mode);
#endif

    pBIOSInfo->IsStableStatus = FALSE;

    /* Enable CBU HW Rotate. */
    if (pVia->IsHWRotateEnabled)
        EnableCBUrotate(pScrn);

    /* Enable the graphics engine. */
    if (!pVia->NoAccel)
        VIAInitialize2DEngine(pScrn);

#ifdef XF86DRI
        VIAInitialize3DEngine(pScrn);
#endif

    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
    "VIAWriteMode exit:TVtype=%d, TVScan=%d\n",
    pBIOSInfo->TVSettingInfo.TVType, pBIOSInfo->TVSettingInfo.TVVScan);
    pBIOSInfo->IsStableStatus = TRUE;

    /* pass graphic info to via_v4l kernel module */
    /* Coz mode changes, some member in VIAGraphicInfo need to modify */
    if (pVia->useRandR) {
        FillGraphicInfo_New(pScrn);
    } 

    if (via_module_loaded) {
        TranslateGFXInfo(pScrn, pVia->pVIAEnt->pVidData->viaGfxInfo,
            &NEWVIAGraphicInfo);
        vvaInitVideo(pVia->FBBase, pVia->MapBase, &NEWVIAGraphicInfo);

        if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO))
            return FALSE;
    }

    pBIOSInfo->FirstInit = FALSE;

    VIAAdjustFrame(pScrn->scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);
    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
    "VIAModeInit exit:TVtype=%d, TVScan=%d\n",
    pBIOSInfo->TVSettingInfo.TVType, pBIOSInfo->TVSettingInfo.TVVScan);
    /* Insert a timer */
    if ((pVia->IsHotkeyTimerEnabled) && (!pVia->pVIAEnt->HasSecondary)) {
        if (!pVia->devicesTimer)
            pVia->devicesTimer = TimerSet(NULL, 0, 30, VIASyncTimer, pScrn);
        } else {
            if (pVia->devicesTimer) {
                TimerCancel(pVia->devicesTimer);
                pVia->devicesTimer = NULL;
        }
    }

    return TRUE;
}

static Bool
VIACloseScreen(int scrnIndex, ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    vgaRegPtr vgaSavePtr = &hwp->SavedReg;
    VIARegPtr viaSavePtr = &pVia->SavedReg;
    CARD32 dwCursorMode;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    int rotate_degree, i;

    if (pVia->devicesTimer)
        TimerCancel(pVia->devicesTimer);

    pVia->devicesTimer = NULL;

    xf86DrvMsg(scrnIndex, X_INFO, "VIACloseScreen\n");

    if (pVia->IsHWRotateEnabled) {
        DisableCBUrotate(pScrn);

        /* Disable CBU HW Rotate.
         * VX855 and VX900 rotation 90 and 270 degree probably has issue
         * but 180 degree doesn't have.
         * So here mimic the behavior of CBU 180
         * The root cause is still unknown.
         */
        if ((pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) &&
            (pVia->RotateDegree == VIA_ROTATE_DEGREE_90 ||
            pVia->RotateDegree == VIA_ROTATE_DEGREE_270)) {
            /* Mimic the behavior of rotate 180 */
            rotate_degree = pVia->RotateDegree;
            pVia->RotateDegree = VIA_ROTATE_DEGREE_180;
            EnableCBUrotate(pScrn);
            pVia->RotateDegree = rotate_degree;
            /* Let CBU 180 rotate take effect */
            memset(pVia->FBBase, 0x00,
                (pScrn->displayWidth * pScrn->bitsPerPixel >> 3));

            DisableCBUrotate(pScrn);
        }
    }

    /* For utility api */
    VIADisplayExtUnregister(pScrn);

    /*Turn off color cursor here */
    VIASETREG(PRIM_HI_CTRL, 0);
    VIASETREG(HI_CONTROL, 0);

    if (pScrn->vtSema) {
        /* Move exit video here if exitvideo after restore SR1A (PCI reset)
         * the V3 command fire may stick and caused system hang when playing video
         * Turn off all video activities */
        viaExitVideo(pScrn);
    }

    if (!pVia->IsSecondary) {
        if (via_module_loaded) {
            TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
            if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_XSERVEROFF))
                return FALSE;
        }

        /* clean viddata structure */

        /* Reset panning mode parameter */
        /*Modified for SAMM, Panning for Video XV rotate */
        for (i = 0; i < 2; i++) {
            pVidData->panning_x[i] = 0;
            pVidData->panning_y[i] = 0;
        }

        DEBUG(xf86DrvMsg(scrnIndex, X_INFO,
            "VIACloseScreen, NEWVIAGraphicInfo->dwXServerEnabled = FALSE\n"));
        viaGfxInfo->drmEnabled = FALSE;

        /* Diable Hardware Cursor */
        dwCursorMode = VIAGETREG(VIA_REG_CURSOR_MODE);
        VIASETREG(VIA_REG_CURSOR_MODE, dwCursorMode & 0xFFFFFFFE);
    }

    /* Wait Hardware Engine idle to exit graphic mode */
    WaitIdle();

    if ((pVia->VQEnable) && (pScrn->vtSema)) {
        /* if we use VQ, disable it before we exit */
        xf86DrvMsg(scrnIndex, X_INFO, "VIACloseScreen, VQ, disable \n");
        VIADisableVQ(pScrn);
    }

    if (pVia->HwCursorImage) {
        free(pVia->HwCursorImage);
        pVia->HwCursorImage = NULL;
    }

    if (pVia->HwIconImage) {
        free(pVia->HwIconImage);
        pVia->HwIconImage = NULL;
    }

    if (pVia->HIScalingPrimImage) {
        free(pVia->HIScalingPrimImage);
        pVia->HIScalingPrimImage = NULL;
    }

    if (pVia->HIScalingSecImage) {
        free(pVia->HIScalingSecImage);
        pVia->HIScalingSecImage = NULL;
    }

    if (pVia->CursorInfoRec) {
        xf86DestroyCursorInfoRec(pVia->CursorInfoRec);
        pVia->CursorInfoRec = NULL;
    }

    if (pVia->ShadowPtr) {
        free(pVia->ShadowPtr);
        pVia->ShadowPtr = NULL;
    }

    viaExitAccel(pScreen);

    if (pScrn->vtSema) {
        DEBUG(xf86DrvMsg(scrnIndex, X_INFO,
            "VIACloseScreen, pScrn->vtSema is true \n"));
        /* Clear Memory to avoid garbage */
        memset(pVia->pBIOSInfo->FBBase, 0x00, pVia->front_bo->size);

        if (!pVia->IsSecondary)
            VIARestore(pScrn, vgaSavePtr, viaSavePtr, FALSE);

        /* the following code can delete after using device save/restore Mechanism.
         * Because only HDMI use, we retain it. */
        if (pVia->Chipset == VIA_VX900) {
            Bool hasHdmi = FALSE;

            xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

            for (i = 0; i < xf86_config->num_output; i++) {
                xf86OutputPtr output = xf86_config->output[i];

                if (!xf86NameCmp(output->name, "HDMI")) {
                    hasHdmi = TRUE;
                }
            }

            for (i = 0; i < pVia->numIgnoredOutput; i++) {
                xf86OutputPtr output = pVia->ignoredOutput[i];

                if (!xf86NameCmp(output->name, "HDMI")) {
                    hasHdmi = TRUE;
                }
            }

            if (!hasHdmi) {
#if VIA_RANDR12_SUPPORT
                if (MMIO_RD(DP_EPHY_PLL_REG) & BIT0)
                    viaDPDisableEPHY();
                if (MMIO_RD(DP2_ENABLE_IF_REG) & BIT0)
                    viaDP2DisableEPHY();
#else
                if (MMIO_RD(DP_EPHY_PLL_REG) & BIT0)
                    VIADPDisableEPHY();
                if (MMIO_RD(DP2_ENABLE_IF_REG) & BIT0)
                    VIADP2DisableEPHY();
#endif
            }
        }
#if VIA_RANDR12_SUPPORT
        for (i = 0; i < pVia->numIgnoredOutput; i++) {
            xf86OutputPtr output = pVia->ignoredOutput[i];

            xf86OutputDestroy(output);
        }
#endif

        vgaHWLock(hwp);
        /*SAMM case, make sure MMIO only unmap once! */
        if (!pVia->IsSecondary)
            VIAUnmapMem(pScrn);
        else {
            if (pVia->FBBase) {
                pVia->FBBase = NULL;
            }
        }
        vgaHWUnmapMem(pScrn);
    }

    /* TODO
     * some console driver(e.x vesa fb) may overwrite
     * GART-table in VRAM.
     * patch this by save/restore gart-table by ourslef
     * No needs when using KMS
     */
    VIAGEMLeaveVT(pScrn);

    /*when log out X, if DRI is enabled, the DRI resource should be cleaned up */
    if (pVia->driType == DRI_1
#ifdef DRM_SAMM_VIA
        || pVia->drmSammEnabled
#endif
        ) {
        VIADRICloseScreen(pScreen);
    }
    /* For MAMM */
    if (!pVia->IsMAMMEnable) {
        if (pVia->pInt10) {
            xf86FreeInt10(pVia->pInt10);
            pVia->pInt10 = NULL;
        }
    }

    if (!pVia->IsSecondary) {
        /* delete the memory of VidData */
        if (pVia->pVIAEnt->pVidData) {
            if (pVia->pVIAEnt->pVidData->viaGfxInfo) {
                free((void *)pVia->pVIAEnt->pVidData->viaGfxInfo);
                pVia->pVIAEnt->pVidData->viaGfxInfo = NULL;
            }
            free((void *)pVia->pVIAEnt->pVidData);
            pVia->pVIAEnt->pVidData = NULL;
        }
    }

    pVia->IsVIAModeInitRunOnceDone = FALSE;
    pScrn->vtSema = FALSE;
    pScreen->CloseScreen = pVia->CloseScreen;
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
    (*pScreen->CloseScreen) (scrnIndex, pScreen);
#else
	(*pScreen->CloseScreen) (pScreen);
#endif
    /* deconstruction bo management */
    via_bo_bufmgr_decon(pVia->bufmgr);
    return TRUE;
}

/*
 * This only gets called when a screen is being deleted.  It does not
 * get called routinely at the end of a server generation.
 */
static void
VIAFreeScreen(int scrnIndex, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);

    xf86DrvMsg(scrnIndex, X_INFO, "VIAFreeScreen\n");

    if (xf86LoaderCheckSymbol("vgaHWFreeHWRec"))
        vgaHWFreeHWRec(pScrn);

    /*SAMM case, make sure MMIO only unmap once! */
    if (!pVia->IsSecondary) {
        /* delete the memory of VidData */
        if (pVia->pVIAEnt->pVidData) {
            if (pVia->pVIAEnt->pVidData->viaGfxInfo) {
                free((void *)pVia->pVIAEnt->pVidData->viaGfxInfo);
                pVia->pVIAEnt->pVidData->viaGfxInfo = NULL;
            }
            free((void *)pVia->pVIAEnt->pVidData);
            pVia->pVIAEnt->pVidData = NULL;
        }
        VIAUnmapMem(pScrn);
    } else {
        if (pVia->FBBase) {
            pVia->FBBase = NULL;
        }
    }

    VIAFreeRec(pScrn);
}

static Bool
VIASaveScreen(ScreenPtr pScreen, int mode)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    Bool on;

    on = xf86IsUnblank(mode);

    if (on) {
        EnableSecondDisplayChannel();
        /*Enable IGA2 input data */
        switch (pVia->Chipset) {
        case VIA_P4M800PRO:
        case VIA_K8M890:
        case VIA_P4M890:
        case VIA_P4M900:
            write_reg_mask(CR91, VIACR, 0x00, BIT5);
            break;
        case VIA_CX700:
        case VIA_VX800:
        case VIA_VX855:
        case VIA_VX900:
            write_reg_mask(CR6B, VIACR, 0x00, BIT2);
            break;
        default:
            write_reg_mask(CR91, VIACR, 0x00, BIT5);
            break;
        }
    } else {
        /*Disable IGA2 input data */
        switch (pVia->Chipset) {
        case VIA_P4M800PRO:
        case VIA_K8M890:
        case VIA_P4M890:
        case VIA_P4M900:
            write_reg_mask(CR91, VIACR, BIT5, BIT5);
            break;
        case VIA_CX700:
        case VIA_VX800:
        case VIA_VX855:
        case VIA_VX900:
            write_reg_mask(CR6B, VIACR, BIT2, BIT2);
            break;
        default:
            write_reg_mask(CR91, VIACR, BIT5, BIT5);
            break;
        }
        DisableSecondDisplayChannel();
    }

    return vgaHWSaveScreen(pScreen, mode);
}

/* This function for tuning XY position in xorg to position in on_screen.
   Only rotation need to care about this.*/
static void
TuneXYToOnScreenXY(ScrnInfoPtr pScrn, int *x, int *y)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    int tmpx = *x, tmpy = *y;

    /* All the rotation cases need to be coverd here.Maybe not all the cases
     * have been coverd,
     * one can add some cases if necessary */
    if (!pVia->RotateDegree)
        return;

    /* rotation exist. to calculate the x y position according to the
       position in xorg. */
    if (pVia->RotateDegree == VIA_ROTATE_DEGREE_90) {
        /* ex: 1600x1200 at 1680x1050 monitor */
        if ((pBIOSInfo->VirtualX < pBIOSInfo->HDisplay) &&
            (pBIOSInfo->VirtualY > pBIOSInfo->VDisplay)) {
            *x = 0;
            *y = tmpx;
        } else {
            *x = pBIOSInfo->VirtualX - tmpy - pBIOSInfo->HDisplay;
            *y = tmpx;
        }
    } else if (pVia->RotateDegree == VIA_ROTATE_DEGREE_270) {
        /* ex:1920x1080 at 1600x1200 monitor */
        if ((pBIOSInfo->VirtualX > pBIOSInfo->HDisplay) &&
            (pBIOSInfo->VirtualY < pBIOSInfo->VDisplay)) {
            *x = tmpy;
            *y = 0;
        } else {
            *x = tmpy;
            *y = pBIOSInfo->VirtualY - tmpx - pBIOSInfo->VDisplay;
        }
    } else if (pVia->RotateDegree == VIA_ROTATE_DEGREE_180) {
        /* ex: 1600x1200 at 1680x1050 monitor */
        if ((pBIOSInfo->VirtualX < pBIOSInfo->HDisplay) &&
            (pBIOSInfo->VirtualY > pBIOSInfo->VDisplay)) {
            *x = 0;
            *y = pBIOSInfo->VirtualY - tmpy - pBIOSInfo->VDisplay;
            /* ex:1920x1080 at 1600x1200 monitor */
        } else if ((pBIOSInfo->VirtualX > pBIOSInfo->HDisplay) &&
            (pBIOSInfo->VirtualY < pBIOSInfo->VDisplay)) {
            *x = pBIOSInfo->VirtualX - tmpx - pBIOSInfo->HDisplay;
            *y = 0;
        } else {
            *x = pBIOSInfo->VirtualX - tmpx - pBIOSInfo->HDisplay;
            *y = pBIOSInfo->VirtualY - tmpy - pBIOSInfo->VDisplay;
        }
    }
    return;
}

void
VIARandR12UpdateOverlay(int scrnIndex, int x, int y, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    int i = 0;
    int ret;
    viaPortPrivPtr pPriv = NULL;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    for (i = XV_PORT_NUM_OVERLAY - 1; i >= 0; i--) {
        if (pVia->pPriv[i] != NULL) {
            if (pVia->pPriv[i]->curIGA != 0) {
                pPriv = pVia->pPriv[i];

                if (pPriv->scrnAttr != viaGfxInfo->screenAttr.uint) {
                    pPriv->forceEngReAlloc = TRUE;
                    if (pPriv->videoFlag & VIDEO_ACTIVE) {
                        viaPutImageG(pScrn, pPriv->src_x, pPriv->src_y,
                            pPriv->drw_x, pPriv->drw_y, pPriv->src_w,
                            pPriv->src_h, pPriv->drw_w, pPriv->drw_h,
                            pPriv->fourCC, pPriv->buf, pPriv->width,
                            pPriv->height, pPriv->sync, &pPriv->clip, pPriv,
                            pPriv->pDraw);
                    }
                } else {
                    pPriv->forceUpdate = TRUE;
                }
            }
        }
    }

    if (via_module_loaded)
        vvaUpdateOverlay(scrnIndex, x, y);

    return;
}

void
VIAAdjustFrame(int scrnIndex, int x, int y, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;
    viaPortPrivPtr pPriv;
    int i = 0;
    int ret;
    unsigned long curIGA = 0;

    DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIAAdjustFrame\n"));

    if (x < 0 || y < 0)
        return;

    /* Patch for Duoview panning cases:
     * The panning_x[], panning_y[] are indexed by Iga Index. */
    /* Unifiy the process of panning_x[], panning_y[] for all case: single, duoview and samm. */
    if (viaGfxInfo->screenInfo[scrnIndex].igaInuse & IGA1) {
        if (viaGfxInfo->igaInfo[0].igaStatus.panning) {
            viaGfxInfo->igaInfo[0].start_x = x;
            viaGfxInfo->igaInfo[0].start_y = y;
            /* Restrict the patch for non-randr samm path only. */
            if (!viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m1.samm) {
                if (viaGfxInfo->igaAttr.iga2_left) {
                    viaGfxInfo->igaInfo[0].start_x =
                        viaGfxInfo->igaInfo[1].visible_width + x;
                }
                if (viaGfxInfo->igaAttr.iga2_above) {
                    viaGfxInfo->igaInfo[0].start_y =
                        viaGfxInfo->igaInfo[1].visible_height + y;
                }
            }
            pVidData->panning_x[0] = x;
            pVidData->panning_y[0] = y;
        }
    }

    if (viaGfxInfo->screenInfo[scrnIndex].igaInuse & IGA2) {
        if (viaGfxInfo->igaInfo[1].igaStatus.panning) {
            viaGfxInfo->igaInfo[1].start_x = x;
            viaGfxInfo->igaInfo[1].start_y = y;
            /* Restrict the patch for non-randr samm path only. */
            if (!viaGfxInfo->xrandrEnabled && viaGfxInfo->screenAttr.m1.samm) {
                if (viaGfxInfo->igaAttr.iga2_right) {
                    viaGfxInfo->igaInfo[1].start_x =
                        viaGfxInfo->igaInfo[0].visible_width + x;
                }
                if (viaGfxInfo->igaAttr.iga2_below) {
                    viaGfxInfo->igaInfo[1].start_y =
                        viaGfxInfo->igaInfo[0].visible_height + y;
                }
            }
            pVidData->panning_x[1] = x;
            pVidData->panning_y[1] = y;
        }
    }

    for (i = XV_PORT_NUM_OVERLAY - 1; i >= 0; i--) {

        if (pVia->pPriv[i] != NULL) {

            if (pVia->pPriv[i]->curIGA != 0) {
                pPriv = pVia->pPriv[i];

                if (pPriv->videoFlag & VIDEO_ACTIVE) {
                    determineCurrentIGAInUse(pScrn, &curIGA, x, y);

                    if (curIGA == pPriv->curIGA) {
                        viaPutImageG(pScrn, pPriv->src_x, pPriv->src_y,
                            pPriv->drw_x, pPriv->drw_y, pPriv->src_w,
                            pPriv->src_h, pPriv->drw_w, pPriv->drw_h,
                            pPriv->fourCC, pPriv->buf, pPriv->width,
                            pPriv->height, pPriv->sync, &pPriv->clip, pPriv,
                            pPriv->pDraw);
                    }
                }
            }
        }
    }

    if (via_module_loaded)
        vvaUpdateOverlay(scrnIndex, x, y);

    return;
}

Bool
VIASwitchMode(int scrnIndex, DisplayModePtr mode, int flags)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    ServerInfoPtr pServerInfo = pVia->pServerInfo;
    int width, height;

    width = mode->HDisplay;
    height = mode->VDisplay;

#ifdef VIA_RANDR12_SUPPORT
        DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "VIASwitchMode\n"));
        DEBUG(xf86DrvMsg(scrnIndex, X_INFO, "xf86SetSingleMode\n"));

        return xf86SetSingleMode(pScrn, mode, RR_Rotate_0);
#endif

}

static void
VIAPreSaveReg(ScrnInfoPtr pScrn)
{
    static int IsSaved = FALSE;
    VIAPtr pVia = VIAPTR(pScrn);
    VIARegPtr save = &pVia->SavedReg;

    /* To fix the problem: In SAMM, the system will hang when suspends.
     * (On VT3364) In VIAEnableMMIO(), it will enable software reset of
     * SR1A, so the value of SR1A we saved is not the original value set
     * by BIOS, and we found that it will cause system hang when restore
     * registers in VIALeaveVT(). In order to keep the original value set
     * by BIOS, we should save SR1A before doing VIAEnableMMIO() to avoid
     * this problem. So, we move the saving code from VIASave() to here.
     */
    if (!IsSaved) {
        VGAOUT8(0x3d4, CR08);
        save->CRTCRegs[0x08] = VGAIN8(0x3d5);
        VGAOUT8(0x3d4, CR09);
        save->CRTCRegs[0x09] = VGAIN8(0x3d5);
        VGAOUT8(0x3C4, SR1A);
        save->SRRegs[0x1A] = VGAIN8(0x3C5);

        IsSaved = TRUE;
    }
}

void
VIAEnableMMIO(ScrnInfoPtr pScrn)
{
    vgaHWPtr hwp = VGAHWPTR(pScrn);
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    unsigned char val;

    /* If we are primary card, we still use std vga port. If we use
     * MMIO, system will hang in vgaHWSave when our card used in
     * PLE and KLE (integrated Trident MVP4)
     */
    if (!pVia->IsMAMMEnable) {
        vgaHWSetStdFuncs(hwp);
    } else {
        vgaHWSetMmioFuncs(hwp, pVia->MapBase, 0x8000);
    }

    val = VGAIN8(0x3c3);
    VGAOUT8(0x3c3, val | 0x01);
    val = VGAIN8(VGA_MISC_OUT_R);
    VGAOUT8(VGA_MISC_OUT_W, val | 0x01);

    /* Unlock Extended IO Space */
    VGAOUT8(0x3c4, 0x10);
    VGAOUT8(0x3c5, 0x01);
    /* Unlock CRTC register protect */
    VGAOUT8(0x3d4, 0x47);
    if (VIAGetChipsetRevisionID() >= REVISION_VX855_A1) {
        VGAOUT8(0x3d5, VGAIN8(0x3d5) & ~0x10);
    } else {
        VGAOUT8(0x3d5, VGAIN8(0x3d5) & ~0x01);
    }

    /* Save some important register before we change its value */
    VIAPreSaveReg(pScrn);

    /* Enable MMIO */
    if (pVia->IsSecondary) {
        VGAOUT8(0x3c4, 0x1a);
        val = VGAIN8(0x3c5);
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "secondary val = %x\n",
            val));
        VGAOUT8(0x3c5, val | 0x38);
    }
    return;
}

void
VIALoadPalette(ScrnInfoPtr pScrn, int numColors, int *indicies,
    LOCO *colors, VisualPtr pVisual)
{
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->useRandR) {
#ifdef VIA_RANDR12_SUPPORT
        xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
        int i, j, index, k;
        unsigned short lut_r[256], lut_g[256], lut_b[256];

        for (k = 0; k < xf86_config->num_crtc; k++) {
            xf86CrtcPtr crtc = xf86_config->crtc[k];
            VIACrtcPrivatePtr viaCrtc = VIACrtcPrivate(crtc);

            /* Initialize to the old lookup table values. */
            for (i = 0; i < 256; i++) {
                lut_r[i] = viaCrtc->colors[i].red << 8;
                lut_g[i] = viaCrtc->colors[i].green << 8;
                lut_b[i] = viaCrtc->colors[i].blue << 8;
            }

            switch (pScrn->depth) {
            case 15:
                for (i = 0; i < numColors; i++) {
                    index = indicies[i];
                    for (j = 0; j < 8; j++) {
                        lut_r[index * 8 + j] = colors[index].red << 8;
                        lut_g[index * 8 + j] = colors[index].green << 8;
                        lut_b[index * 8 + j] = colors[index].blue << 8;
                    }
                }
                break;
            case 16:
                for (i = 0; i < numColors; i++) {
                    index = indicies[i];

                    if (index <= 31) {
                        for (j = 0; j < 8; j++) {
                            lut_r[index * 8 + j] = colors[index].red << 8;
                            lut_b[index * 8 + j] = colors[index].blue << 8;
                        }
                    }

                    for (j = 0; j < 4; j++) {
                        lut_g[index * 4 + j] = colors[index].green << 8;
                    }
                }
                break;
            default:
                for (i = 0; i < numColors; i++) {
                    index = indicies[i];
                    lut_r[index] = colors[index].red << 8;
                    lut_g[index] = colors[index].green << 8;
                    lut_b[index] = colors[index].blue << 8;
                }
                break;
            }

            /* Make the change through RandR */
#ifdef RANDR_12_INTERFACE
            RRCrtcGammaSet(crtc->randr_crtc, lut_r, lut_g, lut_b);
#else /*RANDR_12_INTERFACE */
            crtc->funcs->gamma_set(crtc, lut_r, lut_g, lut_b, 256);
#endif
        }
#endif /*VIA_RANDR12_SUPPORT */
    } 
}

/* SAMM device dispatch */
Bool
VIASetDisplayPath_SAMM(ScrnInfoPtr pScrn)
{

    VIAPtr pVia1 = VIAPTR(pScrn);
    VIAPtr pVia0 = VIAPTR(pVia1->pVIAEnt->pPrimaryScrn);
    VIABIOSInfoPtr pBIOSInfo1 = pVia1->pBIOSInfo;
    VIABIOSInfoPtr pBIOSInfo0 = pVia0->pBIOSInfo;

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIASetDisplayPath_SAMM\n"));
    pBIOSInfo1->PrimaryDevice = pBIOSInfo0->PrimaryDevice;

    DEBUG(xf86DrvMsg(pVia0->pVIAEnt->pPrimaryScrn->scrnIndex, X_INFO,
        "Primary: CRT=%d, TV=%d, DFP=%d, LCD=%d, HDMI=%d, DP=%d\n",
        pBIOSInfo0->CRTSettingInfo.IGAPath,
        pBIOSInfo0->TVSettingInfo.IGAPath,
        pBIOSInfo0->TMDSSettingInfo.IGAPath,
        pBIOSInfo0->LVDSSettingInfo.IGAPath,
        pBIOSInfo0->HDMISettingInfo.IGAPath,
        pBIOSInfo0->DPSettingInfo.IGAPath));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "Secondary: CRT=%d, TV=%d, DFP=%d, LCD=%d, HDMI=%d, DP=%d\n",
        pBIOSInfo1->CRTSettingInfo.IGAPath,
        pBIOSInfo1->TVSettingInfo.IGAPath,
        pBIOSInfo1->TMDSSettingInfo.IGAPath,
        pBIOSInfo1->LVDSSettingInfo.IGAPath,
        pBIOSInfo1->HDMISettingInfo.IGAPath,
        pBIOSInfo1->DPSettingInfo.IGAPath));

    return TRUE;
}

Bool
VIASetDisplayPath(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    Bool ret = TRUE;

    VIACheckIfUseDuoView(pScrn);

    if (pVia->IsSecondary) {
        /* SAMM: */
        if (pVia->pVIAEnt->HasSecondary) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "VIASetDisplayPath is SAMM\n");
            ret = VIASetDisplayPath_SAMM(pScrn);
        }
    } else if (pBIOSInfo->DuoView) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "VIASetDisplayPath is DuoView\n");
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIASetDisplayPath is Single\n");
        /* Simultaneous: */
        pBIOSInfo->CRTSettingInfo.IGAPath = IGA1;
        pBIOSInfo->TVSettingInfo.IGAPath = IGA1;
        pBIOSInfo->TMDSSettingInfo.IGAPath = IGA1;
        pBIOSInfo->TMDSSettingInfo2.IGAPath = IGA1;
        pBIOSInfo->DPSettingInfo.IGAPath = IGA1;
        pBIOSInfo->DPSettingInfo2.IGAPath = IGA1;
        pBIOSInfo->LVDSSettingInfo.IGAPath = IGA2;
        pBIOSInfo->LVDSSettingInfo2.IGAPath = IGA2;
        pBIOSInfo->HDMISettingInfo.IGAPath = IGA2;
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "IGA: CRT=%d, TV=%d, DFP=%d, LCD=%d, HDMI=%d, HDMI2=%d, DP=%d, DP2=%d\n",
        pBIOSInfo->CRTSettingInfo.IGAPath,
        pBIOSInfo->TVSettingInfo.IGAPath,
        pBIOSInfo->TMDSSettingInfo.IGAPath,
        pBIOSInfo->LVDSSettingInfo.IGAPath,
        pBIOSInfo->HDMISettingInfo.IGAPath,
        pBIOSInfo->HDMISettingInfo2.IGAPath,
        pBIOSInfo->DPSettingInfo.IGAPath,
        pBIOSInfo->DPSettingInfo2.IGAPath));

    return ret;
}

void
VIAInitialize3DEngine(ScrnInfoPtr pScrn)
{

#ifndef CS_FLAG_NO_3D_SCAL
    VIAPtr pVia = VIAPTR(pScrn);
    int i;
    DWORD StageOfTexture;

    WaitIdle();
    /*
     * read CR32 for the suspend or resume information
     * Bit 7:1 work from suspend
     *       0 work normally
     */
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "into 3D initial...3Dinitial? %d\n",
    b3DRegsInitialized);
    if (H5_UMA_CHIPID) {
        VIASETREG(0x43C, 0x00010000);

        for (i = 0; i <= 0x8A; i++)
            VIASETREG(0x440, (CARD32) i << 24);

        /* Initial Texture Stage Setting */
        for (StageOfTexture = 0; StageOfTexture < 0xf; StageOfTexture++) {
            VIASETREG(0x43C,
            (0x00020000 | 0x00000000 | (StageOfTexture & 0xf) << 24));
            for (i = 0; i <= 0x30; i++)
                VIASETREG(0x440, (CARD32) i << 24);
        }

        /* Initial Texture Sampler Setting */
        for (StageOfTexture = 0; StageOfTexture < 0xf; StageOfTexture++) {
            VIASETREG(0x43C,
            (0x00020000 | 0x00020000 | (StageOfTexture & 0xf) << 24));
            for (i = 0; i <= 0x30; i++)
                VIASETREG(0x440, (CARD32) i << 24);
        }

        VIASETREG(0x43C, (0x00020000 | 0xfe000000));
        for (i = 0; i <= 0x13; i++)
            VIASETREG(0x440, (CARD32) i << 24);

        /* Initial Gamma Table Setting */
        /* Initial Gamma Table Setting */
        /* 5 + 4 = 9 (12) dwords */
        /* sRGB texture is not directly support by H3 hardware. */
        /* We have to set the deGamma table for texture sampling. */

        /* degamma table */
        VIASETREG(0x43C, (0x00030000 | 0x15000000));
        VIASETREG(0x440, (0x40000000 | (30 << 20) | (15 << 10) | (5)));
        VIASETREG(0x440, ((119 << 20) | (81 << 10) | (52)));
        VIASETREG(0x440, ((283 << 20) | (219 << 10) | (165)));
        VIASETREG(0x440, ((535 << 20) | (441 << 10) | (357)));
        VIASETREG(0x440, ((119 << 20) | (884 << 20) | (757 << 10) | (640)));

        /* gamma table */
        VIASETREG(0x43C, (0x00030000 | 0x17000000));
        VIASETREG(0x440, (0x40000000 | (13 << 20) | (13 << 10) | (13)));
        VIASETREG(0x440, (0x40000000 | (26 << 20) | (26 << 10) | (26)));
        VIASETREG(0x440, (0x40000000 | (39 << 20) | (39 << 10) | (39)));
        VIASETREG(0x440, ((51 << 20) | (51 << 10) | (51)));
        VIASETREG(0x440, ((71 << 20) | (71 << 10) | (71)));
        VIASETREG(0x440, (87 << 20) | (87 << 10) | (87));
        VIASETREG(0x440, (113 << 20) | (113 << 10) | (113));
        VIASETREG(0x440, (135 << 20) | (135 << 10) | (135));
        VIASETREG(0x440, (170 << 20) | (170 << 10) | (170));
        VIASETREG(0x440, (199 << 20) | (199 << 10) | (199));
        VIASETREG(0x440, (246 << 20) | (246 << 10) | (246));
        VIASETREG(0x440, (284 << 20) | (284 << 10) | (284));
        VIASETREG(0x440, (317 << 20) | (317 << 10) | (317));
        VIASETREG(0x440, (347 << 20) | (347 << 10) | (347));
        VIASETREG(0x440, (373 << 20) | (373 << 10) | (373));
        VIASETREG(0x440, (398 << 20) | (398 << 10) | (398));
        VIASETREG(0x440, (442 << 20) | (442 << 10) | (442));
        VIASETREG(0x440, (481 << 20) | (481 << 10) | (481));
        VIASETREG(0x440, (517 << 20) | (517 << 10) | (517));
        VIASETREG(0x440, (550 << 20) | (550 << 10) | (550));
        VIASETREG(0x440, (609 << 20) | (609 << 10) | (609));
        VIASETREG(0x440, (662 << 20) | (662 << 10) | (662));
        VIASETREG(0x440, (709 << 20) | (709 << 10) | (709));
        VIASETREG(0x440, (753 << 20) | (753 << 10) | (753));
        VIASETREG(0x440, (794 << 20) | (794 << 10) | (794));
        VIASETREG(0x440, (832 << 20) | (832 << 10) | (832));
        VIASETREG(0x440, (868 << 20) | (868 << 10) | (868));
        VIASETREG(0x440, (902 << 20) | (902 << 10) | (902));
        VIASETREG(0x440, (934 << 20) | (934 << 10) | (934));
        VIASETREG(0x440, (966 << 20) | (966 << 10) | (966));
        VIASETREG(0x440, (996 << 20) | (996 << 10) | (996));

        /* For Interrupt Restore only
         * All types of write through regsiters should be write header data to
         * hardware at least before it can restore. H/W will automatically record
         * the header to write through state buffer for resture usage.
         * By Jaren:
         * HParaType = 8'h03, HParaSubType = 8'h00
         * 8'h11
         * 8'h12
         * 8'h14
         * 8'h15
         * 8'h17
         * HParaSubType 8'h12, 8'h15 is initialized.
         * [HWLimit]
         * 1. All these write through registers can't be partial update.
         * 2. All these write through must be AGP command
         * 16 entries : 4 128-bit data */

        /* Initialize INV_ParaSubType_TexPal    */
        VIASETREG(0x43C, (0x00030000 | 0x00000000));
        for (i = 0; i < 16; i++)
            VIASETREG(0x440, 0x00000000);

        /* Initialize INV_ParaSubType_4X4Cof */
        /* 32 entries : 8 128-bit data */
        VIASETREG(0x43C, (0x00030000 | 0x11000000));
        for (i = 0; i < 32; i++)
            VIASETREG(0x440, 0x00000000);

        /* Initialize INV_ParaSubType_StipPal */
        /* 5 entries : 2 128-bit data */
        VIASETREG(0x43C, (0x00030000 | 0x14000000));
        for (i = 0; i < (5 + 3); i++)
            VIASETREG(0x440, 0x00000000);

        /* primitive setting & vertex format */
        VIASETREG(0x43C, (0x00040000 | 0x14000000));
        for (i = 0; i < 52; i++)
            VIASETREG(0x440, ((DWORD) i << 24));
#if 1
        VIASETREG(0x43C, 0x00fe0000);
        VIASETREG(0x440, 0x4000840f);
        VIASETREG(0x440, 0x47000400);
        VIASETREG(0x440, 0x44000000);
        VIASETREG(0x440, 0x46000000);
#endif
        b3DRegsInitialized = 1;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "H5 3D Engine has been initilized.\n");
        /* setting Misconfig */
        VIASETREG(0x43C, 0x00fe0000);
        VIASETREG(0x440, 0x00001004);
        VIASETREG(0x440, 0x0800004b);
        VIASETREG(0x440, 0x0a000049);
        VIASETREG(0x440, 0x0b0000fb);
        VIASETREG(0x440, 0x0c000001);
        VIASETREG(0x440, 0x0d0000cb);
        VIASETREG(0x440, 0x0e000009);
        VIASETREG(0x440, 0x10000000);
        VIASETREG(0x440, 0x110000ff);
        VIASETREG(0x440, 0x12000000);
        VIASETREG(0x440, 0x130000db);
        VIASETREG(0x440, 0x14000000);
        VIASETREG(0x440, 0x15000000);
        VIASETREG(0x440, 0x16000000);
        VIASETREG(0x440, 0x17000000);
        VIASETREG(0x440, 0x18000000);
        VIASETREG(0x440, 0x19000000);
        VIASETREG(0x440, 0x20000000);
    } else if (H6_UMA_CHIPID) {
        VIASETREG(0x43C, 0x00010000);
        for (i = 0; i <= 0x9A; i++)
            VIASETREG(0x440, (CARD32) i << 24);
        /* guadband clipping default setting */
        VIASETREG(0x440, (CARD32) ((0x88 << 24) | 0x00001ed0));
        VIASETREG(0x440, (CARD32) ((0x89 << 24) | 0x00000800));

        /* Initial Texture Stage Setting */
        for (StageOfTexture = 0; StageOfTexture <= 0xf; StageOfTexture++) {
            VIASETREG(0x43C,
            (0x00020000 | 0x00000000 | (StageOfTexture & 0xf) << 24));
            for (i = 0; i <= 0x30; i++)
                VIASETREG(0x440, (CARD32) i << 24);
        }

        /* Initial Texture Sampler Setting */
        for (StageOfTexture = 0; StageOfTexture <= 0xf; StageOfTexture++) {
            VIASETREG(0x43C,
            (0x00020000 | 0x20000000 | (StageOfTexture & 0xf) << 24));
            for (i = 0; i <= 0x36; i++)
                VIASETREG(0x440, (CARD32) i << 24);
        }

        VIASETREG(0x43C, (0x00020000 | 0xfe000000));
        for (i = 0; i <= 0x13; i++)
            VIASETREG(0x440, (CARD32) i << 24);

        /* Initial Gamma Table Setting */
        /* Initial Gamma Table Setting */
        /* 5 + 4 = 9 (12) dwords */
        /* sRGB texture is not directly support by H3 hardware. */
        /* We have to set the deGamma table for texture sampling. */

        /* degamma table */
        VIASETREG(0x43C, (0x00030000 | 0x15000000));
        VIASETREG(0x440, (0x40000000 | (30 << 20) | (15 << 10) | (5)));
        VIASETREG(0x440, ((119 << 20) | (81 << 10) | (52)));
        VIASETREG(0x440, ((283 << 20) | (219 << 10) | (165)));
        VIASETREG(0x440, ((535 << 20) | (441 << 10) | (357)));
        VIASETREG(0x440, ((119 << 20) | (884 << 20) | (757 << 10) | (640)));

        /* gamma table */
        VIASETREG(0x43C, (0x00030000 | 0x17000000));
        VIASETREG(0x440, (0x40000000 | (13 << 20) | (13 << 10) | (13)));
        VIASETREG(0x440, (0x40000000 | (26 << 20) | (26 << 10) | (26)));
        VIASETREG(0x440, (0x40000000 | (39 << 20) | (39 << 10) | (39)));
        VIASETREG(0x440, ((51 << 20) | (51 << 10) | (51)));
        VIASETREG(0x440, ((71 << 20) | (71 << 10) | (71)));
        VIASETREG(0x440, (87 << 20) | (87 << 10) | (87));
        VIASETREG(0x440, (113 << 20) | (113 << 10) | (113));
        VIASETREG(0x440, (135 << 20) | (135 << 10) | (135));
        VIASETREG(0x440, (170 << 20) | (170 << 10) | (170));
        VIASETREG(0x440, (199 << 20) | (199 << 10) | (199));
        VIASETREG(0x440, (246 << 20) | (246 << 10) | (246));
        VIASETREG(0x440, (284 << 20) | (284 << 10) | (284));
        VIASETREG(0x440, (317 << 20) | (317 << 10) | (317));
        VIASETREG(0x440, (347 << 20) | (347 << 10) | (347));
        VIASETREG(0x440, (373 << 20) | (373 << 10) | (373));
        VIASETREG(0x440, (398 << 20) | (398 << 10) | (398));
        VIASETREG(0x440, (442 << 20) | (442 << 10) | (442));
        VIASETREG(0x440, (481 << 20) | (481 << 10) | (481));
        VIASETREG(0x440, (517 << 20) | (517 << 10) | (517));
        VIASETREG(0x440, (550 << 20) | (550 << 10) | (550));
        VIASETREG(0x440, (609 << 20) | (609 << 10) | (609));
        VIASETREG(0x440, (662 << 20) | (662 << 10) | (662));
        VIASETREG(0x440, (709 << 20) | (709 << 10) | (709));
        VIASETREG(0x440, (753 << 20) | (753 << 10) | (753));
        VIASETREG(0x440, (794 << 20) | (794 << 10) | (794));
        VIASETREG(0x440, (832 << 20) | (832 << 10) | (832));
        VIASETREG(0x440, (868 << 20) | (868 << 10) | (868));
        VIASETREG(0x440, (902 << 20) | (902 << 10) | (902));
        VIASETREG(0x440, (934 << 20) | (934 << 10) | (934));
        VIASETREG(0x440, (966 << 20) | (966 << 10) | (966));
        VIASETREG(0x440, (996 << 20) | (996 << 10) | (996));

        /* For Interrupt Restore only
         * All types of write through regsiters should be write header data to
         * hardware at least before it can restore. H/W will automatically record
         * the header to write through state buffer for resture usage.
         * By Jaren:
         * HParaType = 8'h03, HParaSubType = 8'h00
         * 8'h11
         * 8'h12
         * 8'h14
         * 8'h15
         * 8'h17
         * HParaSubType 8'h12, 8'h15 is initialized.
         * [HWLimit]
         * 1. All these write through registers can't be partial update.
         * 2. All these write through must be AGP command
         * 16 entries : 4 128-bit data */

        /* Initialize INV_ParaSubType_TexPal    */
        VIASETREG(0x43C, (0x00030000 | 0x00000000));
        for (i = 0; i < 16; i++)
            VIASETREG(0x440, 0x00000000);

        /* Initialize INV_ParaSubType_4X4Cof */
        /* 32 entries : 8 128-bit data */
        VIASETREG(0x43C, (0x00030000 | 0x11000000));
        for (i = 0; i < 32; i++)
            VIASETREG(0x440, 0x00000000);

        /* Initialize INV_ParaSubType_StipPal */
        /* 5 entries : 2 128-bit data */
        VIASETREG(0x43C, (0x00030000 | 0x14000000));
        for (i = 0; i < (5 + 3); i++)
            VIASETREG(0x440, 0x00000000);

        /* primitive setting & vertex format */
        VIASETREG(0x43C, (0x00040000));
        for (i = 0; i <= 0x62; i++)
            VIASETREG(0x440, ((DWORD) i << 24));
        /* c2s clampping value for screen coordinates
         * default setting */
        VIASETREG(0x440, (DWORD) ((0x50 << 24) | 0x00000000));
        VIASETREG(0x440, (DWORD) ((0x51 << 24) | 0x00000000));
        VIASETREG(0x440, (DWORD) ((0x52 << 24) | 0x00147fff));

        /*ParaType 0xFE - Configure and Misc Setting */
        VIASETREG(0x43C, (0x00fe0000));
        for (i = 0; i <= 0x47; i++)
            VIASETREG(0x440, ((DWORD) i << 24));

        /*ParaType 0x11 - Frame Buffer Auto-Swapping and
         * Command Regulator Misc */
        VIASETREG(0x43C, (0x00110000));
        for (i = 0; i <= 0x20; i++)
            VIASETREG(0x440, ((DWORD) i << 24));

#if 1
        VIASETREG(0x43C, 0x00fe0000);
        VIASETREG(0x440, 0x4000840f);
        VIASETREG(0x440, 0x47000404);
        VIASETREG(0x440, 0x44000000);
        VIASETREG(0x440, 0x46000005);
#endif
        b3DRegsInitialized = 1;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "H6 3D Engine has been initilized.\n");
        /* setting Misconfig */
        VIASETREG(0x43C, 0x00fe0000);
        VIASETREG(0x440, 0x00001004);
        VIASETREG(0x440, 0x08000249);
        VIASETREG(0x440, 0x0a0002c9);
        VIASETREG(0x440, 0x0b0002fb);
        VIASETREG(0x440, 0x0c000000);
        VIASETREG(0x440, 0x0d0002cb);
        VIASETREG(0x440, 0x0e000009);
        VIASETREG(0x440, 0x10000049);
        VIASETREG(0x440, 0x110002ff);
        VIASETREG(0x440, 0x12000008);
        VIASETREG(0x440, 0x130002db);
    }
#endif /* CS_FLAG_NO_3D_SCAL */
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIAInitialize3DEngine exit\n"));

    b3DRegsInitialized = 1;
}

/*
 * This function is only required if we need to do anything related to power
 * managemant and via private event handling.
 */
static Bool
VIAPMEvent(int scrnIndex, pmEvent event, Bool undo)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);

    xf86DrvMsg(X_INFO, pScrn->scrnIndex, "enter pm event\n");
    ErrorF("VIAPMEvent: received APM event %d\n", event);

    switch (event) {
    case XF86_APM_SYS_SUSPEND:
    case XF86_APM_CRITICAL_SUSPEND:   /*do we want to delay a critical suspend? */
    case XF86_APM_USER_SUSPEND:
    case XF86_APM_SYS_STANDBY:
    case XF86_APM_USER_STANDBY:
        if (!undo && !pVia->IsSuspending) {
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0)) 
            pScrn->LeaveVT(scrnIndex, 0);
#else
			pScrn->LeaveVT(pScrn);
#endif
            pVia->IsSuspending = TRUE;
            sleep(50);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
        } else if (undo && pVia->IsSuspending) {
            sleep(1);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
            pVia->IsSuspending = FALSE;
        }
        break;
    case XF86_APM_STANDBY_RESUME:
    case XF86_APM_NORMAL_RESUME:
    case XF86_APM_CRITICAL_RESUME:
        if (pVia->IsSuspending) {
            sleep(1);
#if !(XORG_VERSION_CURRENT >= XORG_VERSION_NUMERIC(1,12,99,0,0))
            pScrn->EnterVT(scrnIndex, 0);
#else
			pScrn->EnterVT(pScrn);
#endif
            pVia->IsSuspending = FALSE;
        }
        break;
    case XF86_APM_CAPABILITY_CHANGED:
        if (pVia->IsSecondary)
            return TRUE;
    default:
        ErrorF("VIAPMEvent: received APM event %d\n", event);
        return TRUE;
    }
    return TRUE;
}

#ifdef VIA_RANDR12_SUPPORT
void
viaInitHwDisplayCaps(VIAPtr pVia)
{
    /*Get graphic chip display caps */
    switch (pVia->Chipset) {
    case VIA_CX700:               /* VT3324 */
        pVia->GfxDispCaps =
            INTERNAL_LVDS | INTERNAL_TMDS | INTERNAL_TVEncoder;
        break;
    case VIA_VX800:               /* VT3353 */
        pVia->GfxDispCaps = INTERNAL_LVDS | INTERNAL_TMDS;
        break;
    case VIA_VX855:               /* VT3409 */
        pVia->GfxDispCaps = INTERNAL_LVDS;
        break;
    case VIA_VX900:               /* VT3410 */
        pVia->GfxDispCaps = INTERNAL_LVDS | INTERNAL_HDMI | INTERNAL_DP;
        /* Add graphic chip IGA scaling caps getting. */
        g_ChipCaps =
            CAPS_IGA1_DOWNSCALING | CAPS_IGA1_EXPAND | CAPS_IGA2_DOWNSCALING;
        break;
    default:
        break;
    }
    return;
}

void
viaCheckMbStrapping(VIAPtr pVia)
{
    unsigned char sr12Date = 0;

    sr12Date = viaReadVgaIo(REG_SR12);

    pVia->MbDiPortUsedInfo = 0;

    switch (pVia->Chipset) {
    case VIA_CX700:
    case VIA_VX800:
        /* First, remove the DFP port support */
        /*Note that the port is used, in fact no such port */
        pVia->MbDiPortUsedInfo |= DISP_DI_DFP;

        if (MB_DVP0_ENABLE & sr12Date) {
            /*Enable the ports */
            pVia->MbDiPortUsedInfo &= ~(DISP_DI_DVP0);
            /* IF SR12[6]=1, board supported all devices defualt */
            pVia->MbDvp0Device =
            DISP_DEV_CRT | DISP_DEV_TV | DISP_DEV_DVI | DISP_DEV_LCD;
        } else {
            /*Note that the port is used, in fact no such port */
            pVia->MbDiPortUsedInfo |= DISP_DI_DVP0;
            pVia->MbDvp0Device = DISP_DEV_NONE;
        }
        break;

    case VIA_VX855:
    case VIA_VX900:
        /* Remove one 24-bit DFP port support,
         * VT3409 doesn't support DVP0,
         * VT3409 only support LVDS0, so DFP_HIGH can't be used */
        pVia->MbDiPortUsedInfo |= DISP_DI_DFP | DISP_DI_DVP0 | DISP_DI_DFPH;
        break;

    case VIA_P4M800PRO:
    case VIA_P4M890:
    case VIA_P4M900:
    case VIA_K8M890:
    default:
        /*BIT4 is "1", DFP is one 24bit DFP port, so no DFPH/DFPL */
        if (MB_DFP_24BIT & sr12Date) {
            /*Note that the port is used, in fact no such port */
            pVia->MbDiPortUsedInfo |= DISP_DI_DFPH | DISP_DI_DFPL;
            /* two 12 bit port, no DFP port */
        } else {
            /*Note that the port is used, in fact no such port */
            pVia->MbDiPortUsedInfo |= DISP_DI_DFP;
        }

        /* After test, DVP0 support crt,lcd,dvi whatever the value SR12[5] is */
        pVia->MbDiPortUsedInfo &= ~DISP_DI_DVP0;
        pVia->MbDvp0Device = DISP_DEV_CRT | DISP_DEV_DVI | DISP_DEV_LCD;

        /* DVP0 support tv only when SR12[5]=1 */
        if (MB_DVP0_TV & sr12Date) {
            pVia->MbDvp0Device |= DISP_DEV_TV;
        }
        break;
    }

    return;
}

Bool
viaInitHwInfo(VIAPtr pVia)
{
    /*1. Get graphic chip display caps */
    viaInitHwDisplayCaps(pVia);

    /*2. Get the MB HW straping info */
    viaCheckMbStrapping(pVia);

    return TRUE;
}

/*
    Function Name:  LoadFixedCrtcRegs
    Description: Load fixed CRTC timing registers
*/
static void
LoadFixedCrtcRegs(void)
{
    viaUnlockCrtc();

    viaWriteVgaIoBits(REG_CR03, 0x80, BIT7);    /* always set to 1 */
    viaWriteVgaIo(REG_CR18, 0xFF);     /* line compare should set all bits = 1 (extend modes) */
    viaWriteVgaIoBits(REG_CR07, 0x10, BIT4);
    viaWriteVgaIoBits(REG_CR09, 0x40, 0xFF);
    viaWriteVgaIoBits(REG_CR35, 0x10, BIT4);
    viaWriteVgaIoBits(REG_CR33, 0x05, BIT0 + BIT1 + BIT2);
    viaWriteVgaIo(REG_CR17, 0xE3);     /* extend mode always set to e3h */
    viaWriteVgaIo(REG_CR08, 0x00);     /* extend mode always set to 0h */
    viaWriteVgaIo(REG_CR14, 0x00);     /* extend mode always set to 0h */

    viaLockCrtc();
}

/*
    Function Name:  LoadFixedCrtcRegs
    Description: Init TD timing register (power sequence)
*/
static void
InitTdTimingRegs(VIAPtr pVia)
{
    unsigned int TdTimer[PANEL_TD_TIMING_AMOUNT];
    unsigned int i;

    /* Calculate TD Timer, every step is 572.1uSec */
    TdTimer[0] = PanelTdTimer.tdTimer0 * 10000 / 5721;
    TdTimer[1] = PanelTdTimer.tdTimer1 * 10000 / 5721;
    TdTimer[2] = PanelTdTimer.tdTimer2 * 10000 / 5721;
    TdTimer[3] = PanelTdTimer.tdTimer3 * 10000 / 5721;

    /* Fill primary power sequence */
    for (i = 0; i < PANEL_TD_TIMING_AMOUNT; i++) {
        viaLoadRegs(TdTimer[i], PANEL_TD_TIMING_REG_AMOUNT,
            TdTimerRegs[i].tdRegs);
    }

    /*Note: VT3293, VT3324, VT3353 have two hardware power sequences
     * other chips only have one hardware power sequence */
    switch (pVia->Chipset) {
    case VIA_CX700:
    case VIA_VX800:
        /* set CRD4[0] to "1" to select 2nd LCD power sequence. */
        viaWriteVgaIoBits(REG_CRD4, 0x01, 0x01);

        /* Fill secondary power sequence */
        for (i = 0; i < PANEL_TD_TIMING_AMOUNT; i++) {
            viaLoadRegs(TdTimer[i], PANEL_TD_TIMING_REG_AMOUNT,
            TdTimerRegs[i].tdRegs);
        }
        break;
    default:
        break;
    }
}

void
viaInitDispEngine(VIAPtr pVia)
{
    /*1. Write Common Setting for Video Mode */
    switch (pVia->Chipset) {
    case VIA_P4M800PRO:
    case VIA_K8M890:
    case VIA_P4M890:
    case VIA_P4M900:
        viaWriteVgaIoMultiBits(InitialRegTable_CN700,
            NUM_TOTAL_CN700_INIT_REG_TBL);
        break;
    case VIA_CX700:
    case VIA_VX800:
        viaWriteVgaIoMultiBits(InitialRegTable_CX700,
            NUM_TOTAL_CX700_INIT_REG_TBL);
        break;
    case VIA_VX855:
        viaWriteVgaIoMultiBits(InitialRegTable_VX855,
            NUM_TOTAL_VX855_INIT_REG_TBL);
        break;
    case VIA_VX900:
        viaWriteVgaIoMultiBits(InitialRegTable_VX900,
            NUM_TOTAL_VX900_INIT_REG_TBL);
        break;
    }

    /*2. load fixed CRTC timing registers */
    LoadFixedCrtcRegs();

    /*3. Init TD timing register (power sequence) */
    InitTdTimingRegs(pVia);

    /*4. I/O address bit to be 1 */
    /*Enables access to frame buffer at A0000-BFFFFh */
    viaWriteMiscIo(viaReadMiscIo() | 0x01);

}

/* Set register CRD2 according to internal device setting */
static void
setChannel4InternalDev(VIAPtr pVia)
{
    if (pVia->numOfEmbDvi == 0 && pVia->numOfEmbLcd == 0)
        return;

    /*One Dual LVDS Channel (High Resolution Pannel) */
    if (pVia->dualChannelEmbLcdExist) {
        viaWriteVgaIoBits(REG_CRD2, BIT5, BIT4 + BIT5);
    } else if (pVia->numOfEmbDvi && pVia->numOfEmbLcd) {
        /*One single channel LVDS and one single channel TMDS */
        viaWriteVgaIoBits(REG_CRD2, BIT4, BIT4 + BIT5);
    } else if (pVia->numOfEmbDvi && !pVia->numOfEmbLcd) {
        /*Single Channel TMDS */
        viaWriteVgaIoBits(REG_CRD2, BIT4 + BIT5, BIT4 + BIT5);
    } else {
        /*LVDS1 Channel + LVDS2 Channel */
        viaWriteVgaIoBits(REG_CRD2, 0x00, BIT4 + BIT5);
    }
}

void
viaInitOutputRegSet(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    int i = 0;

    setChannel4InternalDev(pVia);

    for (i = 0; i < xf86_config->num_output; i++) {
        if ((!xf86NameCmp(xf86_config->output[i]->name, "LCD")) ||
            (!xf86NameCmp(xf86_config->output[i]->name, "LCD-2"))) {
            ViaLcdPrivateInfoPtr viaLcdInfo =
                xf86_config->output[i]->driver_private;
            /*Init subchip */
            initLVDS(viaLcdInfo);
        }
    }
}
#endif

void
VIASetChipsetRevisionID(VIAPtr pVia)
{
    CARD32 chipsetID;
    CARD32 revID;

    switch (pVia->Chipset) {
    case VIA_P4M800PRO:
        chipsetID = 0x000314;
        break;
    case VIA_CX700:
        chipsetID = 0x000324;
        break;
    case VIA_K8M890:
        chipsetID = 0x000336;
        break;
    case VIA_P4M890:
        chipsetID = 0x000327;
        break;
    case VIA_P4M900:
        chipsetID = 0x000364;
        break;
    case VIA_VX800:
        chipsetID = 0x000353;
        break;
    case VIA_VX855:
        chipsetID = 0x000409;
        break;
    case VIA_VX900:
        chipsetID = 0x000410;
        break;
#ifdef VIA_VT3293_SUPPORT
    case VIA_CN750:
        chipsetID = 0x293;
        break;
#endif
    default:
        ErrorF("Unknown chipset! \n");
        return;
    }

    VGAOUT8(0x3C4, 0x3B);
    revID = VGAIN8(0x3C5) & 0xff;

    g_ChipsetRevisionID = (chipsetID << 8) | revID;
}

CARD32
VIAGetChipsetRevisionID(void)
{
    return g_ChipsetRevisionID;
}
