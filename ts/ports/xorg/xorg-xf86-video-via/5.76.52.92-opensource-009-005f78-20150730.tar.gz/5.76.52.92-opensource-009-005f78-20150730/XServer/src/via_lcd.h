/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_LCD_H_
#define _VIA_LCD_H_ 1

#define LCD_POWER_SEQUENCE_TD0  200
#define LCD_POWER_SEQUENCE_TD1  25
#define LCD_POWER_SEQUENCE_TD2  0
#define LCD_POWER_SEQUENCE_TD3  250

typedef struct _LcdPanelMatrix
{
    CARD32 PanelSizeIndex;
    CARD32 Width;
    CARD32 Height;
} LcdPanelMatrix, *LcdPanelMatrixPtr;

static LcdPanelMatrix ViaSupportPanel[] = {
    /*PanelSizeIndex,             Width,            Height */
    {VIA_480X640, 480, 640},
    {VIA_640X480, 640, 480},
    {VIA_800X480, 800, 480},
    {VIA_800X600, 800, 600},
    {VIA_1024X600, 1024, 600},
    {VIA_1024X768, 1024, 768},
    {VIA_1280X768, 1280, 768},
    {VIA_1280X800, 1280, 800},
    {VIA_1280X1024, 1280, 1024},
    {VIA_1360X768, 1360, 768},
    {VIA_1366X768, 1366, 768},
    {VIA_1400X1050, 1400, 1050},
    {VIA_1440X900, 1440, 900},
    {VIA_1600X1200, 1600, 1200},
    {VIA_1920X1080, 1920, 1080},
};

#define NUM_SUPPORT_PANEL ARRAY_SIZE(ViaSupportPanel)

/* location: {CR9F,0,1},{CR77,0,7},{CR79,4,5} */
#define LCD_HOR_SCALING_FACTOR_REG_NUM      3
/* location: {CR79,3,3},{CR78,0,7},{CR79,6,7} */
#define LCD_VER_SCALING_FACTOR_REG_NUM      3

/* LCD Scaling factor                  */
/* x: indicate setting horizontal size */
/* y: indicate panel horizontal size   */
/* Horizontal scaling factor 10 bits (2^12) */
#define K800_LCD_HOR_SCF_FORMULA(x,y)       (((x-1)*4096)/(y-1))
/* Vertical scaling factor 10 bits (2^11)   */
#define K800_LCD_VER_SCF_FORMULA(x,y)       (((x-1)*2048)/(y-1))

/* LCD Scaling Factor */
struct _lcd_hor_scaling_factor
{
    int reg_num;
    struct io_register reg[LCD_HOR_SCALING_FACTOR_REG_NUM];
};

struct _lcd_ver_scaling_factor
{
    int reg_num;
    struct io_register reg[LCD_VER_SCALING_FACTOR_REG_NUM];
};

struct _lcd_scaling_factor
{
    struct _lcd_hor_scaling_factor lcd_hor_scaling_factor;
    struct _lcd_ver_scaling_factor lcd_ver_scaling_factor;
};

Bool VIASetLCDPanelInfo(VIABIOSInfoPtr pBIOSInfo, int panel_id);
Bool VIAIsPanelSizeValid(CARD32 width, CARD32 height);

#endif /* _VIA_LCD_H_ */
