/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include "via_driver.h"
#include "via_lcd.h"
#include "hw.h"
#include "via_modedata.h"

Bool
VIAIsPanelSizeValid(CARD32 width, CARD32 height)
{
    int i;

    for (i = 0; i < NUM_SUPPORT_PANEL; i++) {
        if ((ViaSupportPanel[i].Width == width) &&
            (ViaSupportPanel[i].Height == height))
            return TRUE;
        else
            continue;
    }
    return FALSE;
}

/*
    Set LCD Panel Info according to Panel ID.
*/
Bool
VIASetLCDPanelInfo(VIABIOSInfoPtr pBIOSInfo, int panel_id)
{
    switch (panel_id) {
    case 0x0:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_640X480;
        break;
    case 0x1:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_800X600;
        break;
    case 0x2:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1024X768;
        break;
    case 0x3:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X768;
        break;
    case 0x4:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X1024;
        break;
    case 0x5:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1400X1050;
        break;
    case 0x6:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1440X900;
        break;
    case 0x7:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X800;
        break;
    case 0x8:                /*For Quanta */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_800X480;
        break;
    case 0x9:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1024X600;
        break;
    case 0xA:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1366X768;
        break;
    case 0xB:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1600X1200;
        break;
    case 0xC:               /* Need to be fixed to 1680x1050 */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X768;
        break;
    case 0xD:               /* Need to be fixed to 1920x1200 */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X1024;
        break;
    case 0xE:               /* Need to be fixed to 640x240 */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1600X1200;
        break;
    case 0xF:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_480X640;
        break;
    case 0x10:              /*For Panasonic 1280x768 18bit Dual-Channel Panel */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1280X768;
        break;
    case 0x11:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1360X768;
        break;
    case 0x12:
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_1024X768;
        break;
    case 0x13:               /*General 8x4 panel use this setting */
        pBIOSInfo->LVDSSettingInfo.PanelSizeID = VIA_800X480_GEN;
        break;
    default:
        return FALSE;
    }
    return TRUE;

}
