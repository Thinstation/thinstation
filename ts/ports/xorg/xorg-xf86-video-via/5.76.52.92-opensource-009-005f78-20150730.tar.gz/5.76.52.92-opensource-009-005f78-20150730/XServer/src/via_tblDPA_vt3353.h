/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_TBLDPA_VT3353_H_
#define _VIA_TBLDPA_VT3353_H_ 1

/****************************************************************************/
/* The following DPA setting is for LVDS and TMDS: */
/****************************************************************************/

/***************************************************************************/
/*                                   VT3353 DPA Setting                    */
/***************************************************************************/

    /* DVP0,   DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
static GFX_DPA_VALUE VT3353_DEFAULT_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x00, 0x00,    0x00,    0x00,    0x00,    0x00, 0x00, 0x00, 0x00}
};

static GFX_DPA_VALUE VT3353_CLK_50_70M_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x00, 0x00,    0x00,    0x00,    0x00,    0x09, 0x00, 0x00, 0x00}
};

static GFX_DPA_VALUE VT3353_CLK_100_150M_DPA[] = {
    /* CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99 */
    {  0x00, 0x00,    0x00,    0x00,    0x00,    0x09, 0x00, 0x00, 0x00}
};

static GFX_DPA_INFO_TABLE GFX_DPA_VT3353_VT1636[] = {
    {DPA_CLK_RANGE_30M, VT3353_DEFAULT_DPA},
    {DPA_CLK_RANGE_30_50M, VT3353_DEFAULT_DPA},
    {DPA_CLK_RANGE_50_70M, VT3353_CLK_50_70M_DPA},
    {DPA_CLK_RANGE_70_100M, VT3353_DEFAULT_DPA},
    {DPA_CLK_RANGE_100_150M, VT3353_CLK_100_150M_DPA},
    {DPA_CLK_RANGE_150M, VT3353_DEFAULT_DPA}
};

/* The following DPA setting is for TV: */

/****************************************************************************/
/*                              Gfx DPA Settings Table                      */
/****************************************************************************/

static GFX_DPA_VALUE VT1625_DEFAULT_GFX_DPA_VT3353[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x00, 0x00,    0x00,    0x00,    0x00,    0x0A, 0x00, 0x00, 0x00}
};

static GFX_DPA_VALUE VT1625_1080I_1024x768_VN_GFX_DPA_VT3353[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x00, 0x00,    0x00,    0x00,    0x00,    0x0F, 0x00, 0x00, 0x00}
};

static GFX_DPA_VALUE VT1625_720P_1024x768_VN_GFX_DPA_VT3353[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x00, 0x00,    0x00,    0x00,    0x00,    0x0F, 0x00, 0x00, 0x00}
};

static GFX_DPA_VALUE VT1625_1080I_1920x1080_VN_GFX_DPA_VT3353[] = {
/*   DVP0, DVP0DataDriving,  DVP0ClockDriving, DVP1, DVP1Driving, DFPHigh, DFPLow */
/*   CR96, SR2A[5], SR1B[1], SR2A[4], SR1E[2], CR9B, SR65, CR97, CR99   */
    {0x00, 0x00,    0x00,    0x00,    0x00,    0x0D, 0x00, 0x00, 0x00}
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_640X480_VT3353[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_720X480_VT3353[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* NTSC  */
	{NULL, NULL, NULL},	       /* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 480P  */
	{NULL, NULL, NULL},	       /* 476P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_720X576_VT3353[] = {
    /* Normal Scan,                  FitScan,                       OverScan                                  */
    {{NULL, NULL, NULL},	       /* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* PAL   */
	{NULL, NULL, NULL},	       /* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_800x600_VT3353[] = {
    /* Normal Scan,                           FitScan,                       OverScan                                  */
    {{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL},	/* 720P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1024X768_VT3353[] = {
    /* Normal Scan,                            FitScan,                       OverScan                                           */
    {{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* NTSC  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* PAL   */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 480P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353, VT1625_DEFAULT_GFX_DPA_VT3353},	/* 576P  */
	{VT1625_720P_1024x768_VN_GFX_DPA_VT3353, NULL, NULL},	/* 720P  */
	{VT1625_1080I_1024x768_VN_GFX_DPA_VT3353, NULL, NULL}}	/* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1280X720_VT3353[] = {
    /* Normal Scan,               FitScan, OverScan            */
    {{NULL,                         NULL, NULL},	   /* NTSC  */
	{NULL,                          NULL, NULL},	   /* PAL   */
	{NULL,                          NULL, NULL},	   /* 480P  */
	{NULL,                          NULL, NULL},	   /* 576P  */
	{VT1625_DEFAULT_GFX_DPA_VT3353, NULL, NULL},	   /* 720P  */
	{NULL,                          NULL, NULL}}	   /* 1080I */
};

static GFX_DPA_TVTYPE_MAP_TABLE VT1625_GFX_DPA_1920X1080_VT3353[] = {
    /* Normal Scan,                          FitScan, OverScan            */
    {{NULL,                                    NULL, NULL},	     /* NTSC  */
	{NULL,                                     NULL, NULL},	     /* PAL   */
	{NULL,                                     NULL, NULL},	     /* 480P  */
	{NULL,                                     NULL, NULL},	     /* 576P  */
	{NULL,                                     NULL, NULL},	     /* 720P  */
	{VT1625_1080I_1920x1080_VN_GFX_DPA_VT3353, NULL, NULL}}	     /* 1080I */
};

/***************************************************************************/
/*           DPA Settings Table Mapping by Mode                            */
/***************************************************************************/

static TV_DPA_TABLE GFX_DPA_TABLE_VT3353_VT1625[] = {
    /* ModeIndex          GFX DPA Table                    VT1625 DPA Patch Table */
    {VIA_640X480,   VT1625_GFX_DPA_640X480_VT3353,   NULL},
    {VIA_720X480,   VT1625_GFX_DPA_720X480_VT3353,   NULL},
    {VIA_720X576,   VT1625_GFX_DPA_720X576_VT3353,   NULL},
    {VIA_800X600,   VT1625_GFX_DPA_800x600_VT3353,   NULL},
    {VIA_1024X768,  VT1625_GFX_DPA_1024X768_VT3353,  NULL},
    {VIA_1280X720,  VT1625_GFX_DPA_1280X720_VT3353,  NULL},
    {VIA_1920X1080, VT1625_GFX_DPA_1920X1080_VT3353, NULL},
    {VIA_INVALID, NULL, NULL}	       /* End of table. */
};

#endif
