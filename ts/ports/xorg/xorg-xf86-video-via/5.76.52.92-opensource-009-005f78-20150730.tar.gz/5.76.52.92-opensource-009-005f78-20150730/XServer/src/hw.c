/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*************************************************************************
 *
 *  File:       hw.c
 *  Content:    migration from frame buffer device driver's function.
 *
 ************************************************************************/
#include <math.h>
#include "via_driver.h"
#include "hw.h"
#include "drm.h"
#include "via_pll.h"
#include "via_disp_reg.h"
#include "via_dp.h"

/* Access I/O Function */
extern _X_EXPORT __inline__ void write_reg(CARD8, CARD16, CARD8);
extern _X_EXPORT void write_reg_mask(CARD8, int, CARD8, CARD8);
extern _X_EXPORT __inline__ CARD8 read_reg(int, CARD8);
int SearchModeSetting(int);
extern _X_EXPORT void EnableSecondDisplayChannel();
void DisableSecondDisplayChannel();

__inline__ void
write_reg(CARD8 index, CARD16 io_port, CARD8 data)
{
    MMIO_OUT8(MMIOMapBase, io_port, index);
    MMIO_OUT8(MMIOMapBase, io_port + 1, data);
    DEBUG(ErrorF("Index=0x%2X, Value=0x%2X\n", index, data));
}

void
write_reg_mask(CARD8 index, int io_port, CARD8 data, CARD8 mask)
{
    CARD8 tmp;

    MMIO_OUT8(MMIOMapBase, io_port, index);
    tmp = MMIO_IN8(MMIOMapBase, io_port + 1);
    MMIO_OUT8(MMIOMapBase, io_port + 1, (data & mask) | (tmp & (~mask)));
    DEBUG(ErrorF("Index=0x%2X, Value=0x%2X\n",
            index, ((data & mask) | (tmp & (~mask)))));
}

__inline__ CARD8
read_reg(int io_port, CARD8 index)
{
    MMIO_OUT8(MMIOMapBase, io_port, index);
    return(MMIO_IN8(MMIOMapBase, io_port + 1));
}

/* Search Mode Index */
int
SearchModeSetting(int ModeInfoIndex)
{
    int i = 0;

    while ((i < NUM_TOTAL_MODETABLE) &&
           (ModeInfoIndex != VIARoutineModes[i].ModeIndex)) {
        i++;
    }
    if ((i >= NUM_TOTAL_MODETABLE))
        i = 0;
    return i;

}

void
EnableSecondDisplayChannel()
{
    /* It's better to use the following sequence */
    /* to enable second display channel. */
    write_reg_mask(CR6A, VIACR, BIT7, BIT7);
}

void
DisableSecondDisplayChannel()
{
    /* It's better to use the following sequence */
    /* to disable second display channel. */
    write_reg_mask(CR6A, VIACR, 0x00, BIT7);
}

