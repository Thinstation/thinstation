/* config_via.h.  Generated from config_via.h.in by configure.  */
/* config_via.h.in.  Generated from configure.ac by autoheader.  */

#ifndef _CONFIG_VIA_H_

#define _CONFIG_VIA_H_

#include "xorg-server.h"

/* Enable debug output */
/* #undef DEBUG_PRINT */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* libudev support */
#define HAVE_LIBUDEV 1

/* libudev new version support */
#define HAVE_LIBUDEV_NEW 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* old version libudev support */
/* #undef LIBUDEV_I_KNOW_THE_API_IS_SUBJECT_TO_CHANGE */

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "xf86-video-via"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "http://www.viatech.com.tw"

/* Define to the full name of this package. */
#define PACKAGE_NAME "xf86-video-via"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "xf86-video-via 5.76.52.92"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "xf86-video-via"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "5.76.52.92"

/* Major version of this package */
#define PACKAGE_VERSION_MAJOR 5

/* Minor version of this package */
#define PACKAGE_VERSION_MINOR 76

/* Patch version of this package */
#define PACKAGE_VERSION_PATCHLEVEL 52

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Support PC98 */
#define SUPPORT_PC98 1

/* Version number of package */
#define VERSION "5.76.52.92"

/* Build support for Exa */
#define VIA_HAVE_EXA 1

/* Build support for Uxa */
#define VIA_HAVE_UXA 1

/* Addtional subversion build string */
#define VIA_SUBVERSION "v92-005f78-20150730"

/* Build support for Uxa with greedy policy */
#define VIA_UXA_GREEDY 1

/* Build support for VT3293 */
#define VIA_VT3293_SUPPORT 1

/* Enable DRI driver support */
#define XF86DRI 1

/* Enable Xv debug output */
/* #undef XV_DEBUG */

/* Have XAACopyRop function */
#define X_HAVE_XAAGETROP 1

/* TTM file biger than 4G */
#define _FILE_OFFSET_BITS 64

#endif
