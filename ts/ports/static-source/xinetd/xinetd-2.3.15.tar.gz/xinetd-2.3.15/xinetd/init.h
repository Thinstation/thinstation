#ifndef INIT_H
#define INIT_H


void init_daemon(int argc,char *argv[]);
void init_services(void);


#endif
