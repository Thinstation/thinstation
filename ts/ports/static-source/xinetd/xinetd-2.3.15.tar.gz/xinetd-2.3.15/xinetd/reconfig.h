#ifndef RECONFIG_H
#define RECONFIG_H

#include "defs.h"

void hard_reconfig(void);
void terminate_servers(struct service *sp);

#endif
