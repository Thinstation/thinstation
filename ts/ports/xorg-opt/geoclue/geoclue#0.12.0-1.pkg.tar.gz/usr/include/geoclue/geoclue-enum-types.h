


#ifndef __GEOCLUE_ENUM_TYPES_H__
#define __GEOCLUE_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS
/* enumerations from "geoclue-error.h" */
GType geoclue_error_get_type (void);
#define GEOCLUE_TYPE_ERROR (geoclue_error_get_type())
G_END_DECLS

#endif /* __GEOCLUE_ENUM_TYPES_H__ */



