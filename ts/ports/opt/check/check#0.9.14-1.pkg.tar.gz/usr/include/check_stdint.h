#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.9.14"
/* generated using gnu compiler gcc (Thinstation) 4.8.3 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
