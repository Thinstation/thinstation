


#ifndef __GST_VIDEO_ENUM_TYPES_H__
#define __GST_VIDEO_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "video.h" */
GType gst_video_format_get_type (void);
#define GST_TYPE_VIDEO_FORMAT (gst_video_format_get_type())
G_END_DECLS

#endif /* __GST_VIDEO_ENUM_TYPES_H__ */



